package in.gov.gem.app.incident.domain.dto;
import lombok.Getter; import lombok.Setter;
import java.util.Date;
@Getter @Setter
public class DebarmentDetailDTO {
  private String debarmentClauseLookup;
  private Date debarmentStartDate;
  private Date debarmentEndDate;
  private String competentAuthorityName;
  private String competentAuthorityDesignation;
}
