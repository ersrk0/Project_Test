package in.gov.gem.app.incident.service;
import in.gov.gem.app.incident.domain.entity.IncidentStatusLogEntity;
public interface IIncidentStatusLogService {
  IncidentStatusLogEntity save(IncidentStatusLogEntity entity);
  IncidentStatusLogEntity findLatestByIncidentMasterFk(Long masterFk);
}
