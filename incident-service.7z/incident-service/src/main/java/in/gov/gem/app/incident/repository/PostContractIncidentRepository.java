package in.gov.gem.app.incident.repository;
import in.gov.gem.app.incident.domain.entity.PostContractIncidentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PostContractIncidentRepository extends JpaRepository<PostContractIncidentEntity, Long> {
  PostContractIncidentEntity findByIncidentMasterFk(Long incidentMasterFk);
}
