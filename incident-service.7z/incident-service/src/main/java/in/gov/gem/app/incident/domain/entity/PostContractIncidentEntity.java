package in.gov.gem.app.incident.domain.entity;
import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity @Table(name="post_contract_incident", schema="incident_mgmt")
public class PostContractIncidentEntity extends BaseEntity {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
  @Column(name="id", updatable=false, nullable=false)
  private Long id;

  @Column(name="incident_master_fk", nullable=false)
  private Long incidentMasterFk;

  @Column(name="auction_id") private String auctionId;
  @Column(name="bid_id") private String bidId;
  @Column(name="contract_no") private String contractNo;
  @Column(name="invoice_id") private String invoiceId;
  @Column(name="trader_id") private String traderId;
  @Column(name="pan_no") private String panNo;
  @Column(name="is_debarred") private Boolean isDebarred;
}
