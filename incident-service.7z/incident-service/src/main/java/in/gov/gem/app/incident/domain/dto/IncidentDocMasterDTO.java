package in.gov.gem.app.incident.domain.dto;
import lombok.Getter; import lombok.Setter;
@Getter @Setter
public class IncidentDocMasterDTO {
  private java.util.UUID docId;
  private Long incidentAttachmentFk;
}
