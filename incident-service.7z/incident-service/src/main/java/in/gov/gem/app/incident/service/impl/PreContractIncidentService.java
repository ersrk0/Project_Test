package in.gov.gem.app.incident.service.impl;
import in.gov.gem.app.incident.domain.entity.PreContractIncidentEntity;
import in.gov.gem.app.incident.repository.PreContractIncidentRepository;
import in.gov.gem.app.incident.service.IPreContractIncidentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
@Service @RequiredArgsConstructor
public class PreContractIncidentService implements IPreContractIncidentService {
  private final PreContractIncidentRepository repository;
  public PreContractIncidentEntity save(PreContractIncidentEntity e){ return repository.save(e); }
  public PreContractIncidentEntity findByIncidentMasterFk(Long fk){ return repository.findByIncidentMasterFk(fk); }
}
