package in.gov.gem.app.incident.service;
import in.gov.gem.app.incident.domain.entity.IncidentMasterEntity;
import java.util.Optional;
import java.util.UUID;
public interface IIncidentMasterService {
  IncidentMasterEntity save(IncidentMasterEntity entity);
  Optional<IncidentMasterEntity> findByIncidentId(UUID incidentId);
}
