package in.gov.gem.app;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "in.gov.gem.app")
public class GemIncidentApplication {
  public static void main(String[] args) {
    SpringApplication.run(GemIncidentApplication.class, args);
  }
}
