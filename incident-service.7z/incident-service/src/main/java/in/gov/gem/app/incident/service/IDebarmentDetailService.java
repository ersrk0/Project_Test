package in.gov.gem.app.incident.service;
import in.gov.gem.app.incident.domain.entity.DebarmentDetailEntity;
public interface IDebarmentDetailService {
  DebarmentDetailEntity save(DebarmentDetailEntity entity);
  DebarmentDetailEntity findByPostContractIncidentFk(Long postFk);
}
