package in.gov.gem.app.incident.repository;
import in.gov.gem.app.incident.domain.entity.DebarmentDetailEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface DebarmentDetailRepository extends JpaRepository<DebarmentDetailEntity, Long> {
  DebarmentDetailEntity findByPostContractIncidentFk(Long postContractIncidentFk);
}
