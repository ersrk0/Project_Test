package in.gov.gem.app.incident.domain.dto;
import lombok.Getter; import lombok.Setter;
@Getter @Setter
public class PostContractIncidentDTO {
  private String auctionId;
  private String bidId;
  private String contractNo;
  private String invoiceId;
  private String traderId;
  private String panNo;
  private Boolean isDebarred;
}
