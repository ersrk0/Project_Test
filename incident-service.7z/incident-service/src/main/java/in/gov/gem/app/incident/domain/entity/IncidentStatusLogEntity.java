package in.gov.gem.app.incident.domain.entity;
import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import java.time.LocalDateTime;
import java.util.UUID;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@SuperBuilder
@Entity @Table(name="incident_status_log", schema="incident_mgmt")
public class IncidentStatusLogEntity extends BaseEntity {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
  @Column(name="id", updatable=false, nullable=false)
  private Long id;
  @Column(name="log_id") private UUID logId;
  @Column(name="post_contract_incident_fk") private Long postContractIncidentFk;
  @Column(name="incident_doc_master_fk") private Long incidentDocMasterFk;
  @Column(name="action_type_lookup") private String actionTypeLookup;
  @Column(name="previous_status_lookup") private String previousStatusLookup;
  @Column(name="current_status_lookup") private String currentStatusLookup;
  @Column(name="action_by_type_lookup") private String actionByTypeLookup;
  @Column(name="action_by_id") private String actionById;
  @Column(name="remarks") private String remarks;
  @Column(name="incident_master_fk", nullable=false) private Long incidentMasterFk;
  @Column(name="updated_at", insertable=false, updatable=false) private LocalDateTime updatedAt;
}
