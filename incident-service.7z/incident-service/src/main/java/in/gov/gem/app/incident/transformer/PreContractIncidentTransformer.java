package in.gov.gem.app.incident.transformer;
import in.gov.gem.app.incident.domain.dto.PreContractIncidentDTO;
import in.gov.gem.app.incident.domain.entity.PreContractIncidentEntity;
import org.springframework.stereotype.Component;
@Component
public class PreContractIncidentTransformer {
  public PreContractIncidentEntity toEntity(PreContractIncidentDTO d, Long masterPk){
    PreContractIncidentEntity e = new PreContractIncidentEntity();
    e.setIncidentMasterFk(masterPk);
    e.setTraderId(d.getTraderId());
    e.setCategoryCode(d.getCategoryCode());
    e.setProductId(d.getProductId());
    e.setCatalogId(d.getCatalogId());
    e.setCompId(d.getCompId());
    e.setSkuId(d.getSkuId());
    e.setBrandId(d.getBrandId());
    e.setServiceId(d.getServiceId());
    return e;
  }
  public PreContractIncidentDTO toDto(PreContractIncidentEntity e){
    PreContractIncidentDTO d = new PreContractIncidentDTO();
    d.setTraderId(e.getTraderId());
    d.setCategoryCode(e.getCategoryCode());
    d.setProductId(e.getProductId());
    d.setCatalogId(e.getCatalogId());
    d.setCompId(e.getCompId());
    d.setSkuId(e.getSkuId());
    d.setBrandId(e.getBrandId());
    d.setServiceId(e.getServiceId());
    return d;
  }
}
