package in.gov.gem.app.incident.service.impl;
import in.gov.gem.app.incident.domain.entity.IncidentDocMasterEntity;
import in.gov.gem.app.incident.repository.IncidentDocMasterRepository;
import in.gov.gem.app.incident.service.IIncidentDocMasterService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
@Service @RequiredArgsConstructor
public class IncidentDocMasterService implements IIncidentDocMasterService {
  private final IncidentDocMasterRepository repository;
  public IncidentDocMasterEntity save(IncidentDocMasterEntity e){ return repository.save(e); }
  public IncidentDocMasterEntity findByIncidentMasterFk(Long fk){ return repository.findByIncidentMasterFk(fk); }
}
