package in.gov.gem.app.incident.domain.dto;
import lombok.Getter; import lombok.Setter;
@Getter @Setter
public class IncidentMasterDTO {
  private String incidentTypeLookup;
  private String moduleCode;
  private String raisedById;
  private String raisedByRoleLookup;
  private String raisedAgainstTypeLookup;
  private String raisedAgainstRoleLookup;
  private String incidentReasonLookup;
  private String issueTypeLookup;
  private String incidentTitle;
  private String incidentDescription;
  private String statusLookup;
  private String severityLookup;
}
