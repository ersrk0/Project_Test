package in.gov.gem.app.incident.domain.dto;
import lombok.Builder; import lombok.Getter;
import java.util.UUID;
@Getter @Builder
public class SaveIncidentResponse {
  private UUID incidentId;
  private Long incidentMasterPk;
  private String status;
}
