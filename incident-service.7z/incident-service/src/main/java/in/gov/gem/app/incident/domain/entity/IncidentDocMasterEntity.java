package in.gov.gem.app.incident.domain.entity;
import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import java.util.UUID;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@SuperBuilder
@Entity @Table(name="incident_doc_master", schema="incident_mgmt")
public class IncidentDocMasterEntity extends BaseEntity {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
  @Column(name="id", updatable=false, nullable=false)
  private Long id;
  @Column(name="doc_id", nullable=false) private UUID docId;
  @Column(name="incident_master_fk", nullable=false) private Long incidentMasterFk;
  @Column(name="incident_attachment_fk") private Long incidentAttachmentFk;
}
