package in.gov.gem.app.incident.domain.entity;
import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@SuperBuilder
@Entity @Table(name="incident_attachment", schema="incident_mgmt")
public class IncidentAttachmentEntity extends BaseEntity {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
  @Column(name="id", updatable=false, nullable=false)
  private Long id;
  @Column(name="incident_doc_master_fk", nullable=false) private Long incidentDocMasterFk;
  @Column(name="file_name") private String fileName;
  @Column(name="file_type_lookup") private String fileTypeLookup;
  @Column(name="file_path") private String filePath;
  @Column(name="file_size") private java.math.BigInteger fileSize;
}
