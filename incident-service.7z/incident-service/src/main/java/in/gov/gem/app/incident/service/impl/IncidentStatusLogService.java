package in.gov.gem.app.incident.service.impl;
import in.gov.gem.app.incident.domain.entity.IncidentStatusLogEntity;
import in.gov.gem.app.incident.repository.IncidentStatusLogRepository;
import in.gov.gem.app.incident.service.IIncidentStatusLogService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
@Service @RequiredArgsConstructor
public class IncidentStatusLogService implements IIncidentStatusLogService {
  private final IncidentStatusLogRepository repository;
  public IncidentStatusLogEntity save(IncidentStatusLogEntity e){ return repository.save(e); }
  public IncidentStatusLogEntity findLatestByIncidentMasterFk(Long fk){ return repository.findTopByIncidentMasterFkOrderByIdDesc(fk); }
}
