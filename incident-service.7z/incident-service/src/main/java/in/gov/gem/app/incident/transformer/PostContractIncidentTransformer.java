package in.gov.gem.app.incident.transformer;
import in.gov.gem.app.incident.domain.dto.PostContractIncidentDTO;
import in.gov.gem.app.incident.domain.entity.PostContractIncidentEntity;
import org.springframework.stereotype.Component;
@Component
public class PostContractIncidentTransformer {
  public PostContractIncidentEntity toEntity(PostContractIncidentDTO d, Long masterPk){
    PostContractIncidentEntity e = new PostContractIncidentEntity();
    e.setIncidentMasterFk(masterPk);
    e.setAuctionId(d.getAuctionId());
    e.setBidId(d.getBidId());
    e.setContractNo(d.getContractNo());
    e.setInvoiceId(d.getInvoiceId());
    e.setTraderId(d.getTraderId());
    e.setPanNo(d.getPanNo());
    e.setIsDebarred(d.getIsDebarred());
    return e;
  }
  public PostContractIncidentDTO toDto(PostContractIncidentEntity e){
    PostContractIncidentDTO d = new PostContractIncidentDTO();
    d.setAuctionId(e.getAuctionId());
    d.setBidId(e.getBidId());
    d.setContractNo(e.getContractNo());
    d.setInvoiceId(e.getInvoiceId());
    d.setTraderId(e.getTraderId());
    d.setPanNo(e.getPanNo());
    d.setIsDebarred(e.getIsDebarred());
    return d;
  }
}
