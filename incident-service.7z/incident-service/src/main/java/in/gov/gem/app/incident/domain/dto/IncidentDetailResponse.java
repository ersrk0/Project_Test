package in.gov.gem.app.incident.domain.dto;
import lombok.Builder; import lombok.Getter;
import java.util.UUID;
@Getter @Builder
public class IncidentDetailResponse {
  private UUID incidentId;
  private IncidentMasterDTO master;
  private PreContractIncidentDTO preContract;
  private PostContractIncidentDTO postContract;
  private DebarmentDetailDTO debarment;
  private IncidentDocMasterDTO docMaster;
  private IncidentAttachmentDTO attachment;
  private IncidentStatusLogDTO statusLog;
}
