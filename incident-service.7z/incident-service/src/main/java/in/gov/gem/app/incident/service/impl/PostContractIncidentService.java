package in.gov.gem.app.incident.service.impl;
import in.gov.gem.app.incident.domain.entity.PostContractIncidentEntity;
import in.gov.gem.app.incident.repository.PostContractIncidentRepository;
import in.gov.gem.app.incident.service.IPostContractIncidentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
@Service @RequiredArgsConstructor
public class PostContractIncidentService implements IPostContractIncidentService {
  private final PostContractIncidentRepository repository;
  public PostContractIncidentEntity save(PostContractIncidentEntity e){ return repository.save(e); }
  public PostContractIncidentEntity findByIncidentMasterFk(Long fk){ return repository.findByIncidentMasterFk(fk); }
}
