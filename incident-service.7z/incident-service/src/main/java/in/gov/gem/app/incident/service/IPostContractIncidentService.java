package in.gov.gem.app.incident.service;
import in.gov.gem.app.incident.domain.entity.PostContractIncidentEntity;
public interface IPostContractIncidentService {
  PostContractIncidentEntity save(PostContractIncidentEntity entity);
  PostContractIncidentEntity findByIncidentMasterFk(Long masterFk);
}
