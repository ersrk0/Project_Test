package in.gov.gem.app.incident.controller.impl;
import in.gov.gem.app.incident.controller.IIncidentController;
import in.gov.gem.app.incident.domain.dto.*;
import in.gov.gem.app.incident.facade.IIncidentFacade;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
public class IncidentController implements IIncidentController {
  private final IIncidentFacade facade;
  public ResponseEntity<SaveIncidentResponse> save(SaveIncidentRequest request){ return ResponseEntity.ok(facade.saveIncident(request)); }
  public ResponseEntity<Resource> template(TemplateType type){ return facade.downloadTemplate(type); }
  public ResponseEntity<IncidentDetailResponse> getByIncidentId(UUID incidentId){ return ResponseEntity.ok(facade.getIncidentById(incidentId)); }
}
