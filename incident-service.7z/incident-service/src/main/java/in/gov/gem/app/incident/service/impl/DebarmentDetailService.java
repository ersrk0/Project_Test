package in.gov.gem.app.incident.service.impl;
import in.gov.gem.app.incident.domain.entity.DebarmentDetailEntity;
import in.gov.gem.app.incident.repository.DebarmentDetailRepository;
import in.gov.gem.app.incident.service.IDebarmentDetailService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
@Service @RequiredArgsConstructor
public class DebarmentDetailService implements IDebarmentDetailService {
  private final DebarmentDetailRepository repository;
  public DebarmentDetailEntity save(DebarmentDetailEntity e){ return repository.save(e); }
  public DebarmentDetailEntity findByPostContractIncidentFk(Long fk){ return repository.findByPostContractIncidentFk(fk); }
}
