package in.gov.gem.app.incident.repository;
import in.gov.gem.app.incident.domain.entity.IncidentStatusLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface IncidentStatusLogRepository extends JpaRepository<IncidentStatusLogEntity, Long> {
  IncidentStatusLogEntity findTopByIncidentMasterFkOrderByIdDesc(Long incidentMasterFk);
}
