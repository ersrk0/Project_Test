package in.gov.gem.app.incident.transformer;
import in.gov.gem.app.incident.domain.dto.IncidentStatusLogDTO;
import in.gov.gem.app.incident.domain.entity.IncidentStatusLogEntity;
import org.springframework.stereotype.Component;
import java.util.UUID;
@Component
public class IncidentStatusLogTransformer {
  public IncidentStatusLogEntity toEntity(IncidentStatusLogDTO d, Long masterPk){
    IncidentStatusLogEntity e = new IncidentStatusLogEntity();
    e.setLogId(UUID.randomUUID());
    e.setIncidentMasterFk(masterPk);
    e.setActionTypeLookup(d.getActionTypeLookup());
    e.setPreviousStatusLookup(d.getPreviousStatusLookup());
    e.setCurrentStatusLookup(d.getCurrentStatusLookup());
    e.setActionByTypeLookup(d.getActionByTypeLookup());
    e.setActionById(d.getActionById());
    e.setRemarks(d.getRemarks());
    return e;
  }
  public IncidentStatusLogDTO toDto(IncidentStatusLogEntity e){
    IncidentStatusLogDTO d = new IncidentStatusLogDTO();
    d.setActionTypeLookup(e.getActionTypeLookup());
    d.setPreviousStatusLookup(e.getPreviousStatusLookup());
    d.setCurrentStatusLookup(e.getCurrentStatusLookup());
    d.setActionByTypeLookup(e.getActionByTypeLookup());
    d.setActionById(e.getActionById());
    d.setRemarks(e.getRemarks());
    return d;
  }
}
