# Incident Service (Vendor-Style Core)
APIs:
- POST /incident/save
- GET  /incident/template?type=PRE_CONTRACT|POST_CONTRACT
- GET  /incident/{incidentId}

Run:
  mvn clean spring-boot:run
