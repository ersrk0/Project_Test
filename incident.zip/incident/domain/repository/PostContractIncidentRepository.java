package in.gov.gem.app.incident.domain.repository;


import in.gov.gem.app.incident.domain.entity.PostContractIncidentEntity;
import in.gov.gem.app.service.core.entity.BaseEntity;
import in.gov.gem.app.service.core.repository.BaseRepository;


import java.util.UUID;

public interface PostContractIncidentRepository extends BaseRepository<PostContractIncidentEntity, UUID> {
}

