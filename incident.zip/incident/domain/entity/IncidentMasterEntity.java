package in.gov.gem.app.incident.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.GenericGenerator;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
@Entity
@Table(name = "incident_master")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class IncidentMasterEntity extends BaseEntity {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "incident_pk", updatable = false, nullable = false)
    private UUID incidentPk;
    @Column(name = "incident_id", unique = true)
    private String incidentId;
    private String incidentTypeLookup;
    private String moduleCode;
    private String raisedByTypeLookup;
    private String raisedById;
    private String raisedByRoleLookup;
    private String raisedAgainstTypeLookup;
    private String raisedAgainstRoleLookup;
    private String incidentReasonLookup;
    private String issueTypeLookup;
    private String incidentTitle;
    private String incidentDescription;
    private String statusLookup;
    private String severityLookup;
    private LocalDateTime createdOn;
    private String createdBy;
    @OneToMany(mappedBy = "incidentPk", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PreContractIncidentEntity> preContractData;
    @OneToMany(mappedBy = "incidentPk", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PostContractIncidentEntity> postContractData;
    @OneToMany(mappedBy = "incidentPk", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<IncidentStatusLogEntity> incidentStatusLogData;
    @OneToMany(mappedBy = "incidentPk", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<IncidentDocMasterEntity> incidentDocMasterData;
}