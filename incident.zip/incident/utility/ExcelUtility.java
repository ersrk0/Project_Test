package in.gov.gem.app.incident.utility;

import in.gov.gem.app.incident.response.DocumentDownloadResponse;

import io.micrometer.core.instrument.MultiGauge;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.xssf.usermodel.XSSFDataValidationHelper;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.util.List;

@Slf4j
@Component
public class ExcelUtility {
    public DocumentDownloadResponse createIncidentTemplate(List<String> reasons, List<String> severities) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Incident Template");
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Reason");
            headerRow.createCell(1).setCellValue("Catalog_ID");
            headerRow.createCell(2).setCellValue("SKUID");
            headerRow.createCell(3).setCellValue("Severity");
            headerRow.createCell(4).setCellValue("Description");
            // Make headers bold
            CellStyle headerStyle = workbook.createCellStyle();
            Font font = workbook.createFont();
            font.setBold(true);
            headerStyle.setFont(font);
            for (int i = 0; i <= 4; i++) {
                headerRow.getCell(i).setCellStyle(headerStyle);
                sheet.setColumnWidth(i, 5000);
            }
            XSSFDataValidationHelper validationHelper = new XSSFDataValidationHelper((org.apache.poi.xssf.usermodel.XSSFSheet) sheet);
            // Reason dropdown validation (Column 0)
            String[] reasonArray = reasons.toArray(new String[0]);
            CellRangeAddressList reasonAddressList = new CellRangeAddressList(1, 100, 0, 0);
            DataValidationConstraint reasonConstraint = validationHelper.createExplicitListConstraint(reasonArray);
            DataValidation reasonValidation = validationHelper.createValidation(reasonConstraint, reasonAddressList);
            reasonValidation.setSuppressDropDownArrow(true);
            reasonValidation.setShowErrorBox(true);
            sheet.addValidationData(reasonValidation);
            // Severity dropdown validation (Column 3)
            String[] severityArray = severities.toArray(new String[0]);
            CellRangeAddressList severityAddressList = new CellRangeAddressList(1, 100, 3, 3);
            DataValidationConstraint severityConstraint = validationHelper.createExplicitListConstraint(severityArray);
            DataValidation severityValidation = validationHelper.createValidation(severityConstraint, severityAddressList);
            severityValidation.setSuppressDropDownArrow(true);
            severityValidation.setShowErrorBox(true);
            sheet.addValidationData(severityValidation);
            // Catalog_ID (Column 1) and SKUID (Column 2) left blank - user fills conditionally
            // Description (Column 4) free text - no validation
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            DocumentDownloadResponse response = new DocumentDownloadResponse();
            response.setByteArrayResource(new ByteArrayResource(outputStream.toByteArray()));
            return response;
        } catch (Exception e) {
            log.error("Error generating Excel template", e);
            throw new RuntimeException("Error generating Excel template", e);
        }
    }
}