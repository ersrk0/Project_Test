package in.gov.gem.app.incident.service.impl;

import in.gov.gem.app.incident.domain.entity.DebarmentDetailEntity;
import in.gov.gem.app.incident.domain.entity.PostContractIncidentEntity;
import in.gov.gem.app.incident.domain.entity.PreContractIncidentEntity;
import in.gov.gem.app.incident.domain.repository.DebarmentDetailRepository;
import in.gov.gem.app.incident.domain.repository.IncidentStatusLogRepository;
import in.gov.gem.app.incident.domain.repository.PostContractIncidentRepository;
import in.gov.gem.app.incident.domain.repository.PreContractIncidentRepository;
import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.service.IncidentService;
import in.gov.gem.app.incident.transformer.IncidentTransformer;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Slf4j
@Service
@Transactional
public class IncidentServiceImpl implements IncidentService {
    private PreContractIncidentRepository preContractIncidentRepository;
    private PostContractIncidentRepository postContractIncidentRepository;
    private DebarmentDetailRepository debarmentDetailRepository;
    private IncidentStatusLogRepository incidentStatusLogRepository;
    public void saveIncident(String acceptLanguage, IncidentRequestDTO dto) {
       // log.info("Saving incident data for incidentPk: {}", incidentPk);
        // ✅ Save Pre-Contract Data
        UUID incidentPk = UUID.randomUUID();
        if (dto.getPreContractData() != null && !dto.getPreContractData().isEmpty()) {
            List<PreContractIncidentEntity> preEntities =
                    IncidentTransformer.toPreContractEntities(dto.getPreContractData(),incidentPk);
            preContractIncidentRepository.saveAll(preEntities);
        }
        // ✅ Save Post-Contract Data
        if (dto.getPostContractData() != null && !dto.getPostContractData().isEmpty()) {
            List<PostContractIncidentEntity> postEntities =
                    IncidentTransformer.toPostContractEntities(dto.getPostContractData(),incidentPk);
            postContractIncidentRepository.saveAll(postEntities);
            // ✅ Save Debarment Details for each Post-Contract record
            dto.getPostContractData().forEach(postDto -> {
                if (postDto.getDebarmentDetail() != null && !postDto.getDebarmentDetail().isEmpty()) {
                    List<DebarmentDetailEntity> debarmentEntities =
                            IncidentTransformer.toDebarmentEntities(postDto.getDebarmentDetail(), incidentPk);
                    debarmentDetailRepository.saveAll(debarmentEntities);
                }
            });
        }
        // ✅ Save Status Logs
       /* if (dto.getStatusLookup() != null && !dto.getStatusLookup().isEmpty()) {
            List<IncidentStatusLogEntity> logEntities =
                    IncidentTransformer.toStatusLogEntities(dto.getStatusLookup(), incidentPk);
            incidentStatusLogRepository.saveAll(logEntities);*/



    }

    @Override
    public List<String> getReasons() {
        return Arrays.asList(
                "Catalog-based",
                "Catalog_ID + SKUID based",
                "Other"
        );
    }
    @Override
    public List<String> getSeverities() {
        return Arrays.asList("Low", "Medium", "High", "Critical");
    }

}