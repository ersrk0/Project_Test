package in.gov.gem.app.incident.service;

import in.gov.gem.app.incident.request.IncidentRequestDTO;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

public interface IncidentService {
     void saveIncident (String acceptLanguage, IncidentRequestDTO incidentRequestDTO) throws IOException;

     List<String> getReasons();

     List<String> getSeverities();
}