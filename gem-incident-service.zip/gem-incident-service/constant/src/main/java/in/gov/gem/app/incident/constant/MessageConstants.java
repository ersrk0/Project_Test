package in.gov.gem.app.incident.constant;

public class MessageConstants {
    public static final String INCIDENT_CREATED_SUCCESSFULLY = "incident.created.successfully";
    public static final String SUCCESS_MESSAGE = "request.successful";
    public static final String INCIDENT_NOT_FOUND = "incident.not.found";
    public static final String PRE_OR_POST_CONTRACT_ONLY = "PRE_OR_POST_CONTRACT_ONLY";
    public static final String INCIDENT_CREATED = "INCIDENT_CREATED";

}