package in.gov.gem.app.incident.constant;

public class Constants {
    public static final String MSID = "incident-service";
}