package in.gov.gem.app.incident.facade;
import in.gov.gem.app.incident.domain.dto.*;
import in.gov.gem.app.incident.dto.request.SaveIncidentRequest;
import in.gov.gem.app.incident.dto.request.TemplateType;
import in.gov.gem.app.incident.dto.response.IncidentDetailResponse;
import in.gov.gem.app.incident.dto.response.SaveIncidentResponse;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import java.util.UUID;
public interface IIncidentFacade {
  SaveIncidentResponse saveIncident(SaveIncidentRequest request);
  ResponseEntity<Resource> downloadTemplate(TemplateType type);
  IncidentDetailResponse getIncidentById(UUID incidentId);
}
