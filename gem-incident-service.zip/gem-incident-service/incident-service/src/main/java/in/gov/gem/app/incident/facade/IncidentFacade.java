package in.gov.gem.app.incident.facade;

public class IncidentFacade {}