package in.gov.gem.app.incident.utility;

public class IncidentUtils {}