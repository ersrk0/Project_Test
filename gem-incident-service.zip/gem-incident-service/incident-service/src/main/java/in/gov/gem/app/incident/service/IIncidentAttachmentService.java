package in.gov.gem.app.incident.service;
import in.gov.gem.app.incident.domain.entity.IncidentAttachmentEntity;
public interface IIncidentAttachmentService {
  IncidentAttachmentEntity save(IncidentAttachmentEntity entity);
  IncidentAttachmentEntity findByIncidentDocMasterFk(Long docFk);
}
