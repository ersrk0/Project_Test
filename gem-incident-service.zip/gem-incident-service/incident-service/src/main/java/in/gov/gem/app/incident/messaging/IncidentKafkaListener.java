package in.gov.gem.app.incident.messaging;

public class IncidentKafkaListener {}