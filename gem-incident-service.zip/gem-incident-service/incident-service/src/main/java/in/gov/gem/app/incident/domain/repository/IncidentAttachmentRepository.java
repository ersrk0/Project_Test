package in.gov.gem.app.incident.repository;
import in.gov.gem.app.incident.domain.entity.IncidentAttachmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface IncidentAttachmentRepository extends JpaRepository<IncidentAttachmentEntity, Long> {
  IncidentAttachmentEntity findByIncidentDocMasterFk(Long incidentDocMasterFk);
}
