package in.gov.gem.app.incident.facade.impl;

import in.gov.gem.app.incident.domain.entity.*;
import in.gov.gem.app.incident.facade.IncidentFacade;
import in.gov.gem.app.incident.request.AttachmentDTO;
import in.gov.gem.app.incident.request.IncidentDocMasterDTO;
import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.response.DocumentDownloadResponse;
import in.gov.gem.app.incident.response.IncidentResponseDTO;
import in.gov.gem.app.incident.service.IncidentService;
//import in.gov.gem.app.incident.service.impl.DocumentService;
//import in.gov.gem.app.incident.service.impl.SequenceGenerateService;
import in.gov.gem.app.incident.service.impl.SequenceGenerateService;
import in.gov.gem.app.incident.transformer.IncidentTransformer;
//import in.gov.gem.app.incident.utility.ExcelUtility;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;

import in.gov.gem.app.utility.CustomLoggerFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


@Component
@AllArgsConstructor
public class IncidentFacadeImpl implements IncidentFacade {
    private static final Logger logger = LoggerFactory.getLogger(IncidentFacadeImpl.class);
    private final IncidentService incidentService;
    private final IncidentTransformer incidentTransformer;
    private final MessageUtility messageUtility;
    private final in.gov.gem.app.incident.domain.repository.IncidentMasterRepository incidentMasterRepository;

    @Override
    @Transactional
    public IncidentMasterEntity saveIncident(String acceptLanguage, IncidentRequestDTO incidentRequestDTO) throws IOException {
        UUID uuid = UUID.randomUUID();
        long id = uuid.getMostSignificantBits();
        UUID incidentId = UUID.randomUUID();

        // Transform IncidentMasterEntity
//        IncidentMasterEntity incidentMasterEntity = incidentTransformer.toIncidentMasterEntity(id, incidentId, incidentRequestDTO);
//        incidentMasterEntity.setId(id);
//        incidentMasterEntity.setIncidentId(incidentId);

        // ------------------ PreContractData ------------------
        if (incidentRequestDTO.getPreContractData() != null && !incidentRequestDTO.getPreContractData().isEmpty()) {
            List<PreContractIncidentEntity> preContracts = IncidentTransformer.toPreContractEntities(incidentRequestDTO.getPreContractData(), id);
            preContracts.forEach(pc -> pc.setIncidentMaster(incidentMasterEntity));
            incidentMasterEntity.setPreContractData(preContracts);
        }

        // ------------------ PostContractData + Debarment ------------------
        if (incidentRequestDTO.getPostContractData() != null && !incidentRequestDTO.getPostContractData().isEmpty()) {
            List<PostContractIncidentEntity> postContracts = IncidentTransformer.toPostContractEntities(incidentRequestDTO.getPostContractData(), id);
            postContracts.forEach(pc -> pc.setIncidentMaster(incidentMasterEntity));
            for (int i = 0; i < incidentRequestDTO.getPostContractData().size(); i++) {
                var postDto = incidentRequestDTO.getPostContractData().get(i);
                var postEntity = postContracts.get(i);
                if (postDto.getDebarmentDetail() != null && !postDto.getDebarmentDetail().isEmpty()) {
                    List<DebarmentDetailEntity> debarments = IncidentTransformer.toDebarmentEntities(postDto.getDebarmentDetail(), id);
                    debarments.forEach(deb -> deb.setPostContractIncident(postEntity)); // Set parent relationship
                    postEntity.setDebarmentDetails(debarments); // Attach debarments to the post-contract entity
                }
            }
            incidentMasterEntity.setPostContractData(postContracts);
        }

        // ------------------ Status Log ------------------
        if (incidentRequestDTO.getIncidentStatusLogData() != null && !incidentRequestDTO.getIncidentStatusLogData().isEmpty()) {
            List<IncidentStatusLogEntity> statusLogs = IncidentTransformer.toStatusLogEntities(incidentRequestDTO.getIncidentStatusLogData(), id);
            statusLogs.forEach(sl -> sl.setIncidentMaster(incidentMasterEntity));
            incidentMasterEntity.setIncidentStatusLogData(statusLogs);
        }

        // ------------------ Document + Attachments ------------------
        if (incidentRequestDTO.getIncidentDocMasterData() != null && !incidentRequestDTO.getIncidentDocMasterData().isEmpty()) {
            List<IncidentDocMasterEntity> docMasters = incidentRequestDTO.getIncidentDocMasterData().stream()
                    .map(docDto -> {
                        IncidentDocMasterEntity docMaster = incidentTransformer.toDocMasterEntity(docDto, id);
                        docMaster.setIncidentMaster(incidentMasterEntity); // Set the relationship
                        if (docDto.getAttachments() != null && !docDto.getAttachments().isEmpty()) {
                            List<IncidentAttachmentEntity> attachments = incidentTransformer.toAttachmentEntities(docDto.getAttachments(), id);
                            attachments.forEach(att -> att.setIncidentDocMasterEntity(docMaster)); // Set the relationship
                            docMaster.setAttachments(attachments);
                        }
                        return docMaster;
                    })
                    .toList();
            incidentMasterEntity.setIncidentDocMasterData(docMasters);
        }

        // ------------------ Save & Additional Service Call ------------------
        IncidentMasterEntity savedEntity = incidentMasterRepository.save(incidentMasterEntity);
        logger.info("Incident saved successfully with ID: {}", savedEntity.getIncidentId());
        incidentService.saveIncident(incidentId, id, acceptLanguage, incidentRequestDTO);
        return savedEntity;
    }

    @Override
    public DocumentDownloadResponse downloadIncidentTemplate() {
        List<String> reasons = incidentService.getReasons();
        List<String> severities = incidentService.getSeverities();
        return null; // Placeholder for Excel template generation
    }
}
