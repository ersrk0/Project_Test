package in.gov.gem.app.incident.transformer;
import in.gov.gem.app.incident.dto.request.IncidentDocMasterDTO;
import in.gov.gem.app.incident.domain.entity.IncidentDocMasterEntity;
import org.springframework.stereotype.Component;
import java.util.UUID;
@Component
public class IncidentDocMasterTransformer {
  public IncidentDocMasterEntity toEntity(IncidentDocMasterDTO d, Long masterPk){
    IncidentDocMasterEntity e = new IncidentDocMasterEntity();
    e.setDocId(d.getDocId() != null ? d.getDocId() : UUID.randomUUID());
    e.setIncidentMasterFk(masterPk);
    e.setIncidentAttachmentFk(d.getIncidentAttachmentFk());
    return e;
  }
  public IncidentDocMasterDTO toDto(IncidentDocMasterEntity e){
    IncidentDocMasterDTO d = new IncidentDocMasterDTO();
    d.setDocId(e.getDocId());
    d.setIncidentAttachmentFk(e.getIncidentAttachmentFk());
    return d;
  }
}
