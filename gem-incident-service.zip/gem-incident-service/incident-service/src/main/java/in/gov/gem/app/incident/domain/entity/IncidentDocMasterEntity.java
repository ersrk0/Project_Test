package in.gov.gem.app.incident.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "incident_doc_master")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class IncidentDocMasterEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    private Long id;

    @Column(name = "doc_id")
    private UUID docId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "incident_master_fk", referencedColumnName = "id", nullable = false)
    private IncidentMasterEntity incidentMaster;

    @OneToMany(mappedBy = "incidentDocMasterEntity", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<IncidentAttachmentEntity> attachments;
}