package in.gov.gem.app.incident.repository;
import in.gov.gem.app.incident.domain.entity.IncidentDocMasterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface IncidentDocMasterRepository extends JpaRepository<IncidentDocMasterEntity, Long> {
  IncidentDocMasterEntity findByIncidentMasterFk(Long incidentMasterFk);
}
