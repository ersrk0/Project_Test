package in.gov.gem.app.incident.service;
import in.gov.gem.app.incident.domain.entity.IncidentDocMasterEntity;
public interface IIncidentDocMasterService {
  IncidentDocMasterEntity save(IncidentDocMasterEntity entity);
  IncidentDocMasterEntity findByIncidentMasterFk(Long masterFk);
}
