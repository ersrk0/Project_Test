package in.gov.gem.app.incident.domain.entity;
import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import java.util.Date;
import java.util.UUID;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@SuperBuilder
@Entity @Table(name="debarment_detail", schema="incident_mgmt")
public class DebarmentDetailEntity extends BaseEntity {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
  @Column(name="id", updatable=false, nullable=false)
  private Long id;

  @Column(name="debarment_id") private UUID debarmentId;
  @Column(name="post_contract_incident_fk", nullable=false) private Long postContractIncidentFk;
  @Column(name="debarment_clause_lookup") private String debarmentClauseLookup;
  @Temporal(TemporalType.DATE) @Column(name="debarment_start_date") private Date debarmentStartDate;
  @Temporal(TemporalType.DATE) @Column(name="debarment_end_date") private Date debarmentEndDate;
  @Column(name="competent_authority_name") private String competentAuthorityName;
  @Column(name="competent_authority_designation") private String competentAuthorityDesignation;
}
