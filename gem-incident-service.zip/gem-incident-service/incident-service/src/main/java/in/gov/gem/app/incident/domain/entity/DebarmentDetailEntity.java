package in.gov.gem.app.incident.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "debarment_detail")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class DebarmentDetailEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    private Long id;

    @Column(name = "debarment_id")
    private UUID debarmentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "post_contract_incident_fk", nullable = false) // Ensure this matches the mappedBy in PostContractIncidentEntity
    private PostContractIncidentEntity postContractIncident;

    @Column(name = "debarment_clause_lookup")
    private String debarmentClauseLookup;

    @Column(name = "debarment_start_date")
    private Date debarmentStartDate;

    @Column(name = "debarment_end_date")
    private Date debarmentEndDate;

    @Column(name = "competent_authority_name")
    private String competentAuthorityName;

    @Column(name = "competent_authority_designation")
    private String competentAuthorityDesignation;

}