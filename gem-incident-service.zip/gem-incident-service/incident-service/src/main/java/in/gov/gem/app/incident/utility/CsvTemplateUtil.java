package in.gov.gem.app.incident.utility;
import in.gov.gem.app.incident.dto.request.TemplateType;
public final class CsvTemplateUtil {
  private CsvTemplateUtil(){}
  public static String buildTemplate(TemplateType type){
    String common="incidentTypeLookup,moduleCode,raisedById,raisedByRoleLookup,raisedAgainstTypeLookup,"+
      "raisedAgainstRoleLookup,incidentReasonLookup,issueTypeLookup,incidentTitle,incidentDescription,"+
      "statusLookup,severityLookup";
    if(type==TemplateType.PRE_CONTRACT){
      return common + ",traderId,categoryCode,productId,catalogId,compId,skuId,brandId,serviceId\n";
    } else {
      return common + ",auctionId,bidId,contractNo,invoiceId,traderId,panNo,isDebarred\n";
    }
  }
}
