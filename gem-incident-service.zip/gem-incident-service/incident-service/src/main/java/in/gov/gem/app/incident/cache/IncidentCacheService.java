package in.gov.gem.app.incident.cache;

public interface IncidentCacheService {}