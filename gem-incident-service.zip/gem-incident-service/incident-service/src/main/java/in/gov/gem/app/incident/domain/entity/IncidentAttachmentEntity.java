package in.gov.gem.app.incident.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigInteger;

@Entity
@Table(name = "incident_attachment")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class IncidentAttachmentEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "incident_doc_master_fk", referencedColumnName = "id", nullable = false)
    private IncidentDocMasterEntity incidentDocMasterEntity;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "file_type_lookup")
    private String fileTypeLookup;

    @Column(name = "file_path")
    private String filePath;

    @Column(name = "file_size")
    private BigInteger fileSize;
}