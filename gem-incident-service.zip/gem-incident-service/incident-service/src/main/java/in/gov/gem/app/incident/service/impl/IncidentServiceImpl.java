package in.gov.gem.app.incident.service.impl;

import in.gov.gem.app.incident.domain.entity.*;
import in.gov.gem.app.incident.domain.repository.*;
import in.gov.gem.app.incident.request.IncidentDocMasterDTO;
import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.service.IncidentService;
import in.gov.gem.app.incident.transformer.IncidentTransformer;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Slf4j
@Service
@Transactional
public class IncidentServiceImpl implements IncidentService {
    private PreContractIncidentRepository preContractIncidentRepository;
    private PostContractIncidentRepository postContractIncidentRepository;
    private DebarmentDetailRepository debarmentDetailRepository;
    private IncidentStatusLogRepository incidentStatusLogRepository;
    private IncidentMasterRepository incidentMasterRepository;
    private IncidentDocMasterRepository incidentDocMasterRepository;
    private IncidentAttachmentRepository incidentAttachmentRepository;

    @Override
    public void saveIncident(UUID incidentId, long id, String acceptLanguage, IncidentRequestDTO dto) throws IOException {
        // Save IncidentMaster
        IncidentMasterEntity incidentMasterEntity = IncidentTransformer.toIncidentMasterEntity(id, incidentId, dto);
        incidentMasterEntity.setId(id);
        incidentMasterEntity.setIncidentId(incidentId);
        incidentMasterRepository.save(incidentMasterEntity);

        // PreContract data
        if (dto.getPreContractData() != null && !dto.getPreContractData().isEmpty()) {
            List<PreContractIncidentEntity> preEntities = IncidentTransformer.toPreContractEntities(dto.getPreContractData(), id);
            preEntities.forEach(e -> e.setIncidentMaster(incidentMasterEntity));
            preContractIncidentRepository.saveAll(preEntities);
        }

        // PostContract data + Debarment
        if (dto.getPostContractData() != null && !dto.getPostContractData().isEmpty()) {
            List<PostContractIncidentEntity> postEntities = IncidentTransformer.toPostContractEntities(dto.getPostContractData(), id);
            postEntities.forEach(e -> e.setIncidentMaster(incidentMasterEntity));
            postContractIncidentRepository.saveAll(postEntities);
            for (int i = 0; i < dto.getPostContractData().size(); i++) {
                var postDto = dto.getPostContractData().get(i);
                var postEntity = postEntities.get(i);
                if (postDto.getDebarmentDetail() != null && !postDto.getDebarmentDetail().isEmpty()) {
                    List<DebarmentDetailEntity> debarmentEntities = IncidentTransformer.toDebarmentEntities(postDto.getDebarmentDetail(), postEntity.getId());
                    debarmentEntities.forEach(d -> d.setPostContractIncident(postEntity));
                    debarmentDetailRepository.saveAll(debarmentEntities);
                }
            }
        }

        // Incident Status Logs
        if (dto.getIncidentStatusLogData() != null && !dto.getIncidentStatusLogData().isEmpty()) {
            List<IncidentStatusLogEntity> logEntities = IncidentTransformer.toStatusLogEntities(dto.getIncidentStatusLogData(), id);
            logEntities.forEach(e -> e.setIncidentMaster(incidentMasterEntity));
            incidentStatusLogRepository.saveAll(logEntities);
        }

        // Incident Doc Master + Attachments
        if (dto.getIncidentDocMasterData() != null && !dto.getIncidentDocMasterData().isEmpty()) {
            for (IncidentDocMasterDTO docDto : dto.getIncidentDocMasterData()) {
                // Transform and save IncidentDocMasterEntity
                IncidentDocMasterEntity docEntity = IncidentTransformer.toDocMasterEntity(docDto, id);
                docEntity.setIncidentMaster(incidentMasterEntity);
                docEntity = incidentDocMasterRepository.save(docEntity); // Save the doc master entity

                // Transform and save IncidentAttachmentEntity
                if (docDto.getAttachments() != null && !docDto.getAttachments().isEmpty()) {
                    List<IncidentAttachmentEntity> attachmentEntities = IncidentTransformer.toAttachmentEntities(docDto.getAttachments(), docEntity.getId());
                    attachmentEntities.forEach(att -> {
                       // att.setIncidentDocMaster(docEntity); // Set the relationship
                    });
                    incidentAttachmentRepository.saveAll(attachmentEntities); // Save all attachments
                }
            }
        }

        log.info("Incident saved successfully with IncidentId: {} and IncidentPk: {}", incidentId, id);
    }

    @Override
    public List<String> getReasons() {
        return List.of("Catalog-based", "Catalog_ID + SKUID based", "Other");
    }

    @Override
    public List<String> getSeverities() {
        return List.of("Low", "Medium", "High", "Critical");
    }
}