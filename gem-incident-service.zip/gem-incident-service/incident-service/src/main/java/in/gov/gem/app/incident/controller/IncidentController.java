package in.gov.gem.app.incident.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class IncidentController {}