package in.gov.gem.app.incident.batch;

public class IncidentBatchProcessor {}