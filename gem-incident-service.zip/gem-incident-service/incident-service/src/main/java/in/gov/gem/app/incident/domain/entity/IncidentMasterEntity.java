package in.gov.gem.app.incident.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "incident_master")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class IncidentMasterEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    private Long id;

    @Column(name = "incident_id", unique = true, nullable = false)
    private UUID incidentId;

    @Column(name = "incident_type_lookup")
    private String incidentTypeLookup;

    @Column(name = "module_code")
    private String moduleCode;

    @Column(name = "raised_by_id")
    private String raisedById;

    @Column(name = "raised_by_role_lookup")
    private String raisedByRoleLookup;

    @Column(name = "raised_against_type_lookup")
    private String raisedAgainstTypeLookup;

    @Column(name = "raised_against_role_lookup")
    private String raisedAgainstRoleLookup;

    @Column(name = "incident_reason_lookup")
    private String incidentReasonLookup;

    @Column(name = "issue_type_lookup")
    private String issueTypeLookup;

    @Column(name = "incident_title")
    private String incidentTitle;

    @Column(name = "incident_description")
    private String incidentDescription;

    @Column(name = "status_lookup")
    private String statusLookup;

    @Column(name = "severity_lookup")
    private String severityLookup;

    @OneToMany(mappedBy = "incidentMaster", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<IncidentDocMasterEntity> incidentDocMasterData;

    @OneToMany(mappedBy = "incidentMaster", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PreContractIncidentEntity> preContractData;

    @OneToMany(mappedBy = "incidentMaster", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PostContractIncidentEntity> postContractData;

    @OneToMany(mappedBy = "incidentMaster", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<IncidentStatusLogEntity> incidentStatusLogData;


    @Column(name = "updated_at", insertable = false, updatable = false) // Marked as non-insertable and non-updatable
    private LocalDateTime updatedAt;
}