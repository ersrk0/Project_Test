package in.gov.gem.app.incident.service;
import in.gov.gem.app.incident.domain.entity.PreContractIncidentEntity;
public interface IPreContractIncidentService {
  PreContractIncidentEntity save(PreContractIncidentEntity entity);
  PreContractIncidentEntity findByIncidentMasterFk(Long masterFk);
}
