package in.gov.gem.app.incident.repository;
import in.gov.gem.app.incident.domain.entity.IncidentMasterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.UUID;
public interface IncidentMasterRepository extends JpaRepository<IncidentMasterEntity, Long> {
  Optional<IncidentMasterEntity> findByIncidentId(UUID incidentId);
}
