package in.gov.gem.app.incident.cache.impl;

public class IncidentCacheServiceImpl implements in.gov.gem.app.incident.cache.IncidentCacheService {}