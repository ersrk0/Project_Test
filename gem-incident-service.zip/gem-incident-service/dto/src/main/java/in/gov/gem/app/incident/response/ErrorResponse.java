package in.gov.gem.app.incident.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class ErrorResponse {
    private String status;
    private int httpStatus;
    private String message;
    private String msId;
    private ErrorDetailsDTO data;
    private String timestamp;
}
