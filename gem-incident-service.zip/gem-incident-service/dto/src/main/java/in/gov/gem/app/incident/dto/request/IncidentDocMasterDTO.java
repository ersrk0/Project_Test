package in.gov.gem.app.incident.dto.request;
import lombok.Getter; import lombok.Setter;
@Getter @Setter
public class IncidentDocMasterDTO {
  private java.util.UUID docId;
  private Long incidentAttachmentFk;
}
