package in.gov.gem.app.incident.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class PreContractDataResponseDTO {
    private UUID preContractPk;     // PK
    private UUID incidentPk;        // FK
    private String traderId;
    private UUID categoryCode;
    private String productId;
    private String catalogId;
    private String compId;
    private String skuId;
    private String brandId;
    private String serviceId;
}