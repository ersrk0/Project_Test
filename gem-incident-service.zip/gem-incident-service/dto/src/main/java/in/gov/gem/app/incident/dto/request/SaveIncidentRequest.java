package in.gov.gem.app.incident.dto.request;
import lombok.Getter; import lombok.Setter;
@Getter @Setter
public class SaveIncidentRequest {
  private IncidentMasterDTO master;
  private PreContractIncidentDTO preContract;
  private PostContractIncidentDTO postContract;
  private DebarmentDetailDTO debarment;
  private IncidentDocMasterDTO docMaster;
  private IncidentAttachmentDTO attachment;
  private IncidentStatusLogDTO statusLog;
}
