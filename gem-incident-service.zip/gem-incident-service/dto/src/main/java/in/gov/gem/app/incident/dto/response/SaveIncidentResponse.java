package in.gov.gem.app.incident.dto.response;
import lombok.Builder; import lombok.Getter;
import java.util.UUID;
@Getter @Builder
public class SaveIncidentResponse {
  private UUID incidentId;
  private Long incidentMasterPk;
  private String status;
}
