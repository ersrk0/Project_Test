package in.gov.gem.app.incident.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class AttachmentResponseDTO {
    private UUID attachmentPk;           // PK
    private UUID incidentDocMasterPk;    // FK
    private String fileName;
    private String fileTypeLookup;
    private String filePath;
    private long fileSize;
    private String uploadedByTypeLookup;
    private String uploadedById;
    private String statusLookup;
}