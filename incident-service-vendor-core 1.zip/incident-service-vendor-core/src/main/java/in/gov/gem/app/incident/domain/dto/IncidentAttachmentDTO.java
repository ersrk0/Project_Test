package in.gov.gem.app.incident.domain.dto;
import lombok.Getter; import lombok.Setter;
@Getter @Setter
public class IncidentAttachmentDTO {
  private String fileName;
  private String fileTypeLookup;
  private String filePath;
  private java.math.BigInteger fileSize;
}
