package in.gov.gem.app.incident.service.impl;
import in.gov.gem.app.incident.domain.entity.IncidentMasterEntity;
import in.gov.gem.app.incident.repository.IncidentMasterRepository;
import in.gov.gem.app.incident.service.IIncidentMasterService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.Optional;
import java.util.UUID;
@Service @RequiredArgsConstructor
public class IncidentMasterService implements IIncidentMasterService {
  private final IncidentMasterRepository repository;
  public IncidentMasterEntity save(IncidentMasterEntity e){ return repository.save(e); }
  public Optional<IncidentMasterEntity> findByIncidentId(UUID id){ return repository.findByIncidentId(id); }
}
