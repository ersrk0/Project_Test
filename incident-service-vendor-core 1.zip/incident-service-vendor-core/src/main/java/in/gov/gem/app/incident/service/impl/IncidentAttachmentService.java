package in.gov.gem.app.incident.service.impl;
import in.gov.gem.app.incident.domain.entity.IncidentAttachmentEntity;
import in.gov.gem.app.incident.repository.IncidentAttachmentRepository;
import in.gov.gem.app.incident.service.IIncidentAttachmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
@Service @RequiredArgsConstructor
public class IncidentAttachmentService implements IIncidentAttachmentService {
  private final IncidentAttachmentRepository repository;
  public IncidentAttachmentEntity save(IncidentAttachmentEntity e){ return repository.save(e); }
  public IncidentAttachmentEntity findByIncidentDocMasterFk(Long fk){ return repository.findByIncidentDocMasterFk(fk); }
}
