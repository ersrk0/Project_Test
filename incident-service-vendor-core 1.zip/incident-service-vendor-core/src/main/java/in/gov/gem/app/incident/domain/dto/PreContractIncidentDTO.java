package in.gov.gem.app.incident.domain.dto;
import lombok.Getter; import lombok.Setter;
@Getter @Setter
public class PreContractIncidentDTO {
  private String traderId;
  private java.util.UUID categoryCode;
  private String productId;
  private String catalogId;
  private String compId;
  private String skuId;
  private String brandId;
  private String serviceId;
}
