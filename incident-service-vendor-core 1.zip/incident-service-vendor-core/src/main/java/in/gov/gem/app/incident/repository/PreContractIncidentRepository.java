package in.gov.gem.app.incident.repository;
import in.gov.gem.app.incident.domain.entity.PreContractIncidentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PreContractIncidentRepository extends JpaRepository<PreContractIncidentEntity, Long> {
  PreContractIncidentEntity findByIncidentMasterFk(Long incidentMasterFk);
}
