package in.gov.gem.app.incident.domain.entity;
import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import java.util.UUID;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity @Table(name="pre_contract_incident", schema="incident_mgmt")
public class PreContractIncidentEntity extends BaseEntity {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
  @Column(name="id", nullable=false, updatable=false)
  private Long id;

  @Column(name="incident_master_fk", nullable=false)
  private Long incidentMasterFk;

  @Column(name="trader_id") private String traderId;
  @Column(name="category_code") private UUID categoryCode;
  @Column(name="product_id") private String productId;
  @Column(name="catalog_id") private String catalogId;
  @Column(name="comp_id") private String compId;
  @Column(name="sku_id") private String skuId;
  @Column(name="brand_id") private String brandId;
  @Column(name="service_id") private String serviceId;
}
