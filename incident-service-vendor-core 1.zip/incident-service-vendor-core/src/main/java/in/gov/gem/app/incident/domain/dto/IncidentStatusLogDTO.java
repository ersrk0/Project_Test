package in.gov.gem.app.incident.domain.dto;
import lombok.Getter; import lombok.Setter;
@Getter @Setter
public class IncidentStatusLogDTO {
  private String actionTypeLookup;
  private String previousStatusLookup;
  private String currentStatusLookup;
  private String actionByTypeLookup;
  private String actionById;
  private String remarks;
}
