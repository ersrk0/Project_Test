package in.gov.gem.app.incident.transformer;
import in.gov.gem.app.incident.domain.dto.IncidentMasterDTO;
import in.gov.gem.app.incident.domain.entity.IncidentMasterEntity;
import org.springframework.stereotype.Component;
import java.util.UUID;
@Component
public class IncidentMasterTransformer {
  public IncidentMasterEntity toEntity(IncidentMasterDTO dto, UUID incidentId){
    IncidentMasterEntity e = new IncidentMasterEntity();
    e.setIncidentId(incidentId);
    e.setIncidentTypeLookup(dto.getIncidentTypeLookup());
    e.setModuleCode(dto.getModuleCode());
    e.setRaisedById(dto.getRaisedById());
    e.setRaisedByRoleLookup(dto.getRaisedByRoleLookup());
    e.setRaisedAgainstTypeLookup(dto.getRaisedAgainstTypeLookup());
    e.setRaisedAgainstRoleLookup(dto.getRaisedAgainstRoleLookup());
    e.setIncidentReasonLookup(dto.getIncidentReasonLookup());
    e.setIssueTypeLookup(dto.getIssueTypeLookup());
    e.setIncidentTitle(dto.getIncidentTitle());
    e.setIncidentDescription(dto.getIncidentDescription());
    e.setStatusLookup(dto.getStatusLookup());
    e.setSeverityLookup(dto.getSeverityLookup());
    return e;
  }
  public IncidentMasterDTO toDto(IncidentMasterEntity e){
    IncidentMasterDTO d = new IncidentMasterDTO();
    d.setIncidentTypeLookup(e.getIncidentTypeLookup());
    d.setModuleCode(e.getModuleCode());
    d.setRaisedById(e.getRaisedById());
    d.setRaisedByRoleLookup(e.getRaisedByRoleLookup());
    d.setRaisedAgainstTypeLookup(e.getRaisedAgainstTypeLookup());
    d.setRaisedAgainstRoleLookup(e.getRaisedAgainstRoleLookup());
    d.setIncidentReasonLookup(e.getIncidentReasonLookup());
    d.setIssueTypeLookup(e.getIssueTypeLookup());
    d.setIncidentTitle(e.getIncidentTitle());
    d.setIncidentDescription(e.getIncidentDescription());
    d.setStatusLookup(e.getStatusLookup());
    d.setSeverityLookup(e.getSeverityLookup());
    return d;
  }
}
