
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import lombok.Data;

/**
 * DTO for Organisation Details.
 */
@Data
public class organisationDetailsNewRequestDTO {
    private String nameOfOrganisation;
    private String organisationType;
    private String organisationSubType;
    private String organisationPAN;
    private String organisationTAN;
    private String cinFcrnLlpinFllpin;
    private String primaryContactNumber;
    private String primaryEmailId;

  }