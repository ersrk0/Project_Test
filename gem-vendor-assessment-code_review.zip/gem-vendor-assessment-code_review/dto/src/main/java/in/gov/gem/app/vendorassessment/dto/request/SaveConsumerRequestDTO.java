
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import edu.umd.cs.findbugs.annotations.Nullable;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import java.util.UUID;

/**
 * Save Consent
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Validated
public class SaveConsumerRequestDTO {

  /**
   * The Consent code.
   */
  @Pattern(regexp ="^[a-zA-Z0-9]{8,10}$", message = "Invalid ConsentCode : " + " it must be of 8-10"+
    "Alphanumeric")
  @NotNull(message = "ConsentCode must not be null")
  String consentCode;

  /**
   * The Language code.
   */
  @Pattern(regexp = "^[a-zA-Z0-9]+$",
    message = "languageCode should only contain AlphaNumeric"
  )
  @NotNull(message = "languageCode must not be null")
  String languageCode;

  /**
   * The Consumer id.
   */
  @Pattern(regexp = "^[a-zA-Z0-9-]+$",
    message = "consumerId should only contain AlphaNumeric"
  )
  String consumerId;

  /**
   * The Attachment hash.
   */
  @Pattern(regexp = "^[a-zA-Z0-9]+$",
    message = "attachmentHash should only contain AlphaNumeric"
  )
  @NotNull(message = "attachmentHash must not be null")
  String attachmentHash;

  /**
   * The Accept timestamp.
   */
  @NotNull(message = "acceptTimestamp must not be null")
  @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?([Zz]|([+-])([01]\\d|2[0-3]):?([0-9]\\d))?Z$" , message = "Incorrect format of date and time")
  String acceptTimestamp;

  /**
   * The Tenant id.
   */
  @Nullable
  UUID tenantId;

  /**
   * The Consumer type lookup.
   */
  @Pattern(regexp = "^[a-zA-Z0-9]{10}$",
    message = "Invalid ConsumerTypeLookup: " +"ConsumerTypeLookup should only contain AlphaNumeric."+
      "and must be of 10 characters"
  )
  String consumerTypeLookup;

  /**
   * The Is public.
   */
  @Nullable
  Boolean isPublic = Boolean.TRUE;

  /**
   * Instantiates a new Save consumer request dto.
   *
   * @param consentCode     the consent code
   * @param attachmentHash  the attachment hash
   * @param acceptTimestamp the accept timestamp
   * @param languageCode    the language code
   * @param isPublic        the is public
   */
  public SaveConsumerRequestDTO(String consentCode, String attachmentHash, String acceptTimestamp, String languageCode , @Nullable Boolean isPublic) {
    this.consentCode = consentCode;
    this.attachmentHash = attachmentHash;
    this.acceptTimestamp = acceptTimestamp;
    this.languageCode = languageCode;
    this.isPublic = isPublic;
  }
}

