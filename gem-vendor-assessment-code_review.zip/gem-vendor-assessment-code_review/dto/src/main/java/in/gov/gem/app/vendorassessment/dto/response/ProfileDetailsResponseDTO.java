
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import in.gov.gem.app.vendorassessment.dto.request.LookupVORequestDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * The type Profile details response dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProfileDetailsResponseDTO
{
  @Schema(description = "unique id of corresponding to organization ", example = "12")
  private long id;
  @Schema(description = "type of organization", example = "Company")
  private LookupVORequestDTO organizationType;
  @Schema(description = "type of sub organization", example = "Private ltd.")
  private LookupVORequestDTO subOrganizationType;
  @Schema(description = "name of organization", example = "Wayne Industries")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String organizationName;
  @Schema(description = "doi of entity", example = "2015-08-04T10:11:30")
  @JsonInclude(JsonInclude.Include.NON_NULL)

  private Instant dateOfIncorporation;
  @Schema(description = "entity(llpin/cin) of organization", example = "ABC4567")
  private String entityNumber;
  @Schema(description = "role of user", example = "Director")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private LookupVORequestDTO role;
  @Schema(description = "is the organisation firm and has no llpin", example = "true")
  private Boolean isFirmAndNoLlpin;
  @Schema(description = "entity number last verified at", example = "2015-08-04T10:11:30")
  @JsonInclude(JsonInclude.Include.NON_NULL)

  private Instant entityLastVerifiedAt;


}
