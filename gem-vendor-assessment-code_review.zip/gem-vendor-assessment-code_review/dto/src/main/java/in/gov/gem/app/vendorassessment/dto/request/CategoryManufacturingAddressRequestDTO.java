/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for creating/updating Manufacturing Address entries.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryManufacturingAddressRequestDTO {
  private String officeName;
  private String officeAddress;
  private String OfficeType;
  private String gstIn;
  private String email;
  private String mobile;


}
