
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Lookup vo request dto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LookupVORequestDTO {

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String id;

  @Schema(description = "Name of data", example = "ONBOARDING_PROCESS")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String name;

  @Schema(description = "Value of data", example = "Registration with PAN", accessMode = Schema.AccessMode.READ_WRITE)
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String value;

  @Schema(description = "Description related to data", example = "Register with PAN of business entity.",
    accessMode = Schema.AccessMode.READ_WRITE)
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String description;

  @Schema(description = "Whether field is active", example = "true", accessMode = Schema.AccessMode.READ_WRITE)
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Boolean activeFlg;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Boolean isMandatory;

  @Schema(description = "Whether field is mandatory", example = "false", accessMode = Schema.AccessMode.READ_WRITE)
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Boolean mandatoryFlg;

  /**
   * Instantiates a new Lookup vo request dto.
   *
   * @param subType the sub type
   * @param s       the s
   */
  public LookupVORequestDTO(String subType, String s) {
  }
}

