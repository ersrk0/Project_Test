
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import lombok.Data;

/**
 * The type Save answer response dto.
 */
@Data
public class SaveAnswerResponseDTO {
  private Long questionId;
  private Long optionId; // Option selected by the user
  private String answerText; // For open-ended questions, if any

  // Getters and Setters
}

