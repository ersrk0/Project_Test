
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.dto.enums;


import java.util.Optional;

/**
 * The enum Criteria type.
 */
public enum CriteriaType {
  /**
   * The Oem bis license.
   */
  OEM_BIS_LICENSE("OEMs holding BIS License for the particular product category"),
  /**
   * The Central state psus.
   */
  CENTRAL_STATE_PSUS("Central / State PSUs"),
  /**
   * The Seller 500 cr turnover.
   */
  SELLER_500CR_TURNOVER("Sellers recommended for exemption for specific categories and specified validity period by any CPSE, Central and State Government Departments/ Authorities."),
  /**
   * The Societies govt affiliation.
   */
  SOCIETIES_GOVT_AFFILIATION("Sellers who are Registered Societies/ Trusts/ other bodies, if these concerns have Government Representation."),
  /**
   * The Kvic.
   */
  KVIC("Vaccine manufacturer as per list provided by Ministry of Health & Family Welfare"),
  /**
   * The Wdq.
   */
  WDQ("Drugs/Medicine manufacturer with \"Notarized Undertaking\" & \"Valid certified copy of Drug Licenses from the issuing/concerned Drug Authority\""),
  /**
   * The Coir.
   */
  COIR("Medical Device manufacturer with \"Valid Manufacturing License\" from the issuing Licensing Authority"),
  /**
   * The Trifed.
   */
  TRIFED("Turnover based exemption if turnover is greater than 500 Cr in any of the last 3 year");




    private final String displayName;

    CriteriaType(String displayName) {
        this.displayName = displayName;
    }

  /**
   * Converts a string representation to a CriteriaType enum.
   * It first tries to match by the enum's constant name (case-insensitive),
   * and if that fails, it tries to match by the displayName (case-insensitive).
   *
   * @param text The string to convert (e.g., "OEM_BIS_LICENSE", "Oems holding bis license").
   * @return An Optional containing the matching CriteriaType, or an empty Optional if no match is found.
   */
  public static Optional<CriteriaType> fromString(String text) {
        if (text == null || text.trim().isEmpty()) {
            return Optional.empty();
        }
        String trimmedText = text.trim();

        // 1. Try to match by enum constant name (e.g., "OEM_BIS_LICENSE")
        for (CriteriaType type : CriteriaType.values()) {
            if (type.name().equalsIgnoreCase(trimmedText)) {
                return Optional.of(type);
            }
        }

        // 2. If no match by name, try to match by displayName (e.g., "OEMs holding BIS License")
        for (CriteriaType type : CriteriaType.values()) {
            if (type.displayName.equalsIgnoreCase(trimmedText)) {
                return Optional.of(type);
            }
        }

        return Optional.empty(); // No matching enum found
    }

  /**
   * Converts a string representation to a CriteriaType enum.
   * This version throws an IllegalArgumentException if no match is found.
   * Use this if you expect the string to *always* be a valid enum representation.
   *
   * @param text The string to convert.
   * @return The matching CriteriaType enum.
   * @throws IllegalArgumentException If the string does not match any enum constant or display name.
   */
  public static CriteriaType fromStringOrThrow(String text) {
        return fromString(text)
                .orElseThrow(() -> new IllegalArgumentException("No CriteriaType found for string: " + text));
    }

  /**
   * Gets display name.
   *
   * @return the display name
   */
  public String getDisplayName() {
        return displayName;
    }
}
