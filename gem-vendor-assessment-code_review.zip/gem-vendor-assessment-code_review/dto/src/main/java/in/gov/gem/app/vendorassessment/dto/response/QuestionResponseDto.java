package in.gov.gem.app.vendorassessment.dto.response;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class QuestionResponseDto {
    @NotNull(message = "Question ID cannot be null")
    private Long questionId;
    private String answer; // Use String to accommodate boolean, text, etc.
}