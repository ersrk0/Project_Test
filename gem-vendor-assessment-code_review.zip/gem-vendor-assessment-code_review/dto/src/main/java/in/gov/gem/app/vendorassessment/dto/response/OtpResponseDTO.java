
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */
package in.gov.gem.app.vendorassessment.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * The type Otp response dto.
 */
@AllArgsConstructor
@Data
@NoArgsConstructor
@Schema(requiredProperties = {"referenceId"})
public class OtpResponseDTO {

    @NotBlank(message = "Should not be null or empty")
    @Schema(description = "ReferenceId for the user..", example = "1dcbc770-50b4-4162-9443-e8e4e1f25005", minLength = 36, maxLength = 36)
    private UUID referenceId;
}

