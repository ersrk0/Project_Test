
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * DTO representing the detailed response for a document, including fetched attributes.
 * This is used when retrieving document information.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DocumentDetailOldResponseDTO {
    private Long id;
    private String name; // Corresponds to licenseCertificateDetails from request
    private String type; // Corresponds to document type ID
    private String issuingAuthority; // Corresponds to issuingAuthorityDetails
    private String remarks;
    private double sizeInMB;
    private Instant validUpto; // UTC timestamp
    private String status;
    private Instant createdAt; // UTC timestamp
    private Instant updatedAt; // UTC timestamp
    private String fileReferenceId; // A reference to the stored file

  /**
   * Instantiates a new Document detail response.
   *
   * @param id               the id
   * @param name             the name
   * @param type             the type
   * @param issuingAuthority the issuing authority
   * @param remarks          the remarks
   * @param sizeInMB         the size in mb
   * @param validUpto        the valid upto
   * @param status           the status
   * @param fileReferenceId  the file reference id
   */
// Constructor to map from a simple request/simulated save
    public DocumentDetailOldResponseDTO(Long id, String name, String type, String issuingAuthority, String remarks,
                                        double sizeInMB, Instant validUpto, String status, String fileReferenceId) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.issuingAuthority = issuingAuthority;
        this.remarks = remarks;
        this.sizeInMB = sizeInMB;
        this.validUpto = validUpto;
        this.status = status;
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
        this.fileReferenceId = fileReferenceId;
    }
}
