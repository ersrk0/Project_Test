
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import in.gov.gem.app.vendorassessment.dto.enums.NonComplianceStatus;
import lombok.*;

/**
 * The type Bod document new response dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class BODDocumentNewResponseDTO {
  private String docName;
  private String nonComplianceStatus = NonComplianceStatus.CLOSED.toString();
}
