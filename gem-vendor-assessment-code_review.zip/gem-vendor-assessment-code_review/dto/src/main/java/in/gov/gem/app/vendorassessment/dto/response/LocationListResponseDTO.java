
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


/**
 * The type LocationList Response.
 */
@Schema(name = "LocationList Response", description = "LocationList Response")
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LocationListResponseDTO {

  @Schema(description = "Data code of pincode.", example = "P_001")
  private String dataCode;

  @Schema(description = "Specifies the pin code for the location.", example = "495684")
  private String pinCode;

  @Schema(description = "Denotes the village in which the specified location as per the pincode is located.",
    example = "Koregaon Park")
  private String village;

  @Schema(description = "Denotes the panchayat in which the specified location as per the pincode is located.",
    example = "Panjim Municipal Corporation")
  private String panchayat;

  @Schema(description = "Denotes the block in which the specified location as per the pincode is located.",
    example = "Pune City")
  private String block;

  @Schema(description = "Denotes the district in which the specified location as per the pincode is located.",
    example = "Panjim")
  private String subDistrict;

  @Schema(description = "Denotes the district in which the specified location as per the pincode is located.",
    example = "North Goa")
  private String district;

  @Schema(description = "Denotes the state in which the specified location as per the pincode is located.",
    example = "Goa")
  private String state;

  @Schema(description = "Denotes the country in which the specified location as per the pincode is located.",
    example = "India")
  private String country;

}

