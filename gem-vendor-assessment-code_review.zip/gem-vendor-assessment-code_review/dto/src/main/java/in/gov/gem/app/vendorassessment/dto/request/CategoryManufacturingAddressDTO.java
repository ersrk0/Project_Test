/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Manufacturing Address entity.
 * Fields correspond to the image provided.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryManufacturingAddressDTO {
  private String id;
  private String officeName;
  private String officeAddress;
  private String officeType;
  private String gstIn;
  private String email;
  private String mobile;



  // This list will store IDs of categories mapped to this manufacturing address.
  // In a real database, this would be a separate many-to-many join table.
  private List<String> mappedCategoryIds = new ArrayList<>();



  public CategoryManufacturingAddressDTO(String officeName, String officeAddress,
                                         String officeType, String email
          , String gstIn, String mobile) {
    this.officeName = officeName;
    this.officeAddress = officeAddress;
    this.officeType = officeType;
    this.email = email;

    this.gstIn = gstIn;
    this.mobile = mobile;
  }


}

