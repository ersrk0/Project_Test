
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import lombok.Data;

/**
 * DTO for creating or updating a Supplementary Assessment Request.
 * This will be the request body for POST/PUT /api/assessment-requests
 */
@Data
public class AssessmentRequestDTO {
    private String vaId;
    private boolean organizationChangeRequested;
    private boolean experienceDocumentsChangeRequested;
    private boolean licenseDocumentChangeRequested;
}

