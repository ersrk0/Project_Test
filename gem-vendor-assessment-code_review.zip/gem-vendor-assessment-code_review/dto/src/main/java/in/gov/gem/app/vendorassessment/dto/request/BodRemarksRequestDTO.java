
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * The type Bod remarks request dto.
 */
@Slf4j
@Getter
@Setter
@Data

public class BodRemarksRequestDTO {
  /**
   * The Va master fk.
   */
  Long vaMasterFk;
  /**
   * The Remarks.
   */
  String remarks;
}
