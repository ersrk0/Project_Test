
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * The type Business pan details response dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BusinessPanDetailsResponseDTO
{
  @NotBlank
  @Schema(description = "PAN number", example = "ABCDE1234F", minLength = 10, maxLength = 10)
  private String pan;

  @Schema(description = "PAN Date", example = "2024-10-09T12:34:56.789Z")
  private Instant panDate;

  @NotBlank
  @Schema(description = "legal Name", example = "John Doe", minLength = 3, maxLength = 255)
  private String legalName;

  @Schema(description = "details last verified at", example = "2019-03-27T10:15:30")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Instant lastVerifiedAt;

  /**
   * Instantiates a new Business pan details response dto.
   *
   * @param pan123 the pan 123
   */
  public BusinessPanDetailsResponseDTO(String pan123) {
  }
}
