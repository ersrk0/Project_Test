
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import lombok.Data;

/**
 * The type Office address response dto.
 */
@Data
public class OfficeAddressResponseDTO {
  private String officeName;
  private String officeAddress;
  private String officeType;
  private String contactNo;
  private String emailId;
  private String gstinNo;
  private String assessAs;

  /**
   * Instantiates a new Office address response dto.
   *
   * @param innovateLabs the innovate labs
   * @param s            the s
   * @param company      the company
   * @param number       the number
   * @param mail         the mail
   * @param s1           the s 1
   * @param textHere     the text here
   */
  public OfficeAddressResponseDTO(String innovateLabs, String s
      , String company, String number, String mail, String s1, String textHere) {
    this.officeName = innovateLabs;
    this.officeAddress = s;
    this.officeType = company;
    this.contactNo = number;
    this.emailId = mail;
    this.gstinNo = s1;
    this.assessAs = textHere;
  }
}

