
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;


import in.gov.gem.app.service.core.entity.TenantBaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * The type Ums profile response dto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class UmsProfileResponseDTO extends TenantBaseEntity
{
  @Schema(description = "prefix", example = "Mr")
  private String prefix;
  @Schema(description = "first name", example = "vivek")
  private String firstName;
  @Schema(description = "middle name", example = "kumar")
  private String middleName;
  @Schema(description = "last name", example = "yadav")
  private String lastName;
  @Schema(description = "gender of user", example = "Male")
  private String gender;
  @Schema(description = "value corresponding to user type ( ex 100:Primary )", example = "100")
  private String userTypeLookup;
  @Schema(description = "username", example = "abc65432")
  private String userName;
  @Schema(description = "user id", example = "S123456")
  private String userId;
  @Schema(description = "value corresponding to status ( ex 100:inactive )", example = "100")
  private String statusLookup;
  @Schema(description = "aadhaar linked mobile number of user", example = "9999999999")
  private String aadhaarMobileNumber;
  @Schema(description = "alternate mobile number of user", example = "9999999998")
  private String altMobileNumber;
  @Schema(description = "email address of user", example = "abc@gmail.com")
  private String emailId;
  @Schema(description = "tenant id of user", example = "e19491fd-c119-48e0-84c6-20741088a9bf")
  private UUID tenantId;

  @Schema(description = "Indicates if Aadhaar is verified", example = "true")
  private Boolean isAadhaarVerified;
  @Schema(description = "Indicates if eSign is verified", example = "true")
  private Boolean isESignVerified;
  @Schema(description = "Indicates if DSC is verified", example = "true")
  private Boolean isDscVerified;
  @Schema(description = "Workflow ID", example = "123456")
  private Long workflowId;
  @Schema(description = "Signer ID", example = "SIGNER123")
  private String signerId;

}
