
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.*;


/**
 * The type Add mobile request dto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class AddMobileRequestDTO
{
  @Schema(description = "mobile number for user's contact", example = "1234567890", minLength = 10, maxLength = 256)
  @NotBlank(message = "Mobile number is required")
  @Pattern(regexp = "^[0]?[6789]\\d{9}$", message = "Invalid mobile number")
  private String mobileNumber;

}
