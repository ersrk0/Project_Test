package in.gov.gem.app.vendorassessment.dto.enums;

import java.util.Objects;

// ... (Category and ProcessedCategory classes remain the same as before) ...

// A helper class for the composite key in the map
public class OriginalCategoryKey {
    private Long originalDbId;
    private String vaId;

    public OriginalCategoryKey(Long originalDbId, String vaId) {
        this.originalDbId = originalDbId;
        this.vaId = vaId;
    }

    // Must implement equals and hashCode for use as a map key
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OriginalCategoryKey that = (OriginalCategoryKey) o;
        return Objects.equals(originalDbId, that.originalDbId) &&
               Objects.equals(vaId, that.vaId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(originalDbId, vaId);
    }

    @Override
    public String toString() {
        return "OriginalCategoryKey{originalDbId=" + originalDbId + ", vaId='" + vaId + "'}";
    }
}