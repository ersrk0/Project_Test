
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import in.gov.gem.app.vendorassessment.dto.enums.AssessmentType;
import lombok.Data;

import java.util.List;

/**
 * The type V assessment request dto.
 */
@Data
public class VAssessmentRequestDTO {
  private String sellerId; // Or VA Id
  private boolean isVAId;
  private String assessAs; // OSP, OEM etc.
  private List<String> categories;
  private AssessmentType assessmentType;
  private boolean isPaymentRequired;
  private boolean isRefundable;
  private boolean physicalAssessmentRequired;
}

