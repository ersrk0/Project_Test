
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Data;

/**
 * The type Validate otp new request dto.
 */
@Data
@Builder
public class ValidateOtpNewRequestDTO
{
  /**
   * Unique identifier for the OTP validation request.
   * Must follow a valid UUID format.
   */
  @NotBlank(message = "referenceId cannot be blank")
  @Schema(description = "Unique identifier for the OTP validation request", example =
          "eab4d8f1-5c68-4a7e-bf3b-b2d50ebd2a7c",minLength = 36, maxLength = 36)
  private String referenceId;

  /**
   * Delivery Channel where the OTP validation is performed (e.g., web, mobile).
   */
  @NotBlank(message = "Delivery Channel cannot be blank")
  @Schema(
          description = "Delivery Channel for the OTP request.\n" +
                  "Possible values:\n" +
                  "- `LCOM000002`: SEND_ON_MOBILE\n" +
                  "- `LCOM000003`: SEND_ON_EMAIL\n" +
                  "- `LCOM000001`: SEND_ON_BOTH",
          example = "LCOM000002",
          maxLength = 10,
          minLength = 10
  )
  private String deliveryChannel;

  /**
   * The actual OTP entered by the user for validation.
   * Cannot be blank.
   */
  @Schema(description = "OTP to validate in the case the OTP type is same for a particular delivery channel", example = "123456", minLength = 6, maxLength = 10)
  private String otp;

  /**
   * The actual OTP entered by the user for validation.
   * Cannot be blank.
   */
  @Schema(description = "OTP to validate in the case the OTP is sent to mobile and OTP type is different", example = "123456", minLength = 6, maxLength = 10)
  private String otpMobile;

  /**
   * The actual OTP entered by the user for validation.
   * Cannot be blank.
   */
  @Schema(description = "OTP to validate in the case the OTP is sent to email and OTP type is different", example = "123456", minLength = 6, maxLength = 10)
  private String otpEmail;


}
