
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */
package in.gov.gem.app.vendorassessment.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

/**
 * The type Send otp response dto.
 */
@Getter
@Builder
@AllArgsConstructor
public class SendOtpResponseDTO
{
  @Schema(description = "Message", example = "OTP Sent Successfully")
  private String message;
  /**
   * Reference id email.
   */
  @Schema(description = "reference id of the user", example = "5150ff985dcd4af89775e93ab31e88c4")
  private String referenceId;

  private Integer resendTimeSeconds;
  private  Integer totalResendAttempt;
  private Integer totalIncorrectAttempt;

}

