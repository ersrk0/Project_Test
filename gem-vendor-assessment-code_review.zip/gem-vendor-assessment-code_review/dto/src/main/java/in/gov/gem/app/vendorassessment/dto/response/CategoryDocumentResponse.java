package in.gov.gem.app.vendorassessment.dto.response;
import in.gov.gem.app.vendorassessment.dto.request.CategoryDocumentDto;
import lombok.Data;

import java.util.List;
@Data
public class CategoryDocumentResponse {
    private String heading;
    private String subHeading;
    private String infoText;
    private boolean isValidityRequired;
    private List<CategoryDocumentDto> documents;

}

