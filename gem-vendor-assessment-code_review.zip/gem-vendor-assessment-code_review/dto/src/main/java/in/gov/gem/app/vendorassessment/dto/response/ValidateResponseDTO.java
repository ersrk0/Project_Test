
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;


/**
 * The type Validate response dto.
 */
@Getter
@AllArgsConstructor
@Builder
public class ValidateResponseDTO
{
    @NotBlank(message="Should not be null or empty")
    @Schema(description = "Message", example = "OTP_SENT_SUCCESSFULLY", minLength = 8, maxLength = 256)
    private String message;

    @NotNull(message="Should not be null or empty")
    @Schema(description = "Otp Validated", example = "true")
    private Boolean otpValidated;

  /**
   * Instantiates a new Validate response dto.
   *
   * @param otpValidated the otp validated
   */
  public ValidateResponseDTO(Boolean otpValidated) {
        this.otpValidated = otpValidated;
    }

}
