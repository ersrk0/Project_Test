
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import lombok.*;

/**
 * The type Authorize detail request dto.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AuthorizeDetailRequestDTO {

    private String organizationName;//VaOrganizationDetail

    private String officeName; //VAOrganizationAddress

    private String officeTypeLookup;//VAOrganizationAddress

    private String officeAddressLine1; //VAOrganizationAddress

    private String officeAddressLine2;//VAOrganizationAddress

    private String officeLandmark;//VAOrganizationAddress

    private String geographyLocationCode;//VAOrganizationAddress

    private String contactNumber;//AuthorizeOemOspDetail

    private String emailId;//AuthorizeOemOspDetail

    private String assessAsLookupType;//VAOrganizationAddress

    private String countryCode; //AuthorizeOemOspDetail

    private String uniqueIdentifyNumber;//AuthorizeOemOspDetail

    private Long vaMgmtFk;//VaOrganizationDetail

    private String authorizePersonName;//AuthorizeOemOspDetail

    private String stdCode;//AuthorizeOemOspDetail

    private Long briefcaseFk;//AuthorizeOemOspDetail
}
