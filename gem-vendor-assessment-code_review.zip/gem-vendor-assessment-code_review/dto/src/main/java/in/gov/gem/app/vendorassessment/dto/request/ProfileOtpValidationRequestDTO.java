
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

/**
 * The type Profile otp validation request dto.
 */
@Data

@Builder
public class ProfileOtpValidationRequestDTO {
  @NotNull
  @Schema(description = "user input otp", example = "123456", minLength = 6, maxLength = 6,
    requiredMode = Schema.RequiredMode.REQUIRED)
  private Long otp;
  @NotBlank
  @Schema(description = "referenceId ", example = "102cbb93-d481-41b8-93ad-ab1f1a3f04f3")
  private String referenceId;
  @Email
  private String email;

  @Schema(description = "Mobile number", example = "9876543210")
  private String mobile;
}
