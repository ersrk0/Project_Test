
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import lombok.Data;

/**
 * Represents the Organisation Details. This is also a POJO.
 */
@Data
public class OrganisationDetailsRequestDTO {
    private String nameOfOrganisation;
    private String organisationType;
    private String organisationSubType;
    private String organisationPAN;
    private String organisationTAN;
    private String cinFcrnLlpinFllpin;
    private String primaryContactNumber;
    private String primaryEmailId;

  /**
   * Instantiates a new Organisation details request dto.
   */
// Constructors
    public OrganisationDetailsRequestDTO() {}

  /**
   * Instantiates a new Organisation details request dto.
   *
   * @param nameOfOrganisation   the name of organisation
   * @param organisationType     the organisation type
   * @param organisationSubType  the organisation sub type
   * @param organisationPAN      the organisation pan
   * @param organisationTAN      the organisation tan
   * @param cinFcrnLlpinFllpin   the cin fcrn llpin fllpin
   * @param primaryContactNumber the primary contact number
   * @param primaryEmailId       the primary email id
   */
  public OrganisationDetailsRequestDTO(String nameOfOrganisation, String organisationType, String organisationSubType,
                                         String organisationPAN, String organisationTAN, String cinFcrnLlpinFllpin,
                                         String primaryContactNumber, String primaryEmailId) {
        this.nameOfOrganisation = nameOfOrganisation;
        this.organisationType = organisationType;
        this.organisationSubType = organisationSubType;
        this.organisationPAN = organisationPAN;
        this.organisationTAN = organisationTAN;
        this.cinFcrnLlpinFllpin = cinFcrnLlpinFllpin;
        this.primaryContactNumber = primaryContactNumber;
        this.primaryEmailId = primaryEmailId;
    }


}