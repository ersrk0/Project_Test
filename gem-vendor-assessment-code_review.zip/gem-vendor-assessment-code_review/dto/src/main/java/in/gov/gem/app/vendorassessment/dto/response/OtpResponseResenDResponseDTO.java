
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

/**
 * The type Otp response resen d response dto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OtpResponseResenDResponseDTO {

  @Schema(description = "Response Message", example = "Request has been processed successfully")
  private String message;

  @Schema(description = "Cooldown period before next OTP can be sent", example = "60")
  private Integer resendTimeSeconds;

  @Schema(description = "Total number of resend attempts", example = "3", requiredMode = Schema.RequiredMode.REQUIRED)
  private Integer totalResendAttempt;

  @Schema(description = "Total number of incorrect attempts", example = "1", requiredMode = Schema.RequiredMode.REQUIRED)
  private Integer totalIncorrectAttempt;

  @Schema(description = "Indicates if the resend was successful", example = "true", requiredMode = Schema.RequiredMode.REQUIRED)
  private Boolean resendSuccessful;

}
