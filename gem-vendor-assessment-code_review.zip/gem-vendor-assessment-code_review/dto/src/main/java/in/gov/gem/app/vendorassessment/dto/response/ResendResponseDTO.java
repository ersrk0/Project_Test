
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * The type Resend response dto.
 */
@Builder
@Getter
@Setter
public class ResendResponseDTO
{
  /**
   * The time (in seconds) until the OTP can be resent.
   * This represents the cooldown period before a user can request another OTP.
   */
  @Schema(description = "The time (in seconds) until the OTP can be resent", example = "30", required = true)
  private int resendTimeSeconds;

  /**
   * Total number of times the OTP has been resent.
   * Helps in tracking how many resend attempts have been made.
   */
  @Schema(description = "Total number of resend attempts made", example = "5", required = true)
  private int totalResendAttempt;

  /**
   * Total number of incorrect OTP attempts made by the user.
   * Used for tracking invalid OTP submissions.
   */
  @Schema(description = "Total number of incorrect attempts made", example = "3", required = true)
  private int totalIncorrectAttempt;

  /**
   * Indicates whether the OTP resend attempt was successful.
   * If true, the user successfully received a new OTP.
   */
  @Schema(description = "Message to be sent once otp has been sent to email id",
    example = "Otp sent successfully")
  private String message;

}
