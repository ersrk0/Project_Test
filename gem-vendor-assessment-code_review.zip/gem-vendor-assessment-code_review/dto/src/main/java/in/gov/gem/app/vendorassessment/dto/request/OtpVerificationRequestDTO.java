
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


/**
 * The type Otp verification request dto.
 */
@Data
@Getter
@Setter
public class OtpVerificationRequestDTO
{
  /**
   * Reference id.
   */
  @Schema(description = "reference id of the user", example = "e1723c43e53b4723aafcb15350018d53",
    minLength = 32, maxLength = 512)
  private String referenceId;

  /**
   * Otp
   */
  @Schema(description = "otp number", example = "123456",maxLength = 6,minLength = 6)
  @Pattern(regexp = "[0-9]{6}$", message = "Invalid otp")
  private String otp;

}
