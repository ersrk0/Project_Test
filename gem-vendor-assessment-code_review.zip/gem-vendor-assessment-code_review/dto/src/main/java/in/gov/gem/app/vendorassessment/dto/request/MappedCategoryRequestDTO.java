
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;


import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.List;

/**
 * The type Mapped category request dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MappedCategoryRequestDTO {
    private String id; // e.g., "IT (5)" or "Computer Appliances (15)"
    private String name; // e.g., "IT" or "Computer Appliances"
    private int count; // e.g., 5, 15, 35
    private int level; // e.g., 1, 2, 3
    private List<MappedCategoryRequestDTO> subCategories; // For nested categories like "Computer Appliances (15) Level 2" -> "Computer (35) Level 3"
}
