
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Gstin client request dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GstinClientRequestDTO {
  @Schema(description = "GSTIN number", example = "22AAAAA0000A1Z5", requiredMode = Schema.RequiredMode.REQUIRED)
  @Pattern(regexp = "^[0-9]{2}[A-Z]{3}[ABCFGHLJPTF]{1}[A-Z]{1}[0-9]{4}[A-Z]{1}[1-9]{1}[A-Z0-9]{2}$", message = "Invalid GSTIN format")
  private String gstin;

  @Schema(description = "Action to be performed", example = "VERIFY", requiredMode = Schema.RequiredMode.REQUIRED)
  private String action;

  @Schema(description = "Project ID", example = "PVT_ORG_MGMT", requiredMode = Schema.RequiredMode.REQUIRED)
  private String projectId;

  @Schema(description = "User transaction ID", example = "123e4567-e89b-12d3-a456-426614174000", requiredMode = Schema.RequiredMode.REQUIRED)
  private String userTxnId;
}
