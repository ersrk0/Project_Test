
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;
import lombok.*;

import java.util.List;

/**
 * The type Non compliance response.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class NonComplianceNewResponseDTO {
  /**
   * The type Pair.
   *
   * @param <F> the type parameter
   * @param <S> the type parameter
   */
  public static class Pair<F, S> {
    /**
     * The Field name.
     */
    public final F fieldName;
    /**
     * The Value.
     */
    public final S value;

    /**
     * Instantiates a new Pair.
     *
     * @param fieldName the field name
     * @param value     the value
     */
    public Pair(F fieldName, S value) {
            this.fieldName = fieldName;
            this.value = value;
        }

    /**
     * Of pair.
     *
     * @param <F>       the type parameter
     * @param <S>       the type parameter
     * @param fieldName the field name
     * @param value     the value
     * @return the pair
     */
    public static <F, S> Pair<F, S> of(F fieldName, S value) {
            return new Pair<>(fieldName, value);
        }
    }
    private List<Pair<String,String>> nonComplianceOpenFields;
    private List<Pair<String,String>> nonComplianceClosedFields;
}