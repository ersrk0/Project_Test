
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Organization details response dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrganizationDetailsResponseDTO {

    private long id;
    private OrganizationType organizationType;
    private SubOrganizationType subOrganizationType;
    private String organizationName;
    private String dateOfIncorporation;
    private String entityNumber;
    private Role role;
    private boolean isFirmAndNoLlpin;
    private long gemPvtOrgId;
    private String traderId;

  /**
   * The type Organization type.
   */
  @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class OrganizationType {
        private String id;
        private String name;
        private String value;
        private String description;

    }

  /**
   * The type Sub organization type.
   */
  @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class SubOrganizationType {
        private String id;
        private String name;
        private String value;
        private String description;

    }

  /**
   * The type Role.
   */
  @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Role {
        private String id;
        private String name;
        private String value;
        private String description;
    }
}