
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */
package in.gov.gem.app.vendorassessment.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO for returning Manufacturing Address data.
 * Includes mapped categories.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryManufacturingAddressResponseDTO {
  private String id;
  private String officeName;
  private String officeAddress;
  private String emailId;
  private String gstInNo;
    private String officeType;
  private String mobile;
  private List<CategoryNewResponseDTO> mappedCategories; // List of full category DTOs
  private String status;

  /**
   * Constructor for ManufacturingAddress.
   * Note: The original request had 'city' repeated twice at the end of the constructor call.
   * Assuming this was a typo, 'city' is included once in the constructor parameters.
   *
   * @param officeName The name of the office.
   * @param gstin The GSTIN.
   * @param mobile The mobile number.
   */
  public CategoryManufacturingAddressResponseDTO(
          String officeName,
          String officeAddress,
          String officeType,
            String emailId,
          String gstin,
          String mobile) {
    this.officeName = officeName;
    this.officeAddress = officeAddress;
    this.officeType = officeType;
    this.emailId = emailId;
    this.gstInNo = gstin;
    this.mobile = mobile;
  }

  public CategoryManufacturingAddressResponseDTO(String id, String officeName,
                                             String officeAddress, String officeType,
                                             String emailId, String gstin,
                                             String mobile,
                                         List<CategoryNewResponseDTO> collect) {
    this.id = id;
    this.officeName = officeName;
    this.officeAddress = officeAddress;
    this.officeType = officeType;
    this.emailId = emailId;
    this.gstInNo = gstin;
    this.mobile = mobile;
    this.mappedCategories=collect;

  }


}
