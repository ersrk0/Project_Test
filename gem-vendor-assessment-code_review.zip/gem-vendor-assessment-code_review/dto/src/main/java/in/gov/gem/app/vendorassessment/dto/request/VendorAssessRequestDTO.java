
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;


import lombok.*;

import java.time.Instant;


/**
 * The type Vendor assess request dto.
 */
@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class VendorAssessRequestDTO {
    private Long id;

    private String vaNumber;

    private Long userFk;

    private Long pvtOrgMasterFk;

    private Long briefCaseFk;

    private String vaStatusLookUp;

    private Long paymentFk;

    private String applyAsLookUp;

    private String assessorStatusLookUp;

    private Boolean isExemption;

    private String typeLookUp;

    private Instant validUpTo;

    private Boolean needDashboard;

    private String dashboardTypeLookUp;

    private Boolean isContractManufacturer;

    private String subStatusLookUp;
}
