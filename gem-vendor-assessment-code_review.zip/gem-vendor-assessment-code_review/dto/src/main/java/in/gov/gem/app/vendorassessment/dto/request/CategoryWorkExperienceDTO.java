/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for creating/updating Work Experience entries.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryWorkExperienceDTO {
    private String organisationType;
    private String organisation;
    private String ministry;
    private String department;
    private String officeZone;
    private String authName;
    private String authContact;
    private String authEmail;
    private double orderValue;
    private double acceptedValue;
    private int orderQuantity;
    private int suppliedQuantity;
    private String itemSupplied;
    private String orderNumber;
    private String contractNumber;
}
