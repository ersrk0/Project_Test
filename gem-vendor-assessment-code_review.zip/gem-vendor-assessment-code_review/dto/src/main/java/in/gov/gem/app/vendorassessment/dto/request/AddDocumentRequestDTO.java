
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.Instant; // For UTC timestamp

/**
 * DTO representing the request body for adding a new document.
 * This object will carry the metadata associated with the uploaded document.
 */
@Data // Lombok annotation to generate getters, setters, equals, hashCode, and toString
@NoArgsConstructor // Lombok annotation to generate a no-argument constructor
@AllArgsConstructor // Lombok annotation to generate an all-argument constructor
public class AddDocumentRequestDTO {

    // Details from "License/Certificate details" input
    private String licenseCertificateDetails;

    // Details from "Details of issuing authority" input
    private String issuingAuthorityDetails;

    // "Valid Upto" date, expected in ISO 8601 UTC format (e.g., "2025-12-31T23:59:59Z")
    // Jackson will automatically handle deserialization from String to Instant.
    private Instant validUpto;

    // "Remarks" text input
    private String remarks;

    // Note: The file itself will be handled as a MultipartFile in the controller,
    // not directly within this DTO for multipart/form-data requests.
}
