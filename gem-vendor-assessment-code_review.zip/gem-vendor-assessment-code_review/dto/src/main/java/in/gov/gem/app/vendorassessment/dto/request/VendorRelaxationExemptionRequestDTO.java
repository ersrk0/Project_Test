
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import lombok.*;

import java.sql.Timestamp;

/**
 * The type Vendor relaxation exemption request dto.
 */
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VendorRelaxationExemptionRequestDTO
{
  private String vendorAssessmentFk;

  private String licenseDetail;

  private String relaxationTypeLookup;

  private Timestamp expiryDate;

  private String statusLookup;

  private String issuingAuthority;

  private Timestamp expiredAt;

  private Long briefcaseFk;

}
