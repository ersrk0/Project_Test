
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * The type Bank address response dto.
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BankAddressResponseDTO
{
  @Schema(description = "bank branch ID (primary key) to serialize data entries", example = "21")
  private Long id;

  @Schema(description = "Denotes the ifsc-code of mentioned data code.", example = "MAHB0000001")
  private String ifscCode;

  @Schema(description = "Denotes the data code of ifsc-code", example = "DC2")
  private String dataCode;

  @Schema(description = "Denotes the bank branch name (as per the locality situated in)", example = "BAJIRAO ROAD")
  private String branchName;

  @Schema(description = "Denotes the MICR code of the bank branch", example = "411014010",
    minLength = 9, maxLength = 9)
  private String micrCode;

  @Schema(description = "Denotes the branch code of the bank branch to distinguish the bank branch",
    example = "BR001", minLength = 4, maxLength = 15)
  private String branchCode;

  @Schema(description = "Specifies the bank branch address.", example = "Janmangal, 1177, Budhwar Peth Pune 411 002")
  private String branchAddress;

  @Schema(description = "Specifies the district bank branch is located in.", example = "Pune")
  private String district;

  @Schema(description = "Specifies the URL to bank website.", example = "https://bankofmaharashtra.in/")
  private String bankUrl;

  @Schema(description = "Specifies the name of the bank.", example = "Bank Of Maharashtra")
  private String bankName;
}
