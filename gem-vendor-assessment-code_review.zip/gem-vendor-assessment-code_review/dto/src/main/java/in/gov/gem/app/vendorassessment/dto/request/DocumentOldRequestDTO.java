
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;



import lombok.Data;

/**
 * The type Document request.
 */
@Data
public class DocumentOldRequestDTO {
  private String name;
  private String type;
  private String issuingAuthority;
  private String remarks;
  private double sizeInMB;
  private String validUpto;
  private String criteria;


  // Getters and setters
  // ...
}