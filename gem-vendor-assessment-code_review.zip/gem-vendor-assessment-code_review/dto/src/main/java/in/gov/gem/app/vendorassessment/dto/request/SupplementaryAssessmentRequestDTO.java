
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * The type Supplementary assessment request dto.
 */
@Data
@Getter
@Setter
public class SupplementaryAssessmentRequestDTO {

    private String vendorId;

    private String previousAssessmentId;
    private String changeRequestType;  // e.g., "Organization Details", "Experience Certificate"
    private List<DocumentNewRequestDTO> updatedDocuments;
    private String updatedDetails;


  /**
   * Instantiates a new Supplementary assessment request dto.
   */
// Default constructor
    public SupplementaryAssessmentRequestDTO() {
        // TODO document why this constructor is empty
    }

    // Getters and Setters

    @Override
    public String toString() {
        return "SupplementaryAssessmentRequest{" +
                "vendorId=" + vendorId +
                ", previousAssessmentId='" + previousAssessmentId + '\'' +
                '}';
    }
}
