
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */
package in.gov.gem.app.vendorassessment.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Address response dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AddressResponseDTO {
  @Schema(description = "Building name", example = "Sunset Apartments", requiredMode = Schema.RequiredMode.REQUIRED)
  private String bnm;

  @Schema(description = "Street", example = "MG Road", requiredMode = Schema.RequiredMode.REQUIRED)
  private String st;

  @Schema(description = "Locality", example = "Downtown", requiredMode = Schema.RequiredMode.REQUIRED)
  private String loc;

  @Schema(description = "Building number", example = "123", requiredMode = Schema.RequiredMode.REQUIRED)
  private String bno;

  @Schema(description = "State code", example = "KA", requiredMode = Schema.RequiredMode.REQUIRED)
  private String stcd;

  @Schema(description = "Floor number", example = "5", requiredMode = Schema.RequiredMode.REQUIRED)
  private String flno;

  @Schema(description = "Latitude", example = "12.9715987", requiredMode = Schema.RequiredMode.REQUIRED)
  private double lt;

  @Schema(description = "Longitude", example = "77.594566", requiredMode = Schema.RequiredMode.REQUIRED)
  private double lg;

  @Schema(description = "Pincode", example = "560001", requiredMode = Schema.RequiredMode.REQUIRED)
  private String pncd;
}
