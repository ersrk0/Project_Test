
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import lombok.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.UUID;

/**
 * The type Otp validate request dto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class OTPValidateRequestDTO {

    @NotNull(message = "Reference ID should not be null")
    private UUID referenceId;

    @NotBlank(message = "New email should not be blank")
    @Email(message = "Invalid email format")
    private String newEmail;

    @NotBlank(message = "Functional area should not be blank")
    private String functionalArea;

    @NotBlank(message = "OTP should not be blank")
    private String otp;
}
