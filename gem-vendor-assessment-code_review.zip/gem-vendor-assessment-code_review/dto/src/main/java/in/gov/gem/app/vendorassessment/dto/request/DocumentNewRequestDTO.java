
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import lombok.Data;

/**
 * The type Document new request dto.
 */
@Data
public class DocumentNewRequestDTO {
  private String documentName;
  private String documentType;
  private String fileUrl;
  private String documentSize; // Formatted string, e.g., "1.5 MB"
  private String documentId;
  private boolean isUploaded;


  /**
   * Instantiates a new Document new request dto.
   *
   * @param originalFilename the original filename
   * @param contentType      the content type
   * @param size             the size
   * @param documentType     the document type
   * @param fileStorageUrl   the file storage url
   */
  public DocumentNewRequestDTO(String originalFilename,
                               String contentType,
                               long size,
                               String documentType,
                               String fileStorageUrl) {

    this.documentName = originalFilename;
    this.documentType = contentType;
    this.fileUrl = fileStorageUrl + "/" + originalFilename;
    this.documentSize = String.valueOf(size);
    this.documentId = originalFilename; // Assuming documentId is the same as the filename

  }


  // Getters and Setters
}

