package in.gov.gem.app.vendorassessment.dto.request;

import in.gov.gem.app.vendorassessment.dto.response.QuestionResponseDto;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Data
public class SaveResponsesRequestDto {
    @Valid
    @NotEmpty(message = "Responses list cannot be empty")
    private List<QuestionResponseDto> responses;
}