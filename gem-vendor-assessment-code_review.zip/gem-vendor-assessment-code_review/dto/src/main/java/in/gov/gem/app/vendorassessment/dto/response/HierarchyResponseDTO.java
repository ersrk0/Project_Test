
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;
import java.util.Map;

/**
 * The type Hierarchy response dto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HierarchyResponseDTO {
  /**
   * Contains Label
   */
  @Schema(description = "label of the user", example = "DEPARTMENT")
  private String label;
  /**
   * List of entities
   */
  @Schema(description = "Hierarchy Details", example = "[\n" +
    "            {\n" +
    "                \"name\": \"Department Central Autonomous 3\",\n" +
    "                \"id\": \"17\"\n" +
    "            },\n" +
    "            {\n" +
    "                \"name\": \"Department Central Autonomous 8\",\n" +
    "                \"id\": \"22\"\n" +
    "            }\n" +
    "        ]")
  private List<Map<String, String>> entities;
  /**
   * Provide post
   */
  @Schema(description = "Define post of user", example = "GeM Registering Authority")
  private String post;

  @Schema(description = "Define key of user", example = "key")
  private String key;

}

