package in.gov.gem.app.vendorassessment.dto.request;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.time.Instant;
import java.time.LocalDate;

@Data
public class CatDocumentUploadRequestDto {
    private MultipartFile file;
    private String documentType;
    private Instant validUpto; // Using LocalDate for simpler form input
}