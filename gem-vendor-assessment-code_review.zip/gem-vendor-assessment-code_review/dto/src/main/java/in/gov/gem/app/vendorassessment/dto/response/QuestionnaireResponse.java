package in.gov.gem.app.vendorassessment.dto.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
  public class QuestionnaireResponse {
    private Long id;
    private Long questionId; // Link to question by ID
    private Long categoryId; // Link to category by ID
    private String answer;
    private LocalDateTime responseDate;
  }

