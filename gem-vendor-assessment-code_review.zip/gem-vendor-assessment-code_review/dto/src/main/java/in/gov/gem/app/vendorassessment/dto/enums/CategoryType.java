package in.gov.gem.app.vendorassessment.dto.enums;


/**
 * Defines the different types of categories.
 */
public enum CategoryType {
    PRODUCT,
    SERVICE,
    FA; //

    public static CategoryType fromString(String input) {
       if (input == null || input.isBlank()) {
        return CategoryType.PRODUCT;
    }
 
    try {
        return CategoryType.valueOf(input.toUpperCase());
    } catch (IllegalArgumentException e) {
        return CategoryType.PRODUCT;
    }
}
}

