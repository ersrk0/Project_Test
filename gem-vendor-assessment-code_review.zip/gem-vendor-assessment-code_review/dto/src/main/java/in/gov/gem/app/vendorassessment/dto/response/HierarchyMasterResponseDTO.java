
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;
import java.util.Map;

/**
 * The type Hierarchy master response dto.
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HierarchyMasterResponseDTO
{
  /**
   * contains label
   */
  @Schema(description = "Contains Organisation Type", example = "ORGANISATION TYPE")
  private String label;
  /**
   * list of entities
   */
  @Schema(description = "Hierarchy Details", example = "[\n" +
    "            {\n" +
    "                \"name\": \"Central Government\",\n" +
    "                \"id\": \"1\"\n" +
    "            },\n" +
    "            {\n" +
    "                \"name\": \"Central PSU\",\n" +
    "                \"id\": \"2\"\n" +
    "            },\n" +
    "            {\n" +
    "                \"name\": \"Central Autonomous\",\n" +
    "                \"id\": \"3\"\n" +
    "            }\n" +
    "        ]")
  private List<Map<String, String>> entities;
}

