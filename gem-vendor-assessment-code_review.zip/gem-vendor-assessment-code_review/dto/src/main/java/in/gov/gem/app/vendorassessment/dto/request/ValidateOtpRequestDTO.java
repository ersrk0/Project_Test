
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Validate otp request dto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ValidateOtpRequestDTO {

  @NotNull(message = "Should not be null or empty")
  @Schema(description = "ReferenceId for the user.", example = "1dcbc770-50b4-4162-9443-e8e4e1f25005 ", minLength = 36, maxLength = 36)
  private String referenceId;


  @NotBlank(message = "Should not be null or empty")
  @Schema(description = "OTP to validate the request.", example = "123456", minLength = 6, maxLength = 6)
  private String otp;

  @NotBlank(message = "Should not be null or empty")
  @Schema(description = "OTP to validate the request.", example = "123456", minLength = 6, maxLength = 6)
  private String otpEmail;

  private String otpMobile;

  private String deliveryChannel;


}


//---------adding deliveryChannel--------------

