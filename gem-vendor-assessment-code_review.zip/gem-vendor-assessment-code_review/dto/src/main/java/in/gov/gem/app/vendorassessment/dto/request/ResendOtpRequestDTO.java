
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */
package in.gov.gem.app.vendorassessment.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.util.UUID;

/**
 * The type Resend otp request dto.
 */
@Data
@Builder
public class ResendOtpRequestDTO {

  /**
   * Unique identifier for the OTP resend request.
   * Must be a valid UUID format.
   */

  private String referenceId;

  /**
   * Delivery Channel from which the OTP request is initiated.
   * Must not be blank.
   */
  @NotBlank(message = "Delivery Channel cannot be blank")
  @Schema(
          description = "Delivery Channel for the OTP request.\n" +
                  "Possible values:\n" +
                  "- `LCOM000002`: SEND_ON_MOBILE\n" +
                  "- `LCOM000003`: SEND_ON_EMAIL\n" +
                  "- `LCOM000001`: SEND_ON_BOTH",
          example = "LCOM000001",
          maxLength = 10
  )
  private String deliveryChannel;

  /**
   * Converts the referenceId string into a UUID object.
   *
   * @return UUID representation of referenceId.
   */
  public UUID getReferenceId() {
    return UUID.fromString(referenceId);
  }

}