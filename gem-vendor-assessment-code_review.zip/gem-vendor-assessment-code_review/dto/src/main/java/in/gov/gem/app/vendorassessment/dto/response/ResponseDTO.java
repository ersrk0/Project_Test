
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

/**
 * The type Response dto.
 */
public class ResponseDTO {

    private String status;     // Status of the response (e.g., success, error)
    private String message;    // Message providing details about the response
    private Object data;       // Data that is sent with the response (could be assessment ID or any other relevant object)

  /**
   * Instantiates a new Response dto.
   */
// Default constructor
    public ResponseDTO() {
    }

  /**
   * Instantiates a new Response dto.
   *
   * @param status  the status
   * @param message the message
   * @param data    the data
   */
// Constructor with parameters
    public ResponseDTO(String status, String message, Object data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }

  /**
   * Instantiates a new Response dto.
   *
   * @param status  the status
   * @param message the message
   */
  public ResponseDTO(String status, String message) {
        this.status=status;
        this.message=message;
    }

    // Getters and Setters

  /**
   * Gets status.
   *
   * @return the status
   */
  public String getStatus() {
        return status;
    }

  /**
   * Sets status.
   *
   * @param status the status
   */
  public void setStatus(String status) {
        this.status = status;
    }

  /**
   * Gets message.
   *
   * @return the message
   */
  public String getMessage() {
        return message;
    }

  /**
   * Sets message.
   *
   * @param message the message
   */
  public void setMessage(String message) {
        this.message = message;
    }

  /**
   * Gets data.
   *
   * @return the data
   */
  public Object getData() {
        return data;
    }

  /**
   * Sets data.
   *
   * @param data the data
   */
  public void setData(Object data) {
        this.data = data;
    }

    // Optional: Override toString() for better output formatting
    @Override
    public String toString() {
        return "Response{" +
                "status='" + status + '\'' +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }
}

