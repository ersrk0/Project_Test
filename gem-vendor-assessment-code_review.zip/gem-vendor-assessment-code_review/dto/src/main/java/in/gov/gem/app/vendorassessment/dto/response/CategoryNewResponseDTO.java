
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Data Transfer Object (DTO) for outgoing Category responses.
 * Includes children for hierarchical representation.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryNewResponseDTO {
  private Long id;
  private String name;
  private String description;
  private String type;
  private String vaId;
  private Long parentId;
  private int level;
  private List<CategoryNewResponseDTO> children; // List of child categories
  private String status; // For indicating operation status

    public CategoryNewResponseDTO(long l, String laptops, String desc, long l1, String name, String active) {
        this.id = l;
        this.name = laptops;
        this.description = desc;
        this.parentId = l1;
        this.level = 0; // Default level, can be set as needed
        this.status = active; // Status can be "active", "inactive", etc.
    }

    public CategoryNewResponseDTO(Long id, Object o, Object o1, Object o2, int i, Object o3, String deleted) {
        this.id = id;
        this.name = o.toString();
        this.description = o1.toString();
        this.type = o2.toString();
        this.parentId = (Long) o3;
        this.level = i;
        this.status = deleted; // Status can be "active", "inactive", etc.
    }
}
