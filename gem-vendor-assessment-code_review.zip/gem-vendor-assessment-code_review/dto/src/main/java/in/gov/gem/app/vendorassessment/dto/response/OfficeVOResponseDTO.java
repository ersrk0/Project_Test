
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;

import static in.gov.gem.app.constant.RegexConstants.*;

/**
 * The type Office vo response dto.
 */
@Data
@Builder
public class OfficeVOResponseDTO {
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Long id;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String name;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String typeLookup;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Boolean gstnFlag;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String gstn;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String taxpayerTypeLookup;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String phoneNumber;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String additionalPhoneNumber;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String landlineNumber;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String businessEmail;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String additionalEmail;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String pincodeLookup;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String officeAddress;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String flatNumber;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String village;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String street;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String locality;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String countryCode;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String stdCode;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String tenantId;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Instant gstnVerifiedAt;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Boolean businessEmailVerified;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Boolean phoneNumberVerified;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonFormat(pattern = UTC_FORMAT, timezone = "UTC")
  private Instant phoneNumberVerifiedAt;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonFormat(pattern = UTC_FORMAT, timezone = "UTC")
  private Instant businessEmailVerifiedAt;
}
