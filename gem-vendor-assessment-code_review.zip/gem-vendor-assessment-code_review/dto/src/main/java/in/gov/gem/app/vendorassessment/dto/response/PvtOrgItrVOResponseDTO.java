
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * The type Pvt org itr vo response dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class PvtOrgItrVOResponseDTO
{
  private Long id;
  private String itrType;
  private String assessmentYear;
  private String ackNo;
  private BigDecimal profit;
  private BigDecimal sales;
  private String status;
}
