
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Message response dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MessageResponseDTO
{
  /**
   * String response 1
   */
  @Schema(description = "String response 1", example = "Request sent successfully")
  private String message1;
  /**
   * String response 2
   */
  @Schema(description = "String response 2", example = "You will receive eamil on " +
    "gaurav@delhi.gov.in once request is approved")
  private String message2;
}
