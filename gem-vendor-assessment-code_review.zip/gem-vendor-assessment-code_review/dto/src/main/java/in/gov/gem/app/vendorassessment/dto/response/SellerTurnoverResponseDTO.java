
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * The type Seller turnover response dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class SellerTurnoverResponseDTO
{
  private List<PvtOrgItrVOResponseDTO> sellerItrDetails;
  private BigDecimal turnoverBySellerId;
}
