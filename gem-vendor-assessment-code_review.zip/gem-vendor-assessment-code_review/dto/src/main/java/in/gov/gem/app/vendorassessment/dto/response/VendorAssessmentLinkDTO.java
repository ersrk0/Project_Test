
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;


/**
 * The type Vendor assessment link dto.
 */
public class VendorAssessmentLinkDTO {

    private String link;
    private String description;

  /**
   * Instantiates a new Vendor assessment link dto.
   *
   * @param link        the link
   * @param description the description
   */
// Constructor
    public VendorAssessmentLinkDTO(String link, String description) {
        this.link = link;
        this.description = description;
    }

  /**
   * Gets link.
   *
   * @return the link
   */
// Getters and Setters
    public String getLink() {
        return link;
    }

  /**
   * Sets link.
   *
   * @param link the link
   */
  public void setLink(String link) {
        this.link = link;
    }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
        return description;
    }

  /**
   * Sets description.
   *
   * @param description the description
   */
  public void setDescription(String description) {
        this.description = description;
    }
}
