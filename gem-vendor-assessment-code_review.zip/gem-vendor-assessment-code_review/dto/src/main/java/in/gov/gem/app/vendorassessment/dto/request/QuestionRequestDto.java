/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;



import lombok.Data;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@Data
public class QuestionRequestDto {
    private Long questionId; // Null for creation, provided for update

    @NotBlank(message = "Question text cannot be empty")
    private String questionText;

    private String subHeading;

    @NotBlank(message = "Question type cannot be empty")
    @Pattern(regexp = "boolean|text|number|select", message = "Question type must be one of: boolean, text, number, select")
    private String questionType;

    @NotNull(message = "Is required flag cannot be null")
    private Boolean isRequired;

    private String associatedInfoMessage; // Optional info message
}
