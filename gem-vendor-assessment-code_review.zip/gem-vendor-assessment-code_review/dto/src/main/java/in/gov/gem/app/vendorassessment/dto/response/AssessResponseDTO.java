
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Assess response dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AssessResponseDTO {
    private Long id;
    private String applyAsLookUp;
    private String vaNumber;
    private Boolean brandRequest;
    private String brandDetail;
    private Boolean isContractManufacturer;
}
