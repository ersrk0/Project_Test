
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * The type Tan details vo response dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TanDetailsVOResponseDTO
{
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private long id;
  @JsonInclude(JsonInclude.Include.NON_NULL)
//  private Boolean isTan;
//  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String tan;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String tanName;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Instant dateOnTan;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Boolean tanVerified;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String statusLookup;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Instant tanVerifiedTime;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String pan;

}
