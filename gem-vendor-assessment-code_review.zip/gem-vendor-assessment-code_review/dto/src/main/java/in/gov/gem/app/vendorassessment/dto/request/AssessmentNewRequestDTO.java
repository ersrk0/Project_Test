
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;


import lombok.Data;

/**
 * Represents a Supplementary Assessment Request in the system.
 * This class is a POJO (Plain Old Java Object) for in-memory storage.
 */
@Data
public class AssessmentNewRequestDTO {
    private String vaId; // VA ID as shown in the form, e.g., VAE-123036012513115
    private boolean organizationChangeRequested;
    private boolean experienceDocumentsChangeRequested;
    private boolean licenseDocumentChangeRequested;
   }
