
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;


/**
 * The type Relaxation criteria response.
 */
public class RelaxationCriteriaResponseDTO {
  private boolean accepted;
  private String message;

  /**
   * Instantiates a new Relaxation criteria response.
   *
   * @param accepted the accepted
   * @param message  the message
   */
  public RelaxationCriteriaResponseDTO(boolean accepted, String message) {
    this.accepted = accepted;
    this.message = message;
  }

  /**
   * Is accepted boolean.
   *
   * @return the boolean
   */
// Getters and setters
  public boolean isAccepted() {
    return accepted;
  }

  /**
   * Sets accepted.
   *
   * @param accepted the accepted
   */
  public void setAccepted(boolean accepted) {
    this.accepted = accepted;
  }

  /**
   * Gets message.
   *
   * @return the message
   */
  public String getMessage() {
    return message;
  }

  /**
   * Sets message.
   *
   * @param message the message
   */
  public void setMessage(String message) {
    this.message = message;
  }
}
