
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO for returning Work Experience data.
 * Includes mapped categories.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryWorkExperienceResponseDTO {
    private String id;
    private String organisationType;
    private String organisation;
    private String ministry;
    private String department;
    private String officeZone;
    private String authName;
    private String authContact;
    private String authEmail;
    private double orderValue;
    private double acceptedValue;
    private int orderQuantity;
    private int suppliedQuantity;
    private String itemSupplied;
    private String orderNumber;
    private String contractNumber;
    private List<CategoryNewResponseDTO> mappedCategories; // List of full category DTOs
    private String status;

    public  CategoryWorkExperienceResponseDTO(String id, String organisationType, String department
            , String officeZone, String contractNumber, String authEmail, String itemSupplied
            , int orderQuantity, double orderValue, String orderNumber, double acceptedValue, String ministry, String organisation, String status, List<CategoryNewResponseDTO> mappedCategories) {
        this.id = id;
        this.organisationType = organisationType;
        this.department = department;
        this.officeZone = officeZone;
        this.contractNumber = contractNumber;
        this.authEmail = authEmail;
        this.itemSupplied = itemSupplied;
        this.orderQuantity = orderQuantity;
        this.orderValue = orderValue;
        this.orderNumber = orderNumber;
        this.acceptedValue = acceptedValue;
        this.ministry = ministry;
        this.organisation = organisation;
        this.status = status;
        this.mappedCategories= mappedCategories;
    }

    public CategoryWorkExperienceResponseDTO(String id, String status) {
        this.id=id;
        this.status=status;
    }
}
