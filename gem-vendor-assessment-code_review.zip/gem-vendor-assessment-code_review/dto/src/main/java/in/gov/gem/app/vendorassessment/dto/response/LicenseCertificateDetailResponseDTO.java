
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.sql.Timestamp;


/**
 * The type License certificate detail response dto.
 */
@Data
@AllArgsConstructor
public class LicenseCertificateDetailResponseDTO {
  private String certificateNumber;
  private String type;
  private String issuingAuthority;
  private Timestamp expiryDate;
  private String status;

  /**
   * Instantiates a new License certificate detail response dto.
   */
  public LicenseCertificateDetailResponseDTO() {

  }
}
