
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Gstin client response dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GstinClientResponseDTO {
  @Schema(description = "State jurisdiction code", example = "STJ123", requiredMode = Schema.RequiredMode.REQUIRED)
  private String stjCd;

  @Schema(description = "Legal name of the business", example = "ABC Pvt Ltd", requiredMode = Schema.RequiredMode.REQUIRED)
  private String lgnm;

  @Schema(description = "State jurisdiction", example = "State Jurisdiction", requiredMode = Schema.RequiredMode.REQUIRED)
  private String stj;

  @Schema(description = "Duty", example = "Duty Description", requiredMode = Schema.RequiredMode.REQUIRED)
  private String dty;

  @Schema(description = "Cancellation date", example = "2023-01-01", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  private String cxdt;

  @Schema(description = "GSTIN", example = "22AAAAA0000A1Z5", requiredMode = Schema.RequiredMode.REQUIRED)
  private String gstin;

  @Schema(description = "E-invoice status", example = "Active", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  private String einvoiceStatus;

  @Schema(description = "Nature of business activities", example = "[\"Retail\", \"Wholesale\"]", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  private List<String> nba;

  @Schema(description = "Last update date", example = "2023-01-01", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  private String lstupdt;

  @Schema(description = "Registration date", example = "2023-01-01", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  private String rgdt;

  @Schema(description = "Constitution of business", example = "Private Limited Company", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  private String ctb;

  @Schema(description = "Status", example = "Active", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  private String sts;

  @Schema(description = "Central jurisdiction code", example = "CTJ123", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  private String ctjCd;

  @Schema(description = "Central jurisdiction", example = "Central Jurisdiction", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  private String ctj;

  @Schema(description = "Trade name", example = "ABC Trade", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  private String tradeNam;

  @Schema(description = "Additional addresses", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  private List<AddressWrapperResponseDTO> adadr;

  @Schema(description = "Principal address", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  private AddressWrapperResponseDTO pradr;
}
