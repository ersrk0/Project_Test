
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

/**
 * The type Option response dto.
 */
public class OptionResponseDTO {
  private Long optionId;
  private String optionText;

  /**
   * Gets option id.
   *
   * @return the option id
   */
// Getters and Setters
  public Long getOptionId() {
    return optionId;
  }

  /**
   * Sets option id.
   *
   * @param optionId the option id
   */
  public void setOptionId(Long optionId) {
    this.optionId = optionId;
  }

  /**
   * Gets option text.
   *
   * @return the option text
   */
  public String getOptionText() {
    return optionText;
  }

  /**
   * Sets option text.
   *
   * @param optionText the option text
   */
  public void setOptionText(String optionText) {
    this.optionText = optionText;
  }
}

