
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.time.Instant;
import java.util.List;

import static in.gov.gem.app.constant.RegexConstants.UTC_FORMAT;


/**
 * The type Vendor dashboard new request dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VendorDashboardNewRequestDTO {
    private Long id;
    private String vaId;
    private String status;
    private String subStatus;
    private String assessedAs;
    private Integer categoryCount;
    private String assessedBy;
    @JsonFormat(pattern = UTC_FORMAT, timezone = "UTC")
    private Instant validUpTo;
    @JsonFormat(pattern = UTC_FORMAT, timezone = "UTC")
    private Instant submittedOn;
    private List<String> actions;
}
