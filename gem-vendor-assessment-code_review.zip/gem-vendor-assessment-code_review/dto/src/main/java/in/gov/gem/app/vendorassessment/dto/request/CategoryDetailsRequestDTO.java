
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

// NEW: CategoryDetails.java

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.List;

/**
 * The type Category details request dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryDetailsRequestDTO {
    private Boolean selectSameCategory; // "Do you want to select same category?"
    private String categoryType; // "Product", "Service", "Forward Auction"
    private String categoryLevel1; // Selected value for Category - Level 1
    private String categoryLevel2; // Selected value for Category - Level 2
    private String categoryLevel3; // Selected value for Category - Level 3
    private String categoryLevel4; // Selected value for Category - Level 4
    private String categoryLevel5; // Selected value for Category - Level 5
    private List<MappedCategoryRequestDTO> mappedCategoriesForDivision; // List of categories shown on the right side
    // Note: "Auto-Map Subcategories" would likely be a client-side action or trigger an internal service call.
}
