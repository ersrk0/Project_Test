
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;


import lombok.Data;

@Data
public class CategoryNewRequestDTO {
  private Long id;
  private String name;
  private boolean isReserved;
  private boolean isDownForBuyer;
  private String reservedFor;
  private String section;
}