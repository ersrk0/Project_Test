
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;


import in.gov.gem.app.vendorassessment.dto.request.VendorAssessRequestDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;

/**
 * The type Assessment validity response dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AssessmentValidityResponseDTO {
    //sushil need to update here
    private List<VendorAssessRequestDTO> vendorAssessments;
    private Instant currentTime;
}
