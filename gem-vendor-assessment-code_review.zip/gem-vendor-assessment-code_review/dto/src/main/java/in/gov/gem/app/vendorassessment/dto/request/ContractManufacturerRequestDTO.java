
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The type Contract manufacturer request dto.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ContractManufacturerRequestDTO {
    private String organizationName;//VaOrganizationDetail

    private String officeName;

    private String officeTypeLookup;//VAOrganizationAddress

    private String officeAddressLine1; //VAOrganizationAddress

    private String officeAddressLine2;//VAOrganizationAddress

    private String officeLandmark;//VAOrganizationAddress

    private String geographyLocationCode;//VAOrganizationAddress

    private String contactNumber;//AuthorizeOemOspDetail

    private String emailId;//AuthorizeOemOspDetail

    private String gstinNumber;//VAOrganizationAddress

    private String assessAsLookupType;//VAOrganizationAddress

    private String countryCode; //AuthorizeOemOspDetail

    private Long vaMgmtFk;//VaOrganizationDetail

    private String authorizePersonName;//AuthorizeOemOspDetail

    private String stdCode;//AuthorizeOemOspDetail

    private Long briefcaseFk;//AuthorizeOemOspDetail
}
