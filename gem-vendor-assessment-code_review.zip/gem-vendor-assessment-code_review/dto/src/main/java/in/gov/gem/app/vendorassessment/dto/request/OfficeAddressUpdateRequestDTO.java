
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import in.gov.gem.app.constant.RegexConstants;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Office address update request dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OfficeAddressUpdateRequestDTO
{
  @Schema(description = "unique id associated with address", example = "2",
    requiredMode = Schema.RequiredMode.REQUIRED)
  @NotNull
  private Long pvtOrgOfficeId;
  @Hidden
  @Schema(description = "unique id associated with user", example = "23",
    requiredMode = Schema.RequiredMode.REQUIRED)
  private Long pvtOrgMasterFk;
  @Schema(description = "Country", example = "India",
    requiredMode = Schema.RequiredMode.REQUIRED)
  @NotEmpty
  private String countryLookup;
  @Schema(description = "office address type", example = "Billing",
    requiredMode = Schema.RequiredMode.REQUIRED)
  @NotEmpty
  //@LookupAnnotation(lookupName = LookupConstant.OFFICE_TYPE)
  private String typeLookup;
  @Schema(description = "name of itr key person", example = "vivek kumar",
    requiredMode = Schema.RequiredMode.REQUIRED)
  @NotEmpty
  private String name;
  @Schema(description = "flag for gstin", example = "true",
    requiredMode = Schema.RequiredMode.REQUIRED)
  @NotNull
  private Boolean gstnFlag;
  @Schema(description = "gstin number", example = "22AAAAA0000A1Z5")
  private String gstn;
  @Schema(description = "gstin type", example = "regular")
  private String gstnType;
  @Schema(description = "address line 1", example = "A-12 palm lane",
    requiredMode = Schema.RequiredMode.REQUIRED)
  @NotEmpty
  private String addressOne;
  @Schema(description = "address line 2", example = "Sec-70",
    requiredMode = Schema.RequiredMode.REQUIRED)
  private String addressTwo;
  @Schema(description = "landmark", example = "Opposite SBI Bank",
    requiredMode = Schema.RequiredMode.REQUIRED)
  private String landmark;
  @Schema(description = "pincode", example = "201305",
    requiredMode = Schema.RequiredMode.REQUIRED)
  @NotBlank
  private String pincode;
  @Schema(description = "state", example = "Uttar pradesh",
    requiredMode = Schema.RequiredMode.REQUIRED)
  @NotBlank
  private String state;
  @Schema(description = "town/district/city as per pincode entered", example = "Noida",
    requiredMode = Schema.RequiredMode.REQUIRED)
  @NotBlank
  private String townDistrictCity;
  @Schema(description = "mobile number entered by user", example = "9999999999",
    requiredMode = Schema.RequiredMode.REQUIRED)
  @NotBlank
  @Pattern(regexp = RegexConstants.MOBILE_REGEX, message = "Invalid Mobile Number")
  private String mobile;
  @Schema(description = "email entered by user", example = "abc@gmail.com",
    requiredMode = Schema.RequiredMode.REQUIRED)
  @NotBlank
  @Pattern(regexp = RegexConstants.EMAIL_REGEX,message = "Invalid Email")
  private String email;
}
