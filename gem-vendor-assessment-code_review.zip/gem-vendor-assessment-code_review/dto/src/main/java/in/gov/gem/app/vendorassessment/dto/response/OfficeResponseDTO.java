
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

/**
 * The type Office response dto.
 */
@Data
@Builder
@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
public class OfficeResponseDTO {
  @Schema(description = "name of office", example = "lexcorp noida")
  private String name;
  @Schema(description = "address of office", example = "Sector-18,Noida")
  private String officeAddress;
  @Schema(description = "Country", example = "India")
  private String countryLookup;
  @Schema(description = "type of office", example = "billing")
  private String typeLookup;
  @Schema(description = "mobile number of office", example = "9999999999")
  private String mobile;
  @Schema(description = "email of office", example = "abc@gmail.com")
  private String email;
  @Schema(description = "gstin number", example = "22AAAAA0000A1Z5")
  private String gstn;
  @Schema(description = "unique id corresponding to office", example = "10")
  private Long id;
  @Schema(description = "address line 1", example = "A-12 palm lane")
  private String address1;
  @Schema(description = "address line 2", example = "Sec-70")
  private String address2;
  @Schema(description = "landmark", example = "Opposite SBI Bank")
  private String landmark;
  @Schema(description = "Pincode Code", example = "POM123")
  private String pincodeLookUp;
}
