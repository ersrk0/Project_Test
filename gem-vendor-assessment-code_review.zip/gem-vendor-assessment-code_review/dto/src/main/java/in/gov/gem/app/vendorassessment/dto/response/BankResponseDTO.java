
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

/**
 * The type Bank response dto.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BankResponseDTO {
  private Long id;
  @Schema(description = "bank name fetched on basis of ifsc code", example = "State Bank of India")
  private String bankName;
  @Schema(description = "user input ifsc code", example = "SBIN0005943")
  private String ifscCode;
  @Schema(description = "user input account holder name", example = "Jane Doe")
  private String accountHolderName;
  @Schema(description = "user input account holder name", example = "SBIN00059431234")
  private String accountNumber;
  @Schema(description = "bank address fetched on basis of ifsc code", example = "A-23, Palm lane, Sector-51, " +
    "Noida-201301")
  private String bankAddress;

  private String bankBranchCode;

  private String district;
  private String bankUrl;
  private String micrCode;
}
