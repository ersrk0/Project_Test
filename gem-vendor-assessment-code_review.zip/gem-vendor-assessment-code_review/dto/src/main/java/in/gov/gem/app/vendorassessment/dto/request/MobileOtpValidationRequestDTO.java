
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.*;


/**
 * The type Mobile otp validation request dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class MobileOtpValidationRequestDTO
{
  @NotNull
  @Schema(description = "user input otp", example = "123456", minLength = 6, maxLength = 6,
    requiredMode = Schema.RequiredMode.REQUIRED)
  private Long otp;

  @NotBlank
  @Schema(description = "referenceId ", example = "102cbb93-d481-41b8-93ad-ab1f1a3f04f3")
  private String referenceId;

  @Pattern(regexp = "^[0]?[6789]\\d{9}$", message = "Invalid mobile number")
  private String mobile;
}
