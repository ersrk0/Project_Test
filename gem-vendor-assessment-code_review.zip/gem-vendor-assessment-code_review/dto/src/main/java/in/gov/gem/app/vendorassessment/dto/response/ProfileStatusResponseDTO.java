
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Profile status response dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProfileStatusResponseDTO {

    @Schema(description = "Indicates if business details are filled", example = "false")
    private boolean isBusinessDetailsFilled;

    @Schema(description = "Indicates if key person is verified", example = "false")
    private boolean isKeyPersonVerified;

    @Schema(description = "Indicates if consent is declared", example = "true")
    private boolean isConsentDeclared;

    @Schema(description = "Indicates if office address is saved", example = "false")
    private boolean isOfficeAddressSaved;
}
