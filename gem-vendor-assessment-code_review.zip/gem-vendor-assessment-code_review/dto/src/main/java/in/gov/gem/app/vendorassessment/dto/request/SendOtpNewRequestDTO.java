
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Data;

/**
 * The type Send otp new request dto.
 */
@Builder
@Data
public class SendOtpNewRequestDTO
{
  @Schema(description = "Unique identifier for the channel.", example = "CI001", maxLength = 10)
  @NotBlank(message = "Channel ID is required")
  private String channelId;

  /**
   * Delivery Channel where the OTP validation is performed (e.g., web, mobile).
   */
  @Schema(
          description = "Delivery Channel for the OTP request.\n" +
                  "Possible values:\n" +
                  "- `LCOM000002`: SEND_ON_MOBILE\n" +
                  "- `LCOM000003`: SEND_ON_EMAIL\n" +
                  "- `LCOM000001`: SEND_ON_BOTH",
          example = "LCOM000003",
          maxLength = 10
  )
  @NotBlank(message = "Delivery Channel is required")
  private String deliveryChannel;

  /**
   * Type of OTP request (e.g., Same, Different).
   */
  @Schema(
          description = "The OTP Type value defines whether same OTP is to be generated or different for each deliveryChannel.\n" +
                  "Possible values:\n" +
                  "- `LCOM000004`: OTP_TYPE_SAME\n" +
                  "- `LCOM000005`: OTP_TYPE_DIFFERENT",
          example = "LCOM000004",
          maxLength = 10
  )
  private String otpType;

  /**
   * The email address associated with the OTP request.
   * Must be a valid email format.
   */
  @Schema(description = "Email address associated with the OTP request. Must be a valid email format.", example = "user@example.com")
  @Email(message = "Invalid email format")
  private String email;

  /**
   * The mobile number associated with the OTP request.
   * Must be a valid mobile number format.
   */
  @Schema(description = "Mobile number associated with the OTP request.", example = "1234567890", maxLength = 15 , minLength = 10)
  private String mobileNumber;

  /**
   * Unique identifier for the OTP request module.
   * Must follow a valid UUID format.
   */
  @Schema(description = "Name of the module initiating the OTP request.", example = "IAM",maxLength = 10)
  @NotBlank(message = "Module Name is required")
  private String moduleName;

  /**
   * Functional area of the OTP request (e.g., Account Verification).
   * Must not be blank.
   */
  @Schema(description = "Functional area of the OTP request.", example = "LOGIN", maxLength = 10)
  @NotBlank(message = "Functional Area is required")
  private String functionalArea;

  /**
   * Unique identifier for the OTP request.
   * Must follow a valid UUID format.
   */
  @Schema(description = "Service Reference Id for the OTP request.", example = "Ref12a")
  @NotBlank(message = "Service Reference Id is required")
  private String serviceReferenceId;

  /**
   * Template Id for the OTP request.
   * Must not be blank.
   */
  @Schema(description = "Template Id for the OTP request.", example = "Ref12a")
  @NotBlank(message = "Template Id is required")
  private String templateId;
}
