
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import in.gov.gem.app.constant.RegexConstants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;

/**
 * The type Vendor dashboard dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VendorDashboardDTOResponseDTO {
    private Long id;
    private String vaId;
    private String status;
    private String subStatus;
    private String assessedAs;
    private Integer categoryCount;
    private String assessedBy;

    @JsonFormat(pattern = RegexConstants.UTC_FORMAT, timezone = "UTC")
    private Instant validUpTo;

    @JsonFormat(pattern = RegexConstants.UTC_FORMAT, timezone = "UTC")
    private Instant submittedOn;
    private List<String> actions;
}