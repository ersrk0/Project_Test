package in.gov.gem.app.vendorassessment.transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.dto.request.LookupVORequestDTO;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.response.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ProfileClientTransformerTest {

  private ISellerClient iSellerClient;
  private ProfileClientTransformer transformer;

  @BeforeEach
  void setUp() {
    iSellerClient = mock(ISellerClient.class);
    transformer = new ProfileClientTransformer(iSellerClient, new ObjectMapper());
  }
  @Test
  void testGetPanFromSeller_PanFound() {
    BusinessPanDetailsResponseDTO panDetails = new BusinessPanDetailsResponseDTO();
    panDetails.setPan("PANFOUND");

    APIResponse<BusinessPanDetailsResponseDTO> apiResponse = new APIResponse<>();
    apiResponse.setData(panDetails);

    when(iSellerClient.getPan()).thenReturn(ResponseEntity.ok(apiResponse));

    PanResponseResponseDTO result = transformer.getPanFromSeller();

    assertEquals("PANFOUND", result.getPanofSeller());
  }

  @Test
  void testGetPanFromSeller_PanNotFound() {
    APIResponse<BusinessPanDetailsResponseDTO> apiResponse = new APIResponse<>();
    apiResponse.setData(null);

    when(iSellerClient.getPan()).thenReturn(ResponseEntity.ok(apiResponse));

    PanResponseResponseDTO result = transformer.getPanFromSeller();

    assertNotNull(result);
    assertNull(result.getPanofSeller());
  }

  @Test
  void testGetTanFromSeller_TanFound() {
    TanDetailsVOResponseDTO tan1 = new TanDetailsVOResponseDTO();
    tan1.setTan("TAN1");
    TanDetailsVOResponseDTO tan2 = new TanDetailsVOResponseDTO();
    tan2.setTan("TAN2");

    APIResponse<List<TanDetailsVOResponseDTO>> apiResponse = new APIResponse<>();
    apiResponse.setData(List.of(tan1, tan2));

    when(iSellerClient.getTan(any())).thenReturn(ResponseEntity.ok(apiResponse));

    List<TanResponseDTO> result = transformer.getTanFromSeller(new PaginationParams());

    assertEquals(2, result.size());
    assertEquals("TAN1", result.get(0).getTan1());
    assertEquals("TAN2", result.get(1).getTan1());
  }

  @Test
  void testGetTanFromSeller_TanNotFound() {
    APIResponse<List<TanDetailsVOResponseDTO>> apiResponse = new APIResponse<>();
    apiResponse.setData(null);

    when(iSellerClient.getTan(any())).thenReturn(ResponseEntity.ok(apiResponse));

    List<TanResponseDTO> result = transformer.getTanFromSeller(new PaginationParams());

    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void getTanFromSeller_EmptyPaginationParams() {
    PaginationParams paginationParams = new PaginationParams();

    APIResponse<List<TanDetailsVOResponseDTO>> apiResponse = new APIResponse<>();
    apiResponse.setData(Collections.emptyList());

    when(iSellerClient.getTan(any())).thenReturn(ResponseEntity.ok(apiResponse));

    List<TanResponseDTO> result = transformer.getTanFromSeller(paginationParams);

    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void getProfileFromSeller_EmptyResponse() throws JsonProcessingException {
    APIResponse<ProfileDetailsResponseDTO> apiResponse = new APIResponse<>();
    apiResponse.setData(null);

    when(iSellerClient.getProfile()).thenReturn(ResponseEntity.ok(apiResponse));
    when(iSellerClient.getPan()).thenReturn(ResponseEntity.ok(new APIResponse<>()));
    ProfileSellerResponseDTO result = transformer.getProfileFromSeller();

    assertNotNull(result);
    assertNull(result.getOrganizationName());
    assertNull(result.getPan());
    assertNull(result.getOrganizationSubType());
    assertNull(result.getOrganizationType());
    assertNull(result.getCINANDFCRN());
    assertNull(result.getLLPINANDFLLPIN());
  }

  @Test
  void getTanFromSeller_InvalidTanResponse() {
    APIResponse<List<TanDetailsVOResponseDTO>> apiResponse = new APIResponse<>();
    apiResponse.setData(null);

    when(iSellerClient.getTan(any())).thenReturn(ResponseEntity.ok(apiResponse));

    List<TanResponseDTO> result = transformer.getTanFromSeller(new PaginationParams());

    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void getTanFromSeller_NullPaginationParams() {
    APIResponse<List<TanDetailsVOResponseDTO>> apiResponse = new APIResponse<>();
    apiResponse.setData(Collections.emptyList());

    when(iSellerClient.getTan(any())).thenReturn(ResponseEntity.ok(apiResponse));

    List<TanResponseDTO> result = transformer.getTanFromSeller(null);

    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void getTanFromSeller_ValidPaginationParams() {
    PaginationParams paginationParams = new PaginationParams();
    paginationParams.setPageNumber(1);
    paginationParams.setPageSize(10);

    TanDetailsVOResponseDTO tan1 = new TanDetailsVOResponseDTO();
    tan1.setTan("TAN1");
    TanDetailsVOResponseDTO tan2 = new TanDetailsVOResponseDTO();
    tan2.setTan("TAN2");

    APIResponse<List<TanDetailsVOResponseDTO>> apiResponse = new APIResponse<>();
    apiResponse.setData(List.of(tan1, tan2));

    when(iSellerClient.getTan(any())).thenReturn(ResponseEntity.ok(apiResponse));

    List<TanResponseDTO> result = transformer.getTanFromSeller(paginationParams);

    assertNotNull(result);
    assertEquals(2, result.size());
    assertEquals("TAN1", result.get(0).getTan1());
    assertEquals("TAN2", result.get(1).getTan1());
  }

  @Test
  void getTanFromSeller_EmptyResponseEntity() {
    when(iSellerClient.getTan(any())).thenReturn(null);

    List<TanResponseDTO> result = transformer.getTanFromSeller(new PaginationParams());

    assertNotNull(result);
    assertTrue(result.isEmpty());
  }
  @Test
  void testGetProfileFromSeller_CompanyType() throws JsonProcessingException {
    // Arrange
    ProfileDetailsResponseDTO profileDetails = new ProfileDetailsResponseDTO();
    profileDetails.setId(1L);
    profileDetails.setOrganizationName("Test Company");
    profileDetails.setEntityNumber("CIN123");

    LookupVORequestDTO orgType = new LookupVORequestDTO();
    orgType.setDescription("Company");
    profileDetails.setOrganizationType(orgType);

    LookupVORequestDTO subOrgType = new LookupVORequestDTO();
    subOrgType.setDescription("Private");
    profileDetails.setSubOrganizationType(subOrgType);

    APIResponse<ProfileDetailsResponseDTO> profileResponse = new APIResponse<>();
    profileResponse.setData(profileDetails);

    // Mock PAN response
    BusinessPanDetailsResponseDTO panDetails = new BusinessPanDetailsResponseDTO();
    panDetails.setPan("TESTPAN123");
    APIResponse<BusinessPanDetailsResponseDTO> panResponse = new APIResponse<>();
    panResponse.setData(panDetails);

    when(iSellerClient.getProfile()).thenReturn(ResponseEntity.ok(profileResponse));
    when(iSellerClient.getPan()).thenReturn(ResponseEntity.ok(panResponse));

    // Act
    ProfileSellerResponseDTO result = transformer.getProfileFromSeller();

    // Assert
    assertNotNull(result);
    assertEquals(1L, result.getId());
    assertEquals("Test Company", result.getOrganizationName());
    assertEquals("TESTPAN123", result.getPan());
    assertEquals("CIN123", result.getCINANDFCRN());
    assertNull(result.getLLPINANDFLLPIN());
    verify(iSellerClient).getProfile();
    verify(iSellerClient).getPan();
  }

  @Test
  void testGetProfileFromSeller_FirmType() throws JsonProcessingException {
    // Arrange
    ProfileDetailsResponseDTO profileDetails = new ProfileDetailsResponseDTO();
    profileDetails.setId(2L);
    profileDetails.setOrganizationName("Test Firm");
    profileDetails.setEntityNumber("LLP123");

    LookupVORequestDTO orgType = new LookupVORequestDTO();
    orgType.setDescription("Firm");
    profileDetails.setOrganizationType(orgType);

    LookupVORequestDTO subOrgType = new LookupVORequestDTO();
    subOrgType.setDescription("Partnership");
    profileDetails.setSubOrganizationType(subOrgType);

    APIResponse<ProfileDetailsResponseDTO> profileResponse = new APIResponse<>();
    profileResponse.setData(profileDetails);

    // Mock PAN response
    BusinessPanDetailsResponseDTO panDetails = new BusinessPanDetailsResponseDTO();
    panDetails.setPan("TESTPAN456");
    APIResponse<BusinessPanDetailsResponseDTO> panResponse = new APIResponse<>();
    panResponse.setData(panDetails);

    when(iSellerClient.getProfile()).thenReturn(ResponseEntity.ok(profileResponse));
    when(iSellerClient.getPan()).thenReturn(ResponseEntity.ok(panResponse));

    // Act
    ProfileSellerResponseDTO result = transformer.getProfileFromSeller();

    // Assert
    assertNotNull(result);
    assertEquals(2L, result.getId());
    assertEquals("Test Firm", result.getOrganizationName());
    assertEquals("TESTPAN456", result.getPan());
    assertEquals("LLP123", result.getLLPINANDFLLPIN());
    assertNull(result.getCINANDFCRN());
    verify(iSellerClient).getProfile();
    verify(iSellerClient).getPan();
  }

  @Test
  void testGetProfileFromSeller_OtherType() throws JsonProcessingException {
    // Arrange
    ProfileDetailsResponseDTO profileDetails = new ProfileDetailsResponseDTO();
    profileDetails.setId(3L);
    profileDetails.setOrganizationName("Test Other");
    profileDetails.setEntityNumber("OTHER123");

    LookupVORequestDTO orgType = new LookupVORequestDTO();
    orgType.setDescription("Other");
    profileDetails.setOrganizationType(orgType);

    LookupVORequestDTO subOrgType = new LookupVORequestDTO();
    subOrgType.setDescription("Other");
    profileDetails.setSubOrganizationType(subOrgType);

    APIResponse<ProfileDetailsResponseDTO> profileResponse = new APIResponse<>();
    profileResponse.setData(profileDetails);

    // Mock PAN response
    BusinessPanDetailsResponseDTO panDetails = new BusinessPanDetailsResponseDTO();
    panDetails.setPan("TESTPAN789");
    APIResponse<BusinessPanDetailsResponseDTO> panResponse = new APIResponse<>();
    panResponse.setData(panDetails);

    when(iSellerClient.getProfile()).thenReturn(ResponseEntity.ok(profileResponse));
    when(iSellerClient.getPan()).thenReturn(ResponseEntity.ok(panResponse));

    // Act
    ProfileSellerResponseDTO result = transformer.getProfileFromSeller();

    // Assert
    assertNotNull(result);
    assertEquals(3L, result.getId());
    assertEquals("Test Other", result.getOrganizationName());
    assertEquals("TESTPAN789", result.getPan());
    assertNull(result.getCINANDFCRN());
    assertNull(result.getLLPINANDFLLPIN());
    verify(iSellerClient).getProfile();
    verify(iSellerClient).getPan();
  }

  @Test
  void testGetProfileFromSeller_NullOrganizationType() throws JsonProcessingException {
    // Arrange
    ProfileDetailsResponseDTO profileDetails = new ProfileDetailsResponseDTO();
    profileDetails.setId(4L);
    profileDetails.setOrganizationName("Test Null");
    profileDetails.setEntityNumber("NULL123");
    profileDetails.setOrganizationType(null);

    LookupVORequestDTO subOrgType = new LookupVORequestDTO();
    subOrgType.setDescription("Some");
    profileDetails.setSubOrganizationType(subOrgType);

    APIResponse<ProfileDetailsResponseDTO> profileResponse = new APIResponse<>();
    profileResponse.setData(profileDetails);

    // Mock PAN response
    BusinessPanDetailsResponseDTO panDetails = new BusinessPanDetailsResponseDTO();
    panDetails.setPan("TESTPAN000");
    APIResponse<BusinessPanDetailsResponseDTO> panResponse = new APIResponse<>();
    panResponse.setData(panDetails);

    when(iSellerClient.getProfile()).thenReturn(ResponseEntity.ok(profileResponse));
    when(iSellerClient.getPan()).thenReturn(ResponseEntity.ok(panResponse));

    // Act
    ProfileSellerResponseDTO result = transformer.getProfileFromSeller();

    // Assert
    assertNotNull(result);
    assertEquals(4L, result.getId());
    assertEquals("Test Null", result.getOrganizationName());
    assertEquals("TESTPAN000", result.getPan());
    assertNull(result.getCINANDFCRN());
    assertNull(result.getLLPINANDFLLPIN());
    verify(iSellerClient).getProfile();
    verify(iSellerClient).getPan();
  }
}