package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.vendorassessment.dto.response.VideoInstructionsDTOResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VideoScheduleTimeDTOResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VideoUrlDTOResponseDTO;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.repository.LookupRepository;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static in.gov.gem.app.exception.utility.ErrorConstant.CATEGORY.BV;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Slf4j
class VideoAssessmentServiceImplTest {


    @Mock
    private LookupRepository lookupRepository;

    @Mock
    private MessageUtility messageUtility;

    @InjectMocks
    private VideoAssessmentService videoAssessmentService;





    @Test
    void shouldFetchScheduleAssessmentDateTime() {
        VideoScheduleTimeDTOResponseDTO result = (VideoScheduleTimeDTOResponseDTO) videoAssessmentService.fetchScheduleAssessmentDateTime();

        assertThat(result).isNotNull();
        assertThat(result.getScheduleTime()).matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}");
    }




    @Test
    void shouldReturnInstructionsWhenValidLookupCode() {
        Lookup lookup = new Lookup();
        lookup.setDescription("Test Instructions");
        when(lookupRepository.findByLookupCode("LCVA1172")).thenReturn(Optional.of(lookup));

        VideoInstructionsDTOResponseDTO result = (VideoInstructionsDTOResponseDTO) videoAssessmentService.fetchInstructions("SELLER123");

        assertThat(result.getInstructions()).isEqualTo("Test Instructions");
    }



    @Test
    void shouldReturnAppDownloadLinkFromConstant() {
        VideoUrlDTOResponseDTO result = (VideoUrlDTOResponseDTO) videoAssessmentService.fetchAppDownloadLink();

        assertThat(result.getVideoUrl()).isEqualTo(ApplicationConstant.APP_DOWNLOAD_LINK);
    }

    @Test
    void shouldReturnCurrentTimeForScheduleAssessment() {
        VideoScheduleTimeDTOResponseDTO result = (VideoScheduleTimeDTOResponseDTO) videoAssessmentService.fetchScheduleAssessmentDateTime();

        String timeStr = result.getScheduleTime();
        assertThat(timeStr).matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}");
    }





    @Test
    void shouldThrowServiceExceptionWhenFetchAppDownloadLinkFails() {
        // Prepare error message
        String errorMessage = "Unexpected error occurred";

        // Create spy of the service
        VideoAssessmentService serviceSpy = spy(videoAssessmentService);

        // Force the spy to throw exception when method is called
        doThrow(new ServiceException("E-VA-BV-I-4000010", errorMessage, BV, ErrorConstant.SEVERITY.I))
                .when(serviceSpy).fetchAppDownloadLink();

        // Assert the exception
        ServiceException exception = assertThrows(ServiceException.class,
                () -> serviceSpy.fetchAppDownloadLink());

        assertThat(exception.getCode()).isEqualTo("E-VA-BV-I-4000010");
    }
    // Add these tests to your test class


    @Test
    void shouldThrowServiceExceptionWhenLookupNotFound() {
        when(lookupRepository.findByLookupCode(ApplicationConstant.VIDEO_INSTRUCTIONS_LOOKUP_CODE))
                .thenReturn(Optional.empty());
        when(messageUtility.getMessage(MessageConstant.Lookup_NOT_FOUND)).thenReturn("Lookup not found");

        ServiceException exception = assertThrows(ServiceException.class,
                () -> videoAssessmentService.fetchInstructions("SELLER123"));

        assertThat(exception.getCode()).isEqualTo(MessageConstant.Lookup_NOT_FOUND);
    }





    @Test
    void shouldThrowServiceExceptionWhenFetchScheduleAssessmentDateTimeFails() {
        VideoAssessmentService service = new VideoAssessmentService(lookupRepository, messageUtility) {
            @Override
            public Object fetchScheduleAssessmentDateTime() {
                throw new ServiceException(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND,
                        "Not found", ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
            }
        };
        ServiceException exception = assertThrows(ServiceException.class, service::fetchScheduleAssessmentDateTime);
        assertThat(exception.getCode()).isEqualTo(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND);
    }
}
