package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.vendorassessment.dto.request.VendorAssessmentNewRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.InitiateResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VendorAssessmentIdResponseDTO;

import in.gov.gem.app.vendorassessment.facade.Impl.InitiateAssessmentFacade;
import in.gov.gem.app.vendorassessment.service.IInitiateAssessmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class InitiateAssessmentFacadeImplTest {

  @Mock
  private IInitiateAssessmentService service;

  @InjectMocks
  private InitiateAssessmentFacade facade;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testInitiateVendorAssessment() {
    VendorAssessmentNewRequestDTO request = new VendorAssessmentNewRequestDTO();
    InitiateResponseDTO responseDTO = new InitiateResponseDTO(true, "Initiated");

    when(service.initiateVendorAssessment(request)).thenReturn(responseDTO);

    InitiateResponseDTO result = facade.initiateVendorAssessment(request);

    assertNotNull(result);
//        assertTrue(result.isRaiseNewRequest());
    assertEquals("Initiated", result.getMessage());
  }

  @Test
  void testFetchBrandOemOspDashboardStatus() {
    Long vendorId = 123L;

    when(service.fetchBrandOemOspDashboardStatus(vendorId)).thenReturn(true);

    boolean result = facade.fetchBrandOemOspDashboardStatus(vendorId);

    assertTrue(result);
  }


  @Test
  void testFetchSupplementaryVAId() {
    VendorAssessmentIdResponseDTO idDTO = new VendorAssessmentIdResponseDTO();
    idDTO.setVendorAssessmentIds(Arrays.asList("VA001", "VA002"));

    when(service.fetchSupplementaryVAId()).thenReturn(idDTO);

    VendorAssessmentIdResponseDTO result = facade.fetchSupplementaryVAId();

    assertNotNull(result);
    assertEquals(2, result.getVendorAssessmentIds().size());
    assertTrue(result.getVendorAssessmentIds().contains("VA001"));
  }
}
 