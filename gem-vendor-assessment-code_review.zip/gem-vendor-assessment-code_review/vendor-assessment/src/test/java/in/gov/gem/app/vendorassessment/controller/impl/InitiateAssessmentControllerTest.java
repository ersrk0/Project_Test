package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;

import in.gov.gem.app.vendorassessment.dto.request.VendorAssessmentNewRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.VendorAssessmentIdResponseDTO;
import in.gov.gem.app.vendorassessment.facade.IInitiateAssessmentFacade;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class InitiateAssessmentControllerTest {

    @Mock
    private IInitiateAssessmentFacade facade;

    @InjectMocks
    private InitiateAssessmentController controller;

    private VendorAssessmentNewRequestDTO request;

    @Test
    void initiateVendorAssessment_ShouldReturnBadRequest_WhenRequestIsNull() {
        when(facade.initiateVendorAssessment(null)).thenReturn(null);

        ResponseEntity<APIResponse<Object>> response = controller.initiateVendorAssessment(null);

        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertThat(response.getBody().getData()).isNull();
    }

    @Test
    void fetchSupplementaryVAId_ShouldReturnEmptyList_WhenNoIdsExist() {
        VendorAssessmentIdResponseDTO emptyResponse = new VendorAssessmentIdResponseDTO();
        emptyResponse.setVendorAssessmentIds(Arrays.asList());

        when(facade.fetchSupplementaryVAId()).thenReturn(emptyResponse);

        ResponseEntity<APIResponse<Object>> response = controller.fetchSupplementaryVAId();

        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertThat(((VendorAssessmentIdResponseDTO) response.getBody().getData()).getVendorAssessmentIds()).isEmpty();
    }

    @Test
    void fetchBrandOemOspDashboardStatus_ShouldReturnFalse_WhenIdIsInvalid() {
        Long invalidId = -1L;

        when(facade.fetchBrandOemOspDashboardStatus(invalidId)).thenReturn(false);

        ResponseEntity<APIResponse<Object>> response = controller.fetchBrandOemOspDashboardStatus(invalidId);

        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertThat(response.getBody().getData()).isEqualTo(false);
    }
    }
