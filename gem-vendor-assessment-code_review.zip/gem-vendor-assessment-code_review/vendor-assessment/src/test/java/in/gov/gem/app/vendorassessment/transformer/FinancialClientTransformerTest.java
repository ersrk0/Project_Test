package in.gov.gem.app.vendorassessment.transformer;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.dto.response.PvtOrgItrVOResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.TurnoverResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.TurnoverSellerResponseDTO;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FinancialClientTransformerTest {

  @Mock
  private ISellerClient iSellerClient;

  @InjectMocks
  private FinancialClientTransformer transformer;

  @Test
  void getFinancialDetailsFromSeller_returnsMappedList_whenDataPresent() {
    PvtOrgItrVOResponseDTO vo = PvtOrgItrVOResponseDTO.builder()
      .id(100L)
      .itrType("ITR-3")
      .profit(new BigDecimal("45000.50"))
      .assessmentYear("2022-23")
      .ackNo("ACK12345")
      .status("Processed")
      .sales(new BigDecimal("500000.75"))
      .build();

    PageableApiResponse<List<PvtOrgItrVOResponseDTO>> responseBody = new PageableApiResponse<>();
    responseBody.setData(List.of(vo));

    when(iSellerClient.getFinancialItrAddress(any()))
      .thenReturn(ResponseEntity.ok(responseBody));

    List<TurnoverSellerResponseDTO> result = transformer.getFinancialDetailsFromSeller(new PaginationParams());

    assertEquals(1, result.size());
    assertEquals("ITR-3", result.get(0).getItrType());
    assertEquals(new BigDecimal("500000.75"), result.get(0).getSales());
  }

  @Test
  void getFinancialDetailsFromSeller_returnsEmpty_whenNoData() {
    PageableApiResponse<List<PvtOrgItrVOResponseDTO>> responseBody = new PageableApiResponse<>();
    responseBody.setData(Collections.emptyList());

    when(iSellerClient.getFinancialItrAddress(any()))
      .thenReturn(ResponseEntity.ok(responseBody));

    List<TurnoverSellerResponseDTO> result = transformer.getFinancialDetailsFromSeller(new PaginationParams());

    assertTrue(result.isEmpty());
  }

  @Test
  void getTurnOverFromSeller_returnsMappedResponse_whenDataPresent() {
    TurnoverResponseDTO data = TurnoverResponseDTO.builder()
      .turnover(new BigDecimal("1500000"))
      .build();

    APIResponse<TurnoverResponseDTO> responseBody = new APIResponse<>();
    responseBody.setData(data);

    when(iSellerClient.getTurnOver()).thenReturn(ResponseEntity.ok(responseBody));

    TurnoverResponseDTO result = transformer.getTurnOverFromSeller();

    assertEquals(new BigDecimal("1500000"), result.getTurnover());
  }

  @Test
  void getTurnOverFromSeller_returnsEmpty_whenDataAbsent() {
    APIResponse<TurnoverResponseDTO> responseBody = new APIResponse<>();
    responseBody.setData(null);

    when(iSellerClient.getTurnOver()).thenReturn(ResponseEntity.ok(responseBody));

    TurnoverResponseDTO result = transformer.getTurnOverFromSeller();

    assertNull(result.getTurnover());
  }

  @Test
  void getTurnOverFromSeller_returnsEmpty_whenResponseNull() {
    when(iSellerClient.getTurnOver()).thenReturn(null);

    TurnoverResponseDTO result = transformer.getTurnOverFromSeller();

    assertNull(result.getTurnover());
  }
}

