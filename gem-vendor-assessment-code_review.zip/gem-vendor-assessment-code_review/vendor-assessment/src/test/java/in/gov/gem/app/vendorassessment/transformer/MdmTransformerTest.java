package in.gov.gem.app.vendorassessment.transformer;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Collections;
import java.util.List;

import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.vendorassessment.client.IMdmClient;
import in.gov.gem.app.vendorassessment.dto.response.CountryResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.FetchLocationResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.LocationListResponseDTO;
import in.gov.gem.app.service.dto.PaginationParams;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class MdmTransformerTest {

  @Mock
  private IMdmClient iMdmClient;

  @InjectMocks
  private MdmTransformer mdmTransformer;


  @Test
  void getLocationListFromMdm_shouldHandleNullResponse() {
    when(iMdmClient.getLocationList(any(), any(), any())).thenReturn(null);

    List<FetchLocationResponseDTO> result = mdmTransformer.getLocationListFromMdm(
      new PaginationParams(), "X", "en");

    assertTrue(result.isEmpty());
  }

  @Test
  void fetchCountryList_shouldHandleNullResponse() {
    when(iMdmClient.fetchCountryList(any(), any())).thenReturn(null);

    List<CountryResponseDTO> result = mdmTransformer.fetchCountryList(
      new PaginationParams(), "en");

    assertTrue(result.isEmpty());
  }

  @Test
  void getLocationListFromMdm_shouldReturnEmpty_whenNoData() {
    PageableApiResponse<List<LocationListResponseDTO>> empty = new PageableApiResponse<>();
    empty.setData(Collections.emptyList());

    List<FetchLocationResponseDTO> result = mdmTransformer.getLocationListFromMdm(
      new PaginationParams(), "X", "en");

    assertTrue(result.isEmpty());
  }

  @Test
  void fetchCountryList_shouldReturnEmpty_whenNoData() {
    PageableApiResponse<List<CountryResponseDTO>> empty = new PageableApiResponse<>();
    empty.setData(Collections.emptyList());

    List<CountryResponseDTO> result = mdmTransformer.fetchCountryList(
      new PaginationParams(), "en");

    assertTrue(result.isEmpty());
  }

//  @Test
//  void getLocationListFromMdm_shouldReturnData_whenValidResponse() {
//    LocationListResponse location1 = new LocationListResponse();
//    location1.setDataCode("LOC1");
//    location1.setDistrict("District1");
//    location1.setPinCode("123456");
//    location1.setState("State1");
//    location1.setSubDistrict("SubDistrict1");
//    location1.setVillage("Village1");
//    location1.setCountry("Country1");
//
//    LocationListResponse location2 = new LocationListResponse();
//    location2.setDataCode("LOC2");
//    location2.setDistrict("District2");
//    location2.setPinCode("654321");
//    location2.setState("State2");
//    location2.setSubDistrict("SubDistrict2");
//    location2.setVillage("Village2");
//    location2.setCountry("Country2");
//
//    PageableApiResponse<List<LocationListResponse>> response = new PageableApiResponse<>();
//    response.setData(List.of(location1, location2));
//
//    when(iMdmClient.getLocationList(any(), any(), any())).thenReturn(response);
//
//    List<FetchLocationResponse> result = mdmTransformer.getLocationListFromMdm(
//      new PaginationParams(), "X", "en");
//
//    assertEquals(2, result.size());
//    assertEquals("LOC1", result.get(0).getDataCode());
//    assertEquals("District1", result.get(0).getDistrict());
//    assertEquals("LOC2", result.get(1).getDataCode());
//    assertEquals("District2", result.get(1).getDistrict());
//  }
//
//  @Test
//  void fetchCountryList_shouldReturnData_whenValidResponse() {
//    CountryResponse country1 = new CountryResponse();
//    country1.setCountryName("Country1");
//
//    CountryResponse country2 = new CountryResponse();
//    country2.setCountryName("Country2");
//
//    PageableApiResponse<List<CountryResponse>> response = new PageableApiResponse<>();
//    response.setData(List.of(country1, country2));
//
//    when(iMdmClient.fetchCountryList(any(), any())).thenReturn(ResponseEntity.ok(response));
//    when(iMdmClient.fetchCountryList(any(), any())).thenReturn(response);
//
//    List<CountryListResponse> result = mdmTransformer.fetchCountryList(
//      new PaginationParams(), "en");
//
//    assertEquals(2, result.size());
//    assertEquals("Country1", result.get(0).getCountryName());
//    assertEquals("Country2", result.get(1).getCountryName());
//  }
//
//  @Test
//  void getLocationListFromMdm_shouldLogMessage_whenNoData() {
//    PageableApiResponse<List<LocationListResponse>> empty = new PageableApiResponse<>();
//    empty.setData(Collections.emptyList());
//
//    when(iMdmClient.getLocationList(any(), any(), any())).thenReturn(ResponseEntity.ok(empty));
//
//    List<FetchLocationResponse> result = mdmTransformer.getLocationListFromMdm(
//      new PaginationParams(), "X", "en");
//
//    assertTrue(result.isEmpty());
//    verify(iMdmClient, times(1)).getLocationList(any(), any(), any());
//  }
//
//  @Test
//  void fetchCountryList_shouldLogMessage_whenNoData() {
//    PageableApiResponse<List<CountryResponse>> empty = new PageableApiResponse<>();
//    empty.setData(Collections.emptyList());
//
//    when(iMdmClient.fetchCountryList(any(), any())).thenReturn(ResponseEntity.ok(empty));
//
//    List<CountryListResponse> result = mdmTransformer.fetchCountryList(
//      new PaginationParams(), "en");
//
//    assertTrue(result.isEmpty());
//    verify(iMdmClient, times(1)).fetchCountryList(any(), any());
//  }
}

