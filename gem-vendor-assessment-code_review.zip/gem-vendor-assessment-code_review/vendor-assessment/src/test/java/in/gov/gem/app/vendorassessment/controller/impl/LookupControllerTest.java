package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;

import in.gov.gem.app.vendorassessment.dto.response.AssessDescriptionResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.LookupResponseResponseDTO;
import in.gov.gem.app.vendorassessment.facade.IAssessFacade;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LookupControllerTest {

    @Mock
    private IAssessFacade assessFacade;

    @InjectMocks
    private AssessController lookupController;

    private static final String DUMMY_LOOKUP_VALUE = "sample-value";
    private static final String DUMMY_ASSESS = "Products based";

    @BeforeEach
    void setUp() {
        // handled by @InjectMocks
    }
    @Test
void fetchAssessType_ShouldReturnLookupResponse() {
        LookupResponseResponseDTO mockResponse = new LookupResponseResponseDTO();
        when(assessFacade.getLookupValueByLookupName()).thenReturn(mockResponse);

        ResponseEntity<APIResponse<Object>> response = lookupController.fetchAssessType();

        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertThat(response.getBody().getData()).isEqualTo(mockResponse);
    }
    @Test
void fetchDescription_ShouldReturnAssessDescriptionDTO() {
        AssessDescriptionResponseDTO mockResponse = new AssessDescriptionResponseDTO();
        when(assessFacade.getDescriptionByLookupValue(DUMMY_LOOKUP_VALUE)).thenReturn(mockResponse);

        ResponseEntity<APIResponse<Object>> response = lookupController.fetchDescription(DUMMY_LOOKUP_VALUE);

        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertThat(response.getBody().getData()).isEqualTo(mockResponse);
    }
    @Test
void fetchQuestionByAssess_ShouldReturnListOfMaps() {
        List<Map<String, String>> mockResponse = Collections.singletonList(Map.of("key", "value"));
        when(assessFacade.fetchQuestionByAssess(DUMMY_ASSESS)).thenReturn(mockResponse);

        ResponseEntity<APIResponse<Object>> response = lookupController.fetchQuestionByAssess(DUMMY_ASSESS);

        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertThat(response.getBody().getData()).isEqualTo(mockResponse);
    }

}
