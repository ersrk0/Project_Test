package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.vendorassessment.dto.response.NonComplianceResponseDTO;
import in.gov.gem.app.service.dto.APIResponse;

import in.gov.gem.app.vendorassessment.dto.response.NonComplianceNewResponseDTO;
import in.gov.gem.app.vendorassessment.facade.Impl.NonComplianceFacade;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class NonComplianceControllerTest {

    @Mock
    private NonComplianceFacade nonComplianceFacade;

    @InjectMocks
    private NonComplianceController nonComplianceController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("fieldsWithOpenNonClosure returns valid response for valid sellerId")
    void fieldsWithOpenNonClosureReturnsValidResponseForValidSellerId() {
        // Given
        Long sellerId = 123L;
        NonComplianceNewResponseDTO mockResponse = new NonComplianceNewResponseDTO();
        when(nonComplianceFacade.fieldsWithOpenNonClosure(sellerId)).thenReturn(mockResponse);

        // When
        ResponseEntity<APIResponse<NonComplianceNewResponseDTO>> response = nonComplianceController.fieldsWithOpenNonClosure(sellerId);

        // Then
        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertEquals("VAS", response.getBody().getMsId());
        assertEquals("OK", response.getBody().getStatus());
        assertEquals(200, response.getBody().getHttpStatus());
        assertEquals("Fields with open non-compliance retrieved successfully", response.getBody().getMessage());
        assertEquals(mockResponse, response.getBody().getData());

        // Verify facade method was called
        verify(nonComplianceFacade).fieldsWithOpenNonClosure(sellerId);
    }
    @Test
    @DisplayName("nonCompliantFields returns valid response for valid vaMasterFk")
    void nonCompliantFieldsReturnsValidResponseForValidVaMasterFk() {
        // Given
        Long vaMasterFk = 456L;
        List<NonComplianceResponseDTO> mockList = List.of(new NonComplianceResponseDTO());
        when(nonComplianceFacade.nonCompliantFields(vaMasterFk)).thenReturn(mockList);

        // When
        ResponseEntity<APIResponse<List<NonComplianceResponseDTO>>> response = nonComplianceController.nonCompliantFields(vaMasterFk);

        // Then
        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertEquals("VAS", response.getBody().getMsId());
        assertEquals("OK", response.getBody().getStatus());
        assertEquals(200, response.getBody().getHttpStatus());
        assertEquals("Fields with open non-compliance retrieved successfully", response.getBody().getMessage());
        assertEquals(mockList, response.getBody().getData());

        verify(nonComplianceFacade).nonCompliantFields(vaMasterFk);
    }
}