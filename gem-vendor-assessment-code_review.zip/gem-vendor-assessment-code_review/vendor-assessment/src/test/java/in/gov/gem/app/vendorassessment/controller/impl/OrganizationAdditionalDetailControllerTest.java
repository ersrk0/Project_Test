package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.dto.request.AddBodDocumentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.AdditionalDocumentResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.DocumentDetailResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.SaveAdditionalDocumentResponseDTO;
import in.gov.gem.app.vendorassessment.facade.IAdditionalOrganisationDetailFacade;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class OrganizationAdditionalDetailControllerTest {

  private IAdditionalOrganisationDetailFacade facade;
  private OrganizationAdditionalDetailController controller;

  @BeforeEach
  void setUp() {
    facade = mock(IAdditionalOrganisationDetailFacade.class);
    controller = new OrganizationAdditionalDetailController(facade);
  }

  @Test
  void additionaldocuments_ReturnsApiResponseWithDescription() {
    String lookupCode = "CODE";
    String expectedDescription = "Some description";
    when(facade.getAdditionalDocumentQuestion(lookupCode)).thenReturn(expectedDescription);

    ResponseEntity<APIResponse<Object>> response = controller.additionaldocuments(lookupCode);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertEquals(expectedDescription, response.getBody().getData());
    assertEquals(ApplicationConstant.ADDITIONAL_DEBARRED_QUESTION_SUCCESS, response.getBody().getMessage());
  }

  @Test
  void additionaldocuments_ReturnsApiResponseWithNullDescription() {
    String lookupCode = "UNKNOWN";
    when(facade.getAdditionalDocumentQuestion(lookupCode)).thenReturn(null);

    ResponseEntity<APIResponse<Object>> response = controller.additionaldocuments(lookupCode);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertNull(response.getBody().getData());
  }

  @Test
  void addDocument_ReturnsApiResponseWithSavedDocument() {
    AddBodDocumentRequestDTO request = new AddBodDocumentRequestDTO();
    SaveAdditionalDocumentResponseDTO savedResponse = new SaveAdditionalDocumentResponseDTO();
    when(facade.addBodDocument(request)).thenReturn(savedResponse);

    ResponseEntity<APIResponse<Object>> response = controller.addDocument(request);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertEquals(savedResponse, response.getBody().getData());
    assertEquals(ApplicationConstant.DOCUMENT_ADDED_SUCCESS, response.getBody().getMessage());
  }

  @Test
  void exportUsersToExcel_ReturnsResponseEntityWithBytes() {
    List<AdditionalDocumentResponseDTO> docs = Collections.emptyList();
    ResponseEntity<byte[]> expected = new ResponseEntity<>(new byte[]{1,2,3}, HttpStatus.OK);
    when(facade.exportToExcel(docs)).thenReturn(expected);

    ResponseEntity<byte[]> response = controller.exportUsersToExcel(docs);

    assertEquals(expected, response);
  }

  @Test
  void deleteDocument_ReturnsApiResponseWithNullData() {
    Long vaMasterFk = 1L;
    String docName = "doc.pdf";

    ResponseEntity<APIResponse<Object>> response = controller.deleteDocument(vaMasterFk, docName);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertNull(response.getBody().getData());
    assertEquals(ApplicationConstant.DOCUMENT_DELETE_SUCCESS, response.getBody().getMessage());
    verify(facade).deleteBodDocument(vaMasterFk, docName);
  }

  @Test
  void getAdditionalDocuments_ReturnsEmptyContentWhenNoDocuments() {
    Long vaMasterId = 2L;
    PaginationParams params = new PaginationParams();
    Page<DocumentDetailResponseDTO> page = new PageImpl<>(Collections.emptyList());
    when(facade.ByVaMasterFk(vaMasterId, params)).thenReturn(page);

    ResponseEntity<PageableApiResponse<List<DocumentDetailResponseDTO>>> response = controller.getAdditionalDocuments(vaMasterId, params);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertTrue(response.getBody().getData().isEmpty());
  }

  @Test
  void addDocument_ReturnsApiResponseWhenFacadeReturnsNull() {
    AddBodDocumentRequestDTO request = new AddBodDocumentRequestDTO();
    when(facade.addBodDocument(request)).thenReturn(null);

    ResponseEntity<APIResponse<Object>> response = controller.addDocument(request);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertNull(response.getBody().getData());
    assertEquals(ApplicationConstant.DOCUMENT_ADDED_SUCCESS, response.getBody().getMessage());
  }

  @Test
  void exportUsersToExcel_ReturnsEmptyByteArray() {
    List<AdditionalDocumentResponseDTO> docs = Collections.emptyList();
    ResponseEntity<byte[]> expected = new ResponseEntity<>(new byte[0], HttpStatus.OK);
    when(facade.exportToExcel(docs)).thenReturn(expected);

    ResponseEntity<byte[]> response = controller.exportUsersToExcel(docs);

    assertEquals(expected, response);
    assertEquals(0, response.getBody().length);
  }

  @Test
  void deleteDocument_CallsFacadeWithNullDocName() {
    Long vaMasterFk = 1L;
    String docName = null;

    ResponseEntity<APIResponse<Object>> response = controller.deleteDocument(vaMasterFk, docName);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    verify(facade).deleteBodDocument(vaMasterFk, docName);
  }

  @Test
  void additionaldocuments_HandlesEmptyStringLookupCode() {
    String lookupCode = "";
    when(facade.getAdditionalDocumentQuestion(lookupCode)).thenReturn("");

    ResponseEntity<APIResponse<Object>> response = controller.additionaldocuments(lookupCode);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals("", response.getBody().getData());
  }
}