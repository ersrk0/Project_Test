package in.gov.gem.app.vendorassessment.controller.impl;


import in.gov.gem.app.vendorassessment.dto.request.*;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.ResendOtpResponseDTO;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.facade.IAssessmentRequestFacade;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;


import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AssessmentRequestControllerImplTest {

    @Mock
    private IAssessmentRequestFacade assessmentRequestFacadeInterface;

    @InjectMocks
    private AssessmentRequestController assessmentRequestController;

    @Test
    void getOrganizationDetails_ReturnsOrganizationDetails_WhenVaIdIsValid() {
        String vaId = "validVaId";
        OrganisationDetailsRequestDTO organisationDetails = new OrganisationDetailsRequestDTO();
        when(assessmentRequestFacadeInterface.getOrganizationDetails(vaId)).thenReturn(organisationDetails);

        ResponseEntity<APIResponse<OrganisationDetailsRequestDTO>> response = assessmentRequestController.getOrganizationDetails(vaId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(organisationDetails, response.getBody().getData());
    }

    @Test
    void createRequest_ReturnsCreatedRequest_WhenRequestDTOIsValid() {
        AssessmentRequestDTO requestDTO = new AssessmentRequestDTO();
        AssessmentNewRequestDTO createdRequest = new AssessmentNewRequestDTO();
        when(assessmentRequestFacadeInterface.createAssessmentRequest(requestDTO)).thenReturn(createdRequest);

        ResponseEntity<APIResponse<AssessmentNewRequestDTO>> response = assessmentRequestController.createRequest(requestDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(createdRequest, response.getBody().getData());
    }

    @Test
    void sendOtpEmail_ReturnsOtpResponse_WhenEmailIsValid() {
        String email = "test@example.com";
        OtpResponseDTO otpResponse = new OtpResponseDTO(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
        APIResponse<OtpResponseDTO> apiResponse = APIResponse.<OtpResponseDTO>builder().data(otpResponse).build();
        when(assessmentRequestFacadeInterface.sendOtpInter(email)).thenReturn(ResponseEntity.ok(apiResponse));

        ResponseEntity<APIResponse<OtpResponseDTO>> response = assessmentRequestController.sendOtpEmail(email);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(otpResponse.getReferenceId(), response.getBody().getData().getReferenceId());
    }

    @Test
    void resendOtpEmail_ReturnsResendOtpResponse_WhenRequestDTOIsValid() {
        ReSendRequestDTO reSendRequestDTO = new ReSendRequestDTO();
        ResendOtpResponseDTO resendOtpResponseDTO = new ResendOtpResponseDTO();
        APIResponse<ResendOtpResponseDTO> apiResponse = APIResponse.<ResendOtpResponseDTO>builder().data(resendOtpResponseDTO).build();
        when(assessmentRequestFacadeInterface.resendOtpInter(reSendRequestDTO)).thenReturn(ResponseEntity.ok(apiResponse));

        ResponseEntity<APIResponse<ResendOtpResponseDTO>> response = assessmentRequestController.resendOtpEmail(reSendRequestDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(resendOtpResponseDTO, response.getBody().getData());
    }

    @Test
    void updateMobileNumber_ReturnsSuccessMessage_WhenOtpIsValid() {
        String vaId = "validVaId";
        MobileOtpValidationRequestDTO mobileOtpValidationRequestDTO = new MobileOtpValidationRequestDTO();
        String successMessage = "OTP Validated";
        when(assessmentRequestFacadeInterface.validateOtpMobile(mobileOtpValidationRequestDTO, vaId, mobileOtpValidationRequestDTO.getMobile()))
                .thenReturn(successMessage);

        ResponseEntity<APIResponse<String>> response = assessmentRequestController.updateMobileNumber(vaId, mobileOtpValidationRequestDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(successMessage, response.getBody().getData());
    }

    @Test
    void updateEmailId_ReturnsSuccessMessage_WhenOtpIsValid() {
        String vaId = "validVaId";
        OTPValidateRequestDTO otpValidateRequestDTO = new OTPValidateRequestDTO();
        String successMessage = "OTP Validated";
        when(assessmentRequestFacadeInterface.validateOtp(otpValidateRequestDTO, vaId, otpValidateRequestDTO.getNewEmail()))
                .thenReturn(successMessage);

        ResponseEntity<APIResponse<String>> response = assessmentRequestController.updateEmailId(vaId, otpValidateRequestDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(successMessage, response.getBody().getData());
    }

    @Test
    void updateManufacturingLocationDecision_ReturnsSuccessMessage_WhenDecisionIsValid() {
        ManufacturingLocationDecisionRequestDTO decision = new ManufacturingLocationDecisionRequestDTO();
        ManufacturingLocationDecisionRequestDTO expectedResponse = new ManufacturingLocationDecisionRequestDTO();
        when(assessmentRequestFacadeInterface.updateManufacturingLocationDecision(decision)).thenReturn(decision);

        ResponseEntity<APIResponse<ManufacturingLocationDecisionRequestDTO>> response = assessmentRequestController.updateManufacturingLocationDecision(decision);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(expectedResponse, response.getBody().getData());
    }
}


