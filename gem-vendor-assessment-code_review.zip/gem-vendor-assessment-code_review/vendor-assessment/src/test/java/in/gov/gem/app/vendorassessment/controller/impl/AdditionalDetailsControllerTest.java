package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;

import in.gov.gem.app.vendorassessment.dto.request.*;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseResenDResponseDTO;

import in.gov.gem.app.vendorassessment.dto.response.OtpResponseSendResponseDTO;

import in.gov.gem.app.vendorassessment.dto.response.OtpResponseValidateResponseDTO;


import org.springframework.http.ResponseEntity;

@org.junit.jupiter.api.extension.ExtendWith(org.mockito.junit.jupiter.MockitoExtension.class)
public class AdditionalDetailsControllerTest {

  @org.mockito.Mock
  private in.gov.gem.app.vendorassessment.facade.IOtpServiceFacade otpServiceFacade;

  private AdditionalDetailsController controller;

  @org.junit.jupiter.api.BeforeEach
  void setUp() {
    controller = new AdditionalDetailsController(otpServiceFacade);
  }

  @org.junit.jupiter.api.Test
  void sendOtpOnEmail_ReturnsSuccessResponseWithOtpData() {
    AddEmailRequestDTO addEmailDto = new AddEmailRequestDTO();
    APIResponse<OtpResponseSendResponseDTO> apiResponse = APIResponse.<OtpResponseSendResponseDTO>builder()
      .data(new OtpResponseSendResponseDTO())
      .build();
    org.mockito.Mockito.when(otpServiceFacade.SentOtpViaEmail(addEmailDto))
      .thenReturn(ResponseEntity.ok(apiResponse));
    ResponseEntity<APIResponse<Object>> response = controller.sendOtpOnEmail(addEmailDto, "en");
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Send Successfully On Email: 654321", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNotNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void verifytpOnEmail_ReturnsSuccessResponseWithValidationData() {
    OtpValidationRequestDTO requestDTO = new OtpValidationRequestDTO();
    APIResponse<OtpResponseValidateResponseDTO> apiResponse = APIResponse.<OtpResponseValidateResponseDTO>builder()
      .data(new OtpResponseValidateResponseDTO())
      .build();
    org.mockito.Mockito.when(otpServiceFacade.ValidateOtpViaEmail(requestDTO))
      .thenReturn(ResponseEntity.ok(apiResponse));
    ResponseEntity<APIResponse<Object>> response = controller.verifytpOnEmail(requestDTO, null);
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Verify Successfully and Email Added Successfully", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNotNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void resendOtpOnEmail_ReturnsSuccessResponseWithResendData() {
    OtpRegenerateRequestDTO requestDTO = new OtpRegenerateRequestDTO();
    APIResponse<OtpResponseResenDResponseDTO> apiResponse = APIResponse.<OtpResponseResenDResponseDTO>builder()
      .data(new OtpResponseResenDResponseDTO())
      .build();
    org.mockito.Mockito.when(otpServiceFacade.ResendOtpViaEmail(requestDTO))
      .thenReturn(ResponseEntity.ok(apiResponse));
    ResponseEntity<APIResponse<Object>> response = controller.resendOtpOnEmail(requestDTO, null);
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Resend Successfully", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNotNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void sendOtpOnMobile_ReturnsSuccessResponseWithOtpData() {
    AddMobileRequestDTO addMobile = new AddMobileRequestDTO();
    APIResponse<OtpResponseSendResponseDTO> apiResponse = APIResponse.<OtpResponseSendResponseDTO>builder()
      .data(new OtpResponseSendResponseDTO())
      .build();
    org.mockito.Mockito.when(otpServiceFacade.SentOtpViaMobile(addMobile))
      .thenReturn(ResponseEntity.ok(apiResponse));
    ResponseEntity<APIResponse<Object>> response = controller.sendOtpOnMobile(addMobile, "en");
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Send Successfully Mobile: 123456", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNotNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void verifyotpOnMobile_ReturnsSuccessResponseWithValidationData() {
    MobileOtpValidationRequestDTO requestDTO = new MobileOtpValidationRequestDTO();
    APIResponse<OtpResponseValidateResponseDTO> apiResponse = APIResponse.<OtpResponseValidateResponseDTO>builder()
      .data(new OtpResponseValidateResponseDTO())
      .build();
    org.mockito.Mockito.when(otpServiceFacade.ValidateOtpViaMobile(requestDTO))
      .thenReturn(ResponseEntity.ok(apiResponse));
    ResponseEntity<APIResponse<Object>> response = controller.verifyotpOnMobile(requestDTO, null);
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Verify Successfully And Mobile Added Successfully", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNotNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void resendOtpOnMobile_ReturnsSuccessResponseWithResendData() {
    OtpRegenerateRequestDTO requestDTO = new OtpRegenerateRequestDTO();
    APIResponse<OtpResponseResenDResponseDTO> apiResponse = APIResponse.<OtpResponseResenDResponseDTO>builder()
      .data(new OtpResponseResenDResponseDTO())
      .build();
    org.mockito.Mockito.when(otpServiceFacade.ResendOtpViaMobile(requestDTO))
      .thenReturn(ResponseEntity.ok(apiResponse));
    ResponseEntity<APIResponse<Object>> response = controller.resendOtpOnMobile(requestDTO, null);
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Resend Successfully", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNotNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void sendOtpOnEmail_ReturnsSuccessResponseWithNullServiceResponse() {
    AddEmailRequestDTO addEmailDto = new AddEmailRequestDTO();
    org.mockito.Mockito.when(otpServiceFacade.SentOtpViaEmail(addEmailDto)).thenReturn(null);
    ResponseEntity<APIResponse<Object>> response = controller.sendOtpOnEmail(addEmailDto, "en");
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Send Successfully On Email: 654321", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void sendOtpOnEmail_ReturnsSuccessResponseWithNullBody() {
    AddEmailRequestDTO addEmailDto = new AddEmailRequestDTO();
    org.mockito.Mockito.when(otpServiceFacade.SentOtpViaEmail(addEmailDto))
      .thenReturn(ResponseEntity.ok(null));
    ResponseEntity<APIResponse<Object>> response = controller.sendOtpOnEmail(addEmailDto, "en");
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Send Successfully On Email: 654321", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void verifytpOnEmail_ReturnsSuccessResponseWithNullServiceResponse() {
    OtpValidationRequestDTO requestDTO = new OtpValidationRequestDTO();
    org.mockito.Mockito.when(otpServiceFacade.ValidateOtpViaEmail(requestDTO)).thenReturn(null);
    ResponseEntity<APIResponse<Object>> response = controller.verifytpOnEmail(requestDTO, null);
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Verify Successfully and Email Added Successfully", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void verifytpOnEmail_ReturnsSuccessResponseWithNullBody() {
    OtpValidationRequestDTO requestDTO = new OtpValidationRequestDTO();
    org.mockito.Mockito.when(otpServiceFacade.ValidateOtpViaEmail(requestDTO))
      .thenReturn(ResponseEntity.ok(null));
    ResponseEntity<APIResponse<Object>> response = controller.verifytpOnEmail(requestDTO, null);
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Verify Successfully and Email Added Successfully", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void resendOtpOnEmail_ReturnsSuccessResponseWithNullServiceResponse() {
    OtpRegenerateRequestDTO requestDTO = new OtpRegenerateRequestDTO();
    org.mockito.Mockito.when(otpServiceFacade.ResendOtpViaEmail(requestDTO)).thenReturn(null);
    ResponseEntity<APIResponse<Object>> response = controller.resendOtpOnEmail(requestDTO, null);
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Resend Successfully", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void resendOtpOnEmail_ReturnsSuccessResponseWithNullBody() {
    OtpRegenerateRequestDTO requestDTO = new OtpRegenerateRequestDTO();
    org.mockito.Mockito.when(otpServiceFacade.ResendOtpViaEmail(requestDTO))
      .thenReturn(ResponseEntity.ok(null));
    ResponseEntity<APIResponse<Object>> response = controller.resendOtpOnEmail(requestDTO, null);
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Resend Successfully", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void sendOtpOnMobile_ReturnsSuccessResponseWithNullServiceResponse() {
    AddMobileRequestDTO addMobile = new AddMobileRequestDTO();
    org.mockito.Mockito.when(otpServiceFacade.SentOtpViaMobile(addMobile)).thenReturn(null);
    ResponseEntity<APIResponse<Object>> response = controller.sendOtpOnMobile(addMobile, "en");
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Send Successfully Mobile: 123456", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void sendOtpOnMobile_ReturnsSuccessResponseWithNullBody() {
    AddMobileRequestDTO addMobile = new AddMobileRequestDTO();
    org.mockito.Mockito.when(otpServiceFacade.SentOtpViaMobile(addMobile))
      .thenReturn(ResponseEntity.ok(null));
    ResponseEntity<APIResponse<Object>> response = controller.sendOtpOnMobile(addMobile, "en");
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Send Successfully Mobile: 123456", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void verifyotpOnMobile_ReturnsSuccessResponseWithNullServiceResponse() {
    MobileOtpValidationRequestDTO requestDTO = new MobileOtpValidationRequestDTO();
    org.mockito.Mockito.when(otpServiceFacade.ValidateOtpViaMobile(requestDTO)).thenReturn(null);
    ResponseEntity<APIResponse<Object>> response = controller.verifyotpOnMobile(requestDTO, null);
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Verify Successfully And Mobile Added Successfully", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void verifyotpOnMobile_ReturnsSuccessResponseWithNullBody() {
    MobileOtpValidationRequestDTO requestDTO = new MobileOtpValidationRequestDTO();
    org.mockito.Mockito.when(otpServiceFacade.ValidateOtpViaMobile(requestDTO))
      .thenReturn(ResponseEntity.ok(null));
    ResponseEntity<APIResponse<Object>> response = controller.verifyotpOnMobile(requestDTO, null);
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Verify Successfully And Mobile Added Successfully", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void resendOtpOnMobile_ReturnsSuccessResponseWithNullServiceResponse() {
    OtpRegenerateRequestDTO requestDTO = new OtpRegenerateRequestDTO();
    org.mockito.Mockito.when(otpServiceFacade.ResendOtpViaMobile(requestDTO)).thenReturn(null);
    ResponseEntity<APIResponse<Object>> response = controller.resendOtpOnMobile(requestDTO, null);
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Resend Successfully", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNull(response.getBody().getData());
  }

  @org.junit.jupiter.api.Test
  void resendOtpOnMobile_ReturnsSuccessResponseWithNullBody() {
    OtpRegenerateRequestDTO requestDTO = new OtpRegenerateRequestDTO();
    org.mockito.Mockito.when(otpServiceFacade.ResendOtpViaMobile(requestDTO))
      .thenReturn(ResponseEntity.ok(null));
    ResponseEntity<APIResponse<Object>> response = controller.resendOtpOnMobile(requestDTO, null);
    org.junit.jupiter.api.Assertions.assertEquals(200, response.getStatusCodeValue());
    org.junit.jupiter.api.Assertions.assertEquals("OTP Resend Successfully", response.getBody().getMessage());
    org.junit.jupiter.api.Assertions.assertNull(response.getBody().getData());
  }
}