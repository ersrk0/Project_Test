package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.vendorassessment.dto.response.AdditionalDocumentResponseDTO;
import in.gov.gem.app.service.core.repository.LookupRepository;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.vendorassessment.domain.repository.DocumentDetailRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class OrganizationAdditionalDetailimplTest {
  @Mock
  private LookupRepository lookupRepository;
  @Mock
  private MessageUtility messageUtility;
  @Mock
  private DocumentDetailRepository documentDetailRepository;

  @InjectMocks
  private OrganizationAdditionalDetailService service;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void exportToExcelReturnsResponseEntity() {
    AdditionalDocumentResponseDTO doc = new AdditionalDocumentResponseDTO();
    doc.setDocName("TestDoc");
    doc.setDocType("TypeA");
    doc.setUploadedOn("2024-06-01");
    doc.setFileSize(1.5);

    ResponseEntity<byte[]> response = service.exportToExcel(Collections.singletonList(doc));
    assertNotNull(response);
    assertEquals("attachment; filename=Assessment_report.xlsx", response.getHeaders().getFirst("Content-Disposition"));
    assertNotNull(response.getBody());
    assertTrue(response.getBody().length > 0);
  }

  @Test
  void exportToExcelThrowsServiceExceptionOnIOException() {
    // Simulate by passing a list with a null, which is handled, so force exception by mocking messageUtility
    when(messageUtility.getMessage(anyString())).thenReturn("Unexpected error");
    // No real way to force IOException in this context, so this is illustrative
    // In real test, you might refactor to inject Workbook or OutputStream for better testability
  }
}