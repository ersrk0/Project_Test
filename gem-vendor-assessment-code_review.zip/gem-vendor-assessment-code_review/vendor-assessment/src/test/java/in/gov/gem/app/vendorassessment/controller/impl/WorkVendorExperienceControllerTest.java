package in.gov.gem.app.vendorassessment.controller.impl;


import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.request.WorkExperienceNewRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.HierarchyMasterResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.HierarchyResponseDTO;

import in.gov.gem.app.vendorassessment.facade.IWorkVendorExperienceFacade;
import in.gov.gem.app.vendorassessment.transformer.BuyerTransformer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

@ExtendWith(MockitoExtension.class)
class WorkVendorExperienceControllerTest {

  @Mock
  private BuyerTransformer buyerTransformer;

  @Mock
  private IWorkVendorExperienceFacade workVendorExperience;

  @InjectMocks
  private WorkVendorExperienceController controller;

  @Test
  void getOrgAllType_returnsSuccess() {
    PaginationParams paginationParams = new PaginationParams();
    String acceptLanguage = "en";
    HierarchyMasterResponseDTO mockResponse = new HierarchyMasterResponseDTO(); // Correct type

    Mockito.when(workVendorExperience.getOrgType(acceptLanguage, paginationParams)).thenReturn(mockResponse);

    ResponseEntity<APIResponse<Object>> response = controller.getOrgAllType(acceptLanguage, paginationParams);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals("Organization Types fetched successfully", response.getBody().getMessage());
    Assertions.assertEquals(mockResponse, response.getBody().getData());
  }

  @Test
  void getOrgAllTypeWithLevel_returnsSuccess() {
    PaginationParams paginationParams = new PaginationParams();
    String parentId = "123";
    String acceptLanguage = "en";
    HierarchyResponseDTO mockResponse = new HierarchyResponseDTO(); // Correct type

    Mockito.when(workVendorExperience.getOrgTypeWithLevel(parentId, acceptLanguage, paginationParams)).thenReturn(mockResponse);

    ResponseEntity<APIResponse<Object>> response = controller.getOrgAllTypeWithlevel(parentId, acceptLanguage, paginationParams);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals("Heirarchy Organisation fetched successfully", response.getBody().getMessage());
    Assertions.assertEquals(mockResponse, response.getBody().getData());
  }

  @Test
  void createWorkExperience_returnsSuccess() {
    WorkExperienceNewRequestDTO createRequest = WorkExperienceNewRequestDTO.builder()
      .vaMasterFk(1L)
      .departmentName("Department")
      .build();
    WorkExperienceNewRequestDTO mockResponse = WorkExperienceNewRequestDTO.builder()
      .vaMasterFk(1L)
      .departmentName("Department")
      .build(); // Correct type

    Mockito.when(workVendorExperience.createWorkExperience(createRequest)).thenReturn(mockResponse);

    ResponseEntity<APIResponse<Object>> response = controller.createWorkExperience(createRequest);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    //Assertions.assertEquals("Work Experience created successfully", response.getBody().getMessage());
    Assertions.assertEquals(mockResponse, response.getBody().getData());
  }

  @Test
  void getWorkExperience_returnsSuccess() {
    Long vaMasterFk = 1L;
    List<WorkExperienceNewRequestDTO> mockResponse = List.of(
      WorkExperienceNewRequestDTO.builder()
        .vaMasterFk(1L)
        .departmentName("Department")
        .build()
    ); // Correct type

    Mockito.when(workVendorExperience.findByVaMasterFk(vaMasterFk)).thenReturn(mockResponse);

    ResponseEntity<APIResponse<Object>> response = controller.getWorkExperience(vaMasterFk);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals("Work Experience get successfully", response.getBody().getMessage());
    Assertions.assertEquals(mockResponse, response.getBody().getData());
  }

  @Test
  void getOrgAllType_handlesNullResponse() {
    PaginationParams paginationParams = new PaginationParams();
    String acceptLanguage = "en";
    Mockito.when(workVendorExperience.getOrgType(acceptLanguage, paginationParams)).thenReturn(null);

    ResponseEntity<APIResponse<Object>> response = controller.getOrgAllType(acceptLanguage, paginationParams);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals("Organization Types fetched successfully", response.getBody().getMessage());
    Assertions.assertNull(response.getBody().getData());
  }

  @Test
  void getOrgAllTypeWithLevel_handlesNullResponse() {
    PaginationParams paginationParams = new PaginationParams();
    String parentId = "123";
    String acceptLanguage = "en";
    Mockito.when(workVendorExperience.getOrgTypeWithLevel(parentId, acceptLanguage, paginationParams)).thenReturn(null);

    ResponseEntity<APIResponse<Object>> response = controller.getOrgAllTypeWithlevel(parentId, acceptLanguage, paginationParams);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals("Heirarchy Organisation fetched successfully", response.getBody().getMessage());
    Assertions.assertNull(response.getBody().getData());
  }

  @Test
  void createWorkExperience_handlesNullResponse() {
    WorkExperienceNewRequestDTO createRequest = WorkExperienceNewRequestDTO.builder()
      .vaMasterFk(1L)
      .departmentName("Department")
      .build();

    Mockito.when(workVendorExperience.createWorkExperience(createRequest)).thenReturn(null);

    ResponseEntity<APIResponse<Object>> response = controller.createWorkExperience(createRequest);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    //Assertions.assertEquals("Work Experience created successfully", response.getBody().getMessage());
    Assertions.assertNull(response.getBody().getData());
  }

  @Test
  void getWorkExperience_handlesNullResponse() {
    Long vaMasterFk = 1L;
    Mockito.when(workVendorExperience.findByVaMasterFk(vaMasterFk)).thenReturn(null);

    ResponseEntity<APIResponse<Object>> response = controller.getWorkExperience(vaMasterFk);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals("Work Experience get successfully", response.getBody().getMessage());
    Assertions.assertNull(response.getBody().getData());
  }



}

