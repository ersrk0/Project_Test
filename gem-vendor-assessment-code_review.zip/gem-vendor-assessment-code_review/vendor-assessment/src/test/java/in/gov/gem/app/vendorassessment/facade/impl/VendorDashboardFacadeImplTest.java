package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.vendorassessment.dto.response.VendorDashboardDTOResponseDTO;

import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.facade.Impl.VendorDashboardFacade;
import in.gov.gem.app.vendorassessment.service.IVendorDashboardService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VendorDashboardFacadeImplTest {

    private static final String SAMPLE_VA_NUMBER_FOUND = "VA123";
    private static final String SAMPLE_VA_NUMBER_NOT_FOUND = "VA999";
    private static final String SAMPLE_VENDOR_ID = "VENDOR123";
    private static final String CATEGORY_KEY = "category";
    private static final String CATEGORY_VALUE = "IT";

    @InjectMocks
    private VendorDashboardFacade vendorDashboardFacade;

    @Mock
    private IVendorDashboardService vendorDashboardService;

    @Test
    void shouldReturnPaginatedVendorAssessments() {
        PaginationParams params = new PaginationParams(0, 10, "name", Sort.Direction.ASC, "search");
        VendorDashboardDTOResponseDTO dto = new VendorDashboardDTOResponseDTO();
        Page<VendorDashboardDTOResponseDTO> mockPage = new PageImpl<>(List.of(dto));

        when(vendorDashboardService.getAllVendorAssessments(params)).thenReturn(mockPage);

        Page<VendorDashboardDTOResponseDTO> result = vendorDashboardFacade.getAllVendorAssessments(params);

        assertEquals(mockPage, result);
        assertEquals(1, result.getContent().size());
        verify(vendorDashboardService, times(1)).getAllVendorAssessments(params);
    }

    @Test
    void shouldReturnVendorAssessmentWhenVaNumberExists() {
        VendorDashboardDTOResponseDTO dto = new VendorDashboardDTOResponseDTO();

        when(vendorDashboardService.getVendorAssessmentByVaNumber(SAMPLE_VA_NUMBER_FOUND)).thenReturn(Optional.of(dto));

        Optional<VendorDashboardDTOResponseDTO> result = vendorDashboardFacade.getVendorAssessmentByVaNumber(SAMPLE_VA_NUMBER_FOUND);

        assertTrue(result.isPresent());
        assertEquals(dto, result.get());
        verify(vendorDashboardService).getVendorAssessmentByVaNumber(SAMPLE_VA_NUMBER_FOUND);
    }

    @Test
    void shouldReturnEmptyWhenVaNumberNotFound() {
        when(vendorDashboardService.getVendorAssessmentByVaNumber(SAMPLE_VA_NUMBER_NOT_FOUND)).thenReturn(Optional.empty());

        Optional<VendorDashboardDTOResponseDTO> result = vendorDashboardFacade.getVendorAssessmentByVaNumber(SAMPLE_VA_NUMBER_NOT_FOUND);

        assertFalse(result.isPresent());
        verify(vendorDashboardService).getVendorAssessmentByVaNumber(SAMPLE_VA_NUMBER_NOT_FOUND);
    }

    @Test
    void shouldFetchAssessmentCategoriesByVaNumber() {
        List<Map<String, Object>> mockCategories = List.of(Map.of(CATEGORY_KEY, CATEGORY_VALUE));

        when(vendorDashboardService.getCategories(SAMPLE_VA_NUMBER_FOUND)).thenReturn(mockCategories);

        List<Map<String, Object>> result = vendorDashboardFacade.getCategories(SAMPLE_VA_NUMBER_FOUND);

        assertEquals(mockCategories, result);
        verify(vendorDashboardService).getCategories(SAMPLE_VA_NUMBER_FOUND);
    }

    @Test
    void shouldDeleteVendorAssessmentById() {
        doNothing().when(vendorDashboardService).deleteVendorAssessment(SAMPLE_VENDOR_ID);

        vendorDashboardFacade.deleteVendorAssessment(SAMPLE_VENDOR_ID);

        verify(vendorDashboardService).deleteVendorAssessment(SAMPLE_VENDOR_ID);
    }
}
