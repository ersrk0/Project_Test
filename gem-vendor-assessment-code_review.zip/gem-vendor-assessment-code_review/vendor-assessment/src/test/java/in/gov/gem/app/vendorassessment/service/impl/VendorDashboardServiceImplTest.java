package in.gov.gem.app.vendorassessment.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.repository.LookupRepository;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;


import in.gov.gem.app.vendorassessment.dto.response.OrganizationDetailsResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VendorDashboardDTOResponseDTO;

import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.client.ISellerClient;

import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.domain.entity.VAMasterEntity;
import in.gov.gem.app.vendorassessment.domain.repository.VendorAssessmentCategoryRepository;
import in.gov.gem.app.vendorassessment.domain.repository.VendorAssessmentRepository;
import in.gov.gem.app.vendorassessment.service.IVendorDashboardService;
import in.gov.gem.app.vendorassessment.utility.VendorDashboardUtil;
import in.gov.gem.app.vendorassessment.utility.CategoryUtils;
import in.gov.gem.app.vendorassessment.utility.SearchUtils;
import org.junit.jupiter.api.*;
import org.mockito.*;
import org.springframework.data.domain.*;
import org.springframework.http.ResponseEntity;

import java.util.*;

class VendorDashboardServiceImplTest {

    @InjectMocks
    private VendorDashboardService service;

    @Mock private VendorAssessmentRepository assessmentRepository;
    @Mock private VendorAssessmentCategoryRepository categoryRepository;
    @Mock private MessageUtility messageUtility;
    @Mock private VendorDashboardUtil dashboardMapper;
    @Mock private ISellerClient sellerClient;
    @Mock private IVendorDashboardService vendorDashboardService;
    @Mock private LookupRepository lookupRepository;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getAllVendorAssessments_withSearchQuery() {
        OrganizationDetailsResponseDTO orgDetails = new OrganizationDetailsResponseDTO();
        orgDetails.setGemPvtOrgId(3292250000001525L);
        APIResponse<OrganizationDetailsResponseDTO> apiResponse = new APIResponse<>();
        apiResponse.setData(orgDetails);

        VAMasterEntity assessment = new VAMasterEntity();
        assessment.setId(255L);
        Lookup lookup = new Lookup();
        lookup.setLookupCode(null);
        lookup.setLookupValue(null);
        when(lookupRepository.findByLookupCode(null)).thenReturn(Optional.of(lookup));

        PaginationParams params = new PaginationParams(0, 5, "id", Sort.Direction.ASC, "Draft");

        when(sellerClient.getOrganizationDetails()).thenReturn(ResponseEntity.ok(apiResponse));
        when(assessmentRepository.findByPvtOrgMasterFk(3292250000001525L)).thenReturn(List.of(Optional.of(assessment)));
        when(categoryRepository.countByVendorAssessmentFk(255L)).thenReturn(2L);
        when(dashboardMapper.mapToDTO(assessment, 2L, null, null, null))
                .thenReturn(new VendorDashboardDTOResponseDTO());

        try (MockedStatic<SearchUtils> utils = mockStatic(SearchUtils.class)) {
            utils.when(() -> SearchUtils.fuzzySearch(anyList(), eq("Draft")))
                    .thenReturn(List.of(new VendorDashboardDTOResponseDTO()));

            Page<VendorDashboardDTOResponseDTO> result = service.getAllVendorAssessments(params);

            assertEquals(1, result.getContent().size());
            verify(categoryRepository).countByVendorAssessmentFk(255L);
            verify(lookupRepository, times(3)).findByLookupCode(null); // Adjusted to expect 3 calls
            verify(dashboardMapper).mapToDTO(assessment, 2L, null, null, null);
        }
    }

    @Test
    void getAllVendorAssessments_withoutSearchQuery() {
        OrganizationDetailsResponseDTO orgDetails = new OrganizationDetailsResponseDTO();
        orgDetails.setGemPvtOrgId(2595250000001540L);
        APIResponse<OrganizationDetailsResponseDTO> apiResponse = new APIResponse<>();
        apiResponse.setData(orgDetails);
        VAMasterEntity assessment = new VAMasterEntity();
        assessment.setId(255L); // test fallback to 0L
        Lookup lookup = new Lookup();
        lookup.setLookupCode(null);
        lookup.setLookupValue(null);
        when(lookupRepository.findByLookupCode(null)).thenReturn(Optional.of(lookup));

        PaginationParams params = new PaginationParams(0, 5, "id", Sort.Direction.ASC, "");

        when(assessmentRepository.findByPvtOrgMasterFk(2595250000001540L)).thenReturn(List.of(Optional.of(assessment)));
        when(categoryRepository.countByVendorAssessmentFk(255L)).thenReturn(2L);
        when(lookupRepository.findByLookupCode(anyString())).thenReturn(Optional.of(new Lookup()));
        when(dashboardMapper.mapToDTO(any(), anyLong(), anyString(), anyString(), anyString()))
                .thenReturn(new VendorDashboardDTOResponseDTO());
        when(sellerClient.getOrganizationDetails()).thenReturn(ResponseEntity.ok(apiResponse));

        try (MockedStatic<SearchUtils> utils = mockStatic(SearchUtils.class)) {
            Page<VendorDashboardDTOResponseDTO> result = service.getAllVendorAssessments(params);

            assertEquals(0, result.getContent().size());
            verify(categoryRepository).countByVendorAssessmentFk(255L);
            verify(lookupRepository, times(3)).findByLookupCode(null); // Adjusted to expect 3 calls
            verify(dashboardMapper).mapToDTO(assessment, 2L, null, null, null);
        }
    }


    @Test
    void getVendorAssessmentByVaNumber_successWithFallbackId() {
        VAMasterEntity assessment = new VAMasterEntity();
        assessment.setId(null);
        when(assessmentRepository.findByVaNumber("VA-1744780807817")).thenReturn(Optional.of(assessment));
        when(categoryRepository.countByVendorAssessmentFk(6L)).thenReturn(2L);

        Optional<VendorDashboardDTOResponseDTO> result = service.getVendorAssessmentByVaNumber("VA-1744780807817");
        assertTrue(result.isEmpty());
    }

    @Test
    void getCategories_blankVaNumberTriggersException() {
        when(messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR)).thenReturn("Unexpected");

        ServiceException ex = assertThrows(ServiceException.class,
                () -> service.getCategories("  "));
        assertEquals(MessageConstant.UNEXPECTED_ERROR, ex.getCode());
    }

    @Test
    void getCategories_nullVaNumberTriggersException() {
        when(messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR)).thenReturn("Unexpected");

        ServiceException ex = assertThrows(ServiceException.class,
                () -> service.getCategories(null));
        assertEquals(MessageConstant.UNEXPECTED_ERROR, ex.getCode());
    }


    @Test
    void getVendorAssessmentByVaNumber_invalidInputs() {
        when(messageUtility.getMessage(MessageConstant.INVALID_VA_NUMBER)).thenReturn("Invalid");

        assertThrows(ServiceException.class, () -> service.getVendorAssessmentByVaNumber(null));
        assertThrows(ServiceException.class, () -> service.getVendorAssessmentByVaNumber(" "));
    }

    @Test
    void getVendorAssessmentByVaNumber_notFound() {
        when(assessmentRepository.findByVaNumber("VA404")).thenReturn(Optional.empty());
        when(messageUtility.getMessage(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND)).thenReturn("Vendor assessment not found");

        ServiceException ex = assertThrows(ServiceException.class,
                () -> service.getVendorAssessmentByVaNumber("VA404"));
        assertEquals(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND, ex.getCode());
        assertEquals("Vendor assessment not found", ex.getMessage());
    }

    @Test
    void getCategories_validVaNumber() {
        List<Map<String, Object>> cats = List.of(Map.of("name", "X"));

        try (MockedStatic<CategoryUtils> utils = mockStatic(CategoryUtils.class)) {
            utils.when(() -> CategoryUtils.getAllCategoriesForVA("VA-1744780807817")).thenReturn(cats);
            utils.when(() -> CategoryUtils.buildCategoryTree(cats)).thenReturn(cats);

            List<Map<String, Object>> result = service.getCategories("VA-1744780807817");
            assertEquals(1, result.size());
        }
    }

    @Test
    void getCategories_invalidVaNumber() {
        when(messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR)).thenReturn("Unexpected");

        ServiceException ex = assertThrows(ServiceException.class,
                () -> service.getCategories(" "));
        assertEquals(MessageConstant.UNEXPECTED_ERROR, ex.getCode());
    }

    @Test
    void deleteVendorAssessment_successful() {
        VAMasterEntity assessment = new VAMasterEntity();
        assessment.setId(1L);
        assessment.setDeleted(false);

        when(assessmentRepository.findByVaNumber("VA-1744780807817")).thenReturn(Optional.of(assessment));

        service.deleteVendorAssessment("VA-1744780807817");

        assertTrue(assessment.isDeleted());
        assertNotNull(assessment.getUpdateTimestamp());
        verify(assessmentRepository).save(assessment);
    }

    @Test
    void deleteVendorAssessment_nullAndBlank() {
        when(messageUtility.getMessage(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND)).thenReturn("Missing");

        assertThrows(ServiceException.class, () -> service.deleteVendorAssessment(null));
        assertThrows(ServiceException.class, () -> service.deleteVendorAssessment(" "));
    }

    @Test
    void deleteVendorAssessment_vendorNotFound() {
        when(assessmentRepository.findByVaNumber("VA404")).thenReturn(Optional.empty());
        when(messageUtility.getMessage(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND)).thenReturn("Not found");

        ServiceException ex = assertThrows(ServiceException.class,
                () -> service.deleteVendorAssessment("VA404"));
        assertEquals(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND, ex.getCode());
    }

    ///Withouit Page
    // New unit tests for the selected code

    @Test
    @DisplayName("getAllVendorAssessmentsWithouPage returns empty list when no assessments found")
    void getAllVendorAssessmentsWithouPage_noAssessments() {
        when(assessmentRepository.findByPvtOrgMasterFk(3292250000001525L)).thenReturn(Collections.emptyList());

        List<VendorDashboardDTOResponseDTO> result = service.getAllVendorAssessmentsWithouPage(3292250000001525L);

        assertTrue(result.isEmpty());
    }

    @Test
    @DisplayName("getAllVendorAssessmentsWithouPage returns mapped DTOs for valid assessments")
    void getAllVendorAssessmentsWithouPage_validAssessments() {
        VAMasterEntity assessment = new VAMasterEntity();
        assessment.setId(1L);
        when(assessmentRepository.findByPvtOrgMasterFk(3292250000001525L)).thenReturn(List.of(Optional.of(assessment)));
        when(categoryRepository.countByVendorAssessmentFk(1L)).thenReturn(5L);

        List<VendorDashboardDTOResponseDTO> result = service.getAllVendorAssessmentsWithouPage(3292250000001525L);

        assertEquals(0, result.size());
    }

    @Test
    @DisplayName("getAllVendorAssessmentsWithouPage filters out null DTOs")
    void getAllVendorAssessmentsWithouPage_nullDTOsFiltered() {
        VAMasterEntity assessment = new VAMasterEntity();
        assessment.setId(1L);
        when(assessmentRepository.findByPvtOrgMasterFk(3292250000001525L)).thenReturn(List.of(Optional.of(assessment)));
        when(categoryRepository.countByVendorAssessmentFk(1L)).thenReturn(5L);

        List<VendorDashboardDTOResponseDTO> result = service.getAllVendorAssessmentsWithouPage(3292250000001525L);

        assertTrue(result.isEmpty());
    }

    @Test
    @DisplayName("getAllVendorAssessmentsWithouPage handles null assessment IDs gracefully")
    void getAllVendorAssessmentsWithouPage_nullAssessmentId() {
        VAMasterEntity assessment = new VAMasterEntity();
        assessment.setId(null);
        when(assessmentRepository.findByPvtOrgMasterFk(3292250000001525L)).thenReturn(List.of(Optional.of(assessment)));
        when(categoryRepository.countByVendorAssessmentFk(0L)).thenReturn(3L);

        List<VendorDashboardDTOResponseDTO> result = service.getAllVendorAssessmentsWithouPage(3292250000001525L);

        assertEquals(0, result.size());
    }

    // get vendor

    @Test
    @DisplayName("getVendorAssessment returns mapped DTO for valid assessment")
    void getVendorAssessment_returnsMappedDTO() {
        VAMasterEntity assessment = new VAMasterEntity();
        assessment.setId(10L);
        assessment.setVaStatusLookUp("STATUS");
        assessment.setSubStatusLookUp("SUBSTATUS");
        assessment.setApplyAsLookUp("APPLYAS");

        when(assessmentRepository.findById(10L)).thenReturn(Optional.of(assessment));
        when(categoryRepository.countByVendorAssessmentFk(10L)).thenReturn(2L);
        Lookup statusLookup = new Lookup();
        statusLookup.setLookupCode("STATUS");
        statusLookup.setLookupValue("Active");
        when(lookupRepository.findByLookupCode("STATUS")).thenReturn(Optional.of(statusLookup));

        Lookup subStatusLookup = new Lookup();
        subStatusLookup.setLookupCode("SUBSTATUS");
        subStatusLookup.setLookupValue("Pending");
        when(lookupRepository.findByLookupCode("SUBSTATUS")).thenReturn(Optional.of(subStatusLookup));

        Lookup applyAsLookup = new Lookup();
        applyAsLookup.setLookupCode("APPLYAS");
        applyAsLookup.setLookupValue("Self");
        when(lookupRepository.findByLookupCode("APPLYAS")).thenReturn(Optional.of(applyAsLookup));
        VendorDashboardDTOResponseDTO dto = new VendorDashboardDTOResponseDTO();
        when(dashboardMapper.mapToDTO(assessment, 2L, "Active", "Pending", "Self")).thenReturn(dto);

        VendorDashboardDTOResponseDTO result = service.getVendorAssessment(10L);

        assertSame(dto, result);
    }

    @Test
    @DisplayName("getVendorAssessment uses fallback values when lookups are missing")
    void getVendorAssessment_usesFallbackForMissingLookups() {
        VAMasterEntity assessment = new VAMasterEntity();
        assessment.setId(11L);
        assessment.setVaStatusLookUp("STATUS");
        assessment.setSubStatusLookUp("SUBSTATUS");
        assessment.setApplyAsLookUp("APPLYAS");

        when(assessmentRepository.findById(11L)).thenReturn(Optional.of(assessment));
        when(categoryRepository.countByVendorAssessmentFk(11L)).thenReturn(1L);
        when(lookupRepository.findByLookupCode("STATUS")).thenReturn(Optional.empty());
        when(lookupRepository.findByLookupCode("SUBSTATUS")).thenReturn(Optional.empty());
        when(lookupRepository.findByLookupCode("APPLYAS")).thenReturn(Optional.empty());
        VendorDashboardDTOResponseDTO dto = new VendorDashboardDTOResponseDTO();
        when(dashboardMapper.mapToDTO(assessment, 1L, null, null, null)).thenReturn(dto);

        VendorDashboardDTOResponseDTO result = service.getVendorAssessment(11L);
        assertSame(dto, result);
    }

    @Test
    @DisplayName("getVendorAssessment uses 0L for null assessment id")
    void getVendorAssessment_usesZeroForNullAssessmentId() {
        VAMasterEntity assessment = new VAMasterEntity();
        assessment.setId(null);
        assessment.setVaStatusLookUp("STATUS");
        assessment.setSubStatusLookUp("SUBSTATUS");
        assessment.setApplyAsLookUp("APPLYAS");

        when(assessmentRepository.findById(12L)).thenReturn(Optional.of(assessment));
        when(categoryRepository.countByVendorAssessmentFk(0L)).thenReturn(0L);
        when(lookupRepository.findByLookupCode("STATUS")).thenReturn(Optional.empty());
        when(lookupRepository.findByLookupCode("SUBSTATUS")).thenReturn(Optional.empty());
        when(lookupRepository.findByLookupCode("APPLYAS")).thenReturn(Optional.empty());
        VendorDashboardDTOResponseDTO dto = new VendorDashboardDTOResponseDTO();
        when(dashboardMapper.mapToDTO(assessment, 0L, null, null, null)).thenReturn(dto);

        VendorDashboardDTOResponseDTO result = service.getVendorAssessment(12L);

        assertSame(dto, result);
    }

    @Test
    @DisplayName("getVendorAssessment throws NoSuchElementException when assessment not found")
    void getVendorAssessment_throwsWhenAssessmentNotFound() {
        when(assessmentRepository.findById(99L)).thenReturn(Optional.empty());
        ServiceException ex = assertThrows(ServiceException.class, () -> service.getVendorAssessment(99L));
        assertEquals(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND, ex.getCode());
    }
}
