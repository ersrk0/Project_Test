package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;

import in.gov.gem.app.vendorassessment.dto.response.GuidelineResponseDTO;
import in.gov.gem.app.vendorassessment.facade.IVendorAssessmentGuidelineFacade;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class VendorAssessmentGuidelineControllerTest {

    @Mock
    private IVendorAssessmentGuidelineFacade vendorAssessmentGuidelineFacade;

    @InjectMocks
    private VendorAssessmentGuidelineController controller;

    @Test
    void fetchGuidelines_ReturnsOkWithGuidelineResponse_WhenValidLookupName() {
        String lookupName = "testLookup";
        GuidelineResponseDTO guidelineResponseDTO = new GuidelineResponseDTO();
        when(vendorAssessmentGuidelineFacade.fetchGuidelines(lookupName)).thenReturn(guidelineResponseDTO);

        ResponseEntity<APIResponse<Object>> response = controller.fetchGuidelines(lookupName);

        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals("success", response.getBody().getStatus());
        assertEquals(guidelineResponseDTO, response.getBody().getData());
    }

    @Test
    void fetchGuidelines_ReturnsOkWithNull_WhenFacadeReturnsNull() {
        String lookupName = "unknown";
        when(vendorAssessmentGuidelineFacade.fetchGuidelines(lookupName)).thenReturn(null);

        ResponseEntity<APIResponse<Object>> response = controller.fetchGuidelines(lookupName);

        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals("success", response.getBody().getStatus());
        assertNull(response.getBody().getData());
    }
}
