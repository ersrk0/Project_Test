package in.gov.gem.app.vendorassessment.transformer;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.client.IMdmClient;
import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.dto.response.BankAddressResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.BankResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.BankSellerResponseDTO;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BankTransformerTest {

  @Mock
  private ISellerClient iSellerClient;

  @Mock
  private IMdmClient iMdmClient;

  @InjectMocks
  private BankTransformer bankTransformer; // The class you're testing

  private final String LANGUAGE_CODE = "en";

  @Test
  void shouldReturnBankDetailsWhenPresent() {
    // Arrange
    BankResponseDTO bank = BankResponseDTO.builder()
      .id(1L)
      .bankName("Sample Bank")
      .accountHolderName("Bruce Wayne")
      .accountNumber("12345678")
      .ifscCode("SMPB0001")
      .build();

    BankAddressResponseDTO address = new BankAddressResponseDTO();
    address.setBranchAddress("Gotham City Branch");

    APIResponse<BankAddressResponseDTO> addressResponse = new APIResponse<>();
    addressResponse.setData(address);

    PageableApiResponse<List<BankResponseDTO>> bankResponse = new PageableApiResponse<>();
    bankResponse.setData(List.of(bank));

    when(iSellerClient.getBankDetails(any())).thenReturn(ResponseEntity.ok(bankResponse));
    when(iMdmClient.getBankAddress(eq("SMPB0001"), eq(LANGUAGE_CODE)))
      .thenReturn(ResponseEntity.ok(addressResponse));

    // Act
    List<BankSellerResponseDTO> result = bankTransformer.getBankDetailsFromSeller(new PaginationParams(), LANGUAGE_CODE);

    // Assert
    assertEquals(1, result.size());
    BankSellerResponseDTO dto = result.get(0);
    assertEquals("Sample Bank", dto.getBankName());
    assertEquals("Gotham City Branch", dto.getBankAddress());
  }

  @Test
  void shouldReturnEmptyListWhenNoBankData() {
    // Arrange
    PageableApiResponse<List<BankResponseDTO>> emptyBankResponse = new PageableApiResponse<>();
    emptyBankResponse.setData(Collections.emptyList());

    when(iSellerClient.getBankDetails(any())).thenReturn(ResponseEntity.ok(emptyBankResponse));

    // Act
    List<BankSellerResponseDTO> result = bankTransformer.getBankDetailsFromSeller(new PaginationParams(), LANGUAGE_CODE);

    // Assert
    assertTrue(result.isEmpty());
  }

  @Test
  void shouldReturnEmptyListWhenSellerClientResponseIsNull() {
    // Arrange
    when(iSellerClient.getBankDetails(any())).thenReturn(null);

    // Act
    List<BankSellerResponseDTO> result = bankTransformer.getBankDetailsFromSeller(new PaginationParams(), LANGUAGE_CODE);

    // Assert
    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void shouldHandleNullBankAddressGracefully() {
    // Arrange
    BankResponseDTO bank = BankResponseDTO.builder()
      .id(2L)
      .bankName("NoAddr Bank")
      .accountHolderName("Clark Kent")
      .accountNumber("00000000")
      .ifscCode("NA0000")
      .build();

    APIResponse<BankAddressResponseDTO> addressResponse = new APIResponse<>();
    addressResponse.setData(new BankAddressResponseDTO()); // address is null

    PageableApiResponse<List<BankResponseDTO>> bankResponse = new PageableApiResponse<>();
    bankResponse.setData(List.of(bank));

    when(iSellerClient.getBankDetails(any())).thenReturn(ResponseEntity.ok(bankResponse));
    when(iMdmClient.getBankAddress(eq("NA0000"), anyString()))
      .thenReturn(ResponseEntity.ok(addressResponse));

    // Act
    List<BankSellerResponseDTO> result = bankTransformer.getBankDetailsFromSeller(new PaginationParams(), LANGUAGE_CODE);

    // Assert
    assertEquals(1, result.size());
    assertNull(result.get(0).getBankAddress());
  }
}
