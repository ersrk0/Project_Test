package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.vendorassessment.client.ISellerClient;



import in.gov.gem.app.vendorassessment.dto.request.VendorAssessmentNewRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.InitiateResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OrganizationDetailsResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VendorAssessmentIdResponseDTO;
import in.gov.gem.app.vendorassessment.domain.entity.VAMasterEntity;
import in.gov.gem.app.vendorassessment.domain.repository.VendorAssessmentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class VendorAssessmentServiceImplTest {

    @Mock
    private VendorAssessmentRepository repository;

    @Mock
    private ISellerClient sellerClient;

    @Mock
    private MessageUtility messageUtility;

    @InjectMocks
    private VendorAssessmentService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }


    // New tests for VendorAssessmentServiceImpl

    @Test
    void fetchBrandOemOspDashboardStatus_ReturnsTrue_WhenNeedDashboardIsFalse() {
        VAMasterEntity vendorAssessment = mock(VAMasterEntity.class);
        when(vendorAssessment.getNeedDashboard()).thenReturn(false);
        when(repository.findById(anyLong())).thenReturn(Optional.of(vendorAssessment));

        boolean result = service.fetchBrandOemOspDashboardStatus(1L);

        assertTrue(result);
    }

    @Test
    void fetchBrandOemOspDashboardStatus_ReturnsFalse_WhenNeedDashboardIsTrue() {
        VAMasterEntity vendorAssessment = mock(VAMasterEntity.class);
        when(vendorAssessment.getNeedDashboard()).thenReturn(true);
        when(repository.findById(anyLong())).thenReturn(Optional.of(vendorAssessment));

        boolean result = service.fetchBrandOemOspDashboardStatus(1L);

        assertFalse(result);
    }

    @Test
    void fetchBrandOemOspDashboardStatus_ReturnsFalse_WhenVendorAssessmentNotFound() {
        when(repository.findById(anyLong())).thenReturn(Optional.empty());

        boolean result = service.fetchBrandOemOspDashboardStatus(1L);

        assertFalse(result);
    }

    @Test
    void fetchBrandOemOspDashboardStatus_ThrowsServiceException_OnRepositoryException() {
        when(repository.findById(anyLong())).thenThrow(new RuntimeException("DB error"));
        when(messageUtility.getMessage(anyString())).thenReturn("Unexpected error");

        assertThrows(ServiceException.class, () -> service.fetchBrandOemOspDashboardStatus(1L));
    }

    @Test
    void fetchSupplementaryVAId_ReturnsVendorAssessmentIds_WhenAssessmentsExist() {
        OrganizationDetailsResponseDTO orgDetails = new OrganizationDetailsResponseDTO();
        orgDetails.setGemPvtOrgId(123L);
        APIResponse<OrganizationDetailsResponseDTO> apiResponse = new APIResponse<>();
        apiResponse.setData(orgDetails);

        VAMasterEntity va1 = mock(VAMasterEntity.class);
        VAMasterEntity va2 = mock(VAMasterEntity.class);
        when(va1.getVaNumber()).thenReturn("VA001");
        when(va2.getVaNumber()).thenReturn("VA002");

        when(sellerClient.getOrganizationDetails()).thenReturn(ResponseEntity.ok(apiResponse));
        when(repository.findByPvtOrgMasterFk(123L)).thenReturn(Arrays.asList(Optional.of(va1), Optional.of(va2)));

        VendorAssessmentIdResponseDTO result = service.fetchSupplementaryVAId();

        assertNotNull(result);
        assertEquals(2, result.getVendorAssessmentIds().size());
        assertTrue(result.getVendorAssessmentIds().contains("VA001"));
        assertTrue(result.getVendorAssessmentIds().contains("VA002"));
    }

    @Test
    void fetchSupplementaryVAId_ReturnsEmptyList_WhenNoAssessmentsExist() {
        OrganizationDetailsResponseDTO orgDetails = new OrganizationDetailsResponseDTO();
        orgDetails.setGemPvtOrgId(123L);
        APIResponse<OrganizationDetailsResponseDTO> apiResponse = new APIResponse<>();
        apiResponse.setData(orgDetails);

        when(sellerClient.getOrganizationDetails()).thenReturn(ResponseEntity.ok(apiResponse));
        when(repository.findByPvtOrgMasterFk(123L)).thenReturn(Collections.emptyList());

        VendorAssessmentIdResponseDTO result = service.fetchSupplementaryVAId();

        assertNotNull(result);
        assertTrue(result.getVendorAssessmentIds().isEmpty());
    }

    @Test
    void fetchSupplementaryVAId_ThrowsServiceException_WhenOrganizationDetailsIsNull() {
        APIResponse<OrganizationDetailsResponseDTO> apiResponse = new APIResponse<>();
        apiResponse.setData(null);

        when(sellerClient.getOrganizationDetails()).thenReturn(ResponseEntity.ok(apiResponse));
        when(messageUtility.getMessage(anyString())).thenReturn("Unexpected error");

        assertThrows(ServiceException.class, () -> service.fetchSupplementaryVAId());
    }

    @Test
    void fetchSupplementaryVAId_ThrowsServiceException_OnRepositoryException() {
        OrganizationDetailsResponseDTO orgDetails = new OrganizationDetailsResponseDTO();
        orgDetails.setGemPvtOrgId(123L);
        APIResponse<OrganizationDetailsResponseDTO> apiResponse = new APIResponse<>();
        apiResponse.setData(orgDetails);

        when(sellerClient.getOrganizationDetails()).thenReturn(ResponseEntity.ok(apiResponse));
        when(repository.findByPvtOrgMasterFk(123L)).thenThrow(new RuntimeException("DB error"));
        when(messageUtility.getMessage(anyString())).thenReturn("Unexpected error");

        assertThrows(ServiceException.class, () -> service.fetchSupplementaryVAId());
    }

    //increase

    // Java
    @Test
    void initiateVendorAssessment_ReturnsNoNewRequest_WhenDraftExists() {
        VendorAssessmentNewRequestDTO request = new VendorAssessmentNewRequestDTO();
        request.setAssessmentType("TYPE1");

        OrganizationDetailsResponseDTO orgDetails = new OrganizationDetailsResponseDTO();
        orgDetails.setGemPvtOrgId(123L);
        APIResponse<OrganizationDetailsResponseDTO> apiResponse = new APIResponse<>();
        apiResponse.setData(orgDetails);

        when(sellerClient.getOrganizationDetails()).thenReturn(ResponseEntity.ok(apiResponse));
        when(repository.existsByPvtOrgMasterFkAndVaStatusLookUpAndApplyAsLookUp(123L, "Draft", "TYPE1")).thenReturn(true);

        InitiateResponseDTO result = service.initiateVendorAssessment(request);

        assertNotNull(result);
        assertFalse(result.getRaiseNewRequest());
        assertTrue(result.getMessage().contains("draft VA request"));
    }

    @Test
    void initiateVendorAssessment_ReturnsNewRequest_WhenNoDraftExists() {
        VendorAssessmentNewRequestDTO request = new VendorAssessmentNewRequestDTO();
        request.setAssessmentType("TYPE2");

        OrganizationDetailsResponseDTO orgDetails = new OrganizationDetailsResponseDTO();
        orgDetails.setGemPvtOrgId(456L);
        APIResponse<OrganizationDetailsResponseDTO> apiResponse = new APIResponse<>();
        apiResponse.setData(orgDetails);

        when(sellerClient.getOrganizationDetails()).thenReturn(ResponseEntity.ok(apiResponse));
        when(repository.existsByPvtOrgMasterFkAndVaStatusLookUpAndApplyAsLookUp(456L, "Draft", "TYPE2")).thenReturn(false);

        InitiateResponseDTO result = service.initiateVendorAssessment(request);

        assertNotNull(result);
        assertTrue(result.getRaiseNewRequest());
        assertTrue(result.getMessage().contains("raise a new request"));
    }

    @Test
    void initiateVendorAssessment_ThrowsServiceException_OnException() {
        VendorAssessmentNewRequestDTO request = new VendorAssessmentNewRequestDTO();
        when(sellerClient.getOrganizationDetails()).thenThrow(new RuntimeException("error"));
        when(messageUtility.getMessage(anyString())).thenReturn("Unexpected error");

        assertThrows(ServiceException.class, () -> service.initiateVendorAssessment(request));
    }
}
