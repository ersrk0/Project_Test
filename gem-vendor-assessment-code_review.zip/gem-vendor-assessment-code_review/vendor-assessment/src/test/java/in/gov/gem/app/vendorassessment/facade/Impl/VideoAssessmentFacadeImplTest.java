package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.vendorassessment.facade.Impl.VideoAssessmentFacade;
import in.gov.gem.app.vendorassessment.service.IVideoAssessmentService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@Slf4j
class VideoAssessmentFacadeImplTest {


  @Mock
  private IVideoAssessmentService videoAssessmentService;

  @InjectMocks
  private VideoAssessmentFacade videoAssessmentFacade;


  @Test
  void shouldGetInstructionsForValidSellerId() {
    String sellerId = "SELLER123";
    when(videoAssessmentService.fetchInstructions(sellerId)).thenReturn("Instructions");

    Object result = videoAssessmentFacade.getInstructions(sellerId);

    assertThat(result).isEqualTo("Instructions");
    verify(videoAssessmentService).fetchInstructions(sellerId);
  }

  @Test
  void shouldReturnAppDownloadLink() {
    when(videoAssessmentService.fetchAppDownloadLink()).thenReturn("http://example.com/app");

    Object result = videoAssessmentFacade.getAppDownloadLink();

    assertThat(result).isEqualTo("http://example.com/app");
    verify(videoAssessmentService).fetchAppDownloadLink();
  }





  @Test
  void shouldFetchScheduleAssessment() {
    when(videoAssessmentService.fetchScheduleAssessmentDateTime()).thenReturn("2024-03-21T10:00:00Z");

    Object result = videoAssessmentFacade.fetchScheduleAssessment();

    assertThat(result).isEqualTo("2024-03-21T10:00:00Z");
    verify(videoAssessmentService).fetchScheduleAssessmentDateTime();
  }

}