package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.vendorassessment.dto.response.CountryResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.FetchLocationResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.NewVAResponseOrganizationAddressDTO;
import in.gov.gem.app.vendorassessment.dto.response.VAResponseOrganizationAddressResponseDTO;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;

import in.gov.gem.app.vendorassessment.dto.request.VAOrganizationAddressRequestDTO;

import in.gov.gem.app.vendorassessment.facade.IManufacturingAddressFacade;
import in.gov.gem.app.vendorassessment.facade.Impl.MdmFacade;
import in.gov.gem.app.vendorassessment.transformer.MdmTransformer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

@ExtendWith(MockitoExtension.class)
class ManufacturingAddressControllerTest {

  @Mock
  private MdmFacade mdmTransformer;

  @Mock
  private IManufacturingAddressFacade manufacturingAddress;

  @InjectMocks
  private ManufacturingAddressController controller;

  @Test
  void getLocation_returnsLocationListSuccessfully() {
    PaginationParams paginationParams = new PaginationParams();
    String locationCode = "IN";
    String languageCode = "en";
    List<FetchLocationResponseDTO> locations = List.of(new FetchLocationResponseDTO("code", "123", "village", "subDistrict", "district", "state", "country"));
    Mockito.when(manufacturingAddress.getLocationListFromMdm(paginationParams, locationCode, languageCode)).thenReturn(locations);

    ResponseEntity<APIResponse<Object>> response = controller.getLocation(paginationParams, locationCode, languageCode);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals(locations, response.getBody().getData());
  }

  @Test
  void getPincode_returnsPincodeListSuccessfully() {
    PaginationParams paginationParams = new PaginationParams();
    String locationCode = "IN";
    String languageCode = "en";
    List<FetchLocationResponseDTO> pincodes = List.of(new FetchLocationResponseDTO("code", "123", "village", "subDistrict", "district", "state", "country"));
    Mockito.when(manufacturingAddress.getLocationListFromMdm(paginationParams, locationCode, languageCode)).thenReturn(pincodes);

    ResponseEntity<APIResponse<Object>> response = controller.getPincode(paginationParams, locationCode, languageCode);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals(pincodes, response.getBody().getData());
  }

  @Test
  void getCountries_returnsCountryListSuccessfully() {
    PaginationParams paginationParams = new PaginationParams();
    String languageCode = "en";
    List<CountryResponseDTO> countries = List.of();
    Mockito.when(mdmTransformer.fetchCountryList(paginationParams, languageCode)).thenReturn(countries);

    ResponseEntity<APIResponse<Object>> response = controller.getCountries(paginationParams, languageCode);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals(countries, response.getBody().getData());
  }

  @Test
  void saveManufacturingAddress_returnsSavedAddressSuccessfully() {
    VAOrganizationAddressRequestDTO dto = new VAOrganizationAddressRequestDTO();
    Mockito.when(manufacturingAddress.saveManufacturingAddress(dto)).thenReturn(dto);

    ResponseEntity<APIResponse<Object>> response = controller.saveManufacturingAddress(dto);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals(dto, response.getBody().getData());
  }

  @Test
  void getManufacturingAddress_returnsAddressListSuccessfully() {
    Long vaOrganizationDetailFk = 1L;
    List<VAOrganizationAddressRequestDTO> addresses = List.of(new VAOrganizationAddressRequestDTO());
    Mockito.when(manufacturingAddress.findByVaOrganizationDetailFk(vaOrganizationDetailFk)).thenReturn(addresses);

    ResponseEntity<APIResponse<Object>> response = controller.getManufacturingAddress(vaOrganizationDetailFk);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals(addresses, response.getBody().getData());
  }

  @Test
  void saveAssessAsManufacturingAddress_returnsSavedAddressSuccessfully() {
    VAOrganizationAddressRequestDTO dto = new VAOrganizationAddressRequestDTO();
    String vaNumber = "VA123";
    Mockito.when(manufacturingAddress.saveManufacturingAddressAssessAs(dto, vaNumber)).thenReturn(dto);

    ResponseEntity<APIResponse<Object>> response = controller.saveAssessAsManufacturingAddress(dto, vaNumber);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals(dto, response.getBody().getData());
  }

  @Test
  void saveVendorSellerManufacturingAddress_returnsSavedAddressSuccessfully() {
    VAOrganizationAddressRequestDTO dto = new VAOrganizationAddressRequestDTO();
    String vaNumber = "VA456";
    Mockito.when(manufacturingAddress.saveAddressInVendorAndSeller(dto, vaNumber)).thenReturn(dto);

    ResponseEntity<APIResponse<Object>> response = controller.saveVendorSellerManufacturingAddress(dto, vaNumber);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals(dto, response.getBody().getData());
    Assertions.assertEquals("Data saved successfully in vendor and seller", response.getBody().getMessage());
  }

  @Test
  void getManufacturingAddress_returnsEmptyListWhenNoAddressesFound() {
    Long vaOrganizationDetailFk = 2L;
    Mockito.when(manufacturingAddress.findByVaOrganizationDetailFk(vaOrganizationDetailFk)).thenReturn(List.of());

    ResponseEntity<APIResponse<Object>> response = controller.getManufacturingAddress(vaOrganizationDetailFk);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertTrue(((List<?>) response.getBody().getData()).isEmpty());
  }

  @Test
  void saveManufacturingAddress_returnsNullWhenInputIsNull() {
    Mockito.when(manufacturingAddress.saveManufacturingAddress(null)).thenReturn(null);

    ResponseEntity<APIResponse<Object>> response = controller.saveManufacturingAddress(null);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertNull(response.getBody().getData());
  }

  @Test
  void getManufactureAddress_returnsPaginatedAddressesSuccessfully() {
    Long vaOrganizationDetailFk = 1L;
    PaginationParams paginationParams = new PaginationParams();
    List<VAOrganizationAddressRequestDTO> addresses = List.of(new VAOrganizationAddressRequestDTO());
    PageableApiResponse<List<VAOrganizationAddressRequestDTO>> pageableResponse = new PageableApiResponse<>();
    pageableResponse.setData(addresses);
    Mockito.when(manufacturingAddress.findByVaOrganizationDetailFk(paginationParams, vaOrganizationDetailFk)).thenReturn(pageableResponse);

    ResponseEntity<APIResponse<Object>> response = controller.getManufactureAddress(vaOrganizationDetailFk, paginationParams);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals(addresses, response.getBody().getData());
  }

  @Test
  void getManufactureMasterAddress_returnsMasterAddressesSuccessfully() {
    Long vaMasterFk = 1L;
    List<VAOrganizationAddressRequestDTO> addresses = List.of(new VAOrganizationAddressRequestDTO());
    Mockito.when(manufacturingAddress.findByVaMasterFk(vaMasterFk)).thenReturn(addresses);

    ResponseEntity<APIResponse<Object>> response = controller.getManufactureMasterAddress(vaMasterFk);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals(addresses, response.getBody().getData());
  }

  @Test
  void getManufactureMasterPagingAddress_returnsPaginatedMasterAddressesSuccessfully() {
    Long vaMasterFk = 1L;
    PaginationParams paginationParams = new PaginationParams();
    List<VAOrganizationAddressRequestDTO> addresses = List.of(new VAOrganizationAddressRequestDTO());
    PageableApiResponse<List<VAOrganizationAddressRequestDTO>> pageableResponse = new PageableApiResponse<>();
    pageableResponse.setData(addresses);
    Mockito.when(manufacturingAddress.findByVaMasterFk(paginationParams, vaMasterFk)).thenReturn(pageableResponse);

    ResponseEntity<APIResponse<Object>> response = controller.getManufactureMasterPagingAddress(vaMasterFk, paginationParams);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals(addresses, response.getBody().getData());
  }

  @Test
  void getManufacturingPreIdAddress_returnsPreIdAddressesSuccessfully() {
    Long id = 1L;
    List<VAResponseOrganizationAddressResponseDTO> addresses = List.of(new VAResponseOrganizationAddressResponseDTO());
    Mockito.when(manufacturingAddress.findById(id)).thenReturn(addresses);

    ResponseEntity<APIResponse<Object>> response = controller.getManufacturingPreIdAddress(id);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals(addresses, response.getBody().getData());
  }

  @Test
  void NewgetManufacturingPreIdAddress_returnsNewPreIdAddressesSuccessfully() {
    Long id = 1L;
    List<NewVAResponseOrganizationAddressDTO> addresses = List.of(new NewVAResponseOrganizationAddressDTO());
    Mockito.when(manufacturingAddress.findByNewId(id)).thenReturn(addresses);

    ResponseEntity<APIResponse<Object>> response = controller.NewgetManufacturingPreIdAddress(id);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertEquals(addresses, response.getBody().getData());
  }

//  @Test
//  void deleteManufacturingPreAddress_deletesSuccessfully() {
//    Long id = 1L;
//    List<VAResponseOrganizationAddressDTO> addresses = List.of(new VAResponseOrganizationAddressDTO());
//    Mockito.when(manufacturingAddress.findById(id)).thenReturn(addresses);
//
//    ResponseEntity<APIResponse<Object>> response = controller.deleteManufacturingPreAddress(id);
//
//    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
//    Assertions.assertNull(response.getBody().getData());
//    Assertions.assertEquals("Manufacturing address deleted successfully", response.getBody().getMessage());
//    Mockito.verify(manufacturingAddress).deleteById(id);
//  }

  @Test
  void updateManufacturingPreIdAddress_updatesSuccessfully() {
    Long id = 1L;
    VAOrganizationAddressRequestDTO dto = new VAOrganizationAddressRequestDTO();

    ResponseEntity<APIResponse<Object>> response = controller.updateManufacturingPreIdAddress(id, dto);

    Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    Assertions.assertNull(response.getBody().getData());
    Assertions.assertEquals("Manufacturing address updated successfully", response.getBody().getMessage());
    Mockito.verify(manufacturingAddress).updateById(id, dto);
  }
}