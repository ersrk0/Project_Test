package in.gov.gem.app.vendorassessment.transformer;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;



import in.gov.gem.app.vendorassessment.dto.response.VendorDashboardDTOResponseDTO;


import in.gov.gem.app.vendorassessment.domain.entity.VAMasterEntity;
import in.gov.gem.app.vendorassessment.utility.ActionDeterminer;
import in.gov.gem.app.vendorassessment.utility.VendorDashboardUtil;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

@ExtendWith(MockitoExtension.class)
public class VendorDashboardUtilTest {
     @InjectMocks
     private VendorDashboardUtil vendorDashboardMapper;

        @Mock
        private VAMasterEntity vendorAssessment;

        @Test
        void mapToDTO_ReturnsDTO_WhenAllInputsAreValid() {
            when(vendorAssessment.getVaNumber()).thenReturn("VA123");
            when(vendorAssessment.getId()).thenReturn(1L);
            when(vendorAssessment.getCreatedTimestamp()).thenReturn(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());
            when(vendorAssessment.getValidUpTo()).thenReturn(LocalDateTime.now().plusDays(30).atZone(ZoneId.systemDefault()).toInstant());
            VendorDashboardDTOResponseDTO result = vendorDashboardMapper.mapToDTO(vendorAssessment, 5L, "Approved", "Active", "Verified");

            assertNotNull(result);
            assertEquals("VA123", result.getVaId());
            assertEquals(1L, result.getId());
            assertEquals("Approved", result.getStatus());
            assertEquals("Active", result.getSubStatus());
            assertEquals("Verified", result.getAssessedAs());
            assertEquals(5, result.getCategoryCount());
            assertEquals("Verifying Agency", result.getAssessedBy());
            assertNotNull(result.getSubmittedOn());
            assertNotNull(result.getValidUpTo());
            assertTrue(result.getActions().contains("View"));
        }

        @Test
        void mapToDTO_ReturnsNull_WhenVaNumberIsNull() {
            when(vendorAssessment.getVaNumber()).thenReturn(null);

            VendorDashboardDTOResponseDTO result = vendorDashboardMapper.mapToDTO(vendorAssessment, 0L, null, null, null);

            assertNull(result);
        }

        @Test
        void mapToDTO_AddsDefaultAction_WhenActionsListIsEmpty() {
            when(vendorAssessment.getVaNumber()).thenReturn("VA123");
            when(vendorAssessment.getId()).thenReturn(1L);
            when(vendorAssessment.getCreatedTimestamp()).thenReturn(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());
            when(vendorAssessment.getValidUpTo()).thenReturn(LocalDateTime.now().plusDays(30).atZone(ZoneId.systemDefault()).toInstant());
            mockStatic(ActionDeterminer.class);
            when(ActionDeterminer.determineActions("Approved", "Active")).thenReturn(Collections.emptyList());

            VendorDashboardDTOResponseDTO result = vendorDashboardMapper.mapToDTO(vendorAssessment, 0L, null, null, null);

            assertNotNull(result);
            assertTrue(result.getActions().contains("View"));
        }

        @Test
        void mapToDTO_HandlesNullCategoryCountGracefully() {
            when(vendorAssessment.getVaNumber()).thenReturn("VA123");
            when(vendorAssessment.getId()).thenReturn(1L);
            when(vendorAssessment.getCreatedTimestamp()).thenReturn(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());
            when(vendorAssessment.getValidUpTo()).thenReturn(LocalDateTime.now().plusDays(30).atZone(ZoneId.systemDefault()).toInstant());

            VendorDashboardDTOResponseDTO result = vendorDashboardMapper.mapToDTO(vendorAssessment, 0L, null, null, null);

            assertNotNull(result);
            assertEquals(0, result.getCategoryCount());
        }
    }

