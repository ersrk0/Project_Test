package in.gov.gem.app.vendorassessment.transformer;

import in.gov.gem.app.vendorassessment.client.IIamClient;
import in.gov.gem.app.vendorassessment.dto.request.AddEmailRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.AddMobileRequestDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class IAMTransformerTest
{
  private IIamClient iIamClient;
  private IAMTransformer iamTransformer;

  @BeforeEach
  void setUp() {
    iIamClient = Mockito.mock(IIamClient.class);
    iamTransformer = new IAMTransformer(iIamClient);
  }

  @Test
  void shouldCallSaveAdditionalMobile() {
    String lang = "en";
    AddMobileRequestDTO mobileDto = new AddMobileRequestDTO();
    // you can set test values here if needed

    iamTransformer.addMobile(lang, mobileDto);

    Mockito.verify(iIamClient, Mockito.times(1)).saveAdditionalMobile(lang, mobileDto);
  }

  @Test
  void shouldCallSaveAdditionalEmail() {
    String lang = "en";
    AddEmailRequestDTO emailDto = new AddEmailRequestDTO();
    // you can set test values here if needed

    iamTransformer.addEmail(lang, emailDto);

    Mockito.verify(iIamClient, Mockito.times(1)).saveAdditionalEmail(lang, emailDto);
  }
}
