package in.gov.gem.app.vendorassessment.domain;


import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import org.junit.jupiter.api.Test;

import static org.skyscreamer.jsonassert.JSONAssert.assertEquals;

class ApplicationConstantTest {

    @Test
    void testConstants() {
        assertEquals("Vendor-Assessment-Service", ApplicationConstant.MSID);
        assertEquals("Value Fetched Successfully", ApplicationConstant.FETCH_MESSAGE);
        assertEquals("lookup Value Inserted Successfully", ApplicationConstant.CREATED_MESSAGE);
        assertEquals("lookup Update Successfully", ApplicationConstant.UPDATE_MESSAGE);
        assertEquals("lookup Deactivate Successfully", ApplicationConstant.DEACTIVATE_MESSAGE);
        assertEquals("Vendor", ApplicationConstant.TENANT_TYPE_LOOKUP_BUYER);
        assertEquals("Active", ApplicationConstant.TENANT_STATUS_LOOKUP_ACTIVE);
    }

  private void assertEquals(String s, String msid) {
  }
}