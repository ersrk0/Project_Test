package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;



import in.gov.gem.app.vendorassessment.dto.response.BODDocumentNewResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.BODDocumentResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OrganizationDetailsResponseDTO;
import in.gov.gem.app.vendorassessment.domain.entity.VaDocumentDetailEntity;
import in.gov.gem.app.vendorassessment.facade.Impl.BODFacade;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BODControllerTest {

    @Mock
    private BODFacade bodFacade;

    @Mock
    private ISellerClient iSellerClient;

    @InjectMocks
    private BODController bodControllerImpl;

    @Test
    void getRequiredBodDocuments_ReturnsAPIResponse_WhenValidVendorAssessmentIdProvidedAndDocumentsFound() {
        // Given
        Long vendorAssessmentId = 123L;
        BODDocumentNewResponseDTO document = new BODDocumentNewResponseDTO();
        document.setDocName("Required Document 1");
        List<BODDocumentNewResponseDTO> mockDocuments = Collections.singletonList(document);

        when(bodFacade.getRequiredDocuments(vendorAssessmentId)).thenReturn(mockDocuments);

        // When
        ResponseEntity<APIResponse<Object>> result = bodControllerImpl.getRequiredBodDocuments(vendorAssessmentId);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(ApplicationConstant.MSID, result.getBody().getMsId());
        assertEquals(HttpStatus.OK.getReasonPhrase(), result.getBody().getStatus());
        assertEquals(ApplicationConstant.FETCH_MESSAGE, result.getBody().getMessage());
        assertEquals(mockDocuments, result.getBody().getData());
        verify(bodFacade, times(1)).getRequiredDocuments(vendorAssessmentId);
    }

    @Test
    void myOrganisationBodDocumentList_ReturnsAPIResponse_WhenValidVaMasterIdProvidedAndOrganizationDocumentsExist() {
        // Given
        Long vaMasterId = 456L;
        BODDocumentResponseDTO documentResponse = new BODDocumentResponseDTO();
        documentResponse.setDocName("Organization Document");
        List<BODDocumentResponseDTO> mockDocuments = Collections.singletonList(documentResponse);

        when(bodFacade.getMyOrganizationDocuments(vaMasterId)).thenReturn(mockDocuments);

        // When
        ResponseEntity<APIResponse<Object>> result = bodControllerImpl.myOrganisationBodDocumentList(vaMasterId);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(ApplicationConstant.MSID, result.getBody().getMsId());
        assertEquals(HttpStatus.OK.getReasonPhrase(), result.getBody().getStatus());
        assertEquals(ApplicationConstant.FETCH_MESSAGE, result.getBody().getMessage());
        assertEquals(mockDocuments, result.getBody().getData());
        verify(bodFacade, times(1)).getMyOrganizationDocuments(vaMasterId);
    }

    @Test
    void deleteBodDocument_ReturnsSuccessResponse_WhenValidParametersProvidedAndDocumentDeletedSuccessfully() {
        // Given
        Long vaMasterId = 789L;
        String docName = "TestDocument.pdf";

        doNothing().when(bodFacade).deleteBodDocument(vaMasterId, docName);

        // When
        ResponseEntity<APIResponse<Object>> result = bodControllerImpl.deleteBodDocument(vaMasterId, docName);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(ApplicationConstant.MSID, result.getBody().getMsId());
        assertEquals(HttpStatus.OK.getReasonPhrase(), result.getBody().getStatus());
        assertEquals(ApplicationConstant.DELETE_MESSAGE, result.getBody().getMessage());
        assertNull(result.getBody().getData());
        verify(bodFacade, times(1)).deleteBodDocument(vaMasterId, docName);
    }

    @Test
    void exportUsersToExcel_ReturnsExcelFile_WhenValidDocumentListProvidedForExcelExport() {
        // Given
        BODDocumentResponseDTO documentResponse = new BODDocumentResponseDTO();
        documentResponse.setDocName("Export Document");
        List<BODDocumentResponseDTO> bodDocumentResponses = Collections.singletonList(documentResponse);

        byte[] mockExcelData = "Excel Data".getBytes();
        ResponseEntity<byte[]> mockResponse = ResponseEntity.ok()
          .header("Content-Disposition", "attachment; filename=bod_documents.xlsx")
          .body(mockExcelData);

        when(bodFacade.exportToExcel(bodDocumentResponses)).thenReturn(mockResponse);

        // When
        ResponseEntity<byte[]> result = bodControllerImpl.exportUsersToExcel(bodDocumentResponses);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals("Excel Data", new String(result.getBody()));
        verify(bodFacade, times(1)).exportToExcel(bodDocumentResponses);
    }

    @Test
    void getLastVerifiedBODDocument_ReturnsVerifiedDocuments_WhenOrganizationDetailsFoundAndSellerIdExists() {
        // Given
        OrganizationDetailsResponseDTO organizationDetails = new OrganizationDetailsResponseDTO();
        organizationDetails.setGemPvtOrgId(12345L);

        APIResponse<OrganizationDetailsResponseDTO> apiResponse = APIResponse.<OrganizationDetailsResponseDTO>builder()
          .data(organizationDetails)
          .build();

        ResponseEntity<APIResponse<OrganizationDetailsResponseDTO>> mockSellerResponse =
          ResponseEntity.ok(apiResponse);

        BODDocumentResponseDTO verifiedDocument = new BODDocumentResponseDTO();
        verifiedDocument.setDocName("Last Verified Document");
        verifiedDocument.setStatus("VERIFIED");
        List<BODDocumentResponseDTO> mockVerifiedDocuments = Collections.singletonList(verifiedDocument);

        when(iSellerClient.getOrganizationDetails()).thenReturn(mockSellerResponse);
        when(bodFacade.getLastVerifiedBODDocument(12345L)).thenReturn(mockVerifiedDocuments);

        // When
        ResponseEntity<APIResponse<Object>> result = bodControllerImpl.getLastVerifiedBODDocument();

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(ApplicationConstant.MSID, result.getBody().getMsId());
        assertEquals(HttpStatus.OK.getReasonPhrase(), result.getBody().getStatus());
        assertEquals(ApplicationConstant.FETCH_MESSAGE, result.getBody().getMessage());
        assertEquals(mockVerifiedDocuments, result.getBody().getData());
        verify(iSellerClient, times(1)).getOrganizationDetails();
        verify(bodFacade, times(1)).getLastVerifiedBODDocument(12345L);
    }
    @Test
    void myAuthorizingOemOspBodDocumentList_ReturnsAPIResponse_WhenValidVaMasterIdProvidedAndOemOspDocumentsExist() {
        // Given
        Long vaMasterId = 567L;
        BODDocumentResponseDTO oemOspDocument = new BODDocumentResponseDTO();
        oemOspDocument.setDocName("OEM OSP Authorization Document");

        List<BODDocumentResponseDTO> mockDocuments = Collections.singletonList(oemOspDocument);

        when(bodFacade.getAuthorizingOemOspDocuments(vaMasterId)).thenReturn(mockDocuments);

        // When
        ResponseEntity<APIResponse<Object>> result = bodControllerImpl.myAuthorizingOemOspBodDocumentList(vaMasterId);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(ApplicationConstant.MSID, result.getBody().getMsId());
        assertEquals(HttpStatus.OK.getReasonPhrase(), result.getBody().getStatus());
        assertEquals(ApplicationConstant.FETCH_MESSAGE, result.getBody().getMessage());
        assertEquals(mockDocuments, result.getBody().getData());
        verify(bodFacade, times(1)).getAuthorizingOemOspDocuments(vaMasterId);
    }

    @Test
    void myContractManufacturerDocumentList_ReturnsAPIResponse_WhenValidVaMasterIdProvidedAndManufacturerDocumentsExist() {
        // Given
        Long vaMasterId = 678L;
        BODDocumentResponseDTO manufacturerDocument = new BODDocumentResponseDTO();
        manufacturerDocument.setDocName("Contract Manufacturer Document");

        List<BODDocumentResponseDTO> mockDocuments = Collections.singletonList(manufacturerDocument);

        when(bodFacade.getContractManufacturerDocuments(vaMasterId)).thenReturn(mockDocuments);

        // When
        ResponseEntity<APIResponse<Object>> result = bodControllerImpl.myContractManufacturerDocumentList(vaMasterId);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(ApplicationConstant.MSID, result.getBody().getMsId());
        assertEquals(HttpStatus.OK.getReasonPhrase(), result.getBody().getStatus());
        assertEquals(ApplicationConstant.FETCH_MESSAGE, result.getBody().getMessage());
        assertEquals(mockDocuments, result.getBody().getData());
        verify(bodFacade, times(1)).getContractManufacturerDocuments(vaMasterId);
    }
    @Test
    void saveRemarks_ReturnsSuccessResponse_WhenValidRemarksAndVaMasterFkProvided() {
        // Given
        String remarks = "Test remarks for document verification";
        Long vaMasterFk = 123L;

        VaDocumentDetailEntity mockDocumentEntity = new VaDocumentDetailEntity();
        mockDocumentEntity.setId(1L);
        mockDocumentEntity.setRemark(remarks);
        mockDocumentEntity.setVaMasterFk(vaMasterFk);

        when(bodFacade.saveRemarks(remarks, vaMasterFk)).thenReturn(mockDocumentEntity);

        // When
        ResponseEntity<APIResponse<Object>> result = bodControllerImpl.saveRemarks(remarks, vaMasterFk);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(ApplicationConstant.MSID, result.getBody().getMsId());
        assertEquals(HttpStatus.OK.getReasonPhrase(), result.getBody().getStatus());
        assertEquals(ApplicationConstant.SAVE_MESSAGE, result.getBody().getMessage());
        assertEquals(mockDocumentEntity, result.getBody().getData());
        verify(bodFacade, times(1)).saveRemarks(remarks, vaMasterFk);
    }

    @Test
    void getParentBodDocuments_ReturnsAPIResponse_WhenValidVaMasterIdProvidedAndParentDocumentsExist() {
        // Given
        Long vaMasterId = 456L;
        BODDocumentResponseDTO parentDocument = new BODDocumentResponseDTO();
        parentDocument.setDocName("Parent BOD Document");
        parentDocument.setDocType("PARENT");

        List<BODDocumentResponseDTO> mockParentDocuments = Collections.singletonList(parentDocument);

        when(bodFacade.getParentBodDocuments(vaMasterId)).thenReturn(mockParentDocuments);

        // When
        ResponseEntity<APIResponse<Object>> result = bodControllerImpl.getParentBodDocuments(vaMasterId);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(ApplicationConstant.MSID, result.getBody().getMsId());
        assertEquals(HttpStatus.OK.getReasonPhrase(), result.getBody().getStatus());
        assertEquals(ApplicationConstant.FETCH_MESSAGE, result.getBody().getMessage());
        assertEquals(mockParentDocuments, result.getBody().getData());
        verify(bodFacade, times(1)).getParentBodDocuments(vaMasterId);
    }

    @Test
    void getParentOrganisationBODDocument_ReturnsAPIResponse_WhenValidVaMasterIdProvidedAndParentOrgDocumentsExist() {
        // Given
        Long vaMasterId = 789L;
        BODDocumentResponseDTO parentOrgDocument = new BODDocumentResponseDTO();
        parentOrgDocument.setDocName("Parent Organization BOD Document");
        parentOrgDocument.setDocType("PARENT_ORG");
        parentOrgDocument.setStatus("UPLOADED");

        List<BODDocumentResponseDTO> mockParentOrgDocuments = Collections.singletonList(parentOrgDocument);

        when(bodFacade.getUploadedParentBODDocument(vaMasterId)).thenReturn(mockParentOrgDocuments);

        // When
        ResponseEntity<APIResponse<Object>> result = bodControllerImpl.getParentOrganisationBODDocument(vaMasterId);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(ApplicationConstant.MSID, result.getBody().getMsId());
        assertEquals(HttpStatus.OK.getReasonPhrase(), result.getBody().getStatus());
        assertEquals(ApplicationConstant.FETCH_MESSAGE, result.getBody().getMessage());
        assertEquals(mockParentOrgDocuments, result.getBody().getData());
        verify(bodFacade, times(1)).getUploadedParentBODDocument(vaMasterId);
    }
}