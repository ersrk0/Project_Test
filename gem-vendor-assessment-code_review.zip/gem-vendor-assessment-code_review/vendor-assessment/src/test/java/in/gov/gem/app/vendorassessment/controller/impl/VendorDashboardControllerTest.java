package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;

import in.gov.gem.app.vendorassessment.dto.response.VendorDashboardDTOResponseDTO;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.facade.Impl.VendorDashboardFacade;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class VendorDashboardControllerTest {

    @Mock
    private VendorDashboardFacade vendorDashboardFacade;

    @InjectMocks
    private VendorDashboardController vendorDashboardController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getAllVendorAssessments_success() {
        PaginationParams paginationParams = new PaginationParams();
        Page<VendorDashboardDTOResponseDTO> mockPage = mock(Page.class);
        when(mockPage.getContent()).thenReturn(Collections.emptyList());
        when(mockPage.getNumber()).thenReturn(0);
        when(mockPage.getTotalPages()).thenReturn(1);
        when(mockPage.getNumberOfElements()).thenReturn(0);
        when(mockPage.hasNext()).thenReturn(false);
        when(vendorDashboardFacade.getAllVendorAssessments(paginationParams)).thenReturn(mockPage);

        ResponseEntity<PageableApiResponse<List<VendorDashboardDTOResponseDTO>>> response =
                vendorDashboardController.getAllVendorAssessments(paginationParams);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(ApplicationConstant.DASHBOARD_MESSAGE, response.getBody().getMessage());
        assertTrue(response.getBody().getData().isEmpty());
    }

    @Test
    void getVendorAssessmentByVaNumberReturnsVendorAssessmentWhenFound() {
        String vaNumber = "DA-1744780807817";
        VendorDashboardDTOResponseDTO mockDTO = new VendorDashboardDTOResponseDTO();
        when(vendorDashboardFacade.getVendorAssessmentByVaNumber(vaNumber)).thenReturn(Optional.of(mockDTO));

        ResponseEntity<APIResponse<VendorDashboardDTOResponseDTO>> response =
                vendorDashboardController.getVendorAssessmentByVaNumber(vaNumber);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(mockDTO, response.getBody().getData());
        assertEquals(ApplicationConstant.VENDOR_ASSESSMENT_FETCHED, response.getBody().getMessage());
    }

    @Test
    void getVendorAssessmentByVaNumberReturnsNotFoundWhenVendorAssessmentDoesNotExist() {
        String vaNumber = "VA404";
        when(vendorDashboardFacade.getVendorAssessmentByVaNumber(vaNumber)).thenReturn(Optional.empty());

        ResponseEntity<APIResponse<VendorDashboardDTOResponseDTO>> response =
                vendorDashboardController.getVendorAssessmentByVaNumber(vaNumber);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertNull(response.getBody().getData());
        assertEquals(ApplicationConstant.VENDOR_ASSESSMENT_FETCHED, response.getBody().getMessage());
    }

    // Edge case: Null VA number
    void getVendorAssessmentByVaNumberThrowsExceptionWhenVaNumberIsNull() {
        String vaNumber = null;

        assertThrows(IllegalArgumentException.class, () -> {
            vendorDashboardController.getVendorAssessmentByVaNumber(vaNumber);
        });
    }

    @Test
    void getCategoryDetails_success() {
        String vaNumber = "VA123";
        List<Map<String, Object>> mockCategories = Collections.singletonList(Map.of("key", "value"));
        when(vendorDashboardFacade.getCategories(vaNumber)).thenReturn(mockCategories);

        ResponseEntity<APIResponse<List<Map<String, Object>>>> response =
                vendorDashboardController.getCategoryDetails(vaNumber);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(mockCategories, response.getBody().getData());
    }

    @Test
    void getCategoryDetails_noCategories() {
        String vaNumber = "VA123";
        when(vendorDashboardFacade.getCategories(vaNumber)).thenReturn(Collections.emptyList());

        ResponseEntity<APIResponse<List<Map<String, Object>>>> response =
                vendorDashboardController.getCategoryDetails(vaNumber);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().getData().isEmpty());
        assertEquals("No categories found", response.getBody().getMessage());
    }

    @Test
    void deleteVendorAssessment_success() {
        String vendorId = "V123";
        doNothing().when(vendorDashboardFacade).deleteVendorAssessment(vendorId);

        ResponseEntity<APIResponse<String>> response =
                vendorDashboardController.deleteVendorAssessment(vendorId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Vendor assessment deleted successfully", response.getBody().getMessage());
        assertEquals("Vendor assessment deleted successfully", response.getBody().getData());
    }
}