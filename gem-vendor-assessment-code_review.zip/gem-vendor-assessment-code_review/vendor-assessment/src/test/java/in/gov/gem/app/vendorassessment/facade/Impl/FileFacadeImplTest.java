package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.vendorassessment.dto.request.ExportDTORequestDTO;

import in.gov.gem.app.vendorassessment.facade.Impl.FileFacade;
import in.gov.gem.app.vendorassessment.service.IFileService;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

class FileFacadeImplTest {

  private final IFileService fileService = Mockito.mock(IFileService.class);
  private final FileFacade fileFacade = Mockito.mock(FileFacade.class);



  @Nested
  class ExportUsersToExcel {

    @Test
    void propagatesNullResponseFromService() {
      Mockito.when(fileService.exportUsersToExcel(any(ExportDTORequestDTO.class), eq(false)))
        .thenReturn(null);

      ExportDTORequestDTO request = new ExportDTORequestDTO();
      ResponseEntity<byte[]> response = fileFacade.exportUsersToExcel(request, false);

      assertThat(response).isNull();
    }
  }
}