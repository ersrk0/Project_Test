package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.vendorassessment.dto.response.NonComplianceNewResponseDTO;

import in.gov.gem.app.vendorassessment.facade.Impl.NonComplianceFacade;
import in.gov.gem.app.vendorassessment.service.impl.NonComplianceService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NonComplianceFacadeTest {

    @Mock
    private NonComplianceService nonComplianceService;

    @InjectMocks
    private NonComplianceFacade nonComplianceFacade;

    @Test
    void testFieldsWithOpenNonClosure_ShouldReturnNonComplianceResponse() {
        // Given
        Long sellerId = 12345L;
        NonComplianceNewResponseDTO expectedResponse = new NonComplianceNewResponseDTO();


        when(nonComplianceService.fieldsWithOpenNonClosure(sellerId)).thenReturn(expectedResponse);

        // When
        NonComplianceNewResponseDTO actualResponse = nonComplianceFacade.fieldsWithOpenNonClosure(sellerId);

        // Then
        assertNotNull(actualResponse);
        assertEquals(expectedResponse, actualResponse);
        verify(nonComplianceService).fieldsWithOpenNonClosure(sellerId);
    }
}