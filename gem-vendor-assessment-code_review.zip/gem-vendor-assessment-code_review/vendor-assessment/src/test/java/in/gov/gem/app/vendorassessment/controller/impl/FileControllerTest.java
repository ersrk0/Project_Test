package in.gov.gem.app.vendorassessment.controller.impl;


import in.gov.gem.app.vendorassessment.dto.request.ExportDTORequestDTO;
import in.gov.gem.app.vendorassessment.facade.IFileFacade;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

class FileControllerTest {

    private final IFileFacade fileFacade = Mockito.mock(IFileFacade.class);
    private final FileController fileController = new FileController(fileFacade);

    @Nested
    @DisplayName("exportUsersToExcel")
    class ExportUsersToExcel {

        @Test
        void returnsExcelFileWhenRequestIsValid() {
            byte[] expectedBytes = new byte[]{1, 2, 3};
            Mockito.when(fileFacade.exportUsersToExcel(any(ExportDTORequestDTO.class), eq(false)))
                    .thenReturn(ResponseEntity.ok(expectedBytes));

            ExportDTORequestDTO request = new ExportDTORequestDTO();
            ResponseEntity<byte[]> response = fileController.exportUsersToExcel(request, false);

            assertThat(response.getStatusCodeValue()).isEqualTo(200);
            assertThat(response.getBody()).isEqualTo(expectedBytes);
        }

        @Test
        void returnsExcelFileWhenAllFlagIsTrue() {
            byte[] expectedBytes = new byte[]{4, 5, 6};
            Mockito.when(fileFacade.exportUsersToExcel(any(ExportDTORequestDTO.class), eq(true)))
                    .thenReturn(ResponseEntity.ok(expectedBytes));

            ExportDTORequestDTO request = new ExportDTORequestDTO();
            ResponseEntity<byte[]> response = fileController.exportUsersToExcel(request, true);

            assertThat(response.getStatusCodeValue()).isEqualTo(200);
            assertThat(response.getBody()).isEqualTo(expectedBytes);
        }

        @Test
        void handlesNullRequestBody() {
            byte[] expectedBytes = new byte[]{7, 8, 9};
            Mockito.when(fileFacade.exportUsersToExcel(null, false))
                    .thenReturn(ResponseEntity.ok(expectedBytes));

            ResponseEntity<byte[]> response = fileController.exportUsersToExcel(null, false);

            assertThat(response.getStatusCodeValue()).isEqualTo(200);
            assertThat(response.getBody()).isEqualTo(expectedBytes);
        }
    }
}