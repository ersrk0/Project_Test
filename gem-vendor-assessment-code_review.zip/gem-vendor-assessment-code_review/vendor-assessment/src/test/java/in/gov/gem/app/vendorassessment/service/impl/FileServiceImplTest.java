package in.gov.gem.app.vendorassessment.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.request.ExportDTORequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.OrganizationDetailsResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VendorDashboardDTOResponseDTO;

import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.service.IVendorDashboardService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;

class FileServiceImplTest {

    @Mock
    private ISellerClient iSellerClient;
    @Mock
    private IVendorDashboardService vendorDashboardService;
    @InjectMocks
    private FileService fileService;

    @Mock
    private MessageUtility messageUtility;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("Export all vendor assessments to Excel returns valid response")
    void exportAllVendorAssessmentsToExcelReturnsValidResponse() {
        OrganizationDetailsResponseDTO orgDetails = new OrganizationDetailsResponseDTO();
        orgDetails.setGemPvtOrgId(123L);
        APIResponse<OrganizationDetailsResponseDTO> apiResponse = new APIResponse<>();
        apiResponse.setData(orgDetails);

        VendorDashboardDTOResponseDTO dto = new VendorDashboardDTOResponseDTO();
        dto.setId(1L);
        dto.setVaId("VA-001");
        dto.setStatus("APPROVED");
        dto.setSubStatus("COMPLETED");
        dto.setAssessedAs("TypeA");
        dto.setCategoryCount(2);
        dto.setAssessedBy("UserA");
        dto.setValidUpTo(LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant());
        dto.setSubmittedOn(LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant());
        dto.setActions(Arrays.asList("View", "Download"));

        when(iSellerClient.getOrganizationDetails()).thenReturn(ResponseEntity.ok(apiResponse));
        when(vendorDashboardService.getAllVendorAssessmentsWithouPage(123L)).thenReturn(Collections.singletonList(dto));

        ResponseEntity<byte[]> response = fileService.exportUsersToExcel(null, true);

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertTrue(response.getHeaders().get("Content-Disposition").get(0).contains("Assessment_report.xlsx"));
    }

    @Test
    @DisplayName("Export selected vendor assessments to Excel returns valid response")
    void exportSelectedVendorAssessmentsToExcelReturnsValidResponse() {
        OrganizationDetailsResponseDTO orgDetails = new OrganizationDetailsResponseDTO();
        orgDetails.setGemPvtOrgId(123L);
        APIResponse<OrganizationDetailsResponseDTO> apiResponse = new APIResponse<>();
        apiResponse.setData(orgDetails);

        VendorDashboardDTOResponseDTO dto = new VendorDashboardDTOResponseDTO();
        dto.setId(2L);
        dto.setVaId("VA-002");
        dto.setStatus("PENDING");
        dto.setSubStatus("IN_PROGRESS");
        dto.setAssessedAs("TypeB");
        dto.setCategoryCount(1);
        dto.setAssessedBy("UserB");
        dto.setValidUpTo(LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant());
        dto.setSubmittedOn(LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant());
        dto.setActions(Collections.singletonList("Edit"));

        ExportDTORequestDTO request = new ExportDTORequestDTO();
        request.setIds(Collections.singletonList(2L));

        when(iSellerClient.getOrganizationDetails()).thenReturn(ResponseEntity.ok(apiResponse));
        when(vendorDashboardService.getVendorAssessment(2L)).thenReturn(dto);

        ResponseEntity<byte[]> response = fileService.exportUsersToExcel(request, false);

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertTrue(response.getHeaders().get("Content-Disposition").get(0).contains("Assessment_report.xlsx"));
    }

    @Test
    @DisplayName("Export to Excel throws exception when organization details are missing")
    void exportToExcelThrowsExceptionWhenOrganizationDetailsMissing() {
        when(iSellerClient.getOrganizationDetails()).thenReturn(ResponseEntity.ok(null));
        // Mock messageUtility to return the expected message
        when(messageUtility.getMessage(anyString())).thenReturn("Unexpected error");

        ServiceException exception = assertThrows(ServiceException.class, () ->
          fileService.exportUsersToExcel(null, true)
        );
        assertEquals("Unexpected error", exception.getMessage());
    }

    @Test
    @DisplayName("Export to Excel handles empty vendor assessments list")
    void exportToExcelHandlesEmptyVendorAssessmentsList() {
        OrganizationDetailsResponseDTO orgDetails = new OrganizationDetailsResponseDTO();
        orgDetails.setGemPvtOrgId(123L);
        APIResponse<OrganizationDetailsResponseDTO> apiResponse = new APIResponse<>();
        apiResponse.setData(orgDetails);

        when(iSellerClient.getOrganizationDetails()).thenReturn(ResponseEntity.ok(apiResponse));
        when(vendorDashboardService.getAllVendorAssessmentsWithouPage(123L)).thenReturn(Collections.emptyList());

        ResponseEntity<byte[]> response = fileService.exportUsersToExcel(null, true);

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().length > 0);
    }

    @Test
    @DisplayName("Export to Excel handles null actions list gracefully")
    void exportToExcelHandlesNullActionsListGracefully() {
        OrganizationDetailsResponseDTO orgDetails = new OrganizationDetailsResponseDTO();
        orgDetails.setGemPvtOrgId(123L);
        APIResponse<OrganizationDetailsResponseDTO> apiResponse = new APIResponse<>();
        apiResponse.setData(orgDetails);

        VendorDashboardDTOResponseDTO dto = new VendorDashboardDTOResponseDTO();
        dto.setId(3L);
        dto.setActions(null);

        when(iSellerClient.getOrganizationDetails()).thenReturn(ResponseEntity.ok(apiResponse));
        when(vendorDashboardService.getAllVendorAssessmentsWithouPage(123L)).thenReturn(Collections.singletonList(dto));

        ResponseEntity<byte[]> response = fileService.exportUsersToExcel(null, true);

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
    }
}