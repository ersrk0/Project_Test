package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.dto.response.NonComplianceNewResponseDTO;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.repository.LookupRepository;
import in.gov.gem.app.service.core.utility.MessageUtility;


import in.gov.gem.app.vendorassessment.domain.entity.NCClosureEntity;
import in.gov.gem.app.vendorassessment.domain.repository.NonComplianceRepository;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NonComplianceServiceImplTest {

    @Mock
    private NonComplianceRepository nonComplianceRepository;

    @Mock
    private LookupRepository lookupRepository;

    @Mock
    private MessageUtility messageUtility;

    @InjectMocks
    private NonComplianceService nonComplianceService;

    private Long vaMasterFk;
    private List<TestLookup> entityLookups;
    private List<TestLookup> statusLookups;
    private List<TestLookup> attributeLookups;
    private List<TestNonComplianceEntity> nonComplianceEntities;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    private static class TestLookup {
        private String lookupCode;
        private String lookupValue;
        private String lookupName;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    private static class TestNonComplianceEntity {
        private Long id;
        private Long vaMasterFk;
        private String entityLookup;
        private String entityAttributeLookup;
        private String statusLookup;
    }

    @BeforeEach
    void setUp() {
        vaMasterFk = 1L;
        setupTestData();
    }

    private void setupTestData() {
        // Setup Entity Lookups
        entityLookups = Arrays.asList(
                new TestLookup("ENT001", "Work experience details", "Entity"),
                new TestLookup("ENT002", "Other entity", "Entity")
        );

        // Setup Status Lookups
        statusLookups = Arrays.asList(
                new TestLookup("ST001", "OPEN", "nonComplianceStatus"),
                new TestLookup("ST002", "UNDER_REVIEW", "nonComplianceStatus"),
                new TestLookup("ST003", "CLOSED", "nonComplianceStatus")
        );

        // Setup Attribute Lookups
        attributeLookups = Arrays.asList(
                new TestLookup("ATTR001", "Project Value", "Work Experience Details Attribute"),
                new TestLookup("ATTR002", "Client Name", "Work Experience Details Attribute"),
                new TestLookup("ATTR003", "Completion Date", "Work Experience Details Attribute")
        );

        // Setup Non-Compliance Entities
        nonComplianceEntities = Arrays.asList(
                new TestNonComplianceEntity(1L, vaMasterFk, "ENT001", "ATTR001", "ST001"),
                new TestNonComplianceEntity(2L, vaMasterFk, "ENT001", "ATTR002", "ST002")
        );
    }

    private Lookup createLookup(TestLookup testLookup) {
        Lookup lookup = new Lookup();
        lookup.setLookupCode(testLookup.getLookupCode());
        lookup.setLookupValue(testLookup.getLookupValue());
        lookup.setLookupName(testLookup.getLookupName());
        return lookup;
    }

    private NCClosureEntity createNonComplianceEntity(TestNonComplianceEntity testEntity) {
        NCClosureEntity entity = new NCClosureEntity();
        entity.setId(testEntity.getId());
        entity.setVaMasterFk(testEntity.getVaMasterFk());
        entity.setEntityLookup(testEntity.getEntityLookup());
        entity.setEntityAttributeLookup(testEntity.getEntityAttributeLookup());
        entity.setStatusLookup(testEntity.getStatusLookup());
        return entity;
    }


    @Test
    void testFieldsWithOpenNonClosure_Success_WithNoOpenRecords() {
        // Arrange
        List<Lookup> entityLookupList = entityLookups.stream()
                .map(this::createLookup)
                .filter(lookup -> "Entity".equals(lookup.getLookupName()))
                .toList();

        List<Lookup> statusLookupList = statusLookups.stream()
                .map(this::createLookup)
                .filter(lookup -> "nonComplianceStatus".equals(lookup.getLookupName()))
                .toList();

        List<Lookup> attributeLookupList = attributeLookups.stream()
                .map(this::createLookup)
                .toList();

        when(lookupRepository.findByLookupName("Entity")).thenReturn(entityLookupList);
        when(lookupRepository.findByLookupName("nonComplianceStatus")).thenReturn(statusLookupList);
        when(lookupRepository.findByLookupName("Work Experience Details Attribute")).thenReturn(attributeLookupList);

        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(vaMasterFk, "ST001"))
                .thenReturn(new ArrayList<>());
        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(vaMasterFk, "ST002"))
                .thenReturn(new ArrayList<>());

        // Act
        NonComplianceNewResponseDTO response = nonComplianceService.fieldsWithOpenNonClosure(vaMasterFk);

        // Assert
        assertNotNull(response);
        assertEquals(0, response.getNonComplianceOpenFields().size());
        assertEquals(3, response.getNonComplianceClosedFields().size());

        // All attributes should be in closed fields
        List<NonComplianceNewResponseDTO.Pair<String, String>> closedFields = response.getNonComplianceClosedFields();
        assertTrue(closedFields.stream().allMatch(pair -> "Closed".equals(pair.value)));
    }

    @Test
    void testFieldsWithOpenNonClosure_Success_WithNullLookupRepositoryResponse() {
        // Arrange
        when(lookupRepository.findByLookupName("Entity")).thenReturn(null);
        when(lookupRepository.findByLookupName("nonComplianceStatus")).thenReturn(null);
        when(lookupRepository.findByLookupName("Work Experience Details Attribute")).thenReturn(null);

        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(eq(vaMasterFk), any()))
                .thenReturn(null);

        // Act
        NonComplianceNewResponseDTO response = nonComplianceService.fieldsWithOpenNonClosure(vaMasterFk);

        // Assert
        assertNotNull(response);
        assertEquals(0, response.getNonComplianceOpenFields().size());
        assertEquals(0, response.getNonComplianceClosedFields().size());
    }

    @Test
    void testFieldsWithOpenNonClosure_Success_WithEmptyLookupRepositoryResponse() {
        // Arrange
        when(lookupRepository.findByLookupName("Entity")).thenReturn(new ArrayList<>());
        when(lookupRepository.findByLookupName("nonComplianceStatus")).thenReturn(new ArrayList<>());
        when(lookupRepository.findByLookupName("Work Experience Details Attribute")).thenReturn(new ArrayList<>());

        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(eq(vaMasterFk), any()))
                .thenReturn(new ArrayList<>());

        // Act
        NonComplianceNewResponseDTO response = nonComplianceService.fieldsWithOpenNonClosure(vaMasterFk);

        // Assert
        assertNotNull(response);
        assertEquals(0, response.getNonComplianceOpenFields().size());
        assertEquals(0, response.getNonComplianceClosedFields().size());
    }

    @Test
    void testFieldsWithOpenNonClosure_Success_WithNullVaMasterFk() {
        // Arrange
        when(lookupRepository.findByLookupName("Entity")).thenReturn(new ArrayList<>());
        when(lookupRepository.findByLookupName("nonComplianceStatus")).thenReturn(new ArrayList<>());
        when(lookupRepository.findByLookupName("Work Experience Details Attribute")).thenReturn(new ArrayList<>());

        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(eq(null), any()))
                .thenReturn(new ArrayList<>());

        // Act
        NonComplianceNewResponseDTO response = nonComplianceService.fieldsWithOpenNonClosure(null);

        // Assert
        assertNotNull(response);
        assertEquals(0, response.getNonComplianceOpenFields().size());
        assertEquals(0, response.getNonComplianceClosedFields().size());
    }

    @Test
    void testFieldsWithOpenNonClosure_Success_VerifyRepositoryInteractions() {
        // Arrange
        List<Lookup> entityLookupList = entityLookups.stream()
                .map(this::createLookup)
                .filter(lookup -> "Entity".equals(lookup.getLookupName()))
                .toList();

        List<Lookup> statusLookupList = statusLookups.stream()
                .map(this::createLookup)
                .filter(lookup -> "nonComplianceStatus".equals(lookup.getLookupName()))
                .toList();

        when(lookupRepository.findByLookupName("Entity")).thenReturn(entityLookupList);
        when(lookupRepository.findByLookupName("nonComplianceStatus")).thenReturn(statusLookupList);
        when(lookupRepository.findByLookupName("Work Experience Details Attribute")).thenReturn(new ArrayList<>());

        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(vaMasterFk, "ST001"))
                .thenReturn(new ArrayList<>());
        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(vaMasterFk, "ST002"))
                .thenReturn(new ArrayList<>());

        // Act
        nonComplianceService.fieldsWithOpenNonClosure(vaMasterFk);

        // Assert - Verify all expected repository calls were made
        verify(lookupRepository, times(1)).findByLookupName("Entity");
        verify(lookupRepository, times(1)).findByLookupName("nonComplianceStatus");
        verify(lookupRepository, times(1)).findByLookupName("Work Experience Details Attribute");
        verify(nonComplianceRepository, times(1)).findByVaMasterFkAndStatusLookup(vaMasterFk, "ST001");
        verify(nonComplianceRepository, times(1)).findByVaMasterFkAndStatusLookup(vaMasterFk, "ST002");
    }

    @Test
    void testFieldsWithOpenNonClosure_ThrowsServiceException_WhenLookupRepositoryThrowsException() {
        // Arrange
        when(lookupRepository.findByLookupName("Entity"))
                .thenThrow(new RuntimeException("Database connection error"));
        when(messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR))
                .thenReturn("An unexpected error occurred");

        // Act & Assert
        ServiceException exception = assertThrows(ServiceException.class,
                () -> nonComplianceService.fieldsWithOpenNonClosure(vaMasterFk));

        // Fix: Choose one assertion based on how your service creates the exception
        assertEquals(MessageConstant.UNEXPECTED_ERROR, exception.getCode()); // if UNEXPECTED_ERROR is the code
        assertEquals("An unexpected error occurred", exception.getMessage()); // this should be the actual message
    }

    @Test
    void testFieldsWithOpenNonClosure_ThrowsServiceException_WhenNonComplianceRepositoryThrowsException() {
        // Arrange
        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(eq(vaMasterFk), any()))
                .thenThrow(new RuntimeException("Database connection error"));
        when(messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR))
                .thenReturn("An unexpected error occurred");

        // Act & Assert
        ServiceException exception = assertThrows(ServiceException.class,
                () -> nonComplianceService.fieldsWithOpenNonClosure(vaMasterFk));

        assertEquals(MessageConstant.UNEXPECTED_ERROR, exception.getCode());
        assertEquals("An unexpected error occurred", exception.getMessage());
    }


    @Test
    @DisplayName("fieldsWithOpenNonClosure throws ServiceException when unexpected error occurs")
    void fieldsWithOpenNonClosureThrowsServiceExceptionWhenUnexpectedErrorOccurs() {
        // Given
        Long vaMasterFk = 123L;
        String expectedMessage = "Unexpected error occurred";

        when(messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR))
                .thenReturn(expectedMessage);

        // Mock the first lookup call to throw a RuntimeException
        when(lookupRepository.findByLookupName("Entity"))
                .thenThrow(new RuntimeException("Database connection failed"));

        // When & Then
        ServiceException exception = assertThrows(ServiceException.class, () -> {
            nonComplianceService.fieldsWithOpenNonClosure(vaMasterFk);
        });

        assertEquals(MessageConstant.UNEXPECTED_ERROR, exception.getCode());
        assertEquals(expectedMessage, exception.getMessage());

        verify(messageUtility).getMessage(MessageConstant.UNEXPECTED_ERROR);
        verify(lookupRepository).findByLookupName("Entity");
    }

    @Test
    @DisplayName("fieldsWithOpenNonClosure handles null lookups and empty results gracefully")
    void fieldsWithOpenNonClosureHandlesNullLookupsAndEmptyResultsGracefully() {
        // Given
        Long vaMasterFk = 123L;

        // Return null for all lookup calls to test null handling
        when(lookupRepository.findByLookupName("Entity")).thenReturn(null);
        when(lookupRepository.findByLookupName("nonComplianceStatus")).thenReturn(null);
        when(lookupRepository.findByLookupName("Work Experience Details Attribute")).thenReturn(null);

        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(eq(vaMasterFk), isNull()))
                .thenReturn(null);

        // When
        NonComplianceNewResponseDTO response = nonComplianceService.fieldsWithOpenNonClosure(vaMasterFk);

        // Then
        assertNotNull(response);
        assertNotNull(response.getNonComplianceOpenFields());
        assertNotNull(response.getNonComplianceClosedFields());
        assertEquals(0, response.getNonComplianceOpenFields().size());
        assertEquals(0, response.getNonComplianceClosedFields().size());

        verify(lookupRepository, times(3)).findByLookupName(anyString());
    }

    @Test
    @DisplayName("fieldsWithOpenNonClosure processes NonComplianceEntity with matching entityLookup successfully")
    void fieldsWithOpenNonClosureProcessesNonComplianceEntityWithMatchingEntityLookupSuccessfully() {
        // Given
        Long vaMasterFk = 123L;

        // Mock Entity lookup
        Lookup entityLookup = new Lookup();
        entityLookup.setLookupCode("WORK_EXP_CODE");
        entityLookup.setLookupValue("Work experience details");

        // Mock nonComplianceStatus lookups
        Lookup openStatusLookup = new Lookup();
        openStatusLookup.setLookupCode("OPEN_CODE");
        openStatusLookup.setLookupValue("OPEN");

        // Mock attribute lookup
        Lookup attributeLookup = new Lookup();
        attributeLookup.setLookupCode("ATTR_CODE");
        attributeLookup.setLookupValue("Test Attribute");

        // Mock status lookup for the entity
        Lookup statusLookup = new Lookup();
        statusLookup.setLookupCode("STATUS_CODE");
        statusLookup.setLookupValue("Test Status");

        // Create NonComplianceEntity with matching entityLookup
        NCClosureEntity entity = new NCClosureEntity();
        entity.setEntityLookup("WORK_EXP_CODE"); // This matches the lookupCode
        entity.setEntityAttributeLookup("ATTR_CODE");
        entity.setStatusLookup("STATUS_CODE"); // This will be converted to string

        // Setup mocks
        when(lookupRepository.findByLookupName("Entity"))
                .thenReturn(Arrays.asList(entityLookup));

        when(lookupRepository.findByLookupName("nonComplianceStatus"))
                .thenReturn(Arrays.asList(openStatusLookup));

        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(vaMasterFk, "OPEN_CODE"))
                .thenReturn(Arrays.asList(entity));

        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(vaMasterFk, null))
                .thenReturn(new ArrayList<>()); // For UNDER_REVIEW (null because not found)

        when(lookupRepository.findByLookupCode("ATTR_CODE"))
                .thenReturn(Optional.of(attributeLookup));

        when(lookupRepository.findByLookupCode("STATUS_CODE"))
                .thenReturn(Optional.of(statusLookup));

        when(lookupRepository.findByLookupName("Work Experience Details Attribute"))
                .thenReturn(new ArrayList<>()); // Empty to avoid closed fields processing

        // When
        NonComplianceNewResponseDTO response = nonComplianceService.fieldsWithOpenNonClosure(vaMasterFk);

        // Then
        assertNotNull(response);
        assertNotNull(response.getNonComplianceOpenFields());
        assertEquals(1, response.getNonComplianceOpenFields().size());

        NonComplianceNewResponseDTO.Pair<String, String> pair = response.getNonComplianceOpenFields().get(0);
        assertEquals("Test Attribute", pair.fieldName);
        assertEquals("Test Status", pair.value);

        // Verify the specific lookups were called
        verify(lookupRepository).findByLookupCode("ATTR_CODE");
        verify(lookupRepository).findByLookupCode("STATUS_CODE");
    }

    @Test
    @DisplayName("fieldsWithOpenNonClosure throws ServiceException when entity processing fails")
    void fieldsWithOpenNonClosureThrowsServiceExceptionWhenEntityProcessingFails() {
        // Given
        Long vaMasterFk = 123L;
        String expectedMessage = "Unexpected error occurred";

        // Mock Entity lookup
        Lookup entityLookup = new Lookup();
        entityLookup.setLookupCode("WORK_EXP_CODE");
        entityLookup.setLookupValue("Work experience details");

        // Mock nonComplianceStatus lookup
        Lookup openStatusLookup = new Lookup();
        openStatusLookup.setLookupCode("OPEN_CODE");
        openStatusLookup.setLookupValue("OPEN");

        // Create NonComplianceEntity that will cause an exception
        NCClosureEntity entity = new NCClosureEntity();
        entity.setEntityLookup("WORK_EXP_CODE");
        entity.setEntityAttributeLookup("ATTR_CODE");
        entity.setStatusLookup("STATUS_CODE");

        // Setup mocks
        when(lookupRepository.findByLookupName("Entity"))
                .thenReturn(Arrays.asList(entityLookup));

        when(lookupRepository.findByLookupName("nonComplianceStatus"))
                .thenReturn(Arrays.asList(openStatusLookup));

        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(vaMasterFk, "OPEN_CODE"))
                .thenReturn(Arrays.asList(entity));

        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(vaMasterFk, null))
                .thenReturn(new ArrayList<>());

        // Make the findByLookupCode throw an exception to trigger the inner catch block
        when(lookupRepository.findByLookupCode("ATTR_CODE"))
                .thenThrow(new RuntimeException("Lookup failed"));

        when(messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR))
                .thenReturn(expectedMessage);

        // When & Then
        ServiceException exception = assertThrows(ServiceException.class, () -> {
            nonComplianceService.fieldsWithOpenNonClosure(vaMasterFk);
        });

        assertEquals(MessageConstant.UNEXPECTED_ERROR, exception.getCode());
        assertEquals(expectedMessage, exception.getMessage());

        // Verify the inner exception handling was triggered
        verify(lookupRepository).findByLookupCode("ATTR_CODE");
        verify(messageUtility).getMessage(MessageConstant.UNEXPECTED_ERROR);
    }
    @Test
    void fieldsWithOpenNonClosure_shouldIncludeMissingAttributesInClosedFields() {
        Long vaMasterId = 303L;

        // "Entity" lookup with "Work experience details"
        Lookup entityLookup = new Lookup();
        entityLookup.setLookupCode("WORK_EXP_CODE");
        entityLookup.setLookupValue("Work experience details");

        // Status lookup for "OPEN"
        Lookup openLookup = new Lookup();
        openLookup.setLookupCode("OPEN_CODE");
        openLookup.setLookupValue("OPEN");

        // Attribute that is NOT present in any entity
        Lookup missingAttribute = new Lookup();
        missingAttribute.setLookupCode("ATTR_MISSING");
        missingAttribute.setLookupValue("Company Turnover");

        // Matching entity for a different attribute (we'll skip adding it to simulate "openFields" being empty)
        // or simulate that the attribute doesn't match the one we're testing

        // Setup mocks
        when(lookupRepository.findByLookupName("Entity")).thenReturn(List.of(entityLookup));
        when(lookupRepository.findByLookupName("nonComplianceStatus")).thenReturn(List.of(openLookup));

        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(vaMasterId, "OPEN_CODE"))
                .thenReturn(Collections.emptyList());

        when(nonComplianceRepository.findByVaMasterFkAndStatusLookup(vaMasterId, null))
                .thenReturn(Collections.emptyList());

        when(lookupRepository.findByLookupName("Work Experience Details Attribute"))
                .thenReturn(List.of(missingAttribute));

        // Act
        NonComplianceNewResponseDTO response = nonComplianceService.fieldsWithOpenNonClosure(vaMasterId);

        // Assert
        assertNotNull(response);
        assertEquals(0, response.getNonComplianceOpenFields().size());
        assertEquals(1, response.getNonComplianceClosedFields().size());

        NonComplianceNewResponseDTO.Pair<String, String> closed = response.getNonComplianceClosedFields().get(0);
        assertEquals("Company Turnover", closed.fieldName);
        assertEquals("Closed", closed.value); // Assuming "Closed" is the default status for missing attributes
    }
}