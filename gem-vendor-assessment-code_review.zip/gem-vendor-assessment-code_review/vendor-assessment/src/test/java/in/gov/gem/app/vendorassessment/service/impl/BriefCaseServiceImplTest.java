package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.vendorassessment.client.IBriefcaseClient;
import in.gov.gem.app.vendorassessment.dto.response.UploadResponseDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BriefCaseServiceImplTest {

    @Mock
    private IBriefcaseClient briefcaseClient;

    @InjectMocks
    private BriefCaseService briefCaseService;

    @Test
    void uploadDocumentSuccessfully() {
        List<MultipartFile> files = Collections.singletonList(mock(MultipartFile.class));
        String docType = "TEST_DOC";
        List<UploadResponseDTO> expectedResponse = Collections.singletonList(new UploadResponseDTO());

        when(briefcaseClient.Uploaddocument(files, docType))
                .thenReturn(ResponseEntity.ok(expectedResponse));

        ResponseEntity<List<UploadResponseDTO>> response = briefCaseService.uploadDocument(files, docType);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedResponse, response.getBody());
        verify(briefcaseClient).Uploaddocument(files, docType);
    }

    @Test
    void uploadDocumentWithEmptyFileList() {
        List<MultipartFile> files = Collections.emptyList();
        String docType = "TEST_DOC";
        List<UploadResponseDTO> expectedResponse = Collections.emptyList();

        when(briefcaseClient.Uploaddocument(files, docType))
                .thenReturn(ResponseEntity.ok(expectedResponse));

        ResponseEntity<List<UploadResponseDTO>> response = briefCaseService.uploadDocument(files, docType);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isEmpty());
    }

    @Test
    void downloadDocumentSuccessfully() {
        String fileName = "test.pdf";
        byte[] expectedContent = "test content".getBytes();

        when(briefcaseClient.Downloaddocument_(fileName))
                .thenReturn(ResponseEntity.ok(expectedContent));

        byte[] response = briefCaseService.downloadDocument_(fileName);

        assertArrayEquals(expectedContent, response);
        verify(briefcaseClient).Downloaddocument_(fileName);
    }

    @Test
    void downloadDocumentWithEmptyResponse() {
        String fileName = "test.pdf";
        byte[] emptyContent = new byte[0];

        when(briefcaseClient.Downloaddocument_(fileName))
                .thenReturn(ResponseEntity.ok(emptyContent));

        byte[] response = briefCaseService.downloadDocument_(fileName);

        assertNotNull(response);
        assertEquals(0, response.length);
    }

}