package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.vendorassessment.dto.enums.CriteriaType;
import in.gov.gem.app.vendorassessment.dto.request.DropdownItemRequestDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DropdownServiceTest {

  private DropdownService dropdownService;

  @BeforeEach
  void setUp() {
    dropdownService = new DropdownService();
  }

  @Test
  void testGetDocumentTypesByValidCriterion() {
    DropdownItemRequestDTO result = dropdownService.getDocumentTypesByCriterion(CriteriaType.OEM_BIS_LICENSE);
    assertNotNull(result);
    assertEquals("BIS Certificate", result.getLicense());
  }

  @Test
  void testGetDocumentTypesByNullCriterion() {
    DropdownItemRequestDTO result = dropdownService.getDocumentTypesByCriterion(null);
    assertNotNull(result);
    assertEquals("GENERAL_DOC", result.getLicense());
  }
}