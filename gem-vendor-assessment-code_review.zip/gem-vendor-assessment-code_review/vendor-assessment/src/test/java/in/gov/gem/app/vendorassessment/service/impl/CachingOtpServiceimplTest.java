package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.cache.manager.GemCacheManager;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.cache.impl.CachingOtpService;
import in.gov.gem.app.vendorassessment.client.IOtpServiceClient;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.constant.CacheConstant;
import in.gov.gem.app.vendorassessment.dto.request.*;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseResenDResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseSendResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseValidateResponseDTO;


import in.gov.gem.app.vendorassessment.transformer.IAMTransformer;
import in.gov.gem.app.vendorassessment.utility.Helper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CachingOtpServiceimplTest {

    @InjectMocks
    private CachingOtpService cachingOtpService;

    @Mock
    private Helper requestUtil;

    @Mock
    private IOtpServiceClient client;

    @Mock
    private GemCacheManager<String, String> gemCacheManager;

    @Mock
    private IAMTransformer iamTransformer;

    @Test
    void SentOtpViaEmail_shouldStoreReferenceIdInCache_whenResponseHasData() {
        // Arrange
        AddEmailRequestDTO requestDto = new AddEmailRequestDTO();
        requestDto.setEmailId("user@example.com");

        String referenceId = "REF123";
        String cacheKey = CacheConstant.OTP_EMAIL + ":" + requestDto.getEmailId();

        OtpResponseSendResponseDTO sendDTO = new OtpResponseSendResponseDTO();
        sendDTO.setReferenceId(referenceId);

        APIResponse<OtpResponseSendResponseDTO> apiResponse = APIResponse.<OtpResponseSendResponseDTO>builder()
                .data(sendDTO)
                .build();

        ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> response = ResponseEntity.ok(apiResponse);

        when(requestUtil.getChannelId()).thenReturn("CHANNEL123");
        when(client.generateOtp(any(OtpGenerateRequestDTO.class))).thenReturn(response);

        // Act
        ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> result = cachingOtpService.SentOtpViaEmail(requestDto);

        // Assert
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals(referenceId, result.getBody().getData().getReferenceId());

        verify(gemCacheManager).put(cacheKey, referenceId, 600L, TimeUnit.SECONDS);
    }

    @Test
    void SentOtpViaEmail_shouldSkipCaching_whenResponseHasNullData() {
        // Arrange
        AddEmailRequestDTO requestDto = new AddEmailRequestDTO();
        requestDto.setEmailId("user@example.com");

        APIResponse<OtpResponseSendResponseDTO> apiResponse = APIResponse.<OtpResponseSendResponseDTO>builder()
                .data(null)
                .build();

        ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> response = ResponseEntity.ok(apiResponse);

        when(requestUtil.getChannelId()).thenReturn("CHANNEL456");
        when(client.generateOtp(any(OtpGenerateRequestDTO.class))).thenReturn(response);

        // Act
        ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> result = cachingOtpService.SentOtpViaEmail(requestDto);

        // Assert
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertNull(result.getBody().getData());

        verify(gemCacheManager, never()).put(anyString(), anyString(), anyLong(), any());
    }

    @Test
    void SentOtpViaEmail_shouldSkipCaching_whenResponseBodyIsNull() {
        // Arrange
        AddEmailRequestDTO requestDto = new AddEmailRequestDTO();
        requestDto.setEmailId("user@example.com");

        ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> response = ResponseEntity.ok(null);

        when(requestUtil.getChannelId()).thenReturn("CHANNEL789");
        when(client.generateOtp(any(OtpGenerateRequestDTO.class))).thenReturn(response);

        // Act
        ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> result = cachingOtpService.SentOtpViaEmail(requestDto);

        // Assert
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNull(result.getBody());

        verify(gemCacheManager, never()).put(anyString(), anyString(), anyLong(), any());
    }

    @Test
    void ResendOtpViaEmail_shouldSendOtpUsingClientWithProperPayload() {
        // Arrange
        String inputRefId = "ABC123";

        OtpRegenerateRequestDTO inputDto = OtpRegenerateRequestDTO.builder()
                .referenceId(inputRefId)
                .build();

        OtpResponseResenDResponseDTO responseData = new OtpResponseResenDResponseDTO();


        APIResponse<OtpResponseResenDResponseDTO> apiResponse = APIResponse.<OtpResponseResenDResponseDTO>builder()
                .data(responseData)
                .build();

        ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> responseEntity = ResponseEntity.ok(apiResponse);

        when(client.regenerateOtp(any(OtpRegenerateRequestDTO.class))).thenReturn(responseEntity);

        // Act
        ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> result =
                cachingOtpService.ResendOtpViaEmail(inputDto);

        // Assert
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());


        ArgumentCaptor<OtpRegenerateRequestDTO> captor =
                ArgumentCaptor.forClass(OtpRegenerateRequestDTO.class);

        verify(client).regenerateOtp(captor.capture());
        OtpRegenerateRequestDTO actualDto = captor.getValue();

        assertEquals(inputRefId, actualDto.getReferenceId());
        assertEquals(inputRefId, actualDto.getReferenceId());
        assertEquals(ApplicationConstant.OTP_PREFERENCE_EMAIL, actualDto.getDeliveryChannel());
    }

    @Test
    void ValidateOtpViaEmail_shouldReturn500_whenResponseOrBodyIsNull() {
        OtpValidationRequestDTO requestDTO = OtpValidationRequestDTO.builder()
                .email("test@example.com")
                .referenceId("REF999")
                .otp(123456L)
                .build();

        when(client.otpValidate(any(OtpRequestValidateRequestDTO.class)))
                .thenReturn(ResponseEntity.ok(null)); // Simulate null body

        ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> result =
                cachingOtpService.ValidateOtpViaEmail(requestDTO);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
        assertEquals("Invalid response from OTP validation service", result.getBody().getMessage());
    }

//    @Test
//    void ValidateOtpViaEmail_shouldAddEmail_whenValidationIsSuccessfulAndStatusIs2xx() {
//        OtpValidationRequestDTO requestDTO = OtpValidationRequestDTO.builder()
//                .email("test@example.com")
//                .referenceId("REF123")
//                .otp(999999L)
//                .build();
//
//        OtpResponseValidateResponseDTO validateDTO = new OtpResponseValidateResponseDTO();
//        validateDTO.setOtpValidated(true);
//
//        APIResponse<OtpResponseValidateResponseDTO> apiResponse = APIResponse.<OtpResponseValidateResponseDTO>builder()
//                .data(validateDTO)
//                .build();
//
//        ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> successResponse = ResponseEntity.ok(apiResponse);
//
//        when(client.otpValidate(any(OtpRequestValidateRequestDTO.class)))
//                .thenReturn(successResponse);
//
//        ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> result =
//                cachingOtpService.ValidateOtpViaEmail(requestDTO);
//
//        assertEquals(HttpStatus.OK, result.getStatusCode());
//        verify(iamTransformer).addEmail(eq("eng"), any(AddEmailRequestDTO.class)); // assert email was added
//    }

    @Test
    void ValidateOtpViaEmail_shouldNotAddEmail_whenOtpValidatedIsFalse() {
        OtpValidationRequestDTO requestDTO = OtpValidationRequestDTO.builder()
                .email("test@example.com")
                .referenceId("REF321")
                .otp(000000L)
                .build();

        OtpResponseValidateResponseDTO validateDTO = new OtpResponseValidateResponseDTO();
        validateDTO.setOtpValidated(false); // will skip addEmail

        APIResponse<OtpResponseValidateResponseDTO> apiResponse = APIResponse.<OtpResponseValidateResponseDTO>builder()
                .data(validateDTO)
                .build();

        ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> response = ResponseEntity.ok(apiResponse);

        when(client.otpValidate(any(OtpRequestValidateRequestDTO.class)))
                .thenReturn(response);

        ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> result =
                cachingOtpService.ValidateOtpViaEmail(requestDTO);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        verify(iamTransformer, never()).addEmail(any(), any());
    }

    @Test
    void SentOtpViaMobile_shouldStoreReferenceIdInCache_whenResponseHasData() {
        AddMobileRequestDTO dto = AddMobileRequestDTO.builder().mobileNumber("9876543210").build();
        String refId = "REF987";
        String cacheKey = CacheConstant.OTP_EMAIL + ":" + dto.getMobileNumber();

        OtpResponseSendResponseDTO sendDTO = new OtpResponseSendResponseDTO();
        sendDTO.setReferenceId(refId);

        APIResponse<OtpResponseSendResponseDTO> apiResponse = APIResponse.<OtpResponseSendResponseDTO>builder()
                .data(sendDTO)
                .build();

        ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> response = ResponseEntity.ok(apiResponse);

        when(requestUtil.getChannelId()).thenReturn("CHAN_ID");
        when(client.generateOtp(any())).thenReturn(response);

        ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> result = cachingOtpService.SentOtpViaMobile(dto);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(refId, result.getBody().getData().getReferenceId());
        verify(gemCacheManager).put(cacheKey, refId, 600L, TimeUnit.SECONDS);
    }

    @Test
    void SentOtpViaMobile_shouldSkipCaching_whenResponseBodyOrDataIsNull() {
        AddMobileRequestDTO dto = AddMobileRequestDTO.builder().mobileNumber("1234567890").build();

        ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> nullBody = ResponseEntity.ok(null);
        ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> nullData = ResponseEntity.ok(APIResponse.<OtpResponseSendResponseDTO>builder().data(null).build());

        when(requestUtil.getChannelId()).thenReturn("CHAN_ID");

        when(client.generateOtp(any())).thenReturn(nullBody);
        cachingOtpService.SentOtpViaMobile(dto);
        verify(gemCacheManager, never()).put(any(), any(), anyLong(), any());

        when(client.generateOtp(any())).thenReturn(nullData);
        cachingOtpService.SentOtpViaMobile(dto);
        verify(gemCacheManager, never()).put(any(), any(), anyLong(), any());
    }

    @Test
    void ValidateOtpViaMobile_shouldReturn500_whenBodyIsNull() {
        MobileOtpValidationRequestDTO request = MobileOtpValidationRequestDTO.builder()
                .mobile("9876543210")
                .referenceId("REF001")
                .otp(123456L)
                .build();

        ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> nullBody = ResponseEntity.ok(null);
        when(client.otpValidate(any())).thenReturn(nullBody);

        ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> result = cachingOtpService.ValidateOtpViaMobile(request);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
        assertEquals("Invalid response from OTP validation service", result.getBody().getMessage());
    }

//    @Test
//    void ValidateOtpViaMobile_shouldAddMobile_whenValidatedAndStatusIs2xx() {
//        MobileOtpValidationRequestDTO request = MobileOtpValidationRequestDTO.builder()
//                .mobile("9876543210")
//                .referenceId("REF002")
//                .otp(654321L)
//                .build();
//
//        OtpResponseValidateResponseDTO responseDTO = new OtpResponseValidateResponseDTO();
//        responseDTO.setOtpValidated(true);
//
//        APIResponse<OtpResponseValidateResponseDTO> apiResponse = APIResponse.<OtpResponseValidateResponseDTO>builder().data(responseDTO).build();
//        ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> validResponse = ResponseEntity.ok(apiResponse);
//
//        when(client.otpValidate(any())).thenReturn(validResponse);
//
//        ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> result = cachingOtpService.ValidateOtpViaMobile(request);
//        assertEquals(HttpStatus.OK, result.getStatusCode());
//        verify(iamTransformer).addMobile(eq("eng"), any(AddMobileRequestDTO.class));
//    }

    @Test
    void ValidateOtpViaMobile_shouldNotAddMobile_whenNotValidated() {
        MobileOtpValidationRequestDTO request = MobileOtpValidationRequestDTO.builder()
                .mobile("9876543210")
                .referenceId("REF003")
                .otp(000000L)
                .build();

        OtpResponseValidateResponseDTO responseDTO = new OtpResponseValidateResponseDTO();
        responseDTO.setOtpValidated(false);

        APIResponse<OtpResponseValidateResponseDTO> apiResponse = APIResponse.<OtpResponseValidateResponseDTO>builder().data(responseDTO).build();
        ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> invalidResponse = ResponseEntity.ok(apiResponse);

        when(client.otpValidate(any())).thenReturn(invalidResponse);

        ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> result = cachingOtpService.ValidateOtpViaMobile(request);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        verify(iamTransformer, never()).addMobile(any(), any());
    }

    @Test
    void ResendOtpViaMobile_shouldCallClientWithProperPayload() {
        String inputRefId = "REF555";
        OtpRegenerateRequestDTO inputDto = OtpRegenerateRequestDTO.builder().referenceId(inputRefId).build();

        OtpResponseResenDResponseDTO resendDTO = new OtpResponseResenDResponseDTO();

        APIResponse<OtpResponseResenDResponseDTO> apiResponse = APIResponse.<OtpResponseResenDResponseDTO>builder()
                .data(resendDTO)
                .build();

        ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> response = ResponseEntity.ok(apiResponse);

        when(client.regenerateOtp(any())).thenReturn(response);

        ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> result =
                cachingOtpService.ResendOtpViaMobile(inputDto);

        assertEquals(HttpStatus.OK, result.getStatusCode());


        ArgumentCaptor<OtpRegenerateRequestDTO> captor =
                ArgumentCaptor.forClass(OtpRegenerateRequestDTO.class);

        verify(client).regenerateOtp(captor.capture());
        assertEquals(ApplicationConstant.OTP_PREFERENCE_MOBILE, captor.getValue().getDeliveryChannel());

    }
}
