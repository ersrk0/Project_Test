package in.gov.gem.app.vendorassessment.transformer;

import in.gov.gem.app.vendorassessment.dto.response.HierarchyMasterResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.HierarchyResponseDTO;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.client.IBuyerClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BuyerTransformerTest {

  @Mock
  private IBuyerClient buyerClient;

  @InjectMocks
  private BuyerTransformer buyerTransformer;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  // getOrgType tests

  @Test
  void getOrgType_nullResponse_returnsEmpty() {
    when(buyerClient.findAllorgType(anyString(), any())).thenReturn(null);
    HierarchyMasterResponseDTO result = buyerTransformer.getOrgType("en", new PaginationParams());
    assertNotNull(result);
    assertNull(result.getEntities());
  }

  @Test
  void getOrgType_nullEntities_returnsEmpty() {
    PageableApiResponse<HierarchyMasterResponseDTO> apiResp = new PageableApiResponse<>();
    apiResp.setData(HierarchyMasterResponseDTO.builder().label("label").entities(null).build());
    when(buyerClient.findAllorgType(anyString(), any())).thenReturn(ResponseEntity.ok(apiResp));
    HierarchyMasterResponseDTO result = buyerTransformer.getOrgType("en", new PaginationParams());
    assertNotNull(result);
    assertNull(result.getEntities());
  }

  @Test
  void getOrgType_valid_returnsExpected() {
    HierarchyMasterResponseDTO data = HierarchyMasterResponseDTO.builder()
      .label("label")
      .entities(Collections.singletonList(Collections.singletonMap("id", "1")))
      .build();
    PageableApiResponse<HierarchyMasterResponseDTO> apiResp = new PageableApiResponse<>();
    apiResp.setData(data);
    when(buyerClient.findAllorgType(anyString(), any())).thenReturn(ResponseEntity.ok(apiResp));
    HierarchyMasterResponseDTO result = buyerTransformer.getOrgType("en", new PaginationParams());
    assertEquals("label", result.getLabel());
    assertNotNull(result.getEntities());
    assertEquals(1, result.getEntities().size());
  }

  // getOrgTypeWithLevel tests

  @Test
  void getOrgTypeWithLevel_nullResponse_returnsEmpty() {
    when(buyerClient.findHierarchywithlevel(anyString(), anyString(), any())).thenReturn(null);
    HierarchyResponseDTO result = buyerTransformer.getOrgTypeWithLevel("p", "en", new PaginationParams());
    assertNotNull(result);
    assertNull(result.getEntities());
  }

  @Test
  void getOrgTypeWithLevel_nullEntities_returnsEmpty() {
    PageableApiResponse<HierarchyResponseDTO> apiResp = new PageableApiResponse<>();
    apiResp.setData(HierarchyResponseDTO.builder().label("label").entities(null).build());
    when(buyerClient.findHierarchywithlevel(anyString(), anyString(), any())).thenReturn(ResponseEntity.ok(apiResp));
    HierarchyResponseDTO result = buyerTransformer.getOrgTypeWithLevel("p", "en", new PaginationParams());
    assertNotNull(result);
    assertNull(result.getEntities());
  }

  @Test
  void getOrgTypeWithLevel_valid_returnsExpected() {
    HierarchyResponseDTO data = HierarchyResponseDTO.builder()
      .label("label")
      .entities(Collections.singletonList(Collections.singletonMap("id", "1")))
      .key("key")
      .post("post")
      .build();
    PageableApiResponse<HierarchyResponseDTO> apiResp = new PageableApiResponse<>();
    apiResp.setData(data);
    when(buyerClient.findHierarchywithlevel(anyString(), anyString(), any())).thenReturn(ResponseEntity.ok(apiResp));
    HierarchyResponseDTO result = buyerTransformer.getOrgTypeWithLevel("p", "en", new PaginationParams());
    assertEquals("label", result.getLabel());
    assertEquals("key", result.getKey());
    assertEquals("post", result.getPost());
    assertNotNull(result.getEntities());
    assertEquals(1, result.getEntities().size());
  }
}
