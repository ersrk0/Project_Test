package in.gov.gem.app.vendorassessment.controller.impl;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.gov.gem.app.vendorassessment.dto.request.AuthorizeDetailRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ContractManufacturerRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.LookupRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.AuthorizeResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.ContractManufacturerResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.IdentifyRegistrationResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.SaveAssessResponseDTO;
import in.gov.gem.app.vendorassessment.facade.ISaveAssessOptionFacade;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AssessOptionControllerTest {

    @Mock
    private ISaveAssessOptionFacade saveAssessOptionFacade;


    @InjectMocks
    private AssessOptionController assessOptionController;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        mockMvc = MockMvcBuilders.standaloneSetup(assessOptionController).build();
    }

    @Test
    void saveLookupValue_ReturnsOk_WhenValidRequest() throws Exception {
        LookupRequestDTO lookupRequestDto = new LookupRequestDTO();
        SaveAssessResponseDTO responseDTO = new SaveAssessResponseDTO();

        when(saveAssessOptionFacade.saveOption(any(), anyBoolean())).thenReturn(responseDTO);

        mockMvc.perform(post("/v1/assess/apply-as")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(lookupRequestDto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isNotEmpty());

        verify(saveAssessOptionFacade).saveOption(any(), anyBoolean());
    }

    @Test
    void authorizeDetail_ReturnsOk_WhenValidRequest() throws Exception {
        AuthorizeDetailRequestDTO authorizeDetailDTO = new AuthorizeDetailRequestDTO();
        AuthorizeResponseDTO responseDTO = new AuthorizeResponseDTO();

        when(saveAssessOptionFacade.authorizeDetailSave(any())).thenReturn(responseDTO);

        mockMvc.perform(post("/v1/assess/authorize/detail")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(authorizeDetailDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isNotEmpty());

        verify(saveAssessOptionFacade).authorizeDetailSave(any());
    }

    @Test
    void contractManufacturerDetail_ReturnsOk_WhenValidRequest() throws Exception {
        ContractManufacturerRequestDTO contractManufacturerDTO = new ContractManufacturerRequestDTO();
        ContractManufacturerResponseDTO responseDTO = new ContractManufacturerResponseDTO();

        when(saveAssessOptionFacade.contractManufacturerDetailSave(any())).thenReturn(responseDTO);

        mockMvc.perform(post("/v1/assess/contract-manufacturer/detail")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(contractManufacturerDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isNotEmpty());

        verify(saveAssessOptionFacade).contractManufacturerDetailSave(any());
    }

    @Test
    void identifyRegistration_ReturnsOk_WhenFacadeReturnsData() throws Exception {
        IdentifyRegistrationResponseDTO identifyRegistrationDTO = new IdentifyRegistrationResponseDTO();

        when(saveAssessOptionFacade.identifyRegistration()).thenReturn(identifyRegistrationDTO);

        mockMvc.perform(get("/v1/assess/identify"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data").isNotEmpty());

        verify(saveAssessOptionFacade).identifyRegistration();
    }


}