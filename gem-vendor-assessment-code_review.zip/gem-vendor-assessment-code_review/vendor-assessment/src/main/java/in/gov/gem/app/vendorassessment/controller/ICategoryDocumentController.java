
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.request.CategoryDocumentDto;
import in.gov.gem.app.vendorassessment.dto.response.CategoryDocumentResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Instant;



@RequestMapping("/v1/categories/questions/documents")
@Tag(name = "Document Management", description = "Endpoints for managing documents associated with category questions.")
public interface ICategoryDocumentController {

    @GetMapping
    @Operation(
        summary = "Get documents for a specific question",
        description = "Retrieves all documents associated with a given category and question ID.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Documents fetched successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryDocumentResponse.class)))
        }
    )
    ResponseEntity<APIResponse<Object>> getDocumentsForQuestion(
        @Parameter(description = "The ID of the category", required = true) @RequestParam Long categoryId,
        @Parameter(description = "The ID of the question", required = true) @RequestParam Long questionId
    );

    @PostMapping
    @Operation(
        summary = "Upload a new document",
        description = "Uploads a new document for a specific question, with an optional validity date.",
        responses = {
            @ApiResponse(responseCode = "201", description = "Document uploaded successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryDocumentDto.class)))
        }
    )
    ResponseEntity<APIResponse<Object>> uploadDocument(
        @Parameter(description = "The ID of the category", required = true) @RequestParam Long categoryId,
        @Parameter(description = "The ID of the question", required = true) @RequestParam Long questionId,
        @Parameter(description = "The document file to upload", required = true) @RequestParam("file") MultipartFile file,
        @Parameter(description = "Optional instant in UTC when the document is no longer valid", example = "2024-12-31T23:59:59Z") @RequestParam(value = "validUpto", required = false) Instant validUptoStr
    ) throws IOException;

    @DeleteMapping()
    @Operation(
        summary = "Delete a document",
        description = "Deletes a specific document by its ID, question ID, and category ID.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Document deleted successfully")
        }
    )
    ResponseEntity<APIResponse<Object>> deleteDocument(
        @Parameter(description = "The ID of the category", required = true) @RequestParam Long categoryId,
        @Parameter(description = "The ID of the question", required = true) @RequestParam Long questionId,
        @Parameter(description = "The ID of the document to delete", required = true) @RequestParam Long documentId
    ) throws IOException;

    @GetMapping("/view")
    @Operation(
        summary = "View or download a document",
        description = "Retrieves and serves the content of a specific document, allowing it to be viewed or downloaded.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Document content retrieved successfully"),
            @ApiResponse(responseCode = "404", description = "Document not found")
        }
    )
    ResponseEntity<byte[]> viewDocument(
        @Parameter(description = "The ID of the category", required = true) @RequestParam Long categoryId,
        @Parameter(description = "The ID of the question", required = true) @RequestParam Long questionId,
        @Parameter(description = "The ID of the document to view", required = true) @RequestParam Long documentId
    ) throws IOException;
}
