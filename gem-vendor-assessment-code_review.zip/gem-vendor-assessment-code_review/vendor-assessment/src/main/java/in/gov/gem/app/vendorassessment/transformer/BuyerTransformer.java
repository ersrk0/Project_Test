
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.transformer;


import in.gov.gem.app.vendorassessment.dto.response.HierarchyMasterResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.HierarchyResponseDTO;

import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.client.IBuyerClient;
import in.gov.gem.app.utility.CustomLoggerFactory;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Optional;


/**
 * The type Buyer transformer.
 */
@AllArgsConstructor
@Component
public class BuyerTransformer
{
  private final IBuyerClient buyerClient;

  private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(BuyerTransformer.class);


  /**
   * Gets org type.
   *
   * @param acceptLanguage   the accept language
   * @param paginationParams the pagination params
   * @return the org type
   */
  public HierarchyMasterResponseDTO getOrgType(String acceptLanguage, PaginationParams paginationParams )
  {
    ResponseEntity<PageableApiResponse<HierarchyMasterResponseDTO>> response= buyerClient.findAllorgType(acceptLanguage, paginationParams);

    HierarchyMasterResponseDTO masterResponse = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(PageableApiResponse::getData) // Gets single HierarchyMasterResponse
      .orElse(null);

    if (masterResponse == null || masterResponse.getEntities() == null) {
      log.info("No organization types found for the given parameters.");
      return new HierarchyMasterResponseDTO();
    }

    return HierarchyMasterResponseDTO.builder()
      .label(masterResponse.getLabel())
      .entities(masterResponse.getEntities())
      .build();

  }

  /**
   * Gets org type with level.
   *
   * @param parentId         the parent id
   * @param acceptLanguage   the accept language
   * @param paginationParams the pagination params
   * @return the org type with level
   */
  public HierarchyResponseDTO getOrgTypeWithLevel(String parentId, String acceptLanguage,
                                                  PaginationParams paginationParams)
  {
    ResponseEntity<PageableApiResponse<HierarchyResponseDTO>> response =
      buyerClient.findHierarchywithlevel(parentId, acceptLanguage, paginationParams);

    HierarchyResponseDTO masterResponse = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(PageableApiResponse::getData) // Gets single HierarchyMasterResponse
      .orElse(null);

    // 3. Handle empty response
    if (masterResponse == null || masterResponse.getEntities() == null) {
      log.info("No organization types found for the given parameters.");
      return new HierarchyResponseDTO();
    }

    return HierarchyResponseDTO.builder()
      .label(masterResponse.getLabel())
      .entities(masterResponse.getEntities())
      .key(masterResponse.getKey())
      .post(masterResponse.getPost())
      .build();

  }

}
