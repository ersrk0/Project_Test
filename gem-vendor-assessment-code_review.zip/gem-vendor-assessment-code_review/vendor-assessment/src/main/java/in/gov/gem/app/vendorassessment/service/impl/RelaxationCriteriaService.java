
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.vendorassessment.dto.request.DocumentOldRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.DocumentNewResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.RelaxationOptionResponseDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.vendorassessment.domain.repository.VendorAssessmentRepository;
import in.gov.gem.app.vendorassessment.dto.response.*;
import in.gov.gem.app.vendorassessment.service.IRelaxationCriteriaService;
import in.gov.gem.app.vendorassessment.utility.LookUpUtility;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

/**
 * The type Relaxation criteria service.
 */
@Service
@AllArgsConstructor
public class RelaxationCriteriaService implements IRelaxationCriteriaService {

  private final MessageUtility messageUtility;
  private VendorAssessmentRepository vendorAssessmentRepository;
  private static final Logger logger = LoggerFactory.getLogger(RelaxationCriteriaService.class);
  private final LookUpUtility lookUpUtility;


  // In-memory store for demonstration
  private final Map<String, List<DocumentNewResponseDTO>> vendorDocuments = new HashMap<>();
  private final Map<String, List<LicenseCertificateDetailResponseDTO>> vendorLicenses = new HashMap<>();


  private static final List<String> ALLOWED_CRITERIA = List.of(
      "Central / State PSUs",
      "OEMs holding BIS License for the particular product category",
      "Sellers recommended for exemption for specific categories and specified validity period by any CPSE" +
              ", Central and State Government Departments/ Authorities.",
      "Sellers recommended for exemption for specific categories and specified " +
              "validity period by any CPSE, Central and State Government Departments/ Authorities.",
          "Sellers who are Registered Societies/ Trusts/ other bodies, if these concerns have Government Representation.",
        "Vaccine manufacturer as per list provided by Ministry of Health & Family Welfare",
        "Drugs/Medicine manufacturer with \"Notarized Undertaking\" & \"Valid certified copy of Drug Licenses from the issuing/concerned Drug Authority\"",
        "Medical Device manufacturer with \"Valid Manufacturing License\" from the issuing Licensing Authority",
        "Turnover based exemption if turnover is greater than 500 Cr in any of the last 3 year"
  );

  private static final Map<String, List<RelaxationOptionResponseDTO>> relaxationOptionsMap = new HashMap<>();

  static {
    relaxationOptionsMap.put("Central / State PSUs", List.of(
        new RelaxationOptionResponseDTO("Incorporation Certificate ", "Please upload Incorporation Certificate " +
                "or any other document that is applicable")
    ));
    relaxationOptionsMap.put("OEMs holding BIS License for the particular product category", List.of(
        new RelaxationOptionResponseDTO("BIS Certificate", "BIS Certificate " +
                "having a License number")
    ));
    relaxationOptionsMap.put("Sellers recommended for exemption for specific categories and specified" +
            " validity period by any CPSE, Central and State Government Departments/ Authorities.", List.of(
        new RelaxationOptionResponseDTO("recommendation letter and certificate", "Please upload" +
                " recommendation letter and certificate issued by any CPSE/Government Departments requesting for a vendor assessment exemption")
    ));
    relaxationOptionsMap.put("Sellers who are Registered Societies/ Trusts/" +
            " other bodies, if these concerns have Government Representation.", List.of(
        new RelaxationOptionResponseDTO("Society Registration Certificate", "Please upload Society" +
                " Registration Certificate or Trust deed/agreement or any other document that is applicable")
    ));
    relaxationOptionsMap.put("Vaccine manufacturer as per list provided by Ministry of Health & Family Welfare", List.of(
        new RelaxationOptionResponseDTO("valid drug licence", "Please upload Copy of valid drug licence" +
                " from the issuing/concerned Drug Authority")
    ));
    relaxationOptionsMap.put("Drugs/Medicine manufacturer with \"Notarized Undertaking\" &" +
            " \"Valid certified copy of Drug Licenses from the issuing/concerned Drug Authority\"", List.of(
        new RelaxationOptionResponseDTO("Drug License", "The following documents need to be submitted with this application:\t\n" +
                "\t\n" +
                "1. Valid Drug License from the issuing / concerned Drug Authority\t\n" +
                "2. Undertaking as per the Document Template given above printed and notarized on a non-judicial stamp paper of Rs.10\t\n" +
                "\t\n" +
                "Please Note: The two documents above should be combined and uploaded as a single document below.\t")
    ));
    relaxationOptionsMap.put("Medical Device manufacturer with \"Valid Manufacturing License\" " +
            "from the issuing Licensing Authority", List.of(
        new RelaxationOptionResponseDTO("manufacturing license", "Please upload Valid certified copy of" +
                " manufacturing license from the issuing Licensing Authority for the specific medical device (exemption will be valid on only on product category level and not on entity level).\t\t\n" +
                "You are required to upload supporting documents that demonstrate your manufacturing capacity in the categories you have applied for the VA exemption:\t\t")
    ));
    relaxationOptionsMap.put("Turnover based exemption if turnover is greater than 500 Cr in any of the last 3 year", List.of(
        new RelaxationOptionResponseDTO("3 sales invoices ", "1. Please upload 3 invoices for raw materials purchased and 3 sales invoices from any of the last 3 years for the applied categories. (with GSTIN)\t\t\n" +
                "\t\t\n" +
                "Note*:Please ensure that applied categories are reflected in the “Dealing in Goods and Services” section of the online GST portal\t\t")
    ));
  }



  private static final List<String> ADMIN_DEFINED_SELLERS = List.of("FPO", "Artisan", "ODOP");
  private static final List<String> SYSTEM_ASSESSED_SELLERS = List.of("BOD123", "BOD456");

  private final Map<Long, DocumentNewResponseDTO> documentStore = new HashMap<>();
  private final AtomicLong idGenerator = new AtomicLong(1);

  @Override
  public DocumentNewResponseDTO addDocument(DocumentOldRequestDTO request) {
    if (request == null || request.getName() == null || request.getName().isEmpty()) {
      logger.error("File is empty: {}", request);
      throw new ServiceException(
              MessageConstant.FILE_EMPTY,
              messageUtility.getMessage(MessageConstant.FILE_EMPTY),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.I
      );
    }

    Long id = idGenerator.getAndIncrement();
    DocumentNewResponseDTO response = new DocumentNewResponseDTO();
    response.setId(id);
    response.setCriteria(request.getCriteria());
    response.setName(request.getName());
    response.setType(request.getType());
    response.setIssuingAuthority(request.getIssuingAuthority());
    response.setRemarks(request.getRemarks());
    response.setSizeInMB(request.getSizeInMB());
    response.setValidUpto(request.getValidUpto());
    response.setStatus("Saved");
    documentStore.put(id, response);

    logger.info("Document added successfully with ID: {}", id);
    return response;
  }

  @Override
  public List<DocumentNewResponseDTO> getAllDocuments(String criteria) {
    try {
      if (criteria == null || criteria.isEmpty()) {
        return new ArrayList<>(documentStore.values());
      }
      return documentStore.values().stream()
              .filter(doc -> criteria.equalsIgnoreCase(doc.getCriteria()))
              .collect(Collectors.toList());
    } catch (Exception e) {
      logger.error("Error occurred while fetching documents for criteria: {}", criteria, e);
      throw new ServiceException(
              MessageConstant.DOCUMENT_NOT_FOUND,
              messageUtility.getMessage(MessageConstant.DOCUMENT_NOT_FOUND),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.I
      );
    }
  }

  @Override
  public DocumentNewResponseDTO deleteDocument(Long id) {
    DocumentNewResponseDTO removed = documentStore.remove(id);
    if (removed == null) {
      logger.error("Document with ID {} not found for deletion", id);
      throw new ServiceException(
              MessageConstant.DOCUMENT_NOT_FOUND,
              messageUtility.getMessage(MessageConstant.DOCUMENT_NOT_FOUND),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.I
      );
    }
    removed.setStatus("Deleted");
    logger.info("Document with ID {} successfully deleted", id);
    return removed;
  }

  @Override
  public Object validateCriteria(boolean eligible) {
    if (eligible) {
      return ALLOWED_CRITERIA;
    } else {
      return "No exemption selected. Proceed without exemption.";
    }
  }

  @Override
  public boolean isEligibleForAdminExemption(String sellerId) {
    if (sellerId == null || sellerId.isEmpty()) {
      logger.error("Seller ID is null or empty for admin exemption check.");
      throw new ServiceException(
              MessageConstant.SELLER_PROFILE_NOT_FOUND,
              messageUtility.getMessage(MessageConstant.SELLER_PROFILE_NOT_FOUND),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.I
      );
    }
    boolean isEligible = ADMIN_DEFINED_SELLERS.contains(sellerId);
    logger.info("Admin exemption eligibility for seller ID {}: {}", sellerId, isEligible);
    return isEligible;
  }

  @Override
  public boolean isEligibleForSystemExemption(String sellerId) {
    if (sellerId == null || sellerId.isEmpty()) {
      logger.error("Seller ID is null or empty for system exemption check.");
      throw new ServiceException(
              MessageConstant.SELLER_PROFILE_NOT_FOUND,
              messageUtility.getMessage(MessageConstant.SELLER_PROFILE_NOT_FOUND),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.I
      );
    }
    boolean isEligible = SYSTEM_ASSESSED_SELLERS.contains(sellerId);
    logger.info("System exemption eligibility for seller ID {}: {}", sellerId, isEligible);
    return isEligible;
  }

  @Override
  public List<RelaxationOptionResponseDTO> getOptionsByCriteria(String criteria) {
    return relaxationOptionsMap.getOrDefault(criteria, List.of());
  }

  @Override
  public EligibleRelaxationResponseDTO fetchEligibleRelaxationOption() {
    List<CoreLookupDto> eligibleRelaxationCriteria = lookUpUtility.getLookupByLookUpName("Eligible Relaxation");
    String question = null;
    if (eligibleRelaxationCriteria != null && !eligibleRelaxationCriteria.isEmpty()) {
      List<String> options = new ArrayList<>();
      for(CoreLookupDto lookup : eligibleRelaxationCriteria) {
        String op = lookup.getLookupValue();
        options.add(op);
       question= lookup.getDescription();
        }
      return new EligibleRelaxationResponseDTO(question, options);
      }
    return null;
  }

  //-----------------------------------------------------------------------------------------------


  public List<IssuingAuthorityResponseDTO> getIssuingAuthorities(String criteriaType) {
    logger.info("Fetching issuing authorities for criteria: {}", criteriaType);

    // This would normally come from a database or configuration
    Map<String, List<IssuingAuthorityResponseDTO>> authoritiesMap = Map.of(
      "BIS License", List.of(
        new IssuingAuthorityResponseDTO("BIS", "Bureau of Indian Standards", "bis@bis.gov.in"),
        new IssuingAuthorityResponseDTO("State BIS", "State BIS Office", "state.bis@gov.in")
      ),
      "PSU Certification", List.of(
        new IssuingAuthorityResponseDTO("MCA", "Ministry of Corporate Affairs", "mca@nic.in"),
        new IssuingAuthorityResponseDTO("DPE", "Department of Public Enterprises", "dpe@nic.in")
      )
    );

    return criteriaType == null ?
      authoritiesMap.values().stream().flatMap(List::stream).collect(Collectors.toList()) :
      authoritiesMap.getOrDefault(criteriaType, Collections.emptyList());
  }

  public List<LicenseCertificateDetailResponseDTO> getLicenseCertificateDetails(String vendorAssessmentId, String type) {
    initializeStubData(vendorAssessmentId);

    return vendorLicenses.getOrDefault(vendorAssessmentId, List.of()).stream()
      .filter(license -> type == null || license.getType().equalsIgnoreCase(type))
      .collect(Collectors.toList());
  }

  public ConsolidatedExemptionResponseDTO getConsolidatedExemptions(String vendorAssessmentId) {
    initializeStubData(vendorAssessmentId);

    ConsolidatedExemptionResponseDTO response = new ConsolidatedExemptionResponseDTO();
    response.setVendorAssessmentId(vendorAssessmentId);
    response.setAdminExemptions(List.of("FPO_REGISTERED"));
    response.setSystemExemptions(List.of("AUTO_APPROVED"));
    response.setLicenseExemptions(List.of("BIS_LICENSE", "PSU_CERT"));
    response.setOtherExemptions(List.of("TURNOVER_EXEMPTION"));
    response.setLastUpdated(new Timestamp(System.currentTimeMillis()));
    response.setTotalExemptions(4);
    response.setActiveExemptions(3);

    return response;
  }

  public PreviousEligibilityResponseDTO getPreviousEligibility(String vendorAssessmentId) {
    initializeStubData(vendorAssessmentId);

    PreviousEligibilityResponseDTO response = new PreviousEligibilityResponseDTO();
    response.setVendorAssessmentId(vendorAssessmentId);
    response.setWasEligible(true);
    response.setSelectedCriteria(List.of("BIS License", "PSU Certification"));
    response.setSelectedOptions(List.of("BIS-" + vendorAssessmentId + "-001", "PSU-" + vendorAssessmentId + "-001"));
    response.setLastUpdated(new Timestamp(System.currentTimeMillis()));

    return response;
  }

  @Override
  public DraftEligibilityResponseDTO getDraftEligibility(Long vendorAssessmentId) {
    boolean status = vendorAssessmentRepository.existsByIdAndVaStatusLookUp(vendorAssessmentId, "LCVA1112");
    DraftEligibilityResponseDTO response = new DraftEligibilityResponseDTO();
    if(status){
        response.setWasEligible(true);
        response.setVendorAssessmentId(vendorAssessmentId);
        response.setSelectedExemption("OEMs holding BIS License");
        return response;
    }
    response.setWasEligible(false);
    response.setVendorAssessmentId(vendorAssessmentId);
    response.setSelectedExemption(null);
    return response;
  }

  private void initializeStubData(String vendorAssessmentId) {
    // Initialize licenses
    vendorLicenses.putIfAbsent(vendorAssessmentId, List.of(
      new LicenseCertificateDetailResponseDTO(
        "BIS-" + vendorAssessmentId + "-001",
        "BIS License",
        "Bureau of Indian Standards",
        Timestamp.valueOf(LocalDateTime.now().plusYears(1)),
        "ACTIVE"
      ),
      new LicenseCertificateDetailResponseDTO(
        "PSU-" + vendorAssessmentId + "-001",
        "PSU Certification",
        "Ministry of Corporate Affairs",
        Timestamp.valueOf(LocalDateTime.now().plusMonths(6)),
        "ACTIVE"
      )
    ));
  }

}

