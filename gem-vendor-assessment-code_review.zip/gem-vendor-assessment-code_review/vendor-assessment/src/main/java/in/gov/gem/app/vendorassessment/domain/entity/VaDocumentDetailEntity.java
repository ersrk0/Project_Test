
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

/**
 * The type Va document detail entity.
 */
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "va_document_detail",schema = "va_mgmt")
public class VaDocumentDetailEntity extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    @Column(name = "va_master_fk")
    private Long vaMasterFk;
    @Column(name = "document_name")
    private String documentName;
    @Column(name = "document_type_lookup")
    private String documentTypeLookup;
    @Column(name = "document_extension_lookup")
    private String documentExtensionLookup;
    @Column(name = "document_path")
    private String documentPath;
    @Column(name = "status_lookup")
    private String statusLookup;
    @Column(name = "size_in_mb")
    private Double sizeInMb;
    @Column(name = "remark")
    private String remark;
    @Column(name="no_of_page")
    private Integer noOfPage;
    @Column(name = "upload_by")
    private UUID uploadBy;
}
