
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;



import in.gov.gem.app.vendorassessment.dto.request.CategoryManufacturingAddressDTO;
import in.gov.gem.app.vendorassessment.service.ICategoryManufacturingAddressService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Implementation of the ManufacturingAddressService interface.
 * Uses an in-memory map to store manufacturing address data.
 */
@Service
public class CategoryManufacturingAddressServiceImpl implements ICategoryManufacturingAddressService {

  private static final Logger log = LoggerFactory.getLogger(CategoryManufacturingAddressServiceImpl.class);
  private final Map<String, CategoryManufacturingAddressDTO> addressStore = new ConcurrentHashMap<>();
  private final AtomicLong idCounter = new AtomicLong();

  /**
   * Creates a new manufacturing address entry.
   * @param address The manufacturing address object to create.
   * @return The created manufacturing address with its ID.
   */
  @Override
  public CategoryManufacturingAddressDTO createManufacturingAddress(CategoryManufacturingAddressDTO address) {
    String newId = String.valueOf(idCounter.incrementAndGet());
    address.setId(newId);
    addressStore.put(newId, address);
    return address;
  }

  /**
   * Retrieves a manufacturing address by its ID.
   * @param id The ID of the manufacturing address.
   * @return An Optional containing the manufacturing address if found.
   */
  @Override
  public Optional<CategoryManufacturingAddressDTO> getManufacturingAddressById(String id) {
    log.info("Retrieving Manufacturing Address with ID: {}", id);
    return Optional.ofNullable(addressStore.get(id));
  }

  /**
   * Retrieves all manufacturing address entries.
   * @return A list of all manufacturing addresses.
   */
  @Override
  public List<CategoryManufacturingAddressDTO> getAllManufacturingAddresses() {
    log.info("Retrieving all Manufacturing Addresses. Total count: {}", addressStore.size());
    return new ArrayList<>(addressStore.values());
  }

  /**
   * Updates an existing manufacturing address.
   * @param id The ID of the manufacturing address to update.
   * @param address The manufacturing address object with updated details.
   * @return An Optional containing the updated manufacturing address if found.
   */
  @Override
  public Optional<CategoryManufacturingAddressDTO> updateManufacturingAddress(String id, CategoryManufacturingAddressDTO address) {
    if (addressStore.containsKey(id)) {
      address.setId(id);
      addressStore.put(id, address);
      return Optional.of(address);
    }
    return Optional.empty();
  }

  /**
   * Deletes a manufacturing address by its ID.
   * @param id The ID of the manufacturing address to delete.
   * @return True if deleted, false otherwise.
   */
  @Override
  public boolean deleteManufacturingAddress(String id) {
    log.info("Attempting to delete Manufacturing Address with ID: {}", id);
    if (addressStore.containsKey(id)) {
      addressStore.remove(id);
      return true;
    }
    log.warn("Manufacturing Address with ID {} not found for deletion.", id);
    return false;
  }

  /**
   * Maps a list of category IDs to a specific manufacturing address.
   * Overwrites any existing mappings for that address.
   * @param addressId The ID of the manufacturing address.
   * @param categoryIds A list of category IDs to map.
   * @return An Optional containing the updated manufacturing address if found.
   */
  @Override
  public Optional<CategoryManufacturingAddressDTO> mapCategoriesToManufacturingAddress(String addressId, List<String> categoryIds) {
    log.info("Mapping categories to Manufacturing Address with ID: {}", addressId);
    return Optional.ofNullable(addressStore.get(addressId))
        .map(address -> {
          address.setMappedCategoryIds(categoryIds); // Replace existing
          return address;
        });
  }

  /**
   * Retrieves the mapped category IDs for a specific manufacturing address.
   * @param addressId The ID of the manufacturing address.
   * @return A list of category IDs mapped to the manufacturing address.
   */
  @Override
  public List<String> getMappedCategoryIds(String addressId) {
    return Optional.ofNullable(addressStore.get(addressId))
        .map(CategoryManufacturingAddressDTO::getMappedCategoryIds)
        .orElse(new ArrayList<>());
  }
}

