
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.facade;


import in.gov.gem.app.vendorassessment.dto.response.VendorDashboardDTOResponseDTO;
import in.gov.gem.app.service.dto.PaginationParams;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * The interface Vendor dashboard facade.
 */
public interface IVendorDashboardFacade {

  /**
   * Gets all vendor assessments.
   *
   * @param paginationParams the pagination params
   * @return the all vendor assessments
   */
  Page<VendorDashboardDTOResponseDTO> getAllVendorAssessments(PaginationParams paginationParams);

  /**
   * Gets vendor assessment by va number.
   *
   * @param vaNumber the va number
   * @return the vendor assessment by va number
   */
  Optional<VendorDashboardDTOResponseDTO> getVendorAssessmentByVaNumber(String vaNumber);

  /**
   * Gets categories.
   *
   * @param vaNumber the va number
   * @return the categories
   */
  List<Map<String, Object>> getCategories(String vaNumber);

  /**
   * Delete vendor assessment.
   *
   * @param vendorId the vendor id
   */
  void deleteVendorAssessment(String vendorId);
}