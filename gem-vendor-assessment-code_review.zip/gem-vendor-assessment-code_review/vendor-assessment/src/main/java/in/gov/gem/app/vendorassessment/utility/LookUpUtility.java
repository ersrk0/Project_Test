package in.gov.gem.app.vendorassessment.utility;


import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * Utility class that provides methods for retrieving lookup information from a cache service.
 * It interacts with the cache service to fetch individual lookups by their code or value,
 * and to fetch lists of lookups by name, transforming them as needed.
 */
@Component
@AllArgsConstructor
public class LookUpUtility {

    //private final ICacheService cacheService;
    private final CoreLookupService coreLookupService;


    /**
     * Retrieves a lookup by its unique lookup code.
     *
     * @param lookupCode The lookup code to search for.
     * @return The Lookup object corresponding to the provided code, or null if not found.
     */
    public CoreLookupDto getLookupByLookUpCode(String lookupCode) {

       return coreLookupService.findByLookupCode(lookupCode);
    }

    public List<CoreLookupDto> getLookupByLookUpName(String lookupName) {

        return coreLookupService.findByLookupName(lookupName);

    }

    /**
     * Retrieves a lookup by its value.
     *
     * @param lookUpValue The lookup value to search for.
     * @return The Lookup object corresponding to the provided value, or null if not found.
     */
    public CoreLookupDto getLookupByValue(String lookUpValue) {
        List<CoreLookupDto> coreLookupDtos = coreLookupService.findAllByLookupValueIgnoreCase(lookUpValue);
        if (coreLookupDtos.isEmpty()) {
            return null;
        }
        return coreLookupDtos.getFirst();
    }

}
