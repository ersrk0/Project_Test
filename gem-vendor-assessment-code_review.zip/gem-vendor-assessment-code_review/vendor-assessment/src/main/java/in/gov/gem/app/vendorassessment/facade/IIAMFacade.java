
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.request.*;
import in.gov.gem.app.vendorassessment.dto.response.*;
import org.springframework.http.ResponseEntity;

/**
 * The interface Iam facade.
 */
public interface IIAMFacade
{

  /**
   * Add mobile.
   *
   * @param acceptLanguage the accept language
   * @param contactRequest the contact request
   */
  public void addMobile(String acceptLanguage, AddMobileRequestDTO contactRequest);

  /**
   * Add email.
   *
   * @param acceptLanguage the accept language
   * @param contactRequest the contact request
   */
  public void addEmail(String acceptLanguage, AddEmailRequestDTO contactRequest);

  /**
   * Sent otp via mobile response entity.
   *
   * @param otpResp the otp resp
   * @return the response entity
   */
  public ResponseEntity<APIResponse<OtpResponseDTO>> SentOtpViaMobile(SendOtpRequestDTO otpResp);

  /**
   * Re sent otp via mobile response entity.
   *
   * @param reSendRequestDTO the re send request dto
   * @return the response entity
   */
  public ResponseEntity<APIResponse<ResendOtpResponseDTO>> ReSentOtpViaMobile(ReSendRequestDTO reSendRequestDTO);

  /**
   * Validate otp response entity.
   *
   * @param otpValidateRequestDTO the otp validate request dto
   * @return the response entity
   */
  public ResponseEntity<APIResponse<Object>> validateOtp(OTPValidateRequestDTO otpValidateRequestDTO);

  /**
   * Gets user.
   *
   * @return the user
   */
  public UserDetailResponseDTO getUser();

  /**
   * Gets ip address.
   *
   * @return the ip address
   */
  public IpAddressResponseDTO getIpAddress();

}
