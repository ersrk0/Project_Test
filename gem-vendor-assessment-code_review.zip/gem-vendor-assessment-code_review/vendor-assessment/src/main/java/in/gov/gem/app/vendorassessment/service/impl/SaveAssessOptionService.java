
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;



import in.gov.gem.app.vendorassessment.dto.request.AuthorizeDetailRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ContractManufacturerRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.LookupRequestDTO;

import in.gov.gem.app.utility.CustomLoggerFactory;
import in.gov.gem.app.vendorassessment.domain.entity.AuthorizeOemOspDetailEntity;
import in.gov.gem.app.vendorassessment.domain.entity.VAMasterEntity;
import in.gov.gem.app.vendorassessment.domain.entity.VAOrganizationAddressEntity;
import in.gov.gem.app.vendorassessment.domain.entity.VaOrganizationDetailEntity;
import in.gov.gem.app.vendorassessment.domain.repository.*;
import in.gov.gem.app.vendorassessment.dto.response.*;
import in.gov.gem.app.vendorassessment.service.ISaveAssessOptionService;
import in.gov.gem.app.vendorassessment.utility.LookUpUtility;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.security.SecureRandom;
import java.util.*;

/**
 * The type Save assess option service.
 */
@Service
@AllArgsConstructor
public class SaveAssessOptionService implements ISaveAssessOptionService {

private VendorAssessmentRepository vendorAssessmentRepository;
private VAOrganizationAddressRepository vaOrganizationAddressRepository;
private AuthorizeOemOspDetailsRepository authorizeOemOspDetailsRepository;
private VaOrganizationDetailRepository vaOrganizationDetailRepository;
private final ISellerClient iSellerClient;
private final MessageUtility messageUtility;
private final LookUpUtility lookUpUtility;


    private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(SaveAssessOptionService.class);

    @Override
    public SaveAssessResponseDTO saveOption(LookupRequestDTO lookupRequestDto, boolean skip) {
        try {
        ResponseEntity<APIResponse<OrganizationDetailsResponseDTO>> response = iSellerClient.getOrganizationDetails();
        OrganizationDetailsResponseDTO organizationDetails = Objects.requireNonNull(response.getBody()).getData();

        if (organizationDetails == null) {
            log.error("Failed to fetch gemPvtOrgId from organization details.");
            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }

        Long sellerId = organizationDetails.getGemPvtOrgId();
        log.info("Fetched gemPvtOrgId: {}", sellerId);
        lookupRequestDto.setPvtOrgMasterFk(sellerId);

            VAMasterEntity va = new VAMasterEntity();
        String lookupValue = lookupRequestDto.getLookup_value();
        va.setPvtOrgMasterFk(lookupRequestDto.getPvtOrgMasterFk());
        Boolean brandRequest = lookupRequestDto.getBrandRequest();
        String bDetail = lookupRequestDto.getBrandDetail();
        CoreLookupDto brandDetail = lookUpUtility.getLookupByValue(bDetail);
        CoreLookupDto assess = lookUpUtility.getLookupByValue(lookupValue);
        String assessCode = assess.getLookupCode();
        va.setApplyAsLookUp(assessCode);
        if (!brandRequest) {
            va.setNeedDashboard(false);
            va.setDashboardTypeLookUp(null);
        }
        else{
            String lookupCode = brandDetail.getLookupCode();
            va.setNeedDashboard(true);
            va.setDashboardTypeLookUp(lookupCode);
        }
        Boolean isContractManufacturer = lookupRequestDto.getIsContractManufacturer();
        va.setIsContractManufacturer(isContractManufacturer);
        va.setBriefCaseFk(lookupRequestDto.getBriefCaseFk());
        SecureRandom secureRandom = new SecureRandom();
        va.setVaNumber("DA-" + (System.currentTimeMillis() + secureRandom.nextInt(10000)));
        va.setVaStatusLookUp("LCVA1112");
        va.setSubStatusLookUp("LCVA1118");
            VAMasterEntity save = vendorAssessmentRepository.save(va);
        return SaveAssessResponseDTO.builder().id(save.getId()).applyAsLookUp(save.getApplyAsLookUp()).vaNumber(save.getVaNumber()).build();
        }
        catch(Exception ex){
            throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
        }
    }

    @Override
    public SaveAssessResponseDTO getOption(String vaNumber)
    {
        Optional<VAMasterEntity> byVaNumber = vendorAssessmentRepository.findByVaNumber(vaNumber);
        if (byVaNumber.isPresent()) {
            VAMasterEntity va = byVaNumber.get();
            return SaveAssessResponseDTO.builder()
              .id(va.getId())
              .applyAsLookUp(va.getApplyAsLookUp())
              .vaNumber(va.getVaNumber())
              .build();
        } else {
            throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
              messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
              ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
        }
    }

    @Override
    public IdentifyRegistrationResponseDTO identifyRegistration() {
        try {
        ResponseEntity<APIResponse<OrganizationDetailsResponseDTO>> response = iSellerClient.getOrganizationDetails();
        OrganizationDetailsResponseDTO organizationDetails = Objects.requireNonNull(response.getBody()).getData();

        if (organizationDetails == null) {
            log.error("Failed to fetch gemPvtOrgId from organization details.");
            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }

        Long sellerId = organizationDetails.getGemPvtOrgId();
        log.info("Fetched gemPvtOrgId: {}", sellerId);
        List<Optional<VAMasterEntity>> vendorAssessment = vendorAssessmentRepository.findByPvtOrgMasterFk(sellerId);
        IdentifyRegistrationResponseDTO identifyRegistrationDTO = new IdentifyRegistrationResponseDTO();
        if(!vendorAssessment.isEmpty()) {
            identifyRegistrationDTO.setAvailable(true);
            identifyRegistrationDTO.setMessage("available for registration");
            return identifyRegistrationDTO;
        }
        else {
            identifyRegistrationDTO.setAvailable(true);
            identifyRegistrationDTO.setMessage("not available for registration");
            return identifyRegistrationDTO;
        }
    }
        catch(Exception ex){
        throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
                messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
    }
    }

    @Override
    @Transactional
    public AuthorizeResponseDTO authorizeDetailSave(AuthorizeDetailRequestDTO authorizeDetailDTO) {
        try {
            VaOrganizationDetailEntity vaOrganizationDetail=new VaOrganizationDetailEntity();
        vaOrganizationDetail.setOrganizationName(authorizeDetailDTO.getOrganizationName());
        vaOrganizationDetail.setVaMasterFk(authorizeDetailDTO.getVaMgmtFk());
            vaOrganizationDetail.setAuthorizationTypeLookup("LCVA1174");
            VaOrganizationDetailEntity vaOrganizationDetail1 = vaOrganizationDetailRepository.save(vaOrganizationDetail);
        Long id = vaOrganizationDetail1.getId();
        // Save VAOrganizationAddress
            VAOrganizationAddressEntity vaOrganizationAddress=new VAOrganizationAddressEntity();
        vaOrganizationAddress.setVaOrganizationDetailFk(id);
        vaOrganizationAddress.setOfficeName(authorizeDetailDTO.getOfficeName());
        vaOrganizationAddress.setOfficeTypeLookup(authorizeDetailDTO.getOfficeTypeLookup());
        vaOrganizationAddress.setOfficeAddressLine1(authorizeDetailDTO.getOfficeAddressLine1());
        vaOrganizationAddress.setOfficeAddressLine2(authorizeDetailDTO.getOfficeAddressLine2());
        vaOrganizationAddress.setOfficeLandmark(authorizeDetailDTO.getOfficeLandmark());
        vaOrganizationAddress.setGeographyLocationCode(authorizeDetailDTO.getGeographyLocationCode());
        vaOrganizationAddress.setAssessAsLookupType(authorizeDetailDTO.getAssessAsLookupType());
            VAOrganizationAddressEntity vaOrganizationAddress1 = vaOrganizationAddressRepository.save(vaOrganizationAddress);
        //save authorizeOemOspDetail
        AuthorizeOemOspDetailEntity authorizeOemOspDetail=new AuthorizeOemOspDetailEntity();
        authorizeOemOspDetail.setVaOrganizationAddressFk(vaOrganizationAddress1.getId());
        authorizeOemOspDetail.setContactNumber(authorizeDetailDTO.getContactNumber());
        authorizeOemOspDetail.setCountryCode(authorizeDetailDTO.getCountryCode());
        authorizeOemOspDetail.setAuthorizePersonName(authorizeDetailDTO.getAuthorizePersonName());
        authorizeOemOspDetail.setEmailId(authorizeDetailDTO.getEmailId());
        authorizeOemOspDetail.setStdCode(authorizeDetailDTO.getStdCode());
        authorizeOemOspDetail.setBriefcaseFk(authorizeDetailDTO.getBriefcaseFk());
        authorizeOemOspDetail.setUniqueIdentifyNumber(authorizeDetailDTO.getUniqueIdentifyNumber());
        authorizeOemOspDetail.setVaMgmtFk(authorizeDetailDTO.getVaMgmtFk());
        AuthorizeOemOspDetailEntity savedAuthorizeOemOspDetail = authorizeOemOspDetailsRepository.save(authorizeOemOspDetail);
        //response
        AuthorizeResponseDTO authorizeResponseDTO = new AuthorizeResponseDTO();
        authorizeResponseDTO.setId(savedAuthorizeOemOspDetail.getId());
        authorizeResponseDTO.setOfficeName(vaOrganizationAddress1.getOfficeName());
        authorizeResponseDTO.setOfficeTypeLookup(vaOrganizationAddress1.getOfficeTypeLookup());
        authorizeResponseDTO.setOfficeLandmark(vaOrganizationAddress1.getOfficeLandmark());
        authorizeResponseDTO.setOfficeAddressLine1(vaOrganizationAddress1.getOfficeAddressLine1());
        authorizeResponseDTO.setOfficeAddressLine2(vaOrganizationAddress1.getOfficeAddressLine2());
        authorizeResponseDTO.setAssessAsLookupType(vaOrganizationAddress1.getAssessAsLookupType());
        authorizeResponseDTO.setUniqueIdentifyNumber(savedAuthorizeOemOspDetail.getUniqueIdentifyNumber());
        return authorizeResponseDTO; }
        catch(Exception ex){
            throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
        }

    }

    @Override
    @Transactional
    public ContractManufacturerResponseDTO contractManufacturerDetailSave(ContractManufacturerRequestDTO contractManufacturerDTO) {
        try {
            VaOrganizationDetailEntity vaOrganizationDetail=new VaOrganizationDetailEntity();
        vaOrganizationDetail.setOrganizationName(contractManufacturerDTO.getOrganizationName());
        vaOrganizationDetail.setVaMasterFk(contractManufacturerDTO.getVaMgmtFk());
        vaOrganizationDetail.setAuthorizationTypeLookup("LCVA1173");
            VaOrganizationDetailEntity vaOrganizationDetail1 = vaOrganizationDetailRepository.save(vaOrganizationDetail);
        Long id = vaOrganizationDetail1.getId();
        // Save VAOrganizationAddress
            VAOrganizationAddressEntity vaOrganizationAddress=new VAOrganizationAddressEntity();
        vaOrganizationAddress.setVaOrganizationDetailFk(id);
        vaOrganizationAddress.setOfficeName(contractManufacturerDTO.getOfficeName());
        vaOrganizationAddress.setOfficeTypeLookup(contractManufacturerDTO.getOfficeTypeLookup());
        vaOrganizationAddress.setOfficeAddressLine1(contractManufacturerDTO.getOfficeAddressLine1());
        vaOrganizationAddress.setOfficeAddressLine2(contractManufacturerDTO.getOfficeAddressLine2());
        vaOrganizationAddress.setOfficeLandmark(contractManufacturerDTO.getOfficeLandmark());
        vaOrganizationAddress.setGeographyLocationCode(contractManufacturerDTO.getGeographyLocationCode());
        vaOrganizationAddress.setAssessAsLookupType(contractManufacturerDTO.getAssessAsLookupType());
        vaOrganizationAddress.setGstinNumber(contractManufacturerDTO.getGstinNumber());
            VAOrganizationAddressEntity vaOrganizationAddress1 = vaOrganizationAddressRepository.save(vaOrganizationAddress);
        //save authorizeOemOspDetail
        AuthorizeOemOspDetailEntity authorizeOemOspDetail=new AuthorizeOemOspDetailEntity();
        authorizeOemOspDetail.setVaOrganizationAddressFk(vaOrganizationAddress1.getId());
        authorizeOemOspDetail.setContactNumber(contractManufacturerDTO.getContactNumber());
        authorizeOemOspDetail.setCountryCode(contractManufacturerDTO.getCountryCode());
        authorizeOemOspDetail.setAuthorizePersonName(contractManufacturerDTO.getAuthorizePersonName());
        authorizeOemOspDetail.setEmailId(contractManufacturerDTO.getEmailId());
        authorizeOemOspDetail.setStdCode(contractManufacturerDTO.getStdCode());
        authorizeOemOspDetail.setBriefcaseFk(contractManufacturerDTO.getBriefcaseFk());
        authorizeOemOspDetail.setVaMgmtFk(contractManufacturerDTO.getVaMgmtFk());
        AuthorizeOemOspDetailEntity savedAuthorizeOemOspDetail = authorizeOemOspDetailsRepository.save(authorizeOemOspDetail);
        //response
        ContractManufacturerResponseDTO  contractManufactureresponseDTO = new ContractManufacturerResponseDTO ();
        contractManufactureresponseDTO.setId(savedAuthorizeOemOspDetail.getId());
        contractManufactureresponseDTO.setOfficeName(vaOrganizationAddress1.getOfficeName());
        contractManufactureresponseDTO.setOfficeTypeLookup(vaOrganizationAddress1.getOfficeTypeLookup());
        contractManufactureresponseDTO.setOfficeLandmark(vaOrganizationAddress1.getOfficeLandmark());
        contractManufactureresponseDTO.setOfficeAddressLine1(vaOrganizationAddress1.getOfficeAddressLine1());
        contractManufactureresponseDTO.setOfficeAddressLine2(vaOrganizationAddress1.getOfficeAddressLine2());
        contractManufactureresponseDTO.setAssessAsLookupType(vaOrganizationAddress1.getAssessAsLookupType());
        contractManufactureresponseDTO.setGstinNumber(vaOrganizationAddress1.getGstinNumber());
        return contractManufactureresponseDTO;
    }
        catch(Exception ex){
        throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
                messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
    }
    }

    @Override
    @Transactional
    public ContractManufacturerRequestDTO getContractManufacturerDetail(long id) {
        try {
            ContractManufacturerRequestDTO contractManufacturerDTO = new ContractManufacturerRequestDTO();
            VaOrganizationDetailEntity vaOrganizationDetailEntity = vaOrganizationDetailRepository.findByVaMasterFkAndAuthorizationTypeLookup(id, "LCVA1173");
            contractManufacturerDTO.setOrganizationName(vaOrganizationDetailEntity.getOrganizationName());
            contractManufacturerDTO.setVaMgmtFk(vaOrganizationDetailEntity.getVaMasterFk());
            Long vaOrganizationDetailFk = vaOrganizationDetailEntity.getId();
            VAOrganizationAddressEntity vaOrganizationAddress = vaOrganizationAddressRepository.findByVaOrganizationDetailFk(vaOrganizationDetailFk);
            contractManufacturerDTO.setOfficeName(vaOrganizationAddress.getOfficeName());
            contractManufacturerDTO.setOfficeTypeLookup(vaOrganizationAddress.getOfficeTypeLookup());
            contractManufacturerDTO.setOfficeAddressLine1(vaOrganizationAddress.getOfficeAddressLine1());
            contractManufacturerDTO.setOfficeAddressLine2(vaOrganizationAddress.getOfficeAddressLine2());
            contractManufacturerDTO.setOfficeLandmark(vaOrganizationAddress.getOfficeLandmark());
            contractManufacturerDTO.setGeographyLocationCode(vaOrganizationAddress.getGeographyLocationCode());
            contractManufacturerDTO.setAssessAsLookupType(vaOrganizationAddress.getAssessAsLookupType());
            contractManufacturerDTO.setGstinNumber(vaOrganizationAddress.getGstinNumber());
            Long id1 = vaOrganizationAddress.getId();
            AuthorizeOemOspDetailEntity authorizeOemOspDetail = authorizeOemOspDetailsRepository.findByVaOrganizationAddressFk(id1);
            contractManufacturerDTO.setContactNumber(authorizeOemOspDetail.getContactNumber());
            contractManufacturerDTO.setCountryCode(authorizeOemOspDetail.getCountryCode());
            contractManufacturerDTO.setAuthorizePersonName(authorizeOemOspDetail.getAuthorizePersonName());
            contractManufacturerDTO.setEmailId(authorizeOemOspDetail.getEmailId());
            contractManufacturerDTO.setStdCode(authorizeOemOspDetail.getStdCode());
            contractManufacturerDTO.setBriefcaseFk(authorizeOemOspDetail.getBriefcaseFk());
            return contractManufacturerDTO;
        }
        catch(Exception ex){
            throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
        }
    }


    @Override
    @Transactional
    public AuthorizeDetailRequestDTO getAuthorizeDetailSave(long id) {
        try{
        AuthorizeDetailRequestDTO authorizeDetailDTO = new AuthorizeDetailRequestDTO();
        VaOrganizationDetailEntity vaOrganizationDetailEntity = vaOrganizationDetailRepository.findByVaMasterFkAndAuthorizationTypeLookup(id, "LCVA1174");
        authorizeDetailDTO.setOrganizationName(vaOrganizationDetailEntity.getOrganizationName());
        authorizeDetailDTO.setVaMgmtFk(vaOrganizationDetailEntity.getVaMasterFk());
        Long vaOrganizationDetailFk = vaOrganizationDetailEntity.getId();
        VAOrganizationAddressEntity vaOrganizationAddress = vaOrganizationAddressRepository.findByVaOrganizationDetailFk(vaOrganizationDetailFk);
        authorizeDetailDTO.setOfficeName(vaOrganizationAddress.getOfficeName());
        authorizeDetailDTO.setOfficeTypeLookup(vaOrganizationAddress.getOfficeTypeLookup());
        authorizeDetailDTO.setOfficeAddressLine1(vaOrganizationAddress.getOfficeAddressLine1());
        authorizeDetailDTO.setOfficeAddressLine2(vaOrganizationAddress.getOfficeAddressLine2());
        authorizeDetailDTO.setOfficeLandmark(vaOrganizationAddress.getOfficeLandmark());
        authorizeDetailDTO.setGeographyLocationCode(vaOrganizationAddress.getGeographyLocationCode());
        authorizeDetailDTO.setAssessAsLookupType(vaOrganizationAddress.getAssessAsLookupType());
            Long id1 = vaOrganizationAddress.getId();
        AuthorizeOemOspDetailEntity authorizeOemOspDetail = authorizeOemOspDetailsRepository.findByVaOrganizationAddressFk(id1);
        authorizeDetailDTO.setContactNumber(authorizeOemOspDetail.getContactNumber());
        authorizeDetailDTO.setUniqueIdentifyNumber(authorizeOemOspDetail.getUniqueIdentifyNumber());
        authorizeDetailDTO.setCountryCode(authorizeOemOspDetail.getCountryCode());
        authorizeDetailDTO.setAuthorizePersonName(authorizeOemOspDetail.getAuthorizePersonName());
        authorizeDetailDTO.setEmailId(authorizeOemOspDetail.getEmailId());
        authorizeDetailDTO.setStdCode(authorizeOemOspDetail.getStdCode());
        authorizeDetailDTO.setBriefcaseFk(authorizeOemOspDetail.getBriefcaseFk());
        return authorizeDetailDTO;
    }
        catch(Exception ex){
            throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
        }
    }

    public AssessResponseDTO getAssess(long id) {
        try {
            AssessResponseDTO assessResponseDTO = new AssessResponseDTO();
            Optional<VAMasterEntity> byId = vendorAssessmentRepository.findById(id);
            VAMasterEntity vaMasterEntity=byId.get();
            assessResponseDTO.setId(vaMasterEntity.getId());
            assessResponseDTO.setApplyAsLookUp(vaMasterEntity.getApplyAsLookUp());
            assessResponseDTO.setVaNumber(vaMasterEntity.getVaNumber());
            assessResponseDTO.setBrandRequest(vaMasterEntity.getNeedDashboard());
            assessResponseDTO.setBrandDetail(vaMasterEntity.getDashboardTypeLookUp());
            assessResponseDTO.setIsContractManufacturer(vaMasterEntity.getIsContractManufacturer());
            return assessResponseDTO;
        }
        catch(Exception ex){
            throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
        }
    }


}
