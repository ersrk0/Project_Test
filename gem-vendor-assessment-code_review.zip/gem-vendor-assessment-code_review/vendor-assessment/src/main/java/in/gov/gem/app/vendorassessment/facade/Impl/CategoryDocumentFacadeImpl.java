
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;



import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.utility.MessageUtility;

import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.domain.entity.Question;
import in.gov.gem.app.vendorassessment.dto.request.CatDocumentUploadRequestDto;
import in.gov.gem.app.vendorassessment.dto.request.CategoryDocumentDto;
import in.gov.gem.app.vendorassessment.dto.response.CategoryDocumentResponse;
import in.gov.gem.app.vendorassessment.facade.ICategoryDocumentFacade;
import in.gov.gem.app.vendorassessment.service.ICategoryDocumentsService;
import in.gov.gem.app.vendorassessment.service.IQuestionnaireService;
import in.gov.gem.app.vendorassessment.utility.MapperUtil;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Component
@AllArgsConstructor
public class CategoryDocumentFacadeImpl implements ICategoryDocumentFacade {

    private final ICategoryDocumentsService documentService;
    private final IQuestionnaireService questionnaireService;
    private final MessageUtility messageUtility;


    @Override
    public CategoryDocumentResponse getDocumentsForQuestion(Long categoryId, Long questionId) {
        Question question =questionnaireService.getQuestionById(questionId)
                .orElseThrow(() -> new ServiceException(
                MessageConstant.UNEXPECTED_ERROR,
                messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                ErrorConstant.CATEGORY.BV,
                ErrorConstant.SEVERITY.I
        ));
        // Should be caught by service layer too
        List<CategoryDocumentDto> documentDtos=documentService.getDocumentsForQuestion(questionId).stream()
                .map(MapperUtil::toDocumentDto)
                .collect(Collectors.toList());
        CategoryDocumentResponse documentResponse = new CategoryDocumentResponse();
        documentResponse.setDocuments(documentDtos);
        documentResponse.setHeading(question.getQuestionText());
        documentResponse.setInfoText(question.getAssociatedInfoMessage());
        documentResponse.setSubHeading(question.getSubHeading());
        documentResponse.setValidityRequired(question.isRequired());

        return documentResponse;
    }

    @Override
    public CategoryDocumentDto uploadDocument(Long categoryId, Long questionId, CatDocumentUploadRequestDto requestDto) throws IOException {
        MultipartFile file = requestDto.getFile();
        String documentType = requestDto.getDocumentType();
        // Validation for file and question existence is handled by service layer
        return MapperUtil.toDocumentDto(
                documentService.uploadDocument(questionId, file, documentType, requestDto.getValidUpto())
        );
    }

    @Override
    public void deleteDocument(Long categoryId, Long questionId, Long documentId) throws IOException {
        // Optional: Add more checks here if needed, like ensuring document belongs to question/category
        documentService.deleteDocument(documentId);
    }

    @Override
    public byte[] downloadDocument(Long categoryId, Long questionId, Long documentId) throws IOException {
        return documentService.downloadDocument(documentId);
    }
}
