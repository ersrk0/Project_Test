
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */
package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.controller.ICategoryController;
import in.gov.gem.app.vendorassessment.domain.entity.Category;
import in.gov.gem.app.vendorassessment.dto.enums.CategoryType;
import in.gov.gem.app.vendorassessment.dto.request.CategoryRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.CategoryNewResponseDTO;
import in.gov.gem.app.vendorassessment.facade.ICategoryFacade;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@Slf4j
@AllArgsConstructor
public class CategoryControllerController implements ICategoryController {

    private final ICategoryFacade categoryFacade;


  /**
   * Creates a new category.
   *
   * @param requestDTO The CategoryRequestDTO from the request body.
   * @return ResponseEntity with the created CategoryResponseDTO and HTTP status 201 (Created).
   */
  @Override
  public ResponseEntity<APIResponse<Object>> createCategory(String type, CategoryRequestDTO requestDTO) {
    CategoryType categoryType =CategoryType.fromString(type);
    if (categoryType == null) {
      return ResponseEntity.badRequest().body(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.BAD_REQUEST.getReasonPhrase())
              .httpStatus(HttpStatus.BAD_REQUEST.value())
              .message("Invalid category type provided: " + type)
              .build());
    }
    CategoryNewResponseDTO responseDTO = categoryFacade.createCategory(requestDTO);
    return ResponseEntity.ok().body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.FETCH_MESSAGE)
            .data(responseDTO)
            .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> checkCategorySimilarity(List<CategoryRequestDTO> request) {
    Map<String, Object> similarCategories = categoryFacade.checkAndPrepareAddCategory(request);
      return ResponseEntity.ok(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.OK.getReasonPhrase())
              .httpStatus(HttpStatus.OK.value())
              .message(ApplicationConstant.FETCH_MESSAGE)
              .data(similarCategories)
              .build());


  }

  /**
   * Endpoint to bulk add new categories.
   * This functionality is typically restricted to higher-level users (e.g., Level 5).
   * In a real application, this would require robust authentication and authorization checks.
   *
   * @param request The request body containing a list of categories to add.
   * @return ResponseEntity with ApiResponse containing the IDs of the newly added categories.
   */
  @Override
  public ResponseEntity<APIResponse<Object>> bulkAddCategories(List<CategoryRequestDTO> request,
                                                               String vaId) {

    categoryFacade.bulkAddCategories(request, vaId);
    return ResponseEntity.ok().body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.CATEGORY_ADD_SUCCESS)
            .build());
  }






  /**
   * Retrieves the full hierarchical tree of categories.
   *
   * @return ResponseEntity with a list of top-level CategoryResponseDTOs (with children populated)
   * and HTTP status 200 (OK).
   */
  @Override
  public ResponseEntity<APIResponse<Object>> getCategoryTree(Optional<String> type, String vaId) {
    if (type.isEmpty()) {
      return ResponseEntity.badRequest().body(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.BAD_REQUEST.getReasonPhrase())
              .httpStatus(HttpStatus.BAD_REQUEST.value())
              .message("Invalid category type provided: " + type)
              .build());
    }
    List<CategoryNewResponseDTO> responseDTOs = categoryFacade.getCategoryTree(type, vaId);
    return ResponseEntity.ok().body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.FETCH_MESSAGE)
            .data(responseDTOs)
            .build());
  }






  /**
   * API endpoint for searching eligible categories with multiple criteria.
   * Accessible via GET /api/categories/filtered-search
   */
  @Override
  public ResponseEntity<APIResponse<Object>> searchEligibleCategories(
          String type,
          String query,
          Long parentId,
          Boolean exactMatch) {
    CategoryType categoryType =CategoryType.fromString(type);
    if (categoryType == null) {
      return ResponseEntity.badRequest().body(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.BAD_REQUEST.getReasonPhrase())
              .httpStatus(HttpStatus.BAD_REQUEST.value())
              .message("Invalid category type provided: " + type)
              .build());
    }

    List<Category> categories = categoryFacade.searchEligibleCategoriesByCriteria(type,query, parentId, exactMatch);
    return ResponseEntity.ok(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.CATEGORIES_FETCH_SUCCESS)
            .data(categories)
            .build());
  }

  /**
   * Get all categories currently marked as "saved".
   * Accessible via GET /api/saved-categories
   */
  @Override
  public ResponseEntity<APIResponse<Object>> getSavedCategories(String vaId) {
    List<Category> savedCategories = categoryFacade.getSavedCategories(vaId);
    if (savedCategories == null || savedCategories.isEmpty()) {
      return ResponseEntity.status(HttpStatus.NO_CONTENT).body(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.NO_CONTENT.getReasonPhrase())
              .httpStatus(HttpStatus.NO_CONTENT.value())
              .message("No saved categories found.")
              .data(null)
              .build());
    }
    else {
      return ResponseEntity.ok().body(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.OK.getReasonPhrase())
              .httpStatus(HttpStatus.OK.value())
              .message(ApplicationConstant.CATEGORIES_FETCH_SUCCESS)
              .data(savedCategories)
              .build());
    }

  }

  /**
   * Adds a category to the "saved" list.
   * Accessible via POST /api/saved-categories/{id}
   * @param id The ID of the category from the general pool to save.
   */
  @Override
  public ResponseEntity<APIResponse<Object>> addCategoryToSaved(Long id, String type, String vaId) {
    boolean added = categoryFacade.addCategoryToSaved(id, type, vaId);
    if (added) {
      return ResponseEntity.ok().body(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.CREATED.getReasonPhrase())
              .httpStatus(HttpStatus.CREATED.value())
              .message("Category added to saved successfully.")
              .data(null)
              .build());
    } else {
      return ResponseEntity.status(HttpStatus.CONFLICT).body(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.CONFLICT.getReasonPhrase())
              .httpStatus(HttpStatus.CONFLICT.value())
              .message("Category already exists in saved list or does not exist.")
              .data(null)
              .build());
    }
  }

  /**
   * Removes a category from the "saved" list.
   * Accessible via DELETE /api/saved-categories/{id}
   * @param id The ID of the category to remove from saved.
   */
  @Override
  public ResponseEntity<APIResponse<Object>> removeCategoryFromSaved(Long id, String type, String vaId) {
    boolean removed = categoryFacade.removeCategoryFromSaved(id, type, vaId);
    if (removed) {
      return ResponseEntity.ok().body(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.NO_CONTENT.getReasonPhrase())
              .httpStatus(HttpStatus.NO_CONTENT.value())
              .message("Category removed from saved successfully.")
              .data(null)
              .build());
    } else {
      return ResponseEntity.status(HttpStatus.NOT_FOUND).body(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.NOT_FOUND.getReasonPhrase())
              .httpStatus(HttpStatus.NOT_FOUND.value())
              .message("Category not found in saved list.")
              .data(null)
              .build());
    }
  }

  /**
   * Searches within the "saved" categories.
   * Accessible via GET /api/saved-categories/search?query=your_search_term
   * @param query The search string.
   * @return A list of saved categories matching the query.
   */
  @Override
  public ResponseEntity<APIResponse<Object>> searchSavedCategories(String query, String type, String vaId) {
    List<Category> savedCategories = categoryFacade.searchSavedCategories(query,type, vaId);
    return ResponseEntity.ok().body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.CATEGORIES_FETCH_SUCCESS)
            .data(savedCategories)
            .build());


  }
}
