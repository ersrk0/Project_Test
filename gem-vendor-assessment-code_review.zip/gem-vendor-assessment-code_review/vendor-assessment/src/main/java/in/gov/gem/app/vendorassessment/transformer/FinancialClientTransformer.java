
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.transformer;


import in.gov.gem.app.vendorassessment.dto.response.PvtOrgItrVOResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.TurnoverResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.TurnoverSellerResponseDTO;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.client.ISellerClient;

import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.utility.CustomLoggerFactory;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * The type Financial client transformer.
 */
@Component
@AllArgsConstructor
public class FinancialClientTransformer
{
  private final ISellerClient iSellerClient;

  private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(FinancialClientTransformer.class);


  /**
   * Gets financial details from seller.
   *
   * @param paginationParams the pagination params
   * @return the financial details from seller
   */
  public List<TurnoverSellerResponseDTO> getFinancialDetailsFromSeller(PaginationParams paginationParams)
  {

    ResponseEntity<PageableApiResponse<List<PvtOrgItrVOResponseDTO>>> response =
      iSellerClient.getFinancialItrAddress(paginationParams);



    List<PvtOrgItrVOResponseDTO> itrDetails = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(PageableApiResponse::getData) // Corrected mapping
      .orElse(Collections.emptyList());

    if (itrDetails.isEmpty()) {
      log.info("No Financial details found for the given parameters.");
      return Collections.emptyList(); // Return an empty list instead of a single empty DTO
    }

    return itrDetails.stream().map(itr -> TurnoverSellerResponseDTO.builder()
        .id(itr.getId())
      .itrType(itr.getItrType())
      .profitLoss(itr.getProfit())
      .assessmentYear(itr.getAssessmentYear())
      .ackNo(itr.getAckNo())
        .status(itr.getStatus())
        .sales(itr.getSales())
        .build())
      .collect(Collectors.toList());
  }


  /**
   * Gets turn over from seller.
   *
   * @return the turn over from seller
   */
  public TurnoverResponseDTO getTurnOverFromSeller()
  {
    ResponseEntity<APIResponse<TurnoverResponseDTO>> response = iSellerClient.getTurnOver();

    Optional<TurnoverResponseDTO> turnover = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(APIResponse::getData);

    if (turnover.isEmpty()) {
      log.info("No Turnover Details found for the given parameters.");
      return new TurnoverResponseDTO(); // Handle the empty case appropriately
    }
    TurnoverResponseDTO data = turnover.get();

    return TurnoverResponseDTO.builder()
      .turnover(data.getTurnover())
      .build();
  }

}
