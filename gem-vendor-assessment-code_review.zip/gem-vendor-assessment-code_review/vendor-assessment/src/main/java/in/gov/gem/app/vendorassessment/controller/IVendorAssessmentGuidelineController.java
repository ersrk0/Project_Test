
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;
import in.gov.gem.app.service.dto.APIResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Provides APIs for fetching vendor assessment guidelines.
 * This interface defines the contract for guideline-related operations,
 */
@Tag(name = "Vendor Assessment Guidelines", description = "APIs for fetching vendor assessment guidelines")
@RequestMapping("/v1/guidelines")
@RestController
public interface IVendorAssessmentGuidelineController {
  /**
   * Fetches guidelines based on the provided lookup name.
   *
   * @param lookupName the lookup name for guidelines
   * @return the API response with guidelines
   */
  @Operation(
    summary = "Fetch Guidelines",
    description = "Fetches guidelines based on the provided lookup name.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "lookupName", description = "Lookup name for guidelines", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Guidelines not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  ResponseEntity<APIResponse<Object>> fetchGuidelines(@RequestParam String lookupName);
}
 