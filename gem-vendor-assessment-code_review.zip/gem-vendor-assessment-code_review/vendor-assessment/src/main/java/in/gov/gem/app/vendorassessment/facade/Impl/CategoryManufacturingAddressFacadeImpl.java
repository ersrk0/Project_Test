
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.vendorassessment.dto.request.CategoryManufacturingAddressDTO;
import in.gov.gem.app.vendorassessment.dto.request.CategoryManufacturingAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.CategoryNewResponseDTO;
import in.gov.gem.app.vendorassessment.dto.request.ManufacturingAddressCategoryMappingDTO;
import in.gov.gem.app.vendorassessment.dto.response.CategoryManufacturingAddressResponseDTO;
import in.gov.gem.app.vendorassessment.facade.ICategoryFacade;
import in.gov.gem.app.vendorassessment.facade.ICategoryManufacturingAddressFacade;
import in.gov.gem.app.vendorassessment.service.ICategoryManufacturingAddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Implementation of the ManufacturingAddressFacade interface.
 * Handles DTO conversions and delegates to the ManufacturingAddressService and CategoryFacade.
 */
@Service
public class CategoryManufacturingAddressFacadeImpl implements ICategoryManufacturingAddressFacade {

  private final ICategoryManufacturingAddressService manufacturingAddressService;
  private final ICategoryFacade categoryFacade; // To get Category details for responses

  @Autowired
  public CategoryManufacturingAddressFacadeImpl(ICategoryManufacturingAddressService manufacturingAddressService, ICategoryFacade categoryFacade) {
    this.manufacturingAddressService = manufacturingAddressService;
    this.categoryFacade = categoryFacade;
  }

  /**
   * Creates a new manufacturing address.
   * @param requestDTO The DTO containing manufacturing address details.
   * @return The response DTO for the created manufacturing address.
   */
  @Override
  public CategoryManufacturingAddressResponseDTO createManufacturingAddress(CategoryManufacturingAddressRequestDTO requestDTO) {
    CategoryManufacturingAddressDTO address = convertToManufacturingAddress(requestDTO);
    CategoryManufacturingAddressDTO createdAddress = manufacturingAddressService.createManufacturingAddress(address);
    return convertToResponseDTO(createdAddress, "Created");
  }

  /**
   * Retrieves a manufacturing address by ID.
   * @param id The ID of the manufacturing address.
   * @return The response DTO for the manufacturing address, or null if not found.
   */
  @Override
  public CategoryManufacturingAddressResponseDTO getManufacturingAddressById(String id) {
    Optional<CategoryManufacturingAddressDTO> addressOptional = manufacturingAddressService.getManufacturingAddressById(id);
    return addressOptional.map(this::convertToResponseDTO).orElse(null);
  }

  /**
   * Retrieves all manufacturing address entries.
   * @return A list of response DTOs for all manufacturing addresses.
   */
  @Override
  public List<CategoryManufacturingAddressResponseDTO> getAllManufacturingAddresses() {
    List<CategoryManufacturingAddressDTO> addresses = manufacturingAddressService.getAllManufacturingAddresses();
    return addresses.stream()
        .map(this::convertToResponseDTO)
        .collect(Collectors.toList());
  }

  /**
   * Updates an existing manufacturing address.
   * @param id The ID of the manufacturing address to update.
   * @param requestDTO The DTO with updated details.
   * @return The response DTO for the updated manufacturing address, or null if not found.
   */
  @Override
  public CategoryManufacturingAddressResponseDTO updateManufacturingAddress(String id, CategoryManufacturingAddressRequestDTO requestDTO) {
    CategoryManufacturingAddressDTO address = convertToManufacturingAddress(requestDTO);
    Optional<CategoryManufacturingAddressDTO> updatedAddressOptional = manufacturingAddressService.updateManufacturingAddress(id, address);
    return updatedAddressOptional.map(updatedAddr -> convertToResponseDTO(updatedAddr, "Updated")).orElse(null);
  }

  /**
   * Deletes a manufacturing address by ID.
   * @param id The ID of the manufacturing address to delete.
   * @return A response DTO indicating the deletion status.
   */
  @Override
  public CategoryManufacturingAddressResponseDTO deleteManufacturingAddress(String id) {
    boolean deleted = manufacturingAddressService.deleteManufacturingAddress(id);
    if (deleted) {
      return new CategoryManufacturingAddressResponseDTO(id,null,null,null, null, "Deleted");
    }
    return new CategoryManufacturingAddressResponseDTO(id, null, null, null, null, "Not Found or Failed to Delete");
  }

  /**
   * Maps categories to a specific manufacturing address.
   * @param addressId The ID of the manufacturing address.
   * @param mappingDTO The DTO containing the list of category IDs to map.
   * @return The response DTO for the updated manufacturing address with mapped categories, or null if not found.
   */
  @Override
  public CategoryManufacturingAddressResponseDTO mapCategoriesToManufacturingAddress(String addressId, ManufacturingAddressCategoryMappingDTO mappingDTO) {
    Optional<CategoryManufacturingAddressDTO> updatedAddressOptional = manufacturingAddressService.mapCategoriesToManufacturingAddress(addressId, mappingDTO.getCategoryIds());
    return updatedAddressOptional.map(updatedAddr -> getManufacturingAddressWithMappedCategories(updatedAddr.getId())).orElse(null);
  }

  /**
   * Retrieves the manufacturing address along with its mapped categories.
   * @param addressId The ID of the manufacturing address.
   * @return The ManufacturingAddressResponseDTO including the mapped category details.
   */
  @Override
  public CategoryManufacturingAddressResponseDTO getManufacturingAddressWithMappedCategories(String addressId) {
    Optional<CategoryManufacturingAddressDTO> addressOptional = manufacturingAddressService.getManufacturingAddressById(addressId);

    return addressOptional.map(addr -> {
      CategoryManufacturingAddressResponseDTO responseDTO = convertToResponseDTO(addr, "Retrieved with Mapped Categories");
      List<String> mappedCategoryIds = addr.getMappedCategoryIds();

      // Fetch full CategoryResponseDTOs for the mapped IDs using CategoryFacade
      List<CategoryNewResponseDTO> mappedCategories = mappedCategoryIds.stream()
          .map(categoryFacade::getCategoryById) // Use categoryFacade to get category DTOs
          .filter(java.util.Objects::nonNull) // Filter out any categories that might not exist
          .collect(Collectors.toList());

      responseDTO.setMappedCategories(mappedCategories);
      return responseDTO;
    }).orElse(null);
  }

  /**
   * Helper method to convert ManufacturingAddressRequestDTO to ManufacturingAddress domain object.
   */
  private CategoryManufacturingAddressDTO convertToManufacturingAddress(CategoryManufacturingAddressRequestDTO requestDTO) {
    return new CategoryManufacturingAddressDTO(
        requestDTO.getOfficeName(),
            requestDTO.getOfficeAddress(),
            requestDTO.getOfficeType(),
        requestDTO.getEmail(),
            requestDTO.getGstIn(),
            requestDTO.getMobile()

    );
  }

  /**
   * Helper method to convert ManufacturingAddress domain object to ManufacturingAddressResponseDTO.
   * This basic conversion does NOT populate mappedCategories. Use getManufacturingAddressWithMappedCategories
   * for full details.
   */
  private CategoryManufacturingAddressResponseDTO convertToResponseDTO(CategoryManufacturingAddressDTO address) {
    return convertToResponseDTO(address, "Retrieved");
  }

  private CategoryManufacturingAddressResponseDTO convertToResponseDTO(CategoryManufacturingAddressDTO address, String status) {
    return new CategoryManufacturingAddressResponseDTO(
        address.getId(),
        address.getOfficeName(),
        address.getOfficeAddress(),
        address.getOfficeType(),
        address.getEmail(),
        address.getGstIn(),
        address.getMobile(),
        address.getMappedCategoryIds().stream()
                    .map(categoryFacade::getCategoryById)
                    .filter(java.util.Objects::nonNull)
                    .collect(Collectors.toList())

    );
  }
}
