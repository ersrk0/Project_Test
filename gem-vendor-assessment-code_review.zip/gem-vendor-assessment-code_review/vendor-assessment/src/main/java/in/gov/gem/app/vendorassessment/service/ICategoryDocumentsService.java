
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service;


import in.gov.gem.app.vendorassessment.domain.entity.Document;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface ICategoryDocumentsService {
    List<Document> getDocumentsForQuestion(Long questionId);
    Document uploadDocument(Long questionId, MultipartFile file, String documentType, Instant validUpto) throws IOException;
    void deleteDocument(Long documentId) throws IOException; // Added IOException
    Optional<Document> getDocumentById(Long documentId);
    byte[] downloadDocument(Long documentId) throws IOException;
}


