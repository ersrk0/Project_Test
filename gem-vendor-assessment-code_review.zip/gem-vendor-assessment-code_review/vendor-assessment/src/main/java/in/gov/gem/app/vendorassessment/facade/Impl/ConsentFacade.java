
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.vendorassessment.facade.IConsentFacade;
import in.gov.gem.app.vendorassessment.transformer.ConsentTransformer;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;


/**
 * The type Consent facade.
 */
@Component
@AllArgsConstructor
public class ConsentFacade implements IConsentFacade
{

  private final ConsentTransformer consentTransformer;


  public boolean getConsentData(String acceptLanguage, String module, String functionality)
  {

    return consentTransformer.getConsentData(acceptLanguage, module, functionality);
  }

  public Object getViewData(String consentCode, String acceptLanguage)
  {
   return consentTransformer.getViewData(consentCode, acceptLanguage);
  }
}
