
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.utility;

import java.util.*;
import java.util.stream.Collectors;

/**
 * The type Category utils.
 */
public class CategoryUtils {

  /**
   * Gets all categories for va.
   *
   * @param vaNumber the va number
   * @return the all categories for va
   */
  public static List<Map<String, Object>> getAllCategoriesForVA(String vaNumber) {
        List<Map<String, Object>> categories = new ArrayList<>();

        if (vaNumber.equals("VA-1744780807817")) {
            categories.add(createCategory(1L, "Electronics", null, 1, "Electronic devices and gadgets"));
            categories.add(createCategory(2L, "Mobile Phones", 1L, 2, "Smartphones and cellular devices"));
            categories.add(createCategory(3L, "Laptops", 1L, 2, "Portable computing devices"));
            categories.add(createCategory(4L, "Furniture", null, 1, "Home and office furniture items"));
            categories.add(createCategory(5L, "Chairs", 4L, 2, "Seating furniture for various purposes"));
            categories.add(createCategory(6L, "Tables", 4L, 2, "Dining, office and utility tables"));
        } else if (vaNumber.equals("VA-1744780807818")) {
            categories.add(createCategory(7L, "Clothing", null, 1, "Apparel and garments for all ages"));
            categories.add(createCategory(8L, "Men", 7L, 2, "Men's clothing and accessories"));
            categories.add(createCategory(9L, "Women", 7L, 2, "Women's clothing and accessories"));
            categories.add(createCategory(10L, "Footwear", null, 1, "Shoes and sandals for all occasions"));
            categories.add(createCategory(11L, "Sports Shoes", 10L, 2, "Athletic and running shoes"));
            categories.add(createCategory(12L, "Formal Shoes", 10L, 2, "Business and dress shoes"));
        }

        return categories;
    }

  /**
   * Create category map.
   *
   * @param id          the id
   * @param name        the name
   * @param parentId    the parent id
   * @param level       the level
   * @param description the description
   * @return the map
   */
  public static Map<String, Object> createCategory(Long id, String name, Long parentId, int level, String description) {
        Map<String, Object> category = new HashMap<>();
        category.put("id", id);
        category.put("name", name);
        category.put("parentId", parentId);
        category.put("level", level);
        category.put("description", description);
        category.put("children", new ArrayList<>());
        return category;
    }

  /**
   * Build category tree list.
   *
   * @param allCategories the all categories
   * @return the list
   */
  public static List<Map<String, Object>> buildCategoryTree(List<Map<String, Object>> allCategories) {
        // Clear existing children
        allCategories.forEach(category -> {
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> children = (List<Map<String, Object>>) category.get("children");
            children.clear();
        });

        // Create a map for quick lookup
        Map<Long, Map<String, Object>> categoryMap = allCategories.stream()
                .collect(Collectors.toMap(
                        category -> (Long) category.get("id"),
                        category -> category));

        List<Map<String, Object>> topLevelCategories = new ArrayList<>();

        for (Map<String, Object> category : allCategories) {
            Long parentId = (Long) category.get("parentId");

            if (parentId == null || parentId == 0) {
                topLevelCategories.add(category);
            } else {
                Map<String, Object> parent = categoryMap.get(parentId);
                if (parent != null) {
                    @SuppressWarnings("unchecked")
                    List<Map<String, Object>> parentChildren = (List<Map<String, Object>>) parent.get("children");
                    parentChildren.add(category);
                }
            }
        }

        return topLevelCategories;
    }
}