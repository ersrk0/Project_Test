
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.request.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/otp")

public interface IAdditionalDetailsController
{


  /**
   * Sends an OTP to the specified email address.
   *
   * @param addEmailDto     Email details for OTP sending
   * @param acceptLanguage  Preferred language for the response
   * @return API response with operation result
   */
  @Operation(
    summary = "Send OTP on Email",
    description = "Sends an OTP to the specified email address.",
    security = @SecurityRequirement(name = "BearerAuthentication")
  )
  @Parameter(
    name = "accept-language",
    description = "Preferred language for the response. Default is English.",
    in = ParameterIn.HEADER,
    example = "eng",
    schema = @Schema(minLength = 2, maxLength = 6)
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "403", description = "Forbidden - Token does not have the required permissions", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/send/email")
  ResponseEntity<APIResponse<Object>> sendOtpOnEmail(
    @Valid @RequestBody AddEmailRequestDTO addEmailDto,
    @RequestHeader(value = "accept-language", required = false) String acceptLanguage
  );

  /**
   * Verifies the OTP sent to the specified email address.
   *
   * @param profileOtpValidationRequestDTO  OTP validation details
   * @param acceptLanguage                  Preferred language for the response
   * @return API response with verification result
   */
  @Operation(
    summary = "Verify OTP on Email",
    description = "Verifies the OTP sent to the specified email address.",
    security = @SecurityRequirement(name = "BearerAuthentication")
  )
  @Parameter(
    name = "accept-language",
    description = "Preferred language for the response. Default is English.",
    in = ParameterIn.HEADER,
    example = "eng",
    schema = @Schema(minLength = 2, maxLength = 6)
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "403", description = "Forbidden - Token does not have the required permissions", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/verify/email")
  ResponseEntity<APIResponse<Object>> verifytpOnEmail(
    @Valid @RequestBody OtpValidationRequestDTO profileOtpValidationRequestDTO,
    @RequestHeader(value = "accept-language", required = false) String acceptLanguage
  );

  /**
   * Resends the OTP to the specified email address.
   *
   * @param otpRegenerateRequestDTO  OTP regeneration details
   * @param acceptLanguage           Preferred language for the response
   * @return API response with operation result
   */
  @Operation(
    summary = "Resend OTP on Email",
    description = "Resends the OTP to the specified email address.",
    security = @SecurityRequirement(name = "BearerAuthentication")
  )
  @Parameter(
    name = "accept-language",
    description = "Preferred language for the response. Default is English.",
    in = ParameterIn.HEADER,
    example = "eng",
    schema = @Schema(minLength = 2, maxLength = 6)
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "403", description = "Forbidden - Token does not have the required permissions", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/resend/email")
  ResponseEntity<APIResponse<Object>> resendOtpOnEmail(
    @RequestBody OtpRegenerateRequestDTO otpRegenerateRequestDTO,
    @RequestHeader(value = "accept-language", required = false) String acceptLanguage
  );

  /**
   * Sends an OTP to the specified mobile number.
   *
   * @param sendOtpRequestDto  Mobile details for OTP sending
   * @param acceptLanguage     Preferred language for the response
   * @return API response with operation result
   */
  @Operation(
    summary = "Send OTP on Mobile",
    description = "Sends an OTP to the specified mobile number.",
    security = @SecurityRequirement(name = "BearerAuthentication")
  )
  @Parameter(
    name = "accept-language",
    description = "Preferred language for the response. Default is English.",
    in = ParameterIn.HEADER,
    example = "eng",
    schema = @Schema(minLength = 2, maxLength = 6)
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "403", description = "Forbidden - Token does not have the required permissions", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/send/mobile")
  ResponseEntity<APIResponse<Object>> sendOtpOnMobile(
    @Valid @RequestBody AddMobileRequestDTO sendOtpRequestDto,
    @RequestHeader(value = "accept-language", required = false) String acceptLanguage
  );

  /**
   * Verifies the OTP sent to the specified mobile number.
   *
   * @param OtpValidationRequestDTO  OTP validation details
   * @param acceptLanguage           Preferred language for the response
   * @return API response with verification result
   */
  @Operation(
    summary = "Verify OTP on Mobile",
    description = "Verifies the OTP sent to the specified mobile number.",
    security = @SecurityRequirement(name = "BearerAuthentication")
  )
  @Parameter(
    name = "accept-language",
    description = "Preferred language for the response. Default is English.",
    in = ParameterIn.HEADER,
    example = "eng",
    schema = @Schema(minLength = 2, maxLength = 6)
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "403", description = "Forbidden - Token does not have the required permissions", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/verify/mobile")
  ResponseEntity<APIResponse<Object>> verifyotpOnMobile(
    @Valid @RequestBody MobileOtpValidationRequestDTO OtpValidationRequestDTO,
    @RequestHeader(value = "accept-language", required = false) String acceptLanguage
  );

  /**
   * Resends the OTP to the specified mobile number.
   *
   * @param otpRegenerateRequestDTO  OTP regeneration details
   * @param acceptLanguage           Preferred language for the response
   * @return API response with operation result
   */
  @Operation(
    summary = "Resend OTP on Mobile",
    description = "Resends the OTP to the specified mobile number.",
    security = @SecurityRequirement(name = "BearerAuthentication")
  )
  @Parameter(
    name = "accept-language",
    description = "Preferred language for the response. Default is English.",
    in = ParameterIn.HEADER,
    example = "eng",
    schema = @Schema(minLength = 2, maxLength = 6)
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "403", description = "Forbidden - Token does not have the required permissions", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/resend/mobile")
  ResponseEntity<APIResponse<Object>> resendOtpOnMobile(
    @RequestBody OtpRegenerateRequestDTO otpRegenerateRequestDTO,
    @RequestHeader(value = "accept-language", required = false) String acceptLanguage
  );
}
