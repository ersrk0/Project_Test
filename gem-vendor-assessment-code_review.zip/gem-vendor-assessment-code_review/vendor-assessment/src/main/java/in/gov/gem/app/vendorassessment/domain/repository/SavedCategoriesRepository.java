package in.gov.gem.app.vendorassessment.domain.repository;


import in.gov.gem.app.vendorassessment.domain.entity.Category;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * A repository class for managing a thread-safe list of saved categories.
 * This class ensures that all operations on the list, such as adding,
 * removing, and retrieving, are synchronized to prevent concurrency issues.
 */
@Component
public class SavedCategoriesRepository {

    /**
     * The thread-safe list of saved categories.
     */
    private final List<Category> savedCategories = Collections.synchronizedList(new ArrayList<>());

    /**
     * Adds a category to the saved list.
     *
     * @param category The category to be saved.
     */
    public void addCategory(Category category) {
        if (category != null) {
            savedCategories.add(category);
        }
    }

    /**
     * Retrieves all saved categories.
     *
     * @return A new list containing all saved categories.
     */
    public List<Category> getAllCategories() {
        return new ArrayList<>(savedCategories);
    }

}
