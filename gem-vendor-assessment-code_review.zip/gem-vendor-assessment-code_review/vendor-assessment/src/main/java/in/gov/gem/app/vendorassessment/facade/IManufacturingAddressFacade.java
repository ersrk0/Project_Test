
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;

import in.gov.gem.app.vendorassessment.dto.request.VAOrganizationAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.CountryResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.FetchLocationResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.NewVAResponseOrganizationAddressDTO;
import in.gov.gem.app.vendorassessment.dto.response.VAResponseOrganizationAddressResponseDTO;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;

import java.util.List;

/**
 * The interface Manufacturing address facade.
 */
public interface IManufacturingAddressFacade
{
  /**
   * Save manufacturing address va organization address request dto.
   *
   * @param vaOrganizationAddress the va organization address
   * @return the va organization address request dto
   */
  public VAOrganizationAddressRequestDTO saveManufacturingAddress(VAOrganizationAddressRequestDTO vaOrganizationAddress);

  /**
   * Save manufacturing address assess as va organization address request dto.
   *
   * @param vaOrganizationAddress the va organization address
   * @param vaNumber              the va number
   * @return the va organization address request dto
   */
  public VAOrganizationAddressRequestDTO saveManufacturingAddressAssessAs(VAOrganizationAddressRequestDTO vaOrganizationAddress, String vaNumber);

  /**
   * Find by va organization detail fk list.
   *
   * @param vaOrganizationDetailFk the va organization detail fk
   * @return the list
   */
  public List<VAOrganizationAddressRequestDTO> findByVaOrganizationDetailFk(Long vaOrganizationDetailFk);

  /**
   * Find by va organization detail fk pageable api response.
   *
   * @param paginationParams       the pagination params
   * @param vaOrganizationDetailFk the va organization detail fk
   * @return the pageable api response
   */
  public PageableApiResponse<List<VAOrganizationAddressRequestDTO>> findByVaOrganizationDetailFk(PaginationParams paginationParams, Long vaOrganizationDetailFk);

  /**
   * Find by va master fk list.
   *
   * @param vaMasterFk the va master fk
   * @return the list
   */
  public List<VAOrganizationAddressRequestDTO> findByVaMasterFk(Long vaMasterFk);

  /**
   * Find by va master fk pageable api response.
   *
   * @param paginationParams the pagination params
   * @param vaMasterFk       the va master fk
   * @return the pageable api response
   */
  public PageableApiResponse<List<VAOrganizationAddressRequestDTO>> findByVaMasterFk(PaginationParams paginationParams, Long vaMasterFk);

  /**
   * Find by id list.
   *
   * @param id the id
   * @return the list
   */
  public List<VAResponseOrganizationAddressResponseDTO> findById(Long id);

  /**
   * Find by new id list.
   *
   * @param id the id
   * @return the list
   */
  public List<NewVAResponseOrganizationAddressDTO> findByNewId(Long id);

  /**
   * Delete by id.
   *
   * @param id the id
   */
  void deleteById(Long id);

  /**
   * Update by id.
   *
   * @param id      the id
   * @param request the request
   */
  public void updateById(Long id, VAOrganizationAddressRequestDTO request);

  /**
   * Gets location list from mdm.
   *
   * @param paginationParams the pagination params
   * @param locationCode     the location code
   * @param languageCode     the language code
   * @return the location list from mdm
   */
  public List<FetchLocationResponseDTO> getLocationListFromMdm(PaginationParams paginationParams,
                                                               String locationCode, String languageCode);

  /**
   * Fetch country list list.
   *
   * @param paginationParams the pagination params
   * @param languageCode     the language code
   * @return the list
   */
  public List<CountryResponseDTO> fetchCountryList(PaginationParams paginationParams, String languageCode);

  /**
   * Save address in vendor and seller va organization address request dto.
   *
   * @param vendorAddressDTO the vendor address dto
   * @param vaNumber         the va number
   * @return the va organization address request dto
   */
  public VAOrganizationAddressRequestDTO saveAddressInVendorAndSeller(VAOrganizationAddressRequestDTO vendorAddressDTO, String vaNumber);
}
