
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.repository.LookupRepository;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.domain.entity.VAOrganizationAddressEntity;
import in.gov.gem.app.vendorassessment.domain.repository.VaManufacturingAddressRepository;
import in.gov.gem.app.vendorassessment.domain.repository.VaOrganizationDetailRepository;
import in.gov.gem.app.vendorassessment.dto.request.VAOrganizationAddressRequestDTO;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.response.*;
import in.gov.gem.app.vendorassessment.facade.IManufacturingAddressFacade;
import in.gov.gem.app.vendorassessment.service.IManufacturingAddress;
import in.gov.gem.app.vendorassessment.service.ISaveAssessOptionService;
import in.gov.gem.app.vendorassessment.transformer.MdmTransformer;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;


/**
 * The type Manufacturing address facade.
 */
@Component
@AllArgsConstructor
public class ManufacturingAddressFacade implements IManufacturingAddressFacade
{

  private final IManufacturingAddress manufacturingAddress;

  private final VaManufacturingAddressRepository repository;

  private final VaOrganizationDetailRepository organizationDetailRepository;

  private final MessageUtility messageUtility;

  private final ISaveAssessOptionService service;

  private ISellerClient sellerClient;

  private LookupRepository lookupRepository;



  private final MdmTransformer mdmTransformer;

  @Override
  public VAOrganizationAddressRequestDTO saveManufacturingAddress(VAOrganizationAddressRequestDTO vaOrganizationAddress) {
    return manufacturingAddress.saveManufacturingAddress(vaOrganizationAddress);
  }

  public List<FetchLocationResponseDTO> getLocationListFromMdm(PaginationParams paginationParams,
                                                               String locationCode, String languageCode)
  {
    return mdmTransformer.getLocationListFromMdm(paginationParams, locationCode, languageCode);
  }

  public List<CountryResponseDTO> fetchCountryList(PaginationParams paginationParams, String languageCode)
  {

    return mdmTransformer.fetchCountryList(paginationParams, languageCode);

  }

  @Override
  public VAOrganizationAddressRequestDTO saveManufacturingAddressAssessAs(VAOrganizationAddressRequestDTO vaOrganizationAddress, String vaNumber) {
    SaveAssessResponseDTO option = service.getOption(vaNumber);
    Optional<Lookup> byLookupCode = lookupRepository.findByLookupCode(option.getApplyAsLookUp());
    byLookupCode.ifPresent(lookup -> option.setApplyAsLookUp(lookup.getLookupValue()));

    VAOrganizationAddressEntity organizationAddressEntity = VAOrganizationAddressEntity.builder()
      .vaOrganizationDetailFk(vaOrganizationAddress.getVaOrganizationDetailFk())
      .officeName(vaOrganizationAddress.getOfficeName())
      .officeTypeLookup(vaOrganizationAddress.getOfficeTypeLookup())
      .officeAddressLine1(vaOrganizationAddress.getOfficeAddressLine1())
      .officeAddressLine2(vaOrganizationAddress.getOfficeAddressLine2())
      .officeLandmark(vaOrganizationAddress.getOfficeLandmark())
      .geographyLocationCode(vaOrganizationAddress.getGeographyLocationCode())
      .contactNumber(vaOrganizationAddress.getContactNumber())
      .emailId(vaOrganizationAddress.getEmailId())
      .gstinNumber(vaOrganizationAddress.getGstinNumber())
      .assessAsLookupType(vaOrganizationAddress.getAssessAsLookupType())
      .build();

    VAOrganizationAddressEntity savedEntity = repository.save(organizationAddressEntity);

    VAOrganizationAddressRequestDTO responseDTO = VAOrganizationAddressRequestDTO.builder()
      .id(savedEntity.getId())
      .vaOrganizationDetailFk(savedEntity.getVaOrganizationDetailFk())
      .officeName(savedEntity.getOfficeName())
      .officeTypeLookup(savedEntity.getOfficeTypeLookup())
      .officeAddressLine1(savedEntity.getOfficeAddressLine1())
      .officeAddressLine2(savedEntity.getOfficeAddressLine2())
      .officeLandmark(savedEntity.getOfficeLandmark())
      .geographyLocationCode(savedEntity.getGeographyLocationCode())
      .contactNumber(savedEntity.getContactNumber())
      .emailId(savedEntity.getEmailId())
      .gstinNumber(savedEntity.getGstinNumber())
      .assessAsLookupType(byLookupCode.map(Lookup::getLookupValue).orElse(null))
      .build();

    return responseDTO;
  }

  @Override
  public List<VAOrganizationAddressRequestDTO> findByVaOrganizationDetailFk(Long vaOrganizationDetailFk) {
    return manufacturingAddress.findByVaOrganizationDetailFk(vaOrganizationDetailFk);
  }

  @Override
  public PageableApiResponse<List<VAOrganizationAddressRequestDTO>> findByVaOrganizationDetailFk(PaginationParams paginationParams, Long vaOrganizationDetailFk) {
    return manufacturingAddress.findByVaOrganizationDetailFk(paginationParams, vaOrganizationDetailFk);
  }

  @Override
  public List<VAOrganizationAddressRequestDTO> findByVaMasterFk(Long vaMasterFk) {
    return manufacturingAddress.findByVaMasterFk(vaMasterFk);
  }

  @Override
  public PageableApiResponse<List<VAOrganizationAddressRequestDTO>> findByVaMasterFk(PaginationParams paginationParams, Long vaMasterFk) {
    return manufacturingAddress.findByVaMasterFk(paginationParams, vaMasterFk);
  }

  @Override
  public List<VAResponseOrganizationAddressResponseDTO> findById(Long id) {
    return manufacturingAddress.findById(id);
  }

  @Override
  public List<NewVAResponseOrganizationAddressDTO> findByNewId(Long id) {
    return manufacturingAddress.findByNewId(id);
  }

  @Override
  public void deleteById(Long id)
  {
    manufacturingAddress.deleteById(id);

  }

  @Override
  public void updateById(Long id, VAOrganizationAddressRequestDTO request)
  {
    manufacturingAddress.updateById(id, request);
  }

  @Override
  public VAOrganizationAddressRequestDTO saveAddressInVendorAndSeller(VAOrganizationAddressRequestDTO vendorAddressDTO, String vaNumber) {
    return manufacturingAddress.saveAddressInVendorAndSeller(vendorAddressDTO, vaNumber);
  }
}
