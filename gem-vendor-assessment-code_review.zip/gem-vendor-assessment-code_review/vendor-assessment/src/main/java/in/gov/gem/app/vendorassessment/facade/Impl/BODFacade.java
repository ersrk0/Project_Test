
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.vendorassessment.dto.response.BODDocumentNewResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.BODDocumentResponseDTO;
import in.gov.gem.app.vendorassessment.domain.entity.VaDocumentDetailEntity;
import in.gov.gem.app.vendorassessment.facade.IBODFacade;
import in.gov.gem.app.vendorassessment.service.IBODService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * The type Bod facade.
 */
@Component
@AllArgsConstructor
public class BODFacade implements IBODFacade {

    private IBODService bodService;
    @Override
    public List<BODDocumentNewResponseDTO> getRequiredDocuments(Long VendorAssessmentId) {
        return bodService.getRequiredDocuments(VendorAssessmentId);
    }
    @Override
    public List<BODDocumentResponseDTO> getMyOrganizationDocuments(Long vaMasterId) {
        return bodService.getMyOrganisationDocuments(vaMasterId);
    }
    @Override
    public List<BODDocumentResponseDTO> getAuthorizingOemOspDocuments(Long vaMasterId) {
        return bodService.getAuthorizingOemOspDocuments(vaMasterId);
    }
    @Override
    public List<BODDocumentResponseDTO> getContractManufacturerDocuments(Long vaMasterId) {
        return bodService.getContractManufacturerDocuments(vaMasterId);
    }
    @Override
    public void deleteBodDocument(Long vaMasterFk, String docName) {
        bodService.deleteBodDocument(vaMasterFk, docName);
    }
    @Override
    public ResponseEntity<byte[]> exportToExcel(List<BODDocumentResponseDTO> bodDocumentResponses) {
        return bodService.exportToExcel(bodDocumentResponses);
    }
    @Override
    public List<BODDocumentResponseDTO> getLastVerifiedBODDocument(Long sellerID){

        return bodService.getLastVerifiedBODDocument(sellerID);
    }
    @Override
    public VaDocumentDetailEntity saveRemarks(String remarks, Long vaMasterFk) {
        return bodService.saveRemarks(remarks, vaMasterFk);
    }
    @Override
    public List<BODDocumentResponseDTO> getParentBodDocuments(Long vaMasterId) {
        return bodService.getParentBodDocuments(vaMasterId);
    }
    @Override
    public Object getUploadedParentBODDocument(Long sellerId) {
        return bodService.getUploadedParentBODDocument(sellerId);
    }

}
