
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressUpdateRequestDTO;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.response.*;
import in.gov.gem.app.vendorassessment.facade.ISellerFetchDetailsFacade;
import in.gov.gem.app.vendorassessment.transformer.*;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * The type Seller fetch details facade.
 */
@Component
@AllArgsConstructor
public class SellerFetchDetailsFacade implements ISellerFetchDetailsFacade {

  private final ProfileClientTransformer profileClientTransformer;
  private final BankTransformer bankClientTransformer;
  private final OfficeAddressClientFacade officeAddressClientTransform;
  private final FinancialClientTransformer financialClientTransformer;
  private final ISellerClient iSellerClient;
  private final IAMTransformer iamTransformer;
  private final MessageUtility messageUtility;
  private final EkycTransformer ekycTransformer;

  @Override
  public void checkingProfile() {
    var apiResponseResponseEntity = iSellerClient.checkProfileCompletion();
    var data = Optional.ofNullable(apiResponseResponseEntity)
      .map(r -> r.getBody())
      .map(b -> b.getData())
      .orElse(null);

    if (data == null || !data.isConsentDeclared() || !data.isBusinessDetailsFilled() ||
      !data.isOfficeAddressSaved() || !data.isKeyPersonVerified()) {
      throw new ServiceException(MessageConstant.SELLER_PROFILE_NOT_COMPLETE,
        messageUtility.getMessage(MessageConstant.SELLER_PROFILE_NOT_COMPLETE),
        ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
    }
  }

  @Override
  public ProfileSellerResponseDTO getProfileFromSeller() throws JsonProcessingException {
    return profileClientTransformer.getProfileFromSeller();
  }

  @Override
  public PanResponseResponseDTO getPanFromSeller() {
    return profileClientTransformer.getPanFromSeller();
  }

  @Override
  public List<TanResponseDTO> getTanFromSeller(PaginationParams paginationParams) {
    return profileClientTransformer.getTanFromSeller(paginationParams);
  }

  @Override
  public List<BankSellerResponseDTO> getBankFromSeller(PaginationParams paginationParams, String languageCode) {
    return bankClientTransformer.getBankDetailsFromSeller(paginationParams, languageCode);
  }

  @Override
  public List<OfficeSellerResponseDTO> getAddressFromSeller(PaginationParams paginationParams, String vaNumber) {
    return officeAddressClientTransform.getOfficeAddressesFromSeller(paginationParams, vaNumber);
  }

  @Override
  public List<OfficePreSellerResponseDTO> getPreDefinedAddressFromSeller(PaginationParams paginationParams, String vaNumber) {
    return officeAddressClientTransform.getOfficeAddressespredefined(paginationParams, vaNumber);
  }

  @Override
  public OfficeVOResponseDTO saveAddressInSeller(OfficeAddressRequestDTO officeAddressRequestDTO) {
    return officeAddressClientTransform.saveOfficeAddress(officeAddressRequestDTO);
  }

  @Override
  public void deleteAddressInSeller(Long pvtOrgOfficeId) {
    officeAddressClientTransform.deleteOfficeAddress(pvtOrgOfficeId);
  }

  @Override
  public void updateAddressInSeller(OfficeAddressUpdateRequestDTO officeAddressUpdateRequestDTO) {
    officeAddressClientTransform.updateOfficeAddress(officeAddressUpdateRequestDTO);
  }

  @Override
  public List<OfficeVOResponseDTO> getRegisteredOfficeMobileList(PaginationParams paginationParams) {
    return officeAddressClientTransform.getRegisteredOfficeMobileList(paginationParams);
  }

  @Override
  public List<OfficeVOResponseDTO> getRegisteredOfficeEmailList(PaginationParams paginationParams) {
    return officeAddressClientTransform.getRegisteredOfficeEmailList(paginationParams);
  }

  @Override
  public List<TurnoverSellerResponseDTO> getFinancialFromSeller(PaginationParams paginationParams) {
    return financialClientTransformer.getFinancialDetailsFromSeller(paginationParams);
  }

  @Override
  public TurnoverResponseDTO getTurnoverFromSeller() {
    return financialClientTransformer.getTurnOverFromSeller();
  }

  @Override
  public UserDetailResponseDTO getUserDetails() {
    return iamTransformer.getUser();
  }

  @Override
  public IpAddressResponseDTO getIPAddress() {
    return iamTransformer.getIpAddress();
  }

  @Override
  public boolean getVerifyGstin(String gstin, boolean isManufacturing) {
    return isManufacturing
      ? ekycTransformer.verifyGstinForManufacturing(gstin)
      : ekycTransformer.verifyGstin(gstin);
  }

}