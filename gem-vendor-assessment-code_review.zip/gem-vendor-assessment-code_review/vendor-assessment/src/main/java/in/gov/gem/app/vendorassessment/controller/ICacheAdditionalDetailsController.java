
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.controller;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.request.AddEmailRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.AddMobileRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.MobileOtpValidationRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OtpValidationRequestDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@Tag(name = "OTP", description = "APIs for sending and validating OTPs on email and mobile")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/v1/otp")

public interface ICacheAdditionalDetailsController
{

  /**
   * Sends or resends OTP on email.
   *
   * @param addEmailDto     the email details
   * @param acceptLanguage  the accept language header
   * @return the API response
   */
  @Operation(
    summary = "Send/Resend OTP on Email",
    description = "Sends or resends OTP to the provided email address.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "accept-language", description = "Accept language", in = ParameterIn.HEADER, required = false)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/sender/email")
  ResponseEntity<APIResponse<Object>> sendresendOtpOnEmail(
    @RequestBody AddEmailRequestDTO addEmailDto,
    @RequestHeader(value = "accept-language", required = false) String acceptLanguage
  );

  /**
   * Validates OTP on email.
   *
   * @param profileOtpValidationRequestDTO the OTP validation request
   * @param acceptLanguage                 the accept language header
   * @return the API response
   */
  @Operation(
    summary = "Validate OTP on Email",
    description = "Validates the OTP sent to the provided email address.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "accept-language", description = "Accept language", in = ParameterIn.HEADER, required = false)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/validate/email")
  ResponseEntity<APIResponse<Object>> validateotpOnEmail(
    @RequestBody OtpValidationRequestDTO profileOtpValidationRequestDTO,
    @RequestHeader(value = "accept-language", required = false) String acceptLanguage
  );

  /**
   * Sends or resends OTP on mobile.
   *
   * @param sendOtpRequestDto the mobile details
   * @param acceptLanguage    the accept language header
   * @return the API response
   */
  @Operation(
    summary = "Send/Resend OTP on Mobile",
    description = "Sends or resends OTP to the provided mobile number.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "accept-language", description = "Accept language", in = ParameterIn.HEADER, required = false)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/sender/mobile")
  ResponseEntity<APIResponse<Object>> sendresendOtpOnMobile(
    @RequestBody AddMobileRequestDTO sendOtpRequestDto,
    @RequestHeader(value = "accept-language", required = false) String acceptLanguage
  );

  /**
   * Validates OTP on mobile.
   *
   * @param OtpValidationRequestDTO the OTP validation request
   * @param acceptLanguage          the accept language header
   * @return the API response
   */
  @Operation(
    summary = "Validate OTP on Mobile",
    description = "Validates the OTP sent to the provided mobile number.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "accept-language", description = "Accept language", in = ParameterIn.HEADER, required = false)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/validate/mobile")
  ResponseEntity<APIResponse<Object>> validateotpOnMobile(
    @RequestBody MobileOtpValidationRequestDTO OtpValidationRequestDTO,
    @RequestHeader(value = "accept-language", required = false) String acceptLanguage
  );
}
 