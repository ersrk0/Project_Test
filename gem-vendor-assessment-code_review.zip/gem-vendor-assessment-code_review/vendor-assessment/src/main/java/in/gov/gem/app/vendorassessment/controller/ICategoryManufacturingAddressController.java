
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.request.CategoryManufacturingAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ManufacturingAddressCategoryMappingDTO;
import in.gov.gem.app.vendorassessment.dto.response.CategoryManufacturingAddressResponseDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RequestMapping("/v1/manufacturing-addresses")
@Tag(name = "Manufacturing Address Management", description = "Endpoints for managing manufacturing addresses and their category mappings.")
public interface ICategoryManufacturingAddressController{

    @PostMapping
    @Operation(
        summary = "Create a new manufacturing address",
        description = "Creates a new manufacturing address entry.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Manufacturing address created successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryManufacturingAddressResponseDTO.class)))
        }
    )
    ResponseEntity<APIResponse<CategoryManufacturingAddressResponseDTO>> createManufacturingAddress(
        @Parameter(description = "The DTO containing manufacturing address details", required = true) @RequestBody CategoryManufacturingAddressRequestDTO requestDTO
    );

    @GetMapping("/getById")
    @Operation(
        summary = "Retrieve a manufacturing address by ID",
        description = "Retrieves a single manufacturing address entry by its unique ID.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Manufacturing address retrieved successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryManufacturingAddressResponseDTO.class))),
            @ApiResponse(responseCode = "404", description = "Manufacturing address not found")
        }
    )
    ResponseEntity<APIResponse<CategoryManufacturingAddressResponseDTO>> getManufacturingAddressById(
        @Parameter(description = "The ID of the manufacturing address", required = true) @RequestParam String addressId
    );

    @GetMapping
    @Operation(
        summary = "Retrieve all manufacturing addresses",
        description = "Retrieves a list of all manufacturing address entries.",
        responses = {
            @ApiResponse(responseCode = "200", description = "All manufacturing addresses retrieved successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = List.class)))
        }
    )
    ResponseEntity<APIResponse<Object>> getAllManufacturingAddresses();

    @PutMapping("/{id}")
    @Operation(
        summary = "Update an existing manufacturing address",
        description = "Updates the details of an existing manufacturing address by its ID.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Manufacturing address updated successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryManufacturingAddressResponseDTO.class))),
            @ApiResponse(responseCode = "404", description = "Manufacturing address not found")
        }
    )
    ResponseEntity<APIResponse<CategoryManufacturingAddressResponseDTO>> updateManufacturingAddress(
        @Parameter(description = "The ID of the manufacturing address to update", required = true) @PathVariable String id,
        @Parameter(description = "The DTO with updated manufacturing address details", required = true) @RequestBody CategoryManufacturingAddressRequestDTO requestDTO
    );

    @DeleteMapping
    @Operation(
        summary = "Delete a manufacturing address",
        description = "Deletes a manufacturing address entry by its ID.",
        responses = {
            @ApiResponse(responseCode = "204", description = "Manufacturing address deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Manufacturing address not found")
        }
    )
    ResponseEntity<Void> deleteManufacturingAddress(
        @Parameter(description = "The ID of the manufacturing address to delete", required = true) @RequestParam String id
    );

    @PostMapping("/map-categories")
    @Operation(
        summary = "Map categories to a manufacturing address",
        description = "Associates a list of categories with a specific manufacturing address.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Categories mapped successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryManufacturingAddressResponseDTO.class))),
            @ApiResponse(responseCode = "404", description = "Manufacturing address not found")
        }
    )
    ResponseEntity<CategoryManufacturingAddressResponseDTO> mapCategoriesToManufacturingAddress(
        @Parameter(description = "The ID of the manufacturing address", required = true) @RequestParam String addressId,
        @Parameter(description = "The DTO containing the list of category IDs to map", required = true) @RequestBody ManufacturingAddressCategoryMappingDTO mappingDTO
    );

    @GetMapping("/with-categories")
    @Operation(
        summary = "Retrieve a manufacturing address with mapped categories",
        description = "Retrieves a manufacturing address and includes the details of all its mapped categories.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Manufacturing address with categories retrieved successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryManufacturingAddressResponseDTO.class))),
            @ApiResponse(responseCode = "404", description = "Manufacturing address not found")
        }
    )
    ResponseEntity<CategoryManufacturingAddressResponseDTO> getManufacturingAddressWithMappedCategories(
        @Parameter(description = "The ID of the manufacturing address", required = true) @RequestParam String id
    );
}
