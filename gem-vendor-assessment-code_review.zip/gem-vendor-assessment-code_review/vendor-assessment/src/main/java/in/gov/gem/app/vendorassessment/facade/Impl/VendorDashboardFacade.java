
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;



import in.gov.gem.app.vendorassessment.dto.response.VendorDashboardDTOResponseDTO;

import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.facade.IVendorDashboardFacade;
import in.gov.gem.app.vendorassessment.service.IVendorDashboardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * The type Vendor dashboard facade.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class VendorDashboardFacade implements IVendorDashboardFacade {

    private final IVendorDashboardService vendorDashboardService;

    @Override
    public Page<VendorDashboardDTOResponseDTO> getAllVendorAssessments(PaginationParams paginationParams) {
        log.info("Fetching all vendor assessments with pagination: pageNumber={}, pageSize={}, sortBy={}, sortOrder={}, searchQuery={}",
                paginationParams.getPageNumber(), paginationParams.getPageSize(), paginationParams.getSortBy(),
                paginationParams.getSortOrder(), paginationParams.getSearchQuery());
        return vendorDashboardService.getAllVendorAssessments(paginationParams);
    }

    @Override
    public Optional<VendorDashboardDTOResponseDTO> getVendorAssessmentByVaNumber(String vaNumber) {
        log.info("Fetching specific vendor assessment for VA number: {}", vaNumber);
        return vendorDashboardService.getVendorAssessmentByVaNumber(vaNumber);
    }

    @Override
    public List<Map<String, Object>> getCategories(String vaNumber) {
        return vendorDashboardService.getCategories(vaNumber);
    }

    @Override
    public void deleteVendorAssessment(String vendorId) {
        log.info("Deleting vendor assessment for vendor ID: {}", vendorId);
        vendorDashboardService.deleteVendorAssessment(vendorId);
        log.info("Vendor assessment deleted successfully for vendor ID: {}", vendorId);
    }
}