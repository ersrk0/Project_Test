
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;



import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.domain.entity.Category;
import in.gov.gem.app.vendorassessment.domain.repository.CategoryRepository;
import in.gov.gem.app.vendorassessment.domain.repository.SavedCategoriesRepository;
import in.gov.gem.app.vendorassessment.dto.enums.OriginalCategoryKey;
import in.gov.gem.app.vendorassessment.dto.request.CategoryRequestDTO;
import in.gov.gem.app.vendorassessment.service.ICategoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class CategoryServiceImpl implements ICategoryService {

    private final CategoryRepository categoryRepository;
    private final SavedCategoriesRepository savedCategoriesRepository;

    private final Map<OriginalCategoryKey, Long> originalDbIdAndVaIdToNewInternalIdMap = new HashMap<>();


    public CategoryServiceImpl(CategoryRepository categoryRepository, SavedCategoriesRepository savedCategoriesRepository) {
        this.categoryRepository = categoryRepository;
        this.savedCategoriesRepository = savedCategoriesRepository;
    }


    /**
     * Creates a new category.
     * Assigns a unique ID and stores it.
     *
     * @param category The category domain object to create.
     * @return The created category with its assigned ID.
     */
    @Override
    public Category createCategory(Category category) {
        categoryRepository.save( category);
        return category;
    }

    /**
     * Retrieves a category by its ID.
     *
     * @param id The ID of the category.
     * @return An Optional containing the category if found, or empty if not.
     */
    @Override
    public Optional<Category> getCategoryById(String id) {
        long validLong = Long.parseLong(id);
        return categoryRepository.findById(validLong);
    }


    // Helper method to get direct children of a category
    public List<Category> getChildrenOfCategory(Long parentId) {
        return categoryRepository.findByParentId(parentId);
    }

    // Helper method to get siblings of a category (excluding itself)
    private List<Category> getSiblingsOfCategory(Category category) {
        if (category.getParentId() == null) {
            // If it's a top-level category, its siblings are other top-level categories
            List<Category> topLevelCategories = savedCategoriesRepository.getAllCategories().stream()
                    .filter(category1 -> category1.getParentId() == null)
                    .collect(Collectors.toList());;
            topLevelCategories.removeIf(cat -> cat.getId().equals(category.getId()));
            return topLevelCategories;
        } else {
            List<Category> siblings = savedCategoriesRepository.getAllCategories().stream()
                    .filter(cat -> cat.getParentId() != null && cat.getParentId().equals(category.getParentId()))
                    .collect(Collectors.toList());
            siblings.removeIf(cat -> cat.getId().equals(category.getId()));
            return siblings;
        }
    }


    /**
     * STUB IMPLEMENTATION for finding similar categories.
     * This method returns predefined responses based on specific input names.
     * In a real application, this would contain actual similarity logic (e.g., database queries, fuzzy matching).
     *
     * @return A predefined list of SimilarCategoryDTOs.
     */
    public Map<String, Object> findSimilarCategoriesByName(List<CategoryRequestDTO> categoryNames) {
        Map<String, List<String>> data = new LinkedHashMap<>();
        if (categoryNames == null || categoryNames.isEmpty()) {
            return Map.of(
                    ApplicationConstant.MESSAGE, ApplicationConstant.CATEGORIES_NOT_AVAILABLE,
                    ApplicationConstant.DATA, data
            );
        }

        for (CategoryRequestDTO dto : categoryNames) {
            String name = dto.getName();
            if (name == null) continue;
            String lowerCaseName = name.toLowerCase(Locale.ROOT);
            List<String> similar = new ArrayList<>();

            if ("electronics".equals(lowerCaseName)) {
                similar.add("Electronics");
            }
            if ("books".equals(lowerCaseName)) {
                similar.add("Books");
            }
            if (lowerCaseName.contains("sport")) {
                similar.add("Sports");
                similar.add("Outdoor Sports");
            }
            if (lowerCaseName.contains("lap")) {
                similar.add("Laptops");
            }
            if (lowerCaseName.contains("phone")) {
                similar.add("Smartphones");
                similar.add("Mobile Phones");
            }
            if (lowerCaseName.contains("fiction")) {
                similar.add("Fiction");
            }
            if (lowerCaseName.contains("adventure")) {
                similar.add("Adventure");
            }
            if (lowerCaseName.contains("mystery")) {
                similar.add("Mystery");
            }

            if (!similar.isEmpty()) {
                data.put(name, similar);
            }
        }

        return Map.of(
                ApplicationConstant.MESSAGE, ApplicationConstant.SIMILAR_CATEGORIES_FOUND,
                ApplicationConstant.DATA, data
        );

    }


    /**
     * Helper method to recursively delete a category and all its children.
     * @param categoryId The ID of the category to delete.
     */
    private void deleteCategoryAndChildrenRecursive(Long categoryId) {
        List<Category> children = getChildrenOfCategory(categoryId);
        for (Category child : children) {
            deleteCategoryAndChildrenRecursive(child.getId()); // Recursive call for children
        }
        savedCategoriesRepository.getAllCategories().removeIf(c -> c.getId().equals(categoryId)); // Delete the category itself
    }




    /**
     * Builds the full hierarchical tree for all categories.
     * This method first clears existing children lists on all categories,
     * then populates them by iterating through all categories and assigning
     * children to their respective parents.
     *
     * @return A list of top-level categories, with their children populated recursively.
     */
    @Override
    public List<Category> buildCategoryTree( Optional<String> type, String vaId) {
        savedCategoriesRepository.getAllCategories().forEach(Category::clearChildren);
        List<Category> allCategories = getRootCategories(type, vaId);
        Map<Long, Category> categoryMap = allCategories.stream()
                .collect(Collectors.toMap(Category::getId, category -> category));

        List<Category> topLevelCategories = new ArrayList<>();


        for (Category category : allCategories) {
            if (category.getParentId() == null || category.getParentId() == 0) {
                topLevelCategories.add(category);
            } else {

                Category parent = categoryMap.get(category.getParentId());
                //categoryMap.get(2L);
                if (parent != null) {

                    parent.addChild(category);
                }

            }
        }
        return topLevelCategories;
    }


    /**
     * Finds root categories (categories with no parent) from in-memory storage.
     * Can be filtered by type.
     * @param type Optional type to filter root categories by.
     * @return A list of root categories, optionally filtered by type.
     */
    public List<Category> getRootCategories(Optional<String> type, String vaId) {
        return savedCategoriesRepository.getAllCategories().stream()
                .filter(category -> vaId == null || (category.getVaId() != null && category.getVaId().equalsIgnoreCase(vaId)))
                .filter(category -> type.isEmpty() || (category.getType() != null && category.getType().equalsIgnoreCase(type.get())))
                .collect(Collectors.toList());
    }


    @Override
    public List<Long> saveCategories(List<Category> categoryRequests) {
        List<Long> addedCategoryIds = new ArrayList<>();

        for (Category category : categoryRequests) {
            savedCategoriesRepository.addCategory(category);
            addedCategoryIds.add(category.getId());
        }
        return addedCategoryIds;
    }





    /**
     * Adds a category and its entire hierarchical path (from root down to the category)
     * to the saved categories, ensuring no duplicates. This version assumes the Category
     * entity only has a parentId (Long) and no direct parentCategory object reference.
     *
     * @param categoryId The ID of the category to add.
     * @param type The type of the category.
     * @return true if the category (and its ancestors) were successfully added or already present, false otherwise.
     */
    public boolean addCategoryToSaved(Long categoryId, String type, String vaId) {
        Optional<Category> categoryToAddOpt = categoryRepository.findByIdAndType(categoryId, type);
        if (categoryToAddOpt.isPresent()) {
            Category categoryToAdd = categoryToAddOpt.get();
            // Only add if this exact category is not already a leaf in savedCategories
            boolean alreadyLeaf = savedCategoriesRepository.getAllCategories().stream()
                    .anyMatch(cat -> cat.getId().equals(categoryToAdd.getId()) &&
                            (vaId == null || (cat.getVaId() != null && cat.getVaId().equalsIgnoreCase(vaId))));
            if (!alreadyLeaf) {

                addCategoryAndAncestors(categoryToAdd,vaId); // Call the adjusted helper method
            }
            return true;
        }
        return false;
    }

    /**
     * Gets all categories currently marked as "saved".
     * @return A list of saved categories.
     */
    public List<Category> getSavedCategories(String vaId) {
        List<Category> categoryList=savedCategoriesRepository.getAllCategories().stream()
                .filter(category -> vaId == null || (category.getVaId() != null && category.getVaId().equalsIgnoreCase(vaId))).toList();
        return new ArrayList<>(categoryList); // Return a copy
    }



    public void addCategoryAndAncestors(Category category, String vaId) {
        if (category == null) {
            return;
        }
        Long originalDbCategoryId = category.getId();
        OriginalCategoryKey currentCategoryKey = new OriginalCategoryKey(originalDbCategoryId, vaId);

        // If this original DB category has already been processed and mapped, we're done with this branch.
        if (originalDbIdAndVaIdToNewInternalIdMap.containsKey(currentCategoryKey)) {
            return;
        }

        // --- 1. Generate a new internal ID for this category ---
        Long newInternalCategoryId = CategoryRepository.idCounter.incrementAndGet();
        originalDbIdAndVaIdToNewInternalIdMap.put(currentCategoryKey, newInternalCategoryId);

        // --- 2. Determine the new internal parent ID ---
        Long newInternalParentId = null;
        if (category.getParentId() != null) {
            OriginalCategoryKey parentCategoryKey = new OriginalCategoryKey(category.getParentId(), vaId);
            newInternalParentId =  originalDbIdAndVaIdToNewInternalIdMap.get(parentCategoryKey);

        }

        Category processedCategory = new Category(
                newInternalCategoryId,
                newInternalParentId, // May be null initially if parent not processed yet
                category.getName(),
                vaId,
                category.getDescription(),
                category.getType(),
                category.getLevel()

                   );

        savedCategoriesRepository.addCategory(processedCategory);
        if (category.getParentId() != null) {
            OriginalCategoryKey parentCategoryKey = new OriginalCategoryKey(category.getParentId(), vaId);
            if (!originalDbIdAndVaIdToNewInternalIdMap.containsKey(parentCategoryKey)) {
                categoryRepository.findById(category.getParentId())
                        .ifPresent(parentCategory -> {
                            addCategoryAndAncestors(parentCategory, vaId);
                 if (processedCategory.getParentId() == null) {
                                Long updatedParentId = originalDbIdAndVaIdToNewInternalIdMap.get(parentCategoryKey);
                                processedCategory.setParentId(updatedParentId);
                            }
                        });
            } else {
                if (processedCategory.getParentId() == null) { // This handles cases where it was null initially
                    Long updatedParentId = originalDbIdAndVaIdToNewInternalIdMap.get(parentCategoryKey);
                    processedCategory.setParentId(updatedParentId);
                }
            }
        }
    }



    public List<Category> searchEligibleCategoriesByCriteria(String type,String name, Long parentId, Boolean exactMatch) {
        return categoryRepository.searchByCriteria(type,name, parentId, exactMatch);
    }


    /**
     * Removes a category and recursively deletes its parent if it becomes the only child,
     * continuing up the hierarchy until a parent with other children or a top-level parent is encountered.
     *
     * @param categoryId The ID of the category to start deletion from.
     * @param type The type of the category (for initial lookup).
     * @return true if the category (and potentially its ancestors) was successfully removed, false otherwise.
     */
    public boolean removeCategoryFromSaved(Long categoryId, String type, String vaId) {
        Optional<Category> categoryToRemoveOpt = savedCategoriesRepository.getAllCategories().stream()
                .filter(c -> c.getId().equals(categoryId) && (type == null || c.getType() != null && c.getType().equalsIgnoreCase(type))
                        && (vaId == null || c.getVaId() != null && c.getVaId().equalsIgnoreCase(vaId)))
                .findFirst();


        if (categoryToRemoveOpt.isEmpty()) {
            return false; // Category not found or type mismatch in the repository
        }

        Category currentCategoryToDelete = categoryToRemoveOpt.get();
        Long categoryIdToDelete = currentCategoryToDelete.getId(); // Start with the initial category's ID

        // Loop upwards through the hierarchy
        while (categoryIdToDelete != null) {
            Long finalCategoryIdToDelete = categoryIdToDelete;
            Optional<Category> targetCategoryOpt = savedCategoriesRepository.getAllCategories().stream()
                    .filter(c -> c.getId().equals(finalCategoryIdToDelete))
                    .findFirst();

            if (targetCategoryOpt.isEmpty()) {
                break; // Category not found in the repository, stop climbing
            }

            Category targetCategory = targetCategoryOpt.get();
            Long parentIdOfTarget = targetCategory.getParentId();
            deleteCategoryAndChildrenRecursive(targetCategory.getId());
            if (parentIdOfTarget != null && parentIdOfTarget != 0) {
                Optional<Category> parentOpt = savedCategoriesRepository.getAllCategories().stream()
                        .filter(c -> c.getId().equals(parentIdOfTarget))
                        .findFirst();
                if (parentOpt.isPresent()) {
                    Category parent = parentOpt.get();
                    List<Category> childrenOfParent = savedCategoriesRepository.getAllCategories().stream()
                            .filter(c -> c.getParentId() != null && c.getParentId().equals(parent.getId()))
                            .collect(Collectors.toList());


                    if (childrenOfParent.isEmpty()) {
                        categoryIdToDelete = parent.getId();
                    } else {
                        categoryIdToDelete = null; // Exit loop
                    }
                } else {
                    categoryIdToDelete = null; // Exit loop
                }
            } else {
                categoryIdToDelete = null; // Exit loop
            }
        }

        return true; // Operation started successfully (even if no deletes happened for some reason)
    }


    /**
     * Searches within the "saved" categories based on a query string.
     * @param query The search string.
     * @return A list of saved categories matching the query.
     */
    public List<Category> searchSavedCategories(String query, String type, String vaId) {
        savedCategoriesRepository.getAllCategories().forEach(Category::clearChildren);
        List<Category> allCategories = savedCategoriesRepository.getAllCategories().stream()
                .filter(c -> type == null || (c.getType() != null && c.getType().equalsIgnoreCase(type)))
                .filter(c -> vaId == null || (c.getVaId() != null && c.getVaId().equalsIgnoreCase(vaId)))
                .filter(category ->
                        (category.getName() != null && category.getName().toLowerCase().contains(query.toLowerCase()))
                )
                .toList();
        Map<Long, Category> categoryMap = allCategories.stream()
                .collect(Collectors.toMap(Category::getId, category -> category));

        List<Category> topLevelCategories = new ArrayList<>();

        for (Category category : allCategories) {

            if (category.getParentId() == null || category.getParentId() == 0) {
                topLevelCategories.add(category);
            } else {
                Category parent = categoryMap.get(category.getParentId());
                //categoryMap.get(2L);
                if (parent != null) {
                    parent.addChild(category);
                } else {
                    topLevelCategories.add(category); // If no parent found, add as top-level
                }
            }
        }
        return topLevelCategories;
    }

    @Override
    public boolean existsById(Long id, String vaId) {
        return savedCategoriesRepository.getAllCategories().stream()
                .anyMatch(category -> category.getId().equals(id) && (vaId == null
                        || (category.getVaId() != null && category.getVaId().equalsIgnoreCase(vaId))));
    }


}



