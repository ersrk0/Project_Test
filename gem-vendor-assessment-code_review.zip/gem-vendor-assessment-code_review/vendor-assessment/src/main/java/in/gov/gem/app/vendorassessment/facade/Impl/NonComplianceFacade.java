
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.vendorassessment.dto.response.NonComplianceNewResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.NonComplianceResponseDTO;
import in.gov.gem.app.vendorassessment.service.INonComplianceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import in.gov.gem.app.vendorassessment.facade.INonComplianceFacade;
import java.util.List;

/**
 * The type Non compliance facade.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class NonComplianceFacade implements INonComplianceFacade {

    private final INonComplianceService nonComplianceService;
    @Override
    public NonComplianceNewResponseDTO fieldsWithOpenNonClosure(Long sellerId) {
        return nonComplianceService.fieldsWithOpenNonClosure(sellerId);
    }
    @Override
    public List<NonComplianceResponseDTO> nonCompliantFields(Long vaMasterFk) {
        return nonComplianceService.nonCompliantFields(vaMasterFk);
    }
}