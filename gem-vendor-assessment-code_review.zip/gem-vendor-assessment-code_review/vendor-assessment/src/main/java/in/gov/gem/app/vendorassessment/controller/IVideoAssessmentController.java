
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;
import in.gov.gem.app.service.dto.APIResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * APIs for video assessment operations.
 */
@Tag(name = "Video Assessment", description = "APIs for video assessment instructions, app download, and scheduling")
@RequestMapping("/v1/video-assessments")
@RestController
public interface IVideoAssessmentController {
  /**
   * Fetches video assessment instructions for a seller.
   *
   * @param sellerId Seller ID for which instructions are to be fetched
   * @return API response containing video assessment instructions
   */
  @Operation(
    summary = "Get video assessment instructions",
    description = "Fetches instructions for video assessment for a given seller.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(
    name = "sellerId",
    description = "Seller ID for which instructions are to be fetched",
    required = true,
    in = ParameterIn.QUERY
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Guidelines not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/instruction")
  ResponseEntity<APIResponse<Object>> getInstructions(
    @Parameter(description = "Seller ID", required = true) @RequestParam String sellerId
  );

  /**
   * Get the app download link for video assessment.
   ** @return API response containing the app download link
   */

  @Operation(
    summary = "Get app download link",
    description = "Fetches the app download link for video assessment.",
    security = @SecurityRequirement(name = "bearerAuth")
  )

  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Guidelines not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/downloadAppLink")
  ResponseEntity<APIResponse<Object>> getAppDownloadLink();

  /**
   * Fetch the scheduled video assessment.
   * @return API response containing scheduled video assessment details
   */
  @Operation(
    summary = "Fetch scheduled assessment",
    description = "Fetches the scheduled video assessment details.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Guidelines not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/schedule")
  ResponseEntity<APIResponse<Object>> fetchScheduleAssessment();
}
 