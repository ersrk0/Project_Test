
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;


import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.utility.MessageUtility;

import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.domain.entity.Question;
import in.gov.gem.app.vendorassessment.dto.request.QuestionDto;
import in.gov.gem.app.vendorassessment.dto.request.QuestionRequestDto;
import in.gov.gem.app.vendorassessment.dto.request.SaveResponsesRequestDto;
import in.gov.gem.app.vendorassessment.dto.response.QuestionResponseDto;
import in.gov.gem.app.vendorassessment.dto.response.QuestionnaireResponse;
import in.gov.gem.app.vendorassessment.facade.IQuestionnaireFacade;
import in.gov.gem.app.vendorassessment.service.ICategoryService;
import in.gov.gem.app.vendorassessment.service.IQuestionnaireService;
import in.gov.gem.app.vendorassessment.utility.MapperUtil;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
public class QuestionnaireFacadeImpl implements IQuestionnaireFacade {

    private final IQuestionnaireService questionnaireService;
    private final MessageUtility messageUtility;

    public QuestionnaireFacadeImpl(IQuestionnaireService questionnaireService, ICategoryService categoryService, MessageUtility messageUtility) {
        this.questionnaireService = questionnaireService;
        this.messageUtility = messageUtility;
    }

    /**
     * Fetches questions for a given category ID.
     * If no questions exist, returns a list with default questions.
     *
     * @param categoryId the ID of the category to fetch questions for
     * @return List of QuestionDto objects
     */
    @Override
    public List<QuestionDto> getQuestionsForCategory(Long categoryId) {
        return questionnaireService.getQuestionsForCategory(categoryId).stream()
                .map(MapperUtil::toQuestionDto)
                .collect(Collectors.toList());
    }


    @Override
    public List<QuestionResponseDto> getSavedResponsesForCategory(Long categoryId) {
        // Fetch questions for validation and to ensure all questions in category are considered
        List<Question> categoryQuestions = questionnaireService.getQuestionsForCategory(categoryId);
        Map<Long, Question> questionMap = categoryQuestions.stream()
                .collect(Collectors.toMap(Question::getId, Function.identity()));

        List<QuestionnaireResponse> savedResponses = questionnaireService.getResponsesForCategory(categoryId);

        // Map saved responses to DTOs, ensuring only responses for valid questions are returned
        return savedResponses.stream()
                .filter(res -> questionMap.containsKey(res.getQuestionId())) // Ensure response maps to a valid question in the category
                .map(MapperUtil::toQuestionResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public void saveQuestionnaireResponses(Long categoryId, SaveResponsesRequestDto requestDto) {
        List<Question> categoryQuestions = questionnaireService.getQuestionsForCategory(categoryId);
        Map<Long, Question> questionMap = categoryQuestions.stream()
                .collect(Collectors.toMap(Question::getId, Function.identity()));

        for (QuestionResponseDto responseDto : requestDto.getResponses()) {
            Long questionId = responseDto.getQuestionId();
            String answer = responseDto.getAnswer();

            Question question = questionMap.get(questionId);
            if (question == null) {
                throw new ServiceException(
                        MessageConstant.UNEXPECTED_ERROR,
                        messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                        ErrorConstant.CATEGORY.BV,
                        ErrorConstant.SEVERITY.I
                );
            }

            // Basic validation: Check if required and answer is provided
            if (question.isRequired() && (answer == null || answer.trim().isEmpty())) {
                throw new ServiceException(
                        MessageConstant.UNEXPECTED_ERROR,
                        messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                        ErrorConstant.CATEGORY.BV,
                        ErrorConstant.SEVERITY.I
                );            }

            // You can add more specific type-based validation here (e.g., boolean, number)
            if ("boolean".equals(question.getQuestionType())) {
                if (!("true".equalsIgnoreCase(answer) || "false".equalsIgnoreCase(answer) || answer == null || answer.trim().isEmpty())) {
                    throw new ServiceException(
                            MessageConstant.UNEXPECTED_ERROR,
                            messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                            ErrorConstant.CATEGORY.BV,
                            ErrorConstant.SEVERITY.I
                    );                }
            }
            // Add more validation logic as per your question types

            questionnaireService.saveOrUpdateResponse(categoryId, questionId, answer);
        }
    }


    @Override
    public QuestionDto saveQuestion(Long categoryId, QuestionRequestDto requestDto) {
        Question question;
        if (requestDto.getQuestionId() != null) {
            // For update, fetch existing question and ensure it belongs to the category
            question = questionnaireService.getQuestionById(requestDto.getQuestionId())
                    .orElseThrow(() ->  new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            ));
            if (!question.getCategoryId().equals(categoryId)) {

                throw new ServiceException(
                        MessageConstant.UNEXPECTED_ERROR,
                        messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                        ErrorConstant.CATEGORY.BV,
                        ErrorConstant.SEVERITY.I
                );            }
        } else {
            // For creation
            question = new Question();
        }

        // Map DTO fields to entity. ID is handled by persistence layer for new entities.
        question.setQuestionText(requestDto.getQuestionText());
        question.setQuestionType(requestDto.getQuestionType());
        question.setRequired(requestDto.getIsRequired());
        question.setSubHeading(requestDto.getSubHeading());
        question.setAssociatedInfoMessage(requestDto.getAssociatedInfoMessage());

        Question savedQuestion = questionnaireService.saveQuestion(categoryId, question);
        return MapperUtil.toQuestionDto(savedQuestion);
    }

    @Override
    public void deleteQuestion(Long categoryId, Long questionId) {
        questionnaireService.deleteQuestion(questionId);
    }
}

