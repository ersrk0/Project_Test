
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;

import in.gov.gem.app.vendorassessment.controller.ICategoryWorkExperienceController;
import in.gov.gem.app.vendorassessment.dto.request.CategoryWorkExperienceRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.WorkExperienceCategoryMappingDTO;
import in.gov.gem.app.vendorassessment.dto.response.CategoryWorkExperienceResponseDTO;
import in.gov.gem.app.vendorassessment.facade.ICategoryWorkExperienceFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CategoryWorkExperienceController implements ICategoryWorkExperienceController {

  private final ICategoryWorkExperienceFacade workExperienceFacade;

  @Autowired
  public CategoryWorkExperienceController(ICategoryWorkExperienceFacade workExperienceFacade) {
    this.workExperienceFacade = workExperienceFacade;
  }

  /**
   * Creates a new work experience entry.
   * @param requestDTO The DTO containing work experience details.
   * @return ResponseEntity with the created WorkExperienceResponseDTO and HTTP status 201 (Created).
   */
  @Override
  public ResponseEntity<APIResponse<Object>> createWorkExperience(CategoryWorkExperienceRequestDTO requestDTO) {
    return ResponseEntity.ok().body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.WORK_EXPERIENCE_CREATED_MESSAGE)
            .data(workExperienceFacade.createWorkExperience(requestDTO))
            .build());
  }

  /**
   * Retrieves a work experience by its ID.
   * @param id The ID of the work experience from the path variable.
   * @return ResponseEntity with the WorkExperienceResponseDTO and HTTP status 200 (OK),
   * or 404 (Not Found) if the work experience does not exist.
   */
  @Override
  public ResponseEntity<APIResponse<Object>> getWorkExperienceById(String id) {
    CategoryWorkExperienceResponseDTO responseDTO = workExperienceFacade.getWorkExperienceById(id);
    if (responseDTO != null) {
      return ResponseEntity.ok().body(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.OK.getReasonPhrase())
              .httpStatus(HttpStatus.OK.value())
              .message(ApplicationConstant.FETCH_MESSAGE)
              .data(responseDTO)
              .build());
    }
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.NOT_FOUND.getReasonPhrase())
            .httpStatus(HttpStatus.NOT_FOUND.value())
            .message(ApplicationConstant.WORK_EXPERIENCE_NOT_FOUND_MESSAGE)
            .data(null)
            .build());

  }

  /**
   * Retrieves all work experience entries.
   * @return ResponseEntity with a list of WorkExperienceResponseDTOs and HTTP status 200 (OK).
   */
  @Override
  public ResponseEntity<APIResponse<Object>> getAllWorkExperiences() {

    return ResponseEntity.ok().body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.FETCH_MESSAGE)
            .data(workExperienceFacade.getAllWorkExperiences())
            .build());

  }

  /**
   * Updates an existing work experience.
   * @param id The ID of the work experience to update from the path variable.
   * @param requestDTO The DTO with updated details from the request body.
   * @return ResponseEntity with the updated WorkExperienceResponseDTO and HTTP status 200 (OK),
   * or 404 (Not Found) if the work experience does not exist.
   */
  @Override
  public ResponseEntity<APIResponse<Object>> updateWorkExperience(String id, CategoryWorkExperienceRequestDTO requestDTO) {
    CategoryWorkExperienceResponseDTO responseDTO = workExperienceFacade.updateWorkExperience(id, requestDTO);
    if (responseDTO != null && !"Not Found or Failed to Update".equals(responseDTO.getStatus())) {
      return ResponseEntity.ok().body(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.OK.getReasonPhrase())
              .httpStatus(HttpStatus.OK.value())
              .message(ApplicationConstant.FETCH_MESSAGE)
              .data(responseDTO)
              .build());
    }
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.NOT_FOUND.getReasonPhrase())
            .httpStatus(HttpStatus.NOT_FOUND.value())
            .message(ApplicationConstant.WORK_EXPERIENCE_NOT_FOUND_MESSAGE)
            .data(null)
            .build());
  }

  /**
   * Deletes a work experience by its ID.
   * @param id The ID of the work experience to delete from the path variable.
   * @return ResponseEntity with HTTP status 204 (No Content) on successful deletion,
   * or 404 (Not Found) if the work experience does not exist.
   */
  @Override
  public ResponseEntity<APIResponse<Object>> deleteWorkExperience(String id) {
    CategoryWorkExperienceResponseDTO responseDTO = workExperienceFacade.deleteWorkExperience(id);
    if (responseDTO != null && "Deleted".equals(responseDTO.getStatus())) {
      return ResponseEntity.ok().body(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.OK.getReasonPhrase())
              .httpStatus(HttpStatus.OK.value())
              .message(ApplicationConstant.WORK_EXPERIENCE_DELETED_MESSAGE)
              .data(responseDTO)
              .build());
    }
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.NOT_FOUND.getReasonPhrase())
            .httpStatus(HttpStatus.NOT_FOUND.value())
            .message(ApplicationConstant.WORK_EXPERIENCE_NOT_FOUND_MESSAGE)
            .data(null)
            .build());
  }

  /**
   * Maps categories to a specific work experience.
   * @param workExperienceId The ID of the work experience to map categories to.
   * @param mappingDTO The DTO containing the list of category IDs.
   * @return ResponseEntity with the updated WorkExperienceResponseDTO including mapped categories
   * and HTTP status 200 (OK), or 404 (Not Found) if the work experience does not exist.
   */
  @Override
  public ResponseEntity<APIResponse<Object>> mapCategoriesToWorkExperience(
          String workExperienceId,
          WorkExperienceCategoryMappingDTO mappingDTO) {
    CategoryWorkExperienceResponseDTO responseDTO = workExperienceFacade.mapCategoriesToWorkExperience(workExperienceId, mappingDTO);
    if (responseDTO != null) {
      return ResponseEntity.ok().body(APIResponse.builder()
              .msId(ApplicationConstant.MSID)
              .status(HttpStatus.OK.getReasonPhrase())
              .httpStatus(HttpStatus.OK.value())
              .message(ApplicationConstant.WORK_EXPERIENCE_CATEGORIES_MAPPED_MESSAGE)
              .data(responseDTO)
              .build());
    }
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.NOT_FOUND.getReasonPhrase())
            .httpStatus(HttpStatus.NOT_FOUND.value())
            .message(ApplicationConstant.WORK_EXPERIENCE_NOT_FOUND_MESSAGE)
            .data(null)
            .build());
  }

  /**
   * Retrieves a work experience along with its mapped categories.
   * @param id The ID of the work experience.
   * @return ResponseEntity with the WorkExperienceResponseDTO including mapped category details
   * and HTTP status 200 (OK), or 404 (Not Found) if the work experience does not exist.
   */
  @Override
  public ResponseEntity<APIResponse<Object>> getWorkExperienceWithMappedCategories(String id) {
    return ResponseEntity.ok().body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.FETCH_MESSAGE)
            .data(workExperienceFacade.getWorkExperienceWithMappedCategories(id))
            .build());

  }
}
