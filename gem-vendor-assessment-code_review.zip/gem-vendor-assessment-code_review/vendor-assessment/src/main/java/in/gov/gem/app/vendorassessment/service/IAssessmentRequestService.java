
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.request.AssessmentNewRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.AssessmentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OrganisationDetailsRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ReSendRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.MobileOtpValidationRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OTPValidateRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ManufacturingLocationDecisionRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.ResendOtpResponseDTO;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;

/**
 * The interface Assessment request service.
 */
public interface IAssessmentRequestService {
  /**
   * Create assessment request assessment new request dto.
   *
   * @param requestDTO the request dto
   * @return the assessment new request dto
   */
  AssessmentNewRequestDTO createAssessmentRequest(AssessmentRequestDTO requestDTO);

  /**
   * Update manufacturing location decision manufacturing location decision request dto.
   *
   * @param decision the decision
   * @return the manufacturing location decision request dto
   */
  ManufacturingLocationDecisionRequestDTO updateManufacturingLocationDecision(ManufacturingLocationDecisionRequestDTO decision);

  /**
   * Gets organization details.
   *
   * @param vaId the va id
   * @return the organization details
   */
  OrganisationDetailsRequestDTO getOrganizationDetails(String vaId);

  /**
   * Send otp inter response entity.
   *
   * @param email the email
   * @return the response entity
   */
  ResponseEntity<APIResponse<OtpResponseDTO>> sendOtpInter(String email);

  /**
   * Resend otp inter response entity.
   *
   * @param reSendRequestDTO the re send request dto
   * @return the response entity
   */
  ResponseEntity<APIResponse<ResendOtpResponseDTO>> resendOtpInter(@Valid ReSendRequestDTO reSendRequestDTO);

  /**
   * Validate otp string.
   *
   * @param otpValidateRequestDTO the otp validate request dto
   * @param vaId                  the va id
   * @param email                 the email
   * @return the string
   */
  String validateOtp(OTPValidateRequestDTO otpValidateRequestDTO, String vaId, String email);

  /**
   * Validate otp mobile string.
   *
   * @param mobileOtpValidationRequestDTO the mobile otp validation request dto
   * @param vaId                          the va id
   * @param mobileNumber                  the mobile number
   * @return the string
   */
  String validateOtpMobile(MobileOtpValidationRequestDTO mobileOtpValidationRequestDTO, String vaId, String mobileNumber);
}