
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.dto.response.VendorDashboardDTOResponseDTO;
import in.gov.gem.app.vendorassessment.controller.IVendorDashboardController;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.facade.Impl.VendorDashboardFacade;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * The type Vendor dashboard controller.
 */
@RestController
@RequiredArgsConstructor

public class VendorDashboardController extends BaseParentController implements IVendorDashboardController {

    private final VendorDashboardFacade vendorDashboardFacade;

    @Override
    public ResponseEntity<PageableApiResponse<List<VendorDashboardDTOResponseDTO>>> getAllVendorAssessments(
            @Valid PaginationParams paginationParams) {

        Page<VendorDashboardDTOResponseDTO> pageResponse = vendorDashboardFacade.getAllVendorAssessments(paginationParams);

        return ResponseEntity.ok().body(PageableApiResponse.<List<VendorDashboardDTOResponseDTO>>pageableApiResponseBuilder()
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.DASHBOARD_MESSAGE)
                .msId(ApplicationConstant.MSID)
                .data(pageResponse.getContent())
                .currentPage(pageResponse.getNumber())
                .totalPages(pageResponse.getTotalPages())
                .currentElements(pageResponse.getNumberOfElements())
                .hasNext(pageResponse.hasNext())
                .build());
    }

    @Override
    public ResponseEntity<APIResponse<VendorDashboardDTOResponseDTO>> getVendorAssessmentByVaNumber(@Valid String vaNumber) {

        Optional<VendorDashboardDTOResponseDTO> vendorDashboardDTO = vendorDashboardFacade.getVendorAssessmentByVaNumber(vaNumber);

        return ResponseEntity.ok().body(APIResponse.<VendorDashboardDTOResponseDTO>builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.VENDOR_ASSESSMENT_FETCHED)
                .data(vendorDashboardDTO.orElse(null))
                .build());
    }

    @Override
    public ResponseEntity<APIResponse<List<Map<String, Object>>>> getCategoryDetails(String vaNumber) {

        List<Map<String, Object>> categories = vendorDashboardFacade.getCategories(vaNumber);

        return ResponseEntity.ok().body(APIResponse.<List<Map<String, Object>>>builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(categories.isEmpty() ? ApplicationConstant.CATEGORIES_FETCHED_EMPTY : ApplicationConstant.CATEGORIES_FETCHED)
                .data(categories)
                .build());
    }

    @Override
    public ResponseEntity<APIResponse<String>> deleteVendorAssessment(String vendorId) {

        vendorDashboardFacade.deleteVendorAssessment(vendorId);

        return ResponseEntity.ok().body(APIResponse.<String>builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.DELETED_VENDOR_ASSESSMENT)
                .data(ApplicationConstant.DELETED_VENDOR_ASSESSMENT)
                .build());
    }
}