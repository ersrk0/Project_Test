
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service;


import org.springframework.data.domain.Page;

import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.request.AddBodDocumentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.AdditionalDocumentResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.DocumentDetailResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.SaveAdditionalDocumentResponseDTO;

import org.springframework.http.ResponseEntity;

import java.util.List;

/**
 * The interface Organization additional detail service.
 */
public interface IOrganizationAdditionalDetailService
{
  /**
   * Gets additional document question.
   *
   * @param lookupCode the lookup code
   * @return the additional document question
   */
  public String getAdditionalDocumentQuestion(String lookupCode);

  //public List<AdditionalDocumentResponse> getDebarredAndBlacklistedDocuments(Long vaMasterId);

  /**
   * Delete bod document.
   *
   * @param vaMasterFk the va master fk
   * @param docName    the doc name
   */
  void deleteBodDocument(Long vaMasterFk, String docName);

  /**
   * Add bod document save additional document response dto.
   *
   * @param request the request
   * @return the save additional document response dto
   */
  public SaveAdditionalDocumentResponseDTO addBodDocument(AddBodDocumentRequestDTO request);

  /**
   * Export to excel response entity.
   *
   * @param bodDocumentResponses the bod document responses
   * @return the response entity
   */
  ResponseEntity<byte[]> exportToExcel(List<AdditionalDocumentResponseDTO> bodDocumentResponses);

  /**
   * By va master fk page.
   *
   * @param vaMasterFk       the va master fk
   * @param paginationParams the pagination params
   * @return the page
   */
  public Page<DocumentDetailResponseDTO> ByVaMasterFk(Long vaMasterFk, PaginationParams paginationParams);

}

