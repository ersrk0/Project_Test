
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;

/**
 * The interface Consent facade.
 */
public interface IConsentFacade
{

  /**
   * Gets consent data.
   *
   * @param acceptLanguage the accept language
   * @param module         the module
   * @param functionality  the functionality
   * @return the consent data
   */
  public boolean getConsentData(String acceptLanguage, String module, String functionality);

  /**
   * Gets view data.
   *
   * @param consentCode    the consent code
   * @param acceptLanguage the accept language
   * @return the view data
   */
  public Object getViewData(String consentCode, String acceptLanguage);
}
