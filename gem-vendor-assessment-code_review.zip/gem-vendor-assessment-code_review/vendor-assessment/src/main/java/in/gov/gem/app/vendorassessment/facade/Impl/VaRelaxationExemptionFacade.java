
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.domain.entity.VaDocumentDetailEntity;
import in.gov.gem.app.vendorassessment.domain.entity.VaRelaxationExemptionEntity;
import in.gov.gem.app.vendorassessment.domain.repository.DocumentDetailRepository;
import in.gov.gem.app.vendorassessment.domain.repository.VendorRelaxationExemptionRepository;
import in.gov.gem.app.vendorassessment.dto.request.CommonVaDocumentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.*;
import in.gov.gem.app.vendorassessment.facade.IVaRelaxationExemptionFacade;
import in.gov.gem.app.vendorassessment.service.impl.DocumentService;
import in.gov.gem.app.vendorassessment.service.impl.RelaxationCriteriaService;
import in.gov.gem.app.vendorassessment.service.impl.VaRelaxationExemptionService;
import in.gov.gem.app.vendorassessment.utility.Helper;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

/**
 * Implementation of the VaRelaxationExemptionFacade.
 * This class acts as a facade, providing a simplified interface to the
 * VaRelaxationExemptionService and handling basic error propagation.
 */
@Component
@AllArgsConstructor
public class VaRelaxationExemptionFacade implements IVaRelaxationExemptionFacade
{
  private final VaRelaxationExemptionService vaRelaxationExemptionService;
  private final VendorRelaxationExemptionRepository vendorRelaxationExemptionRepository;
  private final MessageUtility messageUtility;
  private final Helper helper;
  private final DocumentDetailRepository documentDetailRepository;
  private final DocumentService documentService;
  private final RelaxationCriteriaService relaxationCriteriaService;

  /**
   * Retrieves a VA Relaxation Exemption by its ID.
   * Delegates to the service layer and handles not found scenarios.
   * @param id The ID of the exemption to retrieve.
   * @return The exemption entity if found.
   * @throws RuntimeException if the exemption is not found.
   */
  @Override
  public VaRelaxationExemptionResponseDto getRelaxationExemptionById(Long id, String lookUpCode) {
    VaRelaxationExemptionEntity vaRelaxationExemptionEntity = vaRelaxationExemptionService.getById(id)
      .orElseThrow(() -> new ServiceException(
        MessageConstant.VA_RELAXATION_EXEMPTION_NOT_FOUND,
        messageUtility.getMessage(MessageConstant.VA_RELAXATION_EXEMPTION_NOT_FOUND),
        ErrorConstant.CATEGORY.BV,
        ErrorConstant.SEVERITY.I
      ));
    List<VaDocumentDetailEntity> dtos = documentDetailRepository.findByVaMasterFkAndDocumentTypeLookup(
      vaRelaxationExemptionEntity.getVaMasterFk(),lookUpCode);
    return helper.convertToVaRelaxationExemptionDto(vaRelaxationExemptionEntity,dtos);
  }




  /**
   * Creates a new VA Relaxation Exemption.
   * Delegates to the service layer for creation and handles any exceptions.
   * @param commonVaDocumentRequest The request containing details for the new exemption.
   * @param files List of files to be associated with the exemption.
   * @return The created exemption entity.
   */
  @Override
  public VaRelaxationExemptionEntity updateRelaxationExemption(Long id, CommonVaDocumentRequestDTO commonVaDocumentRequest, List<MultipartFile> files) {
    return saveOrUpdateRelaxationExemption(id, commonVaDocumentRequest, files, true);
  }

  /**
   * Creates a new VA Relaxation Exemption.
   * Delegates to the service layer for creation and handles any exceptions.
   * @param commonVaDocumentRequest The request containing details for the new exemption.
   * @param files List of files to be associated with the exemption.
   * @return The created exemption entity.
   */
  @Override
  public VaRelaxationExemptionEntity createRelaxationExemption(CommonVaDocumentRequestDTO commonVaDocumentRequest, List<MultipartFile> files) {
    return saveOrUpdateRelaxationExemption(null, commonVaDocumentRequest, files, false);
  }

  /**
   * Saves or updates a VA Relaxation Exemption.
   * This method handles both creation and update operations based on the presence of an ID.
   * @param id The ID of the exemption to update, or null for creation.
   * @param commonVaDocumentRequest The request containing details for the exemption.
   * @param files List of files to be associated with the exemption.
   * @param isUpdate Flag indicating whether this is an update operation.
   * @return The saved or updated exemption entity.
   */
  private VaRelaxationExemptionEntity saveOrUpdateRelaxationExemption(Long id, CommonVaDocumentRequestDTO commonVaDocumentRequest, List<MultipartFile> files, boolean isUpdate) {
    try {
      if (commonVaDocumentRequest == null || commonVaDocumentRequest.getVaMasterFk() == null) {
        throw new ServiceException(
          MessageConstant.VA_MASTER_FK_NOT_FOUND,
          messageUtility.getMessage(MessageConstant.VA_MASTER_FK_NOT_FOUND),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.I
        );
      }
      VaRelaxationExemptionEntity entity = getVaRelaxationExemptionEntity(commonVaDocumentRequest);
      saveOrUpdateRelaxationExemptionDocuments(commonVaDocumentRequest, files);
      if (isUpdate) {
        return vaRelaxationExemptionService.update(id, entity);
      } else {
        return vaRelaxationExemptionService.create(entity);
      }
    } catch (IllegalArgumentException e) {
      throw new ServiceException(
        MessageConstant.VA_RELAXATION_EXEMPTION_NOT_FOUND,
        messageUtility.getMessage(MessageConstant.VA_RELAXATION_EXEMPTION_NOT_FOUND),
        ErrorConstant.CATEGORY.BV,
        ErrorConstant.SEVERITY.I
      );
    }
  }

  /**
   * Saves or updates the relaxation exemption documents associated with a VA Relaxation Exemption.
   * This method handles both the creation of new documents and the update of existing ones.
   * @param commonVaDocumentRequest The request containing details for the documents.
   * @param files List of files to be associated with the exemption.
   */
  private void saveOrUpdateRelaxationExemptionDocuments(
    CommonVaDocumentRequestDTO commonVaDocumentRequest, List<MultipartFile> files) {
    List<VaDocumentDetailEntity> existingDocs = documentDetailRepository.findByVaMasterFkAndDocumentTypeLookup(
      commonVaDocumentRequest.getVaMasterFk(), commonVaDocumentRequest.getDocumentTypeLookup());

    if (files == null || files.isEmpty()) {
      return;
    }

    for (int i = 0; i < files.size(); i++) {
      MultipartFile file = files.get(i);
      validateFileNotEmpty(file);

      VaDocumentDetailEntity docEntity = (i < existingDocs.size())
        ? existingDocs.get(i)
        : new VaDocumentDetailEntity();

      try {
        setDocumentEntityFields(docEntity, file, commonVaDocumentRequest);
      } catch (Exception e) {
        throw new ServiceException(
          MessageConstant.DOCUMENT_NOT_FOUND,
          messageUtility.getMessage(MessageConstant.DOCUMENT_NOT_FOUND),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.I
        );
      }
      documentDetailRepository.save(docEntity);
    }
  }

  /**
   * Validates that the provided file is not empty.
   * Throws a ServiceException if the file is empty.
   * @param file The file to validate.
   */
  private void validateFileNotEmpty(MultipartFile file) {
    if (file.isEmpty()) {
      throw new ServiceException(
        MessageConstant.FILE_EMPTY,
        messageUtility.getMessage(MessageConstant.FILE_EMPTY),
        ErrorConstant.CATEGORY.BV,
        ErrorConstant.SEVERITY.I
      );
    }
  }

  /**
   * Sets the fields of the VaDocumentDetailEntity based on the provided file and request.
   * This method handles file naming, path creation, and entity field population.
   * @param docEntity The VaDocumentDetailEntity to populate.
   * @param file The file to process.
   * @param request The request containing additional details for the document.
   */
  private void setDocumentEntityFields(VaDocumentDetailEntity docEntity, MultipartFile file, CommonVaDocumentRequestDTO request){
    try {
      String originalFileName = file.getOriginalFilename();
      String sanitizedFileName = (originalFileName == null ? "unknown" : originalFileName.replaceAll("[^a-zA-Z0-9_\\-\\.]", "_"));
      String uniqueFileName = UUID.randomUUID() + "_" + sanitizedFileName;
      Path uploadPath = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
      Files.createDirectories(uploadPath);
      Path filePath = uploadPath.resolve(uniqueFileName);
      Files.copy(file.getInputStream(), filePath);
      docEntity.setVaMasterFk(request.getVaMasterFk());
      docEntity.setDocumentTypeLookup(request.getDocumentTypeLookup());
      docEntity.setDocumentExtensionLookup(request.getDocumentExtensionLookup());
      docEntity.setDocumentPath(filePath.toString());
      docEntity.setNoOfPage(request.getNoOfPage());
      docEntity.setRemark(request.getRemark());
      docEntity.setUploadBy(UUID.randomUUID()); // Replace with actual user UUID
      docEntity.setDocumentName(originalFileName);
      docEntity.setSizeInMb((double) file.getSize() / (1024 * 1024));
    } catch (IOException e){
      throw new ServiceException(
        MessageConstant.FILE_EMPTY,
        messageUtility.getMessage(MessageConstant.FILE_EMPTY),
        ErrorConstant.CATEGORY.BV,
        ErrorConstant.SEVERITY.I
      );
    }

  }
  /**
   * Deletes a VA Relaxation Exemption by its ID.
   * Delegates to the service layer.
   * @param id The ID of the exemption to delete.
   * @return true if the exemption was successfully deleted, false otherwise.
   */
  @Override
  @Transactional
  public boolean deleteRelaxationExemption(Long id,String lookUpCode) {
    VaRelaxationExemptionEntity exemption = vaRelaxationExemptionService.getById(id)
      .orElseThrow(() -> new ServiceException(
        MessageConstant.VA_RELAXATION_EXEMPTION_NOT_FOUND,
        messageUtility.getMessage(MessageConstant.VA_RELAXATION_EXEMPTION_NOT_FOUND),
        ErrorConstant.CATEGORY.BV,
        ErrorConstant.SEVERITY.I
      ));
//    List<VaDocumentDetailEntity> docs = documentDetailRepository.findByVaMasterFkAndDocumentTypeLookup(
//      exemption.getVaMasterFk(), lookUpCode);
//    documentService.deleteInBulk(docs);
    return vaRelaxationExemptionService.delete(id);
  }

  /**
   * Converts a Page of DocumentDetailDTO to a Page of DocumentResponse.
   * This method maps each DocumentDetailDTO to a DocumentResponse, including
   * fetching associated VaRelaxationExemptionEntity.
   * @param page The Page of DocumentDetailDTO to convert.
   * @return A Page of DocumentResponse.
   */
  public Page<DocumentNewResponseDTO> convertToDocumentRes(Page<DocumentDetailResponseDTO> page) {
    return page.map(documentDetailDTO -> {
      List<VaRelaxationExemptionEntity> vaRelaxationExemptionEntities=vendorRelaxationExemptionRepository.findByVaMasterFk(documentDetailDTO.getVaMasterFk());
      if (vaRelaxationExemptionEntities.isEmpty()) {
        throw new ServiceException(
          MessageConstant.VA_RELAXATION_EXEMPTION_NOT_FOUND,
          messageUtility.getMessage(MessageConstant.VA_RELAXATION_EXEMPTION_NOT_FOUND),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.I
        );
      }
      return getDocumentResponse(documentDetailDTO, vaRelaxationExemptionEntities);

    });

  }
  /**
   * Retrieves issuing authorities based on the provided lookup code.
   * This method delegates to the relaxationCriteriaService to fetch the authorities.
   * @param lookUpCode The lookup code for which to retrieve issuing authorities.
   * @return A CriteriaLicenseInfo object containing the issuing authorities.
   */
  @Override
  public CriteriaLicenseInfoResponseDTO getIssuingAuthorities(String lookUpCode){
    return (CriteriaLicenseInfoResponseDTO) relaxationCriteriaService.getIssuingAuthorities(lookUpCode);

  }

  /**
   * Checks the eligibility of criteria based on the provided flag.
   * This method delegates to the relaxationCriteriaService to validate the criteria.
   * @param eligible The flag indicating whether to check for eligible criteria.
   * @return A list of CriteriaTypeDTO representing the validated criteria.
   */
  @Override
  public List<CriteriaTypeResponseDTO> checkEligibilityByFlag(boolean eligible){
    return (List<CriteriaTypeResponseDTO>) relaxationCriteriaService.validateCriteria(eligible);
  }

  /**
   * Retrieves draft eligibility information based on the provided VA ID.
   * This method delegates to the relaxationCriteriaService to fetch the draft eligibility.
   *
   * @param vAId The VA ID for which to retrieve draft eligibility.
   * @return A DraftEligibilityResponse containing the draft eligibility information.
   */
  @Override
  public DraftEligibilityResponseDTO getDraftEligibility(Long vAId){
    return relaxationCriteriaService.getDraftEligibility(vAId);
  }




  /**
   * Constructs a DocumentResponse from the provided DocumentDetailDTO and VaRelaxationExemptionEntity.
   * This method populates the DocumentResponse fields based on the DTO and entity data.
   * @param documentDetailDTO The DocumentDetailDTO containing document details.
   * @param vaRelaxationExemptionEntities The list of VaRelaxationExemptionEntity associated with the document.
   * @return A populated DocumentResponse object.
   */
  private DocumentNewResponseDTO getDocumentResponse(DocumentDetailResponseDTO documentDetailDTO, List<VaRelaxationExemptionEntity> vaRelaxationExemptionEntities) {
    VaRelaxationExemptionEntity vaRelaxationExemptionEntity = vaRelaxationExemptionEntities.getFirst();
    DocumentNewResponseDTO documentResponse = new DocumentNewResponseDTO();
    documentResponse.setId(documentDetailDTO.getId());
    documentResponse.setValidUpto(String.valueOf(vaRelaxationExemptionEntity.getExpiryDate()));
    documentResponse.setIssuingAuthority(vaRelaxationExemptionEntity.getIssuingAuthority());
    //documentResponse.setVaMasterFk(documentDetailDTO.getVaMasterFk());
    documentResponse.setName(documentDetailDTO.getDocumentName());
    documentResponse.setType(documentDetailDTO.getDocumentTypeLookup());
    documentResponse.setSizeInMB(documentDetailDTO.getSizeInMb() ==null ? 0.0 : documentDetailDTO.getSizeInMb());
    return documentResponse;
  }


  /**
   * Constructs a VaRelaxationExemptionEntity from the provided CommonVaDocumentRequest.
   * This method populates the entity fields based on the request data.
   * @param commonVaDocumentRequest The request containing details for the exemption.
   * @return A populated VaRelaxationExemptionEntity.
   */
  private VaRelaxationExemptionEntity getVaRelaxationExemptionEntity(CommonVaDocumentRequestDTO commonVaDocumentRequest) {
    VaRelaxationExemptionEntity entity = new VaRelaxationExemptionEntity();
    //entity.setVaMasterFk(commonVaDocumentRequest.getVaMasterFk());
    entity.setRelaxationTypeLookup(commonVaDocumentRequest.getRelaxationTypeLookup());
    entity.setIssuingAuthority(commonVaDocumentRequest.getIssuingAuthority());
    entity.setLicenseDetail(commonVaDocumentRequest.getLicenseDetail());
    entity.setExpiredAt(Timestamp.from(Instant.now()));
    entity.setRelaxationTypeLookup(commonVaDocumentRequest.getRelaxationTypeLookup());
    entity.setStatusLookup(commonVaDocumentRequest.getStatusLookup());// This should be replaced with the actual user UUID from the session or context
    return entity;
  }


}
