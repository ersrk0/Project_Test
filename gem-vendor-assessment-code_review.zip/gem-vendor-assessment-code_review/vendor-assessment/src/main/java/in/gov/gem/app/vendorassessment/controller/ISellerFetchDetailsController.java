
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */
package in.gov.gem.app.vendorassessment.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressUpdateRequestDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.constraints.Pattern;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Provides APIs for fetching and managing seller details.
 */
@Tag(name = "Seller Details", description = "APIs for fetching and managing seller details")
@RestController
@RequestMapping("/v1/seller")
public interface ISellerFetchDetailsController
{

  /**
   * Checks the seller's profile status.
   *
   * @return the API response with profile status
   */
  @Operation(
    summary = "Check Seller Profile Status",
    description = "Checks the seller's profile status.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/profile/status")
  ResponseEntity<APIResponse<Object>> checkingProfile();

  /**
   * Fetches the seller's profile.
   *
   * @return the API response with profile details
   */
  @Operation(
    summary = "Get Seller Profile",
    description = "Fetches the seller's profile.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/profile")
  ResponseEntity<APIResponse<Object>> getProfileFromSeller() throws JsonProcessingException;

  /**
   * Fetches the seller's PAN details.
   *
   * @return the API response with PAN details
   */
  @Operation(
    summary = "Get Seller PAN",
    description = "Fetches the seller's PAN details.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/pan")
  ResponseEntity<APIResponse<Object>> getPanFromSeller();

  /**
   * Fetches the seller's TAN details.
   *
   * @param paginationParams pagination parameters
   * @return the API response with TAN details
   */
  @Operation(
    summary = "Get Seller TAN",
    description = "Fetches the seller's TAN details.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/tan")
  ResponseEntity<APIResponse<Object>> getTanFromSeller(PaginationParams paginationParams);

  /**
   * Fetches the seller's bank details.
   *
   * @param paginationParams pagination parameters
   * @param languageCode     language code
   * @return the API response with bank details
   */
  @Operation(
    summary = "Get Seller Bank Details",
    description = "Fetches the seller's bank details.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "Accept-Language", description = "Language code", in = ParameterIn.HEADER, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/bank")
  ResponseEntity<APIResponse<Object>> getBankFromSeller(
    PaginationParams paginationParams,
    @RequestHeader(name = "Accept-Language") String languageCode
  );

  /**
   * Fetches the seller's address.
   *
   * @param paginationParams pagination parameters
   * @param vaNumber         VA number (optional)
   * @return the API response with address details
   */
  @Operation(
    summary = "Get Seller Address",
    description = "Fetches the seller's address.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaNumber", description = "VA number", in = ParameterIn.QUERY, required = false)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/address")
  ResponseEntity<APIResponse<Object>> getAddressFromSeller(
    PaginationParams paginationParams,
    @RequestParam(required = false) String vaNumber
  );

  /**
   * Fetches the seller's pre-defined address.
   *
   * @param paginationParams pagination parameters
   * @param vaNumber         VA number (optional)
   * @return the API response with pre-defined address details
   */
  @Operation(
    summary = "Get Seller Pre-Defined Address",
    description = "Fetches the seller's pre-defined address.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaNumber", description = "VA number", in = ParameterIn.QUERY, required = false)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/pre-defined/address")
  ResponseEntity<APIResponse<Object>> getPreDefinedAddressFromSeller(
    PaginationParams paginationParams,
    @RequestParam(required = false) String vaNumber
  );

  /**
   * Saves a new address for the seller.
   *
   * @param officeAddressRequestDTO the address request DTO
   * @return the API response
   */
  @Operation(
    summary = "Save Seller Address",
    description = "Saves a new address for the seller.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/address")
  ResponseEntity<APIResponse<Object>> saveAddressInSeller(
    @RequestBody OfficeAddressRequestDTO officeAddressRequestDTO
  );

  /**
   * Deletes a seller's address by office ID.
   *
   * @param pvtOrgOfficeId the office ID
   * @return the API response
   */
  @Operation(
    summary = "Delete Seller Address",
    description = "Deletes a seller's address by office ID.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "pvtOrgOfficeId", description = "Office ID", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @DeleteMapping("/address")
  ResponseEntity<APIResponse<Object>> deleteAddressInSeller(
    @RequestParam Long pvtOrgOfficeId
  );

  /**
   * Updates a seller's address.
   *
   * @param officeAddressUpdateRequestDTO the address update request DTO
   * @return the API response
   */
  @Operation(
    summary = "Update Seller Address",
    description = "Updates a seller's address.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PutMapping("/address")
  ResponseEntity<APIResponse<Object>> updateAddressInSeller(
    @RequestBody OfficeAddressUpdateRequestDTO officeAddressUpdateRequestDTO
  );

  /**
   * Fetches the list of registered office mobile numbers.
   *
   * @param paginationParams pagination parameters
   * @return the API response with mobile list
   */
  @Operation(
    summary = "Get Registered Office Mobile List",
    description = "Fetches the list of registered office mobile numbers.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/mobile-list")
  ResponseEntity<APIResponse<Object>> getRegisteredOfficeMobileList(PaginationParams paginationParams);

  /**
   * Fetches the list of registered office email addresses.
   *
   * @param paginationParams pagination parameters
   * @return the API response with email list
   */
  @Operation(
    summary = "Get Registered Office Email List",
    description = "Fetches the list of registered office email addresses.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/email-list")
  ResponseEntity<APIResponse<Object>> getRegisteredOfficeEmailList(PaginationParams paginationParams);

  /**
   * Fetches the seller's financial details.
   *
   * @param paginationParams pagination parameters
   * @return the API response with financial details
   */
  @Operation(
    summary = "Get Seller Financial Details",
    description = "Fetches the seller's financial details.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/financial")
  ResponseEntity<APIResponse<Object>> getFinancialFromSeller(PaginationParams paginationParams);

  /**
   * Fetches the seller's turnover details.
   *
   * @return the API response with turnover details
   */
  @Operation(
    summary = "Get Seller Turnover",
    description = "Fetches the seller's turnover details.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/turnover")
  ResponseEntity<APIResponse<Object>> getTurnoverFromSeller();

  /**
   * Fetches the seller's user details.
   *
   * @return the API response with user details
   */
  @Operation(
    summary = "Get Seller User Details",
    description = "Fetches the seller's user details.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/user-details")
  ResponseEntity<APIResponse<Object>> getUserDetails();

  /**
   * Fetches the seller's IP address.
   *
   * @return the API response with IP address
   */
  @Operation(
    summary = "Get Seller IP Address",
    description = "Fetches the seller's IP address.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/ip-address")
  ResponseEntity<APIResponse<Object>> getIPAddress();

  /**
   * Verifies the seller's GSTIN.
   *
   * @param gstin the GSTIN to verify
   * @return the API response with verification result
   */
  @Operation(
    summary = "Verify Seller GSTIN",
    description = "Verifies the seller's GSTIN.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "gstin", description = "GSTIN", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/verify/gstin")
  ResponseEntity<APIResponse<Object>> getVerifyGstin(
    @Pattern(regexp = "^[0-9]{2}[A-Z]{3}[ABCFGHLJPTF]{1}[A-Z]{1}[0-9]{4}[A-Z]{1}[1-9]{1}[A-Z0-9]{2}$", message = "Invalid GSTIN format")
    @RequestParam String gstin
  );

  /**
   * Verifies the seller's manufacturing GSTIN.
   *
   * @param gstin the GSTIN to verify
   * @return the API response with verification result
   */
  @Operation(
    summary = "Verify Seller Manufacturing GSTIN",
    description = "Verifies the seller's manufacturing GSTIN.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "gstin", description = "GSTIN", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/verify/manufacturing/gstin")
  ResponseEntity<APIResponse<Object>> getVerifyManufacturingGstin(
    @Pattern(regexp = "^[0-9]{2}[A-Z]{3}[ABCFGHLJPTF]{1}[A-Z]{1}[0-9]{4}[A-Z]{1}[1-9]{1}[A-Z0-9]{2}$", message = "Invalid GSTIN format")
    @RequestParam String gstin
  );

}
 