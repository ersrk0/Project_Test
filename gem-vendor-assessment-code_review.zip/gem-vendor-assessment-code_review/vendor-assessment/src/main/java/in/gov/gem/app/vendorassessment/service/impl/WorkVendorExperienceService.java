
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;


import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;



import in.gov.gem.app.vendorassessment.dto.request.WorkExperienceNewRequestDTO;

import in.gov.gem.app.vendorassessment.domain.entity.WorkExperienceDetailEntity;
import in.gov.gem.app.vendorassessment.domain.repository.WorkExperienceRepository;
import in.gov.gem.app.vendorassessment.service.IWorkVendorExperienceService;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The type Work vendor experience service.
 */
@AllArgsConstructor
@Service
public class WorkVendorExperienceService implements IWorkVendorExperienceService
{

  private final WorkExperienceRepository repository;

  @Override
  public WorkExperienceNewRequestDTO createWorkExperience(WorkExperienceNewRequestDTO createRequest)
  {

    // 1. Map the DTO (createRequest) to your JPA Entity (WorkExperience)
    WorkExperienceDetailEntity workExperienceEntity = WorkExperienceDetailEntity.builder()
      .vaMasterFk(createRequest.getVaMasterFk())
      .hierarchyId(createRequest.getHierarchyId()) // Corrected: Get hierarchyId from createRequest
      .departmentName(createRequest.getDepartmentName())
      .emailId(createRequest.getEmailId())
      .orderValue(createRequest.getOrderValue())
      .officialName(createRequest.getOfficialName())
      .quantitySupplied(createRequest.getQuantitySupplied())
      .contactNumber(createRequest.getContactNumber())
      .completionLetterNumber(createRequest.getCompletionLetterNumber())
      .itemSupplied(createRequest.getItemSupplied())
      .build();

    WorkExperienceDetailEntity savedEntity = repository.save(workExperienceEntity);

    WorkExperienceNewRequestDTO responseDTO = WorkExperienceNewRequestDTO.builder()
      .id(savedEntity.getId())
      .vaMasterFk(savedEntity.getVaMasterFk())
      .hierarchyId(savedEntity.getHierarchyId())
      .departmentName(savedEntity.getDepartmentName())
      .emailId(savedEntity.getEmailId())
      .orderValue(savedEntity.getOrderValue())
      .officialName(savedEntity.getOfficialName())
      .quantitySupplied(savedEntity.getQuantitySupplied())
      .contactNumber(savedEntity.getContactNumber())
      .completionLetterNumber(savedEntity.getCompletionLetterNumber())
      .itemSupplied(savedEntity.getItemSupplied())
      .build();

    return responseDTO;

  }

  @Override
  public PageableApiResponse<List<WorkExperienceNewRequestDTO>> findByVaMasterFk(Long vaMasterFk, PaginationParams paginationParams)
  {

    PageRequest pageRequest = PageRequest.of(paginationParams.getPageNumber(), paginationParams.getPageSize(),
      Sort.by(paginationParams.getSortOrder(), paginationParams.getSortBy()));

    Page<WorkExperienceDetailEntity> work = repository.findByVaMasterFk(vaMasterFk, pageRequest);

    List<WorkExperienceNewRequestDTO> dtos = work.getContent().stream()
      .map(entity -> WorkExperienceNewRequestDTO.builder()
        .id(entity.getId())
        .vaMasterFk(entity.getVaMasterFk())
        .hierarchyId(entity.getHierarchyId())
        .departmentName(entity.getDepartmentName())
        .emailId(entity.getEmailId())
        .orderValue(entity.getOrderValue())
        .officialName(entity.getOfficialName())
        .quantitySupplied(entity.getQuantitySupplied())
        .contactNumber(entity.getContactNumber())
        .completionLetterNumber(entity.getCompletionLetterNumber())
        .itemSupplied(entity.getItemSupplied())
        .build())
      .collect(Collectors.toList());

    return PageableApiResponse.<List<WorkExperienceNewRequestDTO>>pageableApiResponseBuilder()
      .currentElements(work.getNumberOfElements())
      .hasNext(work.hasNext())
      .totalPages(work.getTotalPages())
      .currentPage(work.getNumber())
      .data(dtos)
      .build();
  }

  @Override
  public List<WorkExperienceNewRequestDTO> findByVaMasterFk(Long vaMasterFk)
  {

    List<WorkExperienceDetailEntity> workExperiences = repository.findByVaMasterFk(vaMasterFk);

    List<WorkExperienceNewRequestDTO> workExperienceDTOs = workExperiences.stream()
      .map(entity -> WorkExperienceNewRequestDTO.builder()
        .id(entity.getId()) // Assuming DTO has ID field
        .vaMasterFk(entity.getVaMasterFk())
        .hierarchyId(entity.getHierarchyId())
        .departmentName(entity.getDepartmentName())
        .emailId(entity.getEmailId())
        .orderValue(entity.getOrderValue())
        .officialName(entity.getOfficialName())
        .quantitySupplied(entity.getQuantitySupplied())
        .contactNumber(entity.getContactNumber())
        .completionLetterNumber(entity.getCompletionLetterNumber())
        .itemSupplied(entity.getItemSupplied())
        .build())
      .collect(Collectors.toList());

    return workExperienceDTOs;
  }
}
