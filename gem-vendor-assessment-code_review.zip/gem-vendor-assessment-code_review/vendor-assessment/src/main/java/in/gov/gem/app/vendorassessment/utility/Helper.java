
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.utility;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.repository.LookupRepository;
import in.gov.gem.app.service.core.security.securityUtils.GemUtility;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.domain.entity.VaDocumentDetailEntity;
import in.gov.gem.app.vendorassessment.domain.entity.VaRelaxationExemptionEntity;
import in.gov.gem.app.vendorassessment.dto.response.CriteriaLicenseInfoResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.DocumentNewResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VaRelaxationExemptionResponseDto;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@AllArgsConstructor
public class Helper
{
  private LookupRepository lookupRepository;
  private MessageUtility messageUtility;



  public static List<CriteriaLicenseInfoResponseDTO> criteriaLicenseList = List.of(
    new CriteriaLicenseInfoResponseDTO(
      "Central/State PSUs",
      "Incorporation Certificate",
      "NA - non mandatory",
      "Please upload Incorporation Certificate or any other document that is applicable"
    ),
    new CriteriaLicenseInfoResponseDTO(
      "OEMs holding BIS License for the particular product category",
      "BIS Certificate",
      "NA - non mandatory",
      "BIS Certificate having a License number"
    ),
    new CriteriaLicenseInfoResponseDTO(
      "Sellers recommended for exemption for specific categories and specified  validity period by any CPSE, Central and State Government Departments/ Authorities.",
      "recommendation letter and certificate",
      "CPSE/Government Departments",
      "Please upload recommendation letter and certificate issued by any CPSE/Government Departments requesting for a vendor assessment exemption"
    ),
    new CriteriaLicenseInfoResponseDTO(
      "Sellers who are Registered Societies/ Trusts other bodies, if these concerns have Government Representation.",
      "Society Registration Certificate",
      "NA - non mandatory",
      "Please upload Society Registration Certificate or Trust deed/agreement or any other document that is applicable"
    ),
    new CriteriaLicenseInfoResponseDTO(
      "Vaccine manufacturer as per list provided by Ministry of Health & Family Welfare",
      "valid drug licence",
      "the issuing/concerned Drug Authority",
      "Please upload Copy of valid drug licence from the issuing/concerned Drug Authority"
    ),
    new CriteriaLicenseInfoResponseDTO(
      "Drugs/Medicine manufacturer with Notarized Undertaking &\n" +
        "     Valid certified copy of Drug Licenses from the issuing/concerned Drug Authority",
      "Drug License",
      "issuing / concerned Drug Authority",
      "The following documents need to be submitted with this application:\n1. Valid Drug License from the issuing / concerned Drug Authority\n2. Undertaking as per the Document Template given above printed and notarized on a non-judicial stamp paper of Rs.10\n\nPlease Note: The two documents above should be combined and uploaded as a single document below."
    ),
    new CriteriaLicenseInfoResponseDTO(
      "Medical Device manufacturer with \"Valid Manufacturing License\" from the issuing Licensing Authority",
      "manufacturing license",
      "issuing Licensing Authority",
      "Please upload Valid certified copy of manufacturing license from the issuing Licensing Authority for the specific medical device (exemption will be valid on only on product category level and not on entity level).\nYou are required to upload supporting documents that demonstrate your manufacturing capacity in the categories you have applied for the VA exemption:"
    ),
    new CriteriaLicenseInfoResponseDTO(
      "Turnover based exemption if turnover is greater than 500 Cr in any of the last 3 year",
      "3 sales invoices",
      "NA - non mandatory",
      "1. Please upload 3 invoices for raw materials purchased and 3 sales invoices from any of the last 3 years for the applied categories. (with GSTIN)\nNote*:Please ensure that applied categories are reflected in the “Dealing in Goods and Services” section of the online GST portal"
    ));

  public String getChannelId(){
    return GemUtility.getGemContext().getAppContext().getChannelId();
  }


  public VaRelaxationExemptionResponseDto convertToVaRelaxationExemptionDto(VaRelaxationExemptionEntity vaRelaxationExemptionEntity, List<VaDocumentDetailEntity> vaDocumentDetailEntities) {
    VaRelaxationExemptionResponseDto vaRelaxationExemptionDto = new VaRelaxationExemptionResponseDto();
    vaRelaxationExemptionDto.setId(vaRelaxationExemptionEntity.getId());
    vaRelaxationExemptionDto.setLicenseDetail(vaRelaxationExemptionEntity.getLicenseDetail());
    vaRelaxationExemptionDto.setRelaxationTypeLookup(vaRelaxationExemptionEntity.getRelaxationTypeLookup());
    vaRelaxationExemptionDto.setExpiryDate(vaRelaxationExemptionEntity.getExpiryDate());
    vaRelaxationExemptionDto.setStatusLookup(vaRelaxationExemptionEntity.getStatusLookup());
    vaRelaxationExemptionDto.setIssuingAuthority(vaRelaxationExemptionEntity.getIssuingAuthority());
    vaRelaxationExemptionDto.setExpiryDate(vaRelaxationExemptionEntity.getExpiryDate());
    vaRelaxationExemptionDto.setExpiredAt(vaRelaxationExemptionEntity.getExpiredAt());
    vaRelaxationExemptionDto.setBriefcaseFk(vaRelaxationExemptionEntity.getBriefcaseFk());
    vaRelaxationExemptionDto.setVaMasterFk(vaRelaxationExemptionEntity.getVaMasterFk());

    vaRelaxationExemptionDto.setDocuments(convertToDocumentResponseList(vaDocumentDetailEntities, vaRelaxationExemptionEntity));
    return vaRelaxationExemptionDto;
  }

  public List<DocumentNewResponseDTO> convertToDocumentResponseList(List<VaDocumentDetailEntity> vaDocumentDetailEntities
    , VaRelaxationExemptionEntity vaRelaxationExemptionEntity) {
    return vaDocumentDetailEntities.stream()
      .map(vaDocumentDetailEntity -> {
        DocumentNewResponseDTO response = new DocumentNewResponseDTO();
        response.setId(vaDocumentDetailEntity.getId());
        response.setName(vaDocumentDetailEntity.getDocumentName());
        response.setType(getDocumentExtensionByLookUp(vaDocumentDetailEntity.getDocumentExtensionLookup()));

        response.setValidUpto(String.valueOf(vaRelaxationExemptionEntity.getExpiryDate()));
        response.setIssuingAuthority(vaRelaxationExemptionEntity.getIssuingAuthority());
        response.setSizeInMB(vaDocumentDetailEntity.getSizeInMb());
        response.setRemarks(vaDocumentDetailEntity.getRemark());
        response.setDocumentTypeLookup(vaDocumentDetailEntity.getDocumentTypeLookup());
        response.setDocumentExtensionLookup(vaDocumentDetailEntity.getDocumentExtensionLookup());
        return response;
      }).toList();
  }

  public String getDocumentExtensionByLookUp(String lookUpCode){
    if (lookUpCode == null || lookUpCode.isEmpty()) {
      return null;
    }
    Optional<Lookup> optionalLookUpCode = lookupRepository.findByLookupCode(lookUpCode);

    if (!lookupRepository.findByLookupCode(lookUpCode).isPresent()) {
      throw new ServiceException(
        MessageConstant.UNEXPECTED_ERROR,
        messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
        ErrorConstant.CATEGORY.BV,
        ErrorConstant.SEVERITY.I
      );
    }
    return optionalLookUpCode.get().getLookupValue();
  }
}
