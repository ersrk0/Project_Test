/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.repository;


import in.gov.gem.app.vendorassessment.domain.entity.Category;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Component
public class CategoryRepository {
    private final Map<Long, Category> categories = new ConcurrentHashMap<>();
    public static final AtomicLong idCounter = new AtomicLong();

    public CategoryRepository(){

        // --- Dummy data for FA type ---
        // Level 1
        long electronicsFAId = idCounter.incrementAndGet();
        categories.put(electronicsFAId, new Category(electronicsFAId, "Electronics (FA)", null, 1, "FA"));
        long booksFAId = idCounter.incrementAndGet();
        categories.put(booksFAId, new Category(booksFAId, "Books (FA)", null, 1, "FA"));
        long sportsFAId = idCounter.incrementAndGet();
        categories.put(sportsFAId, new Category(sportsFAId, "Sports (FA)", null, 1, "FA"));

        // Level 2 (Children of Level 1)
        long laptopsFAId = idCounter.incrementAndGet();
        categories.put(laptopsFAId, new Category(laptopsFAId, "Laptops (FA)", electronicsFAId, 2, "FA"));
        long smartphonesFAId = idCounter.incrementAndGet();
        categories.put(smartphonesFAId, new Category(smartphonesFAId, "Smartphones (FA)", electronicsFAId, 2, "FA"));
        long fictionFAId = idCounter.incrementAndGet();
        categories.put(fictionFAId, new Category(fictionFAId, "Fiction (FA)", booksFAId, 2, "FA"));
        long adventureFAId = idCounter.incrementAndGet();
        categories.put(adventureFAId, new Category(adventureFAId, "Adventure (FA)", booksFAId, 2, "FA"));
        long mysteryFAId = idCounter.incrementAndGet();
        categories.put(mysteryFAId, new Category(mysteryFAId, "Mystery (FA)", booksFAId, 2, "FA"));
        // Corrected parent for Outdoor Gear and Sporting Goods to be direct children of SportsFA
        long outdoorGearFAId = idCounter.incrementAndGet();
        categories.put(outdoorGearFAId, new Category(outdoorGearFAId, "Outdoor Gear (FA)", sportsFAId, 2, "FA"));
        long sportingGoodsFAId = idCounter.incrementAndGet();
        categories.put(sportingGoodsFAId, new Category(sportingGoodsFAId, "Sporting Goods (FA)", sportsFAId, 2, "FA"));

        // Level 3 (Children of Level 2)
        long gamingLaptopsFAId = idCounter.incrementAndGet();
        categories.put(gamingLaptopsFAId, new Category(gamingLaptopsFAId, "Gaming Laptops (FA)", laptopsFAId, 3, "FA"));
        long businessLaptopsFAId = idCounter.incrementAndGet();
        categories.put(businessLaptopsFAId, new Category(businessLaptopsFAId, "Business Laptops (FA)", laptopsFAId, 3, "FA"));
        long androidSmartphonesFAId = idCounter.incrementAndGet();
        categories.put(androidSmartphonesFAId, new Category(androidSmartphonesFAId, "Android Smartphones (FA)", smartphonesFAId, 3, "FA"));
        long iOSSmartphonesFAId = idCounter.incrementAndGet();
        categories.put(iOSSmartphonesFAId, new Category(iOSSmartphonesFAId, "iOS Smartphones (FA)", smartphonesFAId, 3, "FA"));
        long fantasyFictionFAId = idCounter.incrementAndGet();
        categories.put(fantasyFictionFAId, new Category(fantasyFictionFAId, "Fantasy Fiction (FA)", fictionFAId, 3, "FA"));
        long hikingGearFAId = idCounter.incrementAndGet();
        categories.put(hikingGearFAId, new Category(hikingGearFAId, "Hiking Gear (FA)", outdoorGearFAId, 3, "FA"));

        // Level 4 (Children of Level 3)
        long highEndGamingLaptopsFAId = idCounter.incrementAndGet();
        categories.put(highEndGamingLaptopsFAId, new Category(highEndGamingLaptopsFAId, "High-End Gaming Laptops (FA)", gamingLaptopsFAId, 4, "FA"));
        long budgetGamingLaptopsFAId = idCounter.incrementAndGet();
        categories.put(budgetGamingLaptopsFAId, new Category(budgetGamingLaptopsFAId, "Budget Gaming Laptops (FA)", gamingLaptopsFAId, 4, "FA"));
        long premiumAndroidFAId = idCounter.incrementAndGet();
        categories.put(premiumAndroidFAId, new Category(premiumAndroidFAId, "Premium Android (FA)", androidSmartphonesFAId, 4, "FA"));
        long budgetAndroidFAId = idCounter.incrementAndGet();
        categories.put(budgetAndroidFAId, new Category(budgetAndroidFAId, "Budget Android (FA)", androidSmartphonesFAId, 4, "FA"));
        long trekkingPacksFAId = idCounter.incrementAndGet();
        categories.put(trekkingPacksFAId, new Category(trekkingPacksFAId, "Trekking Packs (FA)", hikingGearFAId, 4, "FA"));

        // Level 5 (Children of Level 4)
        long rtx4090LaptopsFAId = idCounter.incrementAndGet();
        categories.put(rtx4090LaptopsFAId, new Category(rtx4090LaptopsFAId, "RTX 4090 Laptops (FA)", highEndGamingLaptopsFAId, 5, "FA"));
        long rtx4070LaptopsFAId = idCounter.incrementAndGet();
        categories.put(rtx4070LaptopsFAId, new Category(rtx4070LaptopsFAId, "RTX 4070 Laptops (FA)", highEndGamingLaptopsFAId, 5, "FA"));
        long flagshipAndroidFAId = idCounter.incrementAndGet();
        categories.put(flagshipAndroidFAId, new Category(flagshipAndroidFAId, "Flagship Android Models (FA)", premiumAndroidFAId, 5, "FA"));
        long midRangeAndroidFAId = idCounter.incrementAndGet();
        categories.put(midRangeAndroidFAId, new Category(midRangeAndroidFAId, "Mid-Range Android Models (FA)", budgetAndroidFAId, 5, "FA"));
        long specificTrekkingBrandFAId = idCounter.incrementAndGet();
        categories.put(specificTrekkingBrandFAId, new Category(specificTrekkingBrandFAId, "Specific Trekking Pack Brand (FA)", trekkingPacksFAId, 5, "FA"));


        // --- Dummy data for PRODUCT type ---
        // Level 1
        long electronicsProdId = idCounter.incrementAndGet();
        categories.put(electronicsProdId, new Category(electronicsProdId, "Electronics (PRODUCT)", null, 1, "PRODUCT"));
        long booksProdId = idCounter.incrementAndGet();
        categories.put(booksProdId, new Category(booksProdId, "Books (PRODUCT)", null, 1, "PRODUCT"));
        long sportsProdId = idCounter.incrementAndGet();
        categories.put(sportsProdId, new Category(sportsProdId, "Sports (PRODUCT)", null, 1, "PRODUCT"));

        // Level 2 (Children of Level 1)
        long laptopsProdId = idCounter.incrementAndGet();
        categories.put(laptopsProdId, new Category(laptopsProdId, "Laptops (PRODUCT)", electronicsProdId, 2, "PRODUCT"));
        long smartphonesProdId = idCounter.incrementAndGet();
        categories.put(smartphonesProdId, new Category(smartphonesProdId, "Smartphones (PRODUCT)", electronicsProdId, 2, "PRODUCT"));
        long fictionProdId = idCounter.incrementAndGet();
        categories.put(fictionProdId, new Category(fictionProdId, "Fiction (PRODUCT)", booksProdId, 2, "PRODUCT"));
        long adventureProdId = idCounter.incrementAndGet();
        categories.put(adventureProdId, new Category(adventureProdId, "Adventure (PRODUCT)", booksProdId, 2, "PRODUCT"));
        long outdoorGearProdId = idCounter.incrementAndGet();
        categories.put(outdoorGearProdId, new Category(outdoorGearProdId, "Outdoor Gear (PRODUCT)", sportsProdId, 2, "PRODUCT"));
        long sportingGoodsProdId = idCounter.incrementAndGet();
        categories.put(sportingGoodsProdId, new Category(sportingGoodsProdId, "Sporting Goods (PRODUCT)", sportsProdId, 2, "PRODUCT"));

        // Level 3 (Children of Level 2)
        long gamingLaptopsProdId = idCounter.incrementAndGet();
        categories.put(gamingLaptopsProdId, new Category(gamingLaptopsProdId, "Gaming Laptops (PRODUCT)", laptopsProdId, 3, "PRODUCT"));
        long workLaptopsProdId = idCounter.incrementAndGet();
        categories.put(workLaptopsProdId, new Category(workLaptopsProdId, "Work Laptops (PRODUCT)", laptopsProdId, 3, "PRODUCT"));
        long sciFiProdId = idCounter.incrementAndGet();
        categories.put(sciFiProdId, new Category(sciFiProdId, "Science Fiction (PRODUCT)", fictionProdId, 3, "PRODUCT"));
        long campingGearProdId = idCounter.incrementAndGet();
        categories.put(campingGearProdId, new Category(campingGearProdId, "Camping Gear (PRODUCT)", outdoorGearProdId, 3, "PRODUCT"));

        // Level 4 (Children of Level 3)
        long ultraGamingLaptopsProdId = idCounter.incrementAndGet();
        categories.put(ultraGamingLaptopsProdId, new Category(ultraGamingLaptopsProdId, "Ultra Gaming Laptops (PRODUCT)", gamingLaptopsProdId, 4, "PRODUCT"));
        long midRangeGamingLaptopsProdId = idCounter.incrementAndGet();
        categories.put(midRangeGamingLaptopsProdId, new Category(midRangeGamingLaptopsProdId, "Mid-Range Gaming Laptops (PRODUCT)", gamingLaptopsProdId, 4, "PRODUCT"));
        long classicSciFiProdId = idCounter.incrementAndGet();
        categories.put(classicSciFiProdId, new Category(classicSciFiProdId, "Classic Sci-Fi (PRODUCT)", sciFiProdId, 4, "PRODUCT"));
        long tentsProdId = idCounter.incrementAndGet();
        categories.put(tentsProdId, new Category(tentsProdId, "Tents (PRODUCT)", campingGearProdId, 4, "PRODUCT"));

        // Level 5 (Children of Level 4)
        long proGamingLaptopsProdId = idCounter.incrementAndGet();
        categories.put(proGamingLaptopsProdId, new Category(proGamingLaptopsProdId, "Pro Gaming Laptops (PRODUCT)", ultraGamingLaptopsProdId, 5, "PRODUCT"));
        long budgetGamingLaptopProdId = idCounter.incrementAndGet();
        categories.put(budgetGamingLaptopProdId, new Category(budgetGamingLaptopProdId, "Budget Gaming Laptops (PRODUCT)", midRangeGamingLaptopsProdId, 5, "PRODUCT"));
        long specificSciFiAuthorProdId = idCounter.incrementAndGet();
        categories.put(specificSciFiAuthorProdId, new Category(specificSciFiAuthorProdId, "Specific Sci-Fi Author Series (PRODUCT)", classicSciFiProdId, 5, "PRODUCT"));
        long PersonTentsProdId = idCounter.incrementAndGet();
        categories.put(PersonTentsProdId, new Category(PersonTentsProdId, "2-Person Tents (PRODUCT)", tentsProdId, 5, "PRODUCT"));


        // --- Dummy data for SERVICE type ---
        // Level 1
        long consultingServiceId = idCounter.incrementAndGet();
        categories.put(consultingServiceId, new Category(consultingServiceId, "Consulting (SERVICE)", null, 1, "SERVICE"));
        long itSupportServiceId = idCounter.incrementAndGet();
        categories.put(itSupportServiceId, new Category(itSupportServiceId, "IT Support (SERVICE)", null, 1, "SERVICE"));
        long trainingServiceId = idCounter.incrementAndGet();
        categories.put(trainingServiceId, new Category(trainingServiceId, "Training (SERVICE)", null, 1, "SERVICE"));

        // Level 2 (Children of Level 1)
        long cloudServicesId = idCounter.incrementAndGet();
        categories.put(cloudServicesId, new Category(cloudServicesId, "Cloud Services (SERVICE)", consultingServiceId, 2, "SERVICE"));
        long businessConsultingId = idCounter.incrementAndGet();
        categories.put(businessConsultingId, new Category(businessConsultingId, "Business Consulting (SERVICE)", consultingServiceId, 2, "SERVICE"));
        long technicalSupportId = idCounter.incrementAndGet();
        categories.put(technicalSupportId, new Category(technicalSupportId, "Technical Support (SERVICE)", itSupportServiceId, 2, "SERVICE"));
        long onsiteTrainingId = idCounter.incrementAndGet();
        categories.put(onsiteTrainingId, new Category(onsiteTrainingId, "Onsite Training (SERVICE)", trainingServiceId, 2, "SERVICE"));

        // Level 3 (Children of Level 2)
        long cloudMigrationId = idCounter.incrementAndGet();
        categories.put(cloudMigrationId, new Category(cloudMigrationId, "Cloud Migration (SERVICE)", cloudServicesId, 3, "SERVICE"));
        long cloudSecurityId = idCounter.incrementAndGet();
        categories.put(cloudSecurityId, new Category(cloudSecurityId, "Cloud Security (SERVICE)", cloudServicesId, 3, "SERVICE"));
        long businessStrategyId = idCounter.incrementAndGet();
        categories.put(businessStrategyId, new Category(businessStrategyId, "Business Strategy (SERVICE)", businessConsultingId, 3, "SERVICE"));
        long itInfrastructureId = idCounter.incrementAndGet();
        categories.put(itInfrastructureId, new Category(itInfrastructureId, "IT Infrastructure (SERVICE)", technicalSupportId, 3, "SERVICE"));
        long remoteTrainingId = idCounter.incrementAndGet();
        categories.put(remoteTrainingId, new Category(remoteTrainingId, "Remote Training (SERVICE)", onsiteTrainingId, 3, "SERVICE")); // Changed parent for remote training to be under Onsite Training for deeper nesting

        // Level 4 (Children of Level 3)
        long hybridCloudMigrationId = idCounter.incrementAndGet();
        categories.put(hybridCloudMigrationId, new Category(hybridCloudMigrationId, "Hybrid Cloud Migration (SERVICE)", cloudMigrationId, 4, "SERVICE"));
        long publicCloudMigrationId = idCounter.incrementAndGet();
        categories.put(publicCloudMigrationId, new Category(publicCloudMigrationId, "Public Cloud Migration (SERVICE)", cloudMigrationId, 4, "SERVICE"));
        long privateCloudMigrationId = idCounter.incrementAndGet();
        categories.put(privateCloudMigrationId, new Category(privateCloudMigrationId, "Private Cloud Migration (SERVICE)", cloudMigrationId, 4, "SERVICE"));
        long advancedSecurityId = idCounter.incrementAndGet();
        categories.put(advancedSecurityId, new Category(advancedSecurityId, "Advanced Security (SERVICE)", cloudSecurityId, 4, "SERVICE"));
        long securityAuditsId = idCounter.incrementAndGet();
        categories.put(securityAuditsId, new Category(securityAuditsId, "Security Audits (SERVICE)", cloudSecurityId, 4, "SERVICE"));
        long itPolicyDevelopmentId = idCounter.incrementAndGet(); // New L4 child for IT Infrastructure
        categories.put(itPolicyDevelopmentId, new Category(itPolicyDevelopmentId, "IT Policy Development (SERVICE)", itInfrastructureId, 4, "SERVICE"));
        long customRemoteTrainingId = idCounter.incrementAndGet(); // New L4 child for Remote Training
        categories.put(customRemoteTrainingId, new Category(customRemoteTrainingId, "Custom Remote Training (SERVICE)", remoteTrainingId, 4, "SERVICE"));

        // Level 5 (Children of Level 4)
        long hybridCloudAssessmentId = idCounter.incrementAndGet();
        categories.put(hybridCloudAssessmentId, new Category(hybridCloudAssessmentId, "Hybrid Cloud Assessment (SERVICE)", hybridCloudMigrationId, 5, "SERVICE"));
        long hybridCloudImplementationId = idCounter.incrementAndGet();
        categories.put(hybridCloudImplementationId, new Category(hybridCloudImplementationId, "Hybrid Cloud Implementation (SERVICE)", hybridCloudMigrationId, 5, "SERVICE"));
        long publicCloudAssessmentId = idCounter.incrementAndGet();
        categories.put(publicCloudAssessmentId, new Category(publicCloudAssessmentId, "Public Cloud Assessment (SERVICE)", publicCloudMigrationId, 5, "SERVICE"));
        long publicCloudImplementationId = idCounter.incrementAndGet();
        categories.put(publicCloudImplementationId, new Category(publicCloudImplementationId, "Public Cloud Implementation (SERVICE)", publicCloudMigrationId, 5, "SERVICE"));
        long privateCloudAssessmentId = idCounter.incrementAndGet();
        categories.put(privateCloudAssessmentId, new Category(privateCloudAssessmentId, "Private Cloud Assessment (SERVICE)", privateCloudMigrationId, 5, "SERVICE"));
        long privateCloudImplementationId = idCounter.incrementAndGet();
        categories.put(privateCloudImplementationId, new Category(privateCloudImplementationId, "Private Cloud Implementation (SERVICE)", privateCloudMigrationId, 5, "SERVICE"));
        long advancedThreatDetectionId = idCounter.incrementAndGet(); // L5 for Advanced Security
        categories.put(advancedThreatDetectionId, new Category(advancedThreatDetectionId, "Advanced Threat Detection (SERVICE)", advancedSecurityId, 5, "SERVICE"));
        long itPolicyReviewId = idCounter.incrementAndGet(); // L5 for IT Policy Development
        categories.put(itPolicyReviewId, new Category(itPolicyReviewId, "IT Policy Review (SERVICE)", itPolicyDevelopmentId, 5, "SERVICE"));
        long specializedRemoteTrainingId = idCounter.incrementAndGet(); // L5 for Custom Remote Training
        categories.put(specializedRemoteTrainingId, new Category(specializedRemoteTrainingId, "Specialized Remote Training (SERVICE)", customRemoteTrainingId, 5, "SERVICE"));

    }

    public Category save(Category category) {
        if (category.getId() == null) {
            category.setId(idCounter.incrementAndGet());
        }
        categories.put(category.getId(), category);
        return category;
    }

    public Optional<Category> findById(Long id) {
        return Optional.ofNullable(categories.get(id));
    }


    public List<Category> searchByCriteria(String type,String name, Long parentId, Boolean exactMatch) {
        return categories.values().stream()
                .filter(category -> {
                    boolean nameMatches = true;
                    if (name != null && !name.trim().isEmpty()) {
                        if (Boolean.TRUE.equals(exactMatch)) {
                            nameMatches = category.getName().equalsIgnoreCase(name);
                        } else {
                            nameMatches = category.getName().toLowerCase().contains(name.toLowerCase());
                        }
                    }

                    boolean parentIdMatches = true;
                    if (parentId != null) {
                        parentIdMatches = (category.getParentId() != null && category.getParentId().equals(parentId));
                    }
                    boolean typeMatches = true;
                    if (type != null && !type.trim().isEmpty()) {
                        typeMatches= nameMatches && parentIdMatches && category.getType().equalsIgnoreCase(type);
                    }

                    return nameMatches && parentIdMatches && typeMatches;
                })
                .collect(Collectors.toList());
    }

    public boolean existsById(Long id) {
        return categories.containsKey(id);
    }

    public List<Category> findByParentId(Long parentId) {
        return categories.values().stream()
                .filter(category -> category.getParentId() != null && category.getParentId().equals(parentId))
                .collect(Collectors.toList());
    }

    public Category deleteById(Long id) {
        return categories.remove(id);
    }

    public List<Category> findByParentIdIsNull() {
        return categories.values().stream()
                .filter(category -> category.getParentId() == null)
                .collect(Collectors.toList());
    }

    public Optional<Category> findByIdAndType(Long id, String type) {
        return categories.values().stream()
                .filter(c -> Objects.equals(c.getId(), id) && c.getType().equalsIgnoreCase(type))
                .findFirst();
    }

}


