
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;

import in.gov.gem.app.service.dto.APIResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Provides lookup APIs for assessment types, descriptions, and questions.
 */
@Tag(name = "Lookup", description = "APIs for fetching assessment types, descriptions, and questions")
@RestController
@RequestMapping("/v1/lookup")
public interface IAssessController {
  /**
   * Fetches all assessment types.
   *
   * @return the API response with assessment types
   */
  @Operation(
    summary = "Fetch Assessment Types",
    description = "Fetches all available assessment types.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("assess/types")
  ResponseEntity<APIResponse<Object>> fetchAssessType();

  /**
   * Fetches description for a given lookup value.
   *
   * @param lookupValue the lookup value
   * @return the API response with description
   */
  @Operation(
    summary = "Fetch Description",
    description = "Fetches description for a given lookup value.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "lookupValue", description = "Lookup value", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/description")
  ResponseEntity<APIResponse<Object>> fetchDescription(@RequestParam String lookupValue);

  /**
   * Fetches questions for a given assessment type.
   *
   * @param assess the assessment type
   * @return the API response with questions
   */
  @Operation(
    summary = "Fetch Questions by Assessment",
    description = "Fetches questions for a given assessment type.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "assess", description = "Assessment type", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/question")
  ResponseEntity<APIResponse<Object>> fetchQuestionByAssess(@RequestParam String assess);
}
 