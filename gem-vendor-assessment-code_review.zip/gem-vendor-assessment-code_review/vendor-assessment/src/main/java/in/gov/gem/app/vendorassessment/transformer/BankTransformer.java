
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.transformer;


import in.gov.gem.app.vendorassessment.dto.response.BankAddressResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.BankResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.BankSellerResponseDTO;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.client.IMdmClient;
import in.gov.gem.app.vendorassessment.client.ISellerClient;

import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.utility.CustomLoggerFactory;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * The type Bank transformer.
 */
@Component
@AllArgsConstructor
public class BankTransformer
{
  private final ISellerClient iSellerClient;

  private final IMdmClient iMdmClient;

  private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(BankTransformer.class);

  /**
   * Gets bank details from seller.
   *
   * @param paginationParams the pagination params
   * @param languageCode     the language code
   * @return the bank details from seller
   */
  public List<BankSellerResponseDTO> getBankDetailsFromSeller(PaginationParams paginationParams, String languageCode) {
    // Call seller client to get bank data
    ResponseEntity<PageableApiResponse<List<BankResponseDTO>>> response = iSellerClient.getBankDetails(paginationParams);

    // Safely extract list of bank details
    List<BankResponseDTO> bankList = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(PageableApiResponse::getData)
      .orElse(Collections.emptyList());

    if (bankList.isEmpty()) {
      log.info("No bank details found for the given parameters.");
      return Collections.emptyList(); // Return an empty list if no data is available
    }

    // Transform bank list into BankSellerResponseDTO list
    List<BankSellerResponseDTO> bankSellerResponseList = bankList.stream().map(bankData -> {
      ResponseEntity<APIResponse<BankAddressResponseDTO>> addressResponse =
        iMdmClient.getBankAddress(bankData.getIfscCode(),languageCode);

      return BankSellerResponseDTO.builder()
        .id(bankData.getId())
        .bankName(bankData.getBankName())
        .accountHolderName(bankData.getAccountHolderName())
        .ifscCode(bankData.getIfscCode())
        .accountNumber(bankData.getAccountNumber())
        .bankAddress(addressResponse.getBody().getData().getBranchAddress())
        .build();
    }).collect(Collectors.toList());

    return bankSellerResponseList;
  }

}

