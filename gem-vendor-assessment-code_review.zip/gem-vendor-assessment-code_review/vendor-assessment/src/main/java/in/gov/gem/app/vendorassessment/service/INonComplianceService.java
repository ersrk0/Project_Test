
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service;


import in.gov.gem.app.vendorassessment.dto.response.NonComplianceNewResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.NonComplianceResponseDTO;

import java.util.List;


/**
 * The interface Non compliance service.
 */
public interface INonComplianceService {

  /**
   * Fields with open non closure non compliance response.
   *
   * @param sellerId the seller id
   * @return the non compliance response
   */
  NonComplianceNewResponseDTO fieldsWithOpenNonClosure(Long sellerId);

  /**
   * Non compliant fields list.
   *
   * @param vaMasterFk the va master fk
   * @return the list
   */
  List<NonComplianceResponseDTO> nonCompliantFields(Long vaMasterFk);
}