
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.repository;

import in.gov.gem.app.service.core.repository.BaseRepository;

import in.gov.gem.app.vendorassessment.domain.entity.QuesAnsEntity;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;


/**
 * The interface Ques ans repository.
 */
@Repository
public interface QuesAnsRepository extends BaseRepository<QuesAnsEntity, BigInteger> {
    /**
     * Find by id optional.
     *
     * @param id the id
     * @return the optional
     */
    Optional<QuesAnsEntity> findById(Long id);

    /**
     * Find by va master fk list.
     *
     * @param vaMasterFk the va master fk
     * @return the list
     */
    List<QuesAnsEntity> findByVaMasterFk(Long vaMasterFk);

    /**
     * Find by que master fk list.
     *
     * @param quesMasterFk the ques master fk
     * @return the list
     */
    List<QuesAnsEntity> findByQueMasterFk(Long quesMasterFk);

    /**
     * Find by va master fk and que master fk list.
     *
     * @param vaMasterFk   the va master fk
     * @param quesMasterFk the ques master fk
     * @return the list
     */
    List<QuesAnsEntity> findByVaMasterFkAndQueMasterFk(Long vaMasterFk, Long quesMasterFk);

    /**
     * Exists by va master fk and que master fk boolean.
     *
     * @param vaMasterFk   the va master fk
     * @param quesMasterFk the ques master fk
     * @return the boolean
     */
    boolean existsByVaMasterFkAndQueMasterFk(Long vaMasterFk, Long quesMasterFk);
}


