
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;


import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.dto.response.CountryResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.FetchLocationResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.NewVAResponseOrganizationAddressDTO;
import in.gov.gem.app.vendorassessment.dto.response.VAResponseOrganizationAddressResponseDTO;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.dto.request.VAOrganizationAddressRequestDTO;


import in.gov.gem.app.vendorassessment.controller.IManufacturingAddressController;
import in.gov.gem.app.vendorassessment.facade.IManufacturingAddressFacade;
import in.gov.gem.app.vendorassessment.facade.Impl.MdmFacade;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * The type Manufacturing address controller.
 */
@RestController
@AllArgsConstructor
public class ManufacturingAddressController extends BaseParentController implements IManufacturingAddressController
{

  private final MdmFacade mdmTransformer;

  private final IManufacturingAddressFacade manufacturingAddressFacade;


  @Override
  public ResponseEntity<APIResponse<Object>> getLocation(PaginationParams paginationParams,
                                                         @RequestParam String locationCode,
                                                         @Valid @RequestHeader(
                                                           name = "Accept-Language")
                                                         String languageCode)

  {
    List<FetchLocationResponseDTO> locationListFromMdm =
      manufacturingAddressFacade.getLocationListFromMdm(paginationParams, locationCode, languageCode);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(locationListFromMdm)
      .build());

  }

  @Override
  public ResponseEntity<APIResponse<Object>> getPincode(PaginationParams paginationParams,
                                                        @RequestParam String locationCode,
                                                        @Valid @RequestHeader(
                                                          name = "Accept-Language")
                                                        String languageCode)

  {
    List<FetchLocationResponseDTO> locationListFromMdm =
      manufacturingAddressFacade.getLocationListFromMdm(paginationParams, locationCode, languageCode);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(locationListFromMdm)
      .build());

  }

  @Override
  public ResponseEntity<APIResponse<Object>> getCountries(PaginationParams paginationParams,
                                                          @Valid @RequestHeader(
                                                            name = "Accept-Language")
                                                          String languageCode)

  {
    List<CountryResponseDTO> countryListResponses= mdmTransformer.fetchCountryList(paginationParams, languageCode);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(countryListResponses)
      .build());

  }

  @Override
  public ResponseEntity<APIResponse<Object>> saveManufacturingAddress(@RequestBody VAOrganizationAddressRequestDTO vaOrganizationAddressDTO )
  {
    VAOrganizationAddressRequestDTO response = manufacturingAddressFacade.saveManufacturingAddress(vaOrganizationAddressDTO);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(response)
      .build());

  }

  @Override
  public ResponseEntity<APIResponse<Object>> saveAssessAsManufacturingAddress(@RequestBody VAOrganizationAddressRequestDTO vaOrganizationAddressDTO,
                                                                              String vaNumber)
  {
    VAOrganizationAddressRequestDTO response = manufacturingAddressFacade.saveManufacturingAddressAssessAs(vaOrganizationAddressDTO, vaNumber);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(response)
      .build());

  }

  @Override
  public ResponseEntity<APIResponse<Object>> saveVendorSellerManufacturingAddress(@RequestBody VAOrganizationAddressRequestDTO vaOrganizationAddressDTO,
                                                                                  String vaNumber)
  {
    VAOrganizationAddressRequestDTO response = manufacturingAddressFacade.saveAddressInVendorAndSeller(vaOrganizationAddressDTO, vaNumber);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message("Data saved successfully in vendor and seller")
      .data(response)
      .build());

  }

  @Override
  public ResponseEntity<APIResponse<Object>> getManufacturingAddress(@RequestParam Long vaOrganizationDetailFk)
  {
    List<VAOrganizationAddressRequestDTO> res = manufacturingAddressFacade.findByVaOrganizationDetailFk(vaOrganizationDetailFk);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(res)
      .build());

  }

  //-------------------------------------------------------------------------------------

  @Override
  public ResponseEntity<APIResponse<Object>> getManufactureAddress(@RequestParam Long vaOrganizationDetailFk, PaginationParams paginationParams)
  {
    PageableApiResponse<List<VAOrganizationAddressRequestDTO>> byVaOrganizationDetailFk = manufacturingAddressFacade.findByVaOrganizationDetailFk(paginationParams,vaOrganizationDetailFk);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.WORK_EXPERIENCE_GET_SUCCESS)
      .data(byVaOrganizationDetailFk.getData())
      .build());

  }

  @Override
  public ResponseEntity<APIResponse<Object>> getManufactureMasterAddress(@RequestParam Long vaMasterFk)
  {
    List<VAOrganizationAddressRequestDTO> byVaMasterFk= manufacturingAddressFacade.findByVaMasterFk(vaMasterFk);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.WORK_EXPERIENCE_GET_SUCCESS)
      .data(byVaMasterFk)
      .build());

  }


  @Override
  public ResponseEntity<APIResponse<Object>> getManufactureMasterPagingAddress(@RequestParam Long vaMasterFk,PaginationParams paginationParams)
  {

    PageableApiResponse<List<VAOrganizationAddressRequestDTO>> byVaMasterFk= manufacturingAddressFacade.findByVaMasterFk(paginationParams, vaMasterFk);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.WORK_EXPERIENCE_GET_SUCCESS)
      .data(byVaMasterFk.getData())
      .build());

  }

  //----------------------------------------------------------

  @Override
  public ResponseEntity<APIResponse<Object>> getManufacturingPreIdAddress(@RequestParam Long id)
  {
    List<VAResponseOrganizationAddressResponseDTO> byId = manufacturingAddressFacade.findById(id);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.WORK_EXPERIENCE_GET_SUCCESS)
      .data(byId)
      .build());

  }

  @Override
  public ResponseEntity<APIResponse<Object>> NewgetManufacturingPreIdAddress(@RequestParam Long id)
  {
    List<NewVAResponseOrganizationAddressDTO> byNewId= manufacturingAddressFacade.findByNewId(id);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.WORK_EXPERIENCE_GET_SUCCESS)
      .data(byNewId)
      .build());

  }

  @Override
  public ResponseEntity<APIResponse<Object>> deleteManufacturingPreAddress(@RequestParam Long id)
  {
    //List<VAResponseOrganizationAddressDTO> byId = manufacturingAddress.findById(id);

    manufacturingAddressFacade.deleteById(id);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.MANUFACTURING_ADDRESS_DELETE_SUCCESS)
      .data(null)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> updateManufacturingPreIdAddress(@RequestParam Long id,
                                                                             @RequestBody VAOrganizationAddressRequestDTO request)
  {
    manufacturingAddressFacade.updateById(id, request);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.MANUFACTURING_ADDRESS_UPDATE_SUCCESS)
      .data(null)
      .build());
  }

}
