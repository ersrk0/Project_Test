
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

/**
 * The type Authorize oem osp detail entity.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "authorize_oem_osp_detail", schema = "va_mgmt")
public class AuthorizeOemOspDetailEntity extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "country_code", length = 15)
    private String countryCode;

    @Column(name = "unique_identify_number", length = 20)
    private String uniqueIdentifyNumber;

    @Column(name = "va_mgmt_fk")
    private Long vaMgmtFk;

    @Column(name = "authorize_person_name", length = 255)
    private String authorizePersonName;

    @Column(name = "email_id", length = 255)
    private String emailId;

    @Column(name = "std_code", length = 8)
    private String stdCode;

    @Column(name = "contact_number", length = 255)
    private String contactNumber;

    @Column(name = "briefcase_fk")
    private Long briefcaseFk;

    @Column(name = "va_organization_address_fk")
    private Long vaOrganizationAddressFk;
}