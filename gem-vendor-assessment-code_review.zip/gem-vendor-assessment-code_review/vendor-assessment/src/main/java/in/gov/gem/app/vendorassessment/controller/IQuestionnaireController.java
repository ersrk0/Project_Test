
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.request.QuestionDto;
import in.gov.gem.app.vendorassessment.dto.request.QuestionRequestDto;
import in.gov.gem.app.vendorassessment.dto.request.SaveResponsesRequestDto;
import in.gov.gem.app.vendorassessment.dto.response.QuestionResponseDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/v1/categories")
@Tag(name = "Questionnaire Management", description = "Endpoints for managing questions and responses for categories.")
public interface IQuestionnaireController {

    @GetMapping("/questions")
    @Operation(
        summary = "Get questions for a specific category",
        description = "Fetches all questions associated with a given category ID.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Questions fetched successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = QuestionDto.class))),
            @ApiResponse(responseCode = "404", description = "No questions found for the category")
        }
    )
    ResponseEntity<APIResponse<Object>> getQuestionsForCategory(
        @Parameter(description = "The ID of the category", required = true) @RequestParam Long categoryId
    );

    @PostMapping("/responses")
    @Operation(
        summary = "Save questionnaire responses",
        description = "Saves the responses to a questionnaire for a specific category.",
        responses = {
            @ApiResponse(responseCode = "201", description = "Responses saved successfully")
        }
    )
    ResponseEntity<APIResponse<Object>> saveQuestionnaireResponses(
        @Parameter(description = "The ID of the category", required = true) @RequestParam Long categoryId,
        @Parameter(description = "The DTO containing the user's responses", required = true) @Valid @RequestBody SaveResponsesRequestDto requestDto
    );

    @GetMapping("/responses")
    @Operation(
        summary = "Get saved questionnaire responses",
        description = "Fetches all saved responses for a given category.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Saved responses fetched successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = QuestionResponseDto.class)))
        }
    )
    ResponseEntity<APIResponse<Object>> getSavedQuestionnaireResponses(
        @Parameter(description = "The ID of the category", required = true) @RequestParam Long categoryId
    );

    @PostMapping("/questions")
    @Operation(
        summary = "Create a new question",
        description = "Adds a new question to a specific category. The questionId in the request body must be null.",
        responses = {
            @ApiResponse(responseCode = "201", description = "Question created successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = QuestionDto.class))),
            @ApiResponse(responseCode = "400", description = "Validation error, e.g., questionId is not null")
        }
    )
    ResponseEntity<APIResponse<Object>> createQuestion(
        @Parameter(description = "The ID of the category", required = true) @RequestParam Long categoryId,
        @Parameter(description = "The DTO for the new question", required = true) @Valid @RequestBody QuestionRequestDto questionRequestDto
    );

    @PutMapping("/questions")
    @Operation(
        summary = "Update an existing question",
        description = "Updates an existing question for a category. The questionId in the path must match the one in the request body.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Question updated successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = QuestionDto.class))),
            @ApiResponse(responseCode = "400", description = "Validation error, e.g., question ID mismatch"),
            @ApiResponse(responseCode = "404", description = "Question not found")
        }
    )
    ResponseEntity<APIResponse<Object>> updateQuestion(
        @Parameter(description = "The ID of the category", required = true) @RequestParam Long categoryId,
        @Parameter(description = "The ID of the question to update", required = true) @RequestParam Long questionId,
        @Parameter(description = "The DTO with the updated question details", required = true) @Valid @RequestBody QuestionRequestDto questionRequestDto
    );

    @DeleteMapping("/questions")
    @Operation(
        summary = "Delete a question",
        description = "Deletes a question from a specific category.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Question deleted successfully")
        }
    )
    ResponseEntity<APIResponse<Object>> deleteQuestion(
        @Parameter(description = "The ID of the category", required = true) @RequestParam Long categoryId,
        @Parameter(description = "The ID of the question to delete", required = true) @RequestParam Long questionId
    );
}
