
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.request.WorkExperienceNewRequestDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * APIs for managing vendor work experience and organization hierarchy.
 */
@Tag(name = "Work Vendor Experience", description = "APIs for vendor work experience and organization hierarchy")
@RequestMapping("/v1")
@RestController
public interface IWorkVendorExperienceController {
  /**
   * Get all organization types in the hierarchy.
   */
  @Operation(
    summary = "Get all organization types",
    description = "Fetches all organization types in the hierarchy.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "Accept-Language", description = "Language", in = ParameterIn.HEADER)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Guidelines not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/heirarchy/organization")
  ResponseEntity<APIResponse<Object>> getOrgAllType(
    @RequestHeader("Accept-Language") String acceptLanguage,
    @Parameter(hidden = true) PaginationParams paginationParams);

  /**
   * Get all organization types with level.
   */
  @Operation(
    summary = "Get organization types with level",
    description = "Fetches organization types by parent ID and level.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "parentId", description = "Parent organization ID", in = ParameterIn.QUERY, required = true)
  @Parameter(name = "Accept-Language", description = "Language", in = ParameterIn.HEADER)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Guidelines not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/heirarchy/level")
  ResponseEntity<APIResponse<Object>> getOrgAllTypeWithlevel(
    @RequestParam String parentId,
    @RequestHeader("Accept-Language") String acceptLanguage,
    @Parameter(hidden = true) PaginationParams paginationParams);

  /**
   * Create a new work experience entry for a vendor.
   */
  @Operation(
    summary = "Create work experience",
    description = "Creates a new work experience entry for a vendor.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Guidelines not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/vendor/work-experience")
  ResponseEntity<APIResponse<Object>> createWorkExperience(
    @RequestBody WorkExperienceNewRequestDTO createRequest);

  /**
   * Get work experience by VA master foreign key.
   */
  @Operation(
    summary = "Get work experience",
    description = "Fetches work experience by VA master foreign key.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaMasterFk", description = "VA master foreign key", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Guidelines not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/vendor/work-experience")
  ResponseEntity<APIResponse<Object>> getWorkExperience(
    @RequestParam Long vaMasterFk);

  /**
   * Get paginated work experience for a vendor.
   */
  @Operation(
    summary = "Get paginated work experience",
    description = "Fetches paginated work experience for a vendor.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaMasterFk", description = "VA master foreign key", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Guidelines not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/vendor/pagination/work-experience")
  ResponseEntity<APIResponse<Object>> getVendorWorkExperience(
    @RequestParam Long vaMasterFk,
    @Parameter(hidden = true) PaginationParams paginationParams);
}