
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.dto.request.AddDocumentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.DocumentDetailOldResponseDTO;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;


/**
 * Service layer to handle core document-related operations (e.g., file storage, database interaction).
 * This service would typically interact with repositories or external storage systems.
 */
@Service
public class DocumentService {
    private final MessageUtility messageUtility;

    // Define a directory for temporary file storage (for demonstration purposes)
    // IMPORTANT: In production, use a secure and scalable storage solution.
    private final String UPLOAD_DIR = "uploads/";

    // Simulate in-memory database for documents
    private final ConcurrentHashMap<Long, DocumentDetailOldResponseDTO> documentsStore = new ConcurrentHashMap<>();
    private final AtomicLong documentIdCounter = new AtomicLong(0);

  /**
   * Instantiates a new Document service.
   *
   * @param messageUtility the message utility
   */
  public DocumentService(MessageUtility messageUtility) {
        this.messageUtility = messageUtility;
        // Ensure the upload directory exists
        try {
            Files.createDirectories(Paths.get(UPLOAD_DIR));
        } catch (IOException e) {

            throw new ServiceException(
                    MessageConstant.DOCUMENT_NOT_FOUND,
                    messageUtility.getMessage(MessageConstant.DOCUMENT_NOT_FOUND),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
        // Add some dummy data for demonstration
        initializeDummyDocuments();
    }

    private void initializeDummyDocuments() {
        // Simulate some pre-existing documents
        long id1 = documentIdCounter.incrementAndGet();
        documentsStore.put(id1, new DocumentDetailOldResponseDTO(
                id1,
                "Old Driving License",
                "DL",
                "RTO Bangalore",
                "Old license for reference",
                1.2,
                Instant.parse("2020-01-01T00:00:00Z"),
                "Archived",
                "file_ref_old_dl_1"
        ));

        long id2 = documentIdCounter.incrementAndGet();
        documentsStore.put(id2, new DocumentDetailOldResponseDTO(
                id2,
                "Passport Copy",
                "PASSPORT",
                "Passport Office Delhi",
                "Current passport copy",
                2.1,
                Instant.parse("2030-05-15T23:59:59Z"),
                "Active",
                "file_ref_passport_2"
        ));
    }


  /**
   * Stores the actual document file.
   *
   * @param file The actual document file.
   * @return A unique file identifier/path, or null if an error occurs.
   * @throws IOException              If there's an issue saving the file.
   * @throws IllegalArgumentException If validation fails (e.g., file size, type).
   */
  public String saveDocumentFile(MultipartFile file) throws IOException, IllegalArgumentException {
        // Basic validation as per screen requirements (max 5.0 MB, PDF)
        final long MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024; // 5 MB
        if (file.getSize() > MAX_FILE_SIZE_BYTES) {
            throw new IllegalArgumentException("File size exceeds the maximum limit of 5.0 MB.");
        }
        if (!"application/pdf".equalsIgnoreCase(file.getContentType())) {
            throw new IllegalArgumentException("Only PDF files are allowed.");
        }

        // Simulate saving the file
        String fileId = UUID.randomUUID().toString();
        String originalFilename = file.getOriginalFilename();
        // Extract file extension to preserve it
        String fileExtension = "";
        if (originalFilename != null && originalFilename.contains(".")) {
            fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
        }
        Path filePath = Paths.get(UPLOAD_DIR + fileId + fileExtension);
        Files.copy(file.getInputStream(), filePath);


        return fileId; // In a real app, this might be a cloud storage URL or a path reference
    }

  /**
   * Saves the document metadata to a database.
   * (Placeholder for actual database interaction)
   *
   * @param documentRequest The metadata for the document.
   * @param fileReferenceId The ID/reference to the stored file.
   * @return A unique ID for the metadata entry.
   */
  public Long saveDocumentMetadata(AddDocumentRequestDTO documentRequest, String fileReferenceId) {

        // Simulate saving to a database and returning an ID
        // In a real app, this would involve a JPA repository save operation
        Long newId = documentIdCounter.incrementAndGet();

        // For demonstration, we'll store a simplified DocumentDetailResponse
        // In real app, you'd create a proper entity, save it, and then map to DTO
        DocumentDetailOldResponseDTO newDoc = new DocumentDetailOldResponseDTO(
                newId,
                documentRequest.getLicenseCertificateDetails(),
                // Assuming type is derived from licenseCertificateDetails or passed separately
                "UNKNOWN_TYPE", // Placeholder, as AddDocumentRequest doesn't have it
                documentRequest.getIssuingAuthorityDetails(),
                documentRequest.getRemarks(),
                // Assuming size in MB would be calculated or passed, using file.getSize()
                (double) fileReferenceId.length() / 100000, // Dummy size calculation
                documentRequest.getValidUpto(),
                "Saved", // Default status
                fileReferenceId
        );
        documentsStore.put(newId, newDoc); // Store in our dummy map

        return newId;
    }

  /**
   * Fetches all stored documents.
   * In a real application, this would query the database.
   *
   * @return A list of all DocumentDetailResponse objects.
   */
  public List<DocumentDetailOldResponseDTO> getAllDocuments() {
        return new ArrayList<>(documentsStore.values());
    }
}

