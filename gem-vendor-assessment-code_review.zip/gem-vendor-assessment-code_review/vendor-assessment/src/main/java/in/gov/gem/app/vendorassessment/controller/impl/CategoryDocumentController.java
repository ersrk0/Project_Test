
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;

import com.amazonaws.services.secretsmanager.model.ResourceNotFoundException;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.controller.ICategoryDocumentController;
import in.gov.gem.app.vendorassessment.dto.request.CatDocumentUploadRequestDto;
import in.gov.gem.app.vendorassessment.dto.request.CategoryDocumentDto;
import in.gov.gem.app.vendorassessment.dto.response.CategoryDocumentResponse;
import in.gov.gem.app.vendorassessment.facade.ICategoryDocumentFacade;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Instant;

@RestController
@AllArgsConstructor
public class CategoryDocumentController implements ICategoryDocumentController {

    private final ICategoryDocumentFacade documentFacade;

    /**
     * DocumentController handles document-related operations for questions in categories.
     * It provides APIs to fetch, upload, delete, and view/download documents associated with specific questions.
     */
    @Override
    public ResponseEntity<APIResponse<Object>> getDocumentsForQuestion(Long categoryId, Long questionId) {
        CategoryDocumentResponse documents = documentFacade.getDocumentsForQuestion(categoryId, questionId);
        return ResponseEntity.ok(APIResponse.builder()
                .msId("VCS")
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message("Fetched documents successfully.")
                .data(documents)
                .build());

    }

    // API to upload documents
    @Override
    public ResponseEntity<APIResponse<Object>> uploadDocument(Long categoryId, Long questionId, MultipartFile file, Instant validUptoStr) throws IOException {

        // Manually create DTO for MultipartFile and other form data
        CatDocumentUploadRequestDto requestDto = new CatDocumentUploadRequestDto();
        requestDto.setFile(file);
        requestDto.setDocumentType(file.getContentType());
        if (validUptoStr != null) {
            requestDto.setValidUpto(validUptoStr);
        }

        CategoryDocumentDto uploadedDocument = documentFacade.uploadDocument(categoryId, questionId, requestDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(APIResponse.builder()
                        .msId("VCS")
                        .status(HttpStatus.CREATED.getReasonPhrase())
                        .httpStatus(HttpStatus.CREATED.value())
                        .message("Document uploaded successfully.")
                        .data(uploadedDocument)
                        .build());
    }

    // API to delete a document
    @Override
    public ResponseEntity<APIResponse<Object>> deleteDocument(Long categoryId, Long questionId, Long documentId) throws IOException {
        documentFacade.deleteDocument(categoryId, questionId, documentId);
        return ResponseEntity.ok(APIResponse.<Object>builder()
                .msId("VCS")
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message("Document deleted successfully.")
                .data(null)
                .build());

    }

    // API to view/download a document (e.g., /api/documents/{documentId}/view, if you split it)
    // Here it's integrated via a path on the document itself
    @Override
    public ResponseEntity<byte[]> viewDocument(Long categoryId, Long questionId, Long documentId) throws IOException {
        byte[] documentBytes = documentFacade.downloadDocument(categoryId, questionId, documentId);
        CategoryDocumentDto docDto = documentFacade.getDocumentsForQuestion(categoryId, questionId).getDocuments().stream()
                .filter(d -> d.getDocumentId().equals(documentId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Document metadata not found for ID: " + documentId));

        MediaType contentType = MediaType.APPLICATION_OCTET_STREAM; // Default
        if (docDto.getDocumentName().endsWith(".pdf")) {
            contentType = MediaType.APPLICATION_PDF;
        } else if (docDto.getDocumentName().endsWith(".png")) {
            contentType = MediaType.IMAGE_PNG;
        } else if (docDto.getDocumentName().endsWith(".jpg") || docDto.getDocumentName().endsWith(".jpeg")) {
            contentType = MediaType.IMAGE_JPEG;
        }

        return ResponseEntity.ok()
                .contentType(contentType)
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + docDto.getDocumentName() + "\"") // "inline" to view in browser, "attachment" to download
                .body(documentBytes);
    }
}
