
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;

import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressUpdateRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.*;
import java.util.List;

/**
 * The interface Office address client facade.
 */
public interface IOfficeAddressClientFacade
{


  /**
   * Gets office addresses from seller.
   *
   * @param paginationParams the pagination params
   * @param vaNumber         the va number
   * @return the office addresses from seller
   */
  public List<OfficeSellerResponseDTO> getOfficeAddressesFromSeller(PaginationParams paginationParams, String vaNumber);

  /**
   * Gets office addressespredefined.
   *
   * @param paginationParams the pagination params
   * @param vaNumber         the va number
   * @return the office addressespredefined
   */
  public List<OfficePreSellerResponseDTO> getOfficeAddressespredefined(PaginationParams paginationParams,
                                                                       String vaNumber);

  /**
   * Save office address office vo response dto.
   *
   * @param officeAddressRequestDTO the office address request dto
   * @return the office vo response dto
   */
  public OfficeVOResponseDTO saveOfficeAddress(OfficeAddressRequestDTO officeAddressRequestDTO);

  /**
   * Delete office address.
   *
   * @param pvtOrgOfficeId the pvt org office id
   */
  public void deleteOfficeAddress(Long pvtOrgOfficeId);

  /**
   * Update office address.
   *
   * @param officeAddressUpdateRequestDTO the office address update request dto
   */
  public void updateOfficeAddress(OfficeAddressUpdateRequestDTO officeAddressUpdateRequestDTO);


  /**
   * Gets registered office mobile list.
   *
   * @param paginationParams the pagination params
   * @return the registered office mobile list
   */
  public List<OfficeVOResponseDTO> getRegisteredOfficeMobileList(PaginationParams paginationParams);

  /**
   * Gets registered office email list.
   *
   * @param paginationParams the pagination params
   * @return the registered office email list
   */
  public List<OfficeVOResponseDTO> getRegisteredOfficeEmailList(PaginationParams paginationParams);


}
