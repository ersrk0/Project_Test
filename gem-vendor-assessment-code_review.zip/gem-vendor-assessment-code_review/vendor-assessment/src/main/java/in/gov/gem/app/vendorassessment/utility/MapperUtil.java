package in.gov.gem.app.vendorassessment.utility;



import in.gov.gem.app.vendorassessment.domain.entity.Category;
import in.gov.gem.app.vendorassessment.domain.entity.Document;
import in.gov.gem.app.vendorassessment.domain.entity.Question;
import in.gov.gem.app.vendorassessment.dto.request.CategoryNewRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.CategoryDocumentDto;
import in.gov.gem.app.vendorassessment.dto.request.QuestionDto;
import in.gov.gem.app.vendorassessment.dto.response.QuestionResponseDto;
import in.gov.gem.app.vendorassessment.dto.response.QuestionnaireResponse;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class MapperUtil {

    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    public static CategoryNewRequestDTO toCategoryDto(Category category) {
        if (category == null) return null;
        CategoryNewRequestDTO dto = new CategoryNewRequestDTO();
        dto.setId(category.getId());
        dto.setName(category.getName());
        dto.setSection(category.getSection());
        return dto;
    }

    public static QuestionDto toQuestionDto(Question question) {
        if (question == null) return null;
        QuestionDto dto = new QuestionDto();
        dto.setQuestionId(question.getId());
        dto.setQuestionText(question.getQuestionText());
        dto.setQuestionType(question.getQuestionType());
        dto.setRequired(question.isRequired());
        dto.setAssociatedInfoMessage(question.getAssociatedInfoMessage());
        return dto;
    }

    public static CategoryDocumentDto toDocumentDto(Document document) {
        if (document == null) return null;
        CategoryDocumentDto dto = new CategoryDocumentDto();
        dto.setDocumentId(document.getId());
        dto.setDocumentName(document.getDocumentName());
        dto.setDocumentType(document.getDocumentType());
        dto.setUploadedOn(document.getUploadedOn().toString());
        dto.setValidUpto(document.getValidUpto().toString());
        dto.setDocumentSize(formatSize(document.getDocumentSizeKb()));
        dto.setActions(List.of("View", "Delete"));
        dto.setViewUrl("/api/documents/" + document.getId() + "/view");
        dto.setDeleteUrl("/api/documents/" + document.getId());
        return dto;
    }





    public static QuestionnaireResponse toQuestionnaireResponse(QuestionResponseDto dto, Question question, Category category) {
        if (dto == null || question == null || category == null) return null;
        QuestionnaireResponse entity = new QuestionnaireResponse();
        entity.setQuestionId(question.getId()); // Store ID
        entity.setCategoryId(category.getId()); // Store ID
        entity.setAnswer(dto.getAnswer());
        entity.setResponseDate(LocalDateTime.now());
        return entity;
    }

    public static QuestionResponseDto toQuestionResponseDto(QuestionnaireResponse entity) {
        if (entity == null) return null;
        QuestionResponseDto dto = new QuestionResponseDto();
        dto.setQuestionId(entity.getQuestionId());
        dto.setAnswer(entity.getAnswer());
        return dto;
    }

    static String formatSize(Long sizeKb) {
        if (sizeKb == null) return "0 KB";
        if (sizeKb < 1024) {
            return sizeKb + " KB";
        }
        double sizeMb = sizeKb / 1024.0;
        return String.format("%.1f MB", sizeMb);
    }
}
