
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */
package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.service.core.security.securityUtils.GemUtility;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.utility.CustomLoggerFactory;
import in.gov.gem.app.vendorassessment.client.IIamClient;
import in.gov.gem.app.vendorassessment.dto.request.*;
import in.gov.gem.app.vendorassessment.dto.response.*;
import in.gov.gem.app.vendorassessment.facade.IIAMFacade;
import in.gov.gem.app.vendorassessment.transformer.IAMTransformer;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Optional;


/**
 * The type Iam facade.
 */
@Component
@AllArgsConstructor
public class IAMFacade implements IIAMFacade
{
  private IIamClient iIamClient;

  private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(IAMTransformer.class);

  /**
   * Add mobile.
   *
   * @param acceptLanguage the accept language
   * @param contactRequest the contact request
   */
  public void addMobile(String acceptLanguage, AddMobileRequestDTO contactRequest) {
    iIamClient.saveAdditionalMobile(acceptLanguage, contactRequest);
  }

  /**
   * Add email.
   *
   * @param acceptLanguage the accept language
   * @param contactRequest the contact request
   */
  public void addEmail(String acceptLanguage, AddEmailRequestDTO contactRequest) {
    iIamClient.saveAdditionalEmail(acceptLanguage, contactRequest);
  }

  /**
   * Sent otp via mobile response entity.
   *
   * @param otpResp the otp resp
   * @return the response entity
   */
  public ResponseEntity<APIResponse<OtpResponseDTO>> SentOtpViaMobile(SendOtpRequestDTO otpResp) {
    return iIamClient.sendOtp(otpResp);
  }

  /**
   * Re sent otp via mobile response entity.
   *
   * @param reSendRequestDTO the re send request dto
   * @return the response entity
   */
  public ResponseEntity<APIResponse<ResendOtpResponseDTO>> ReSentOtpViaMobile(ReSendRequestDTO reSendRequestDTO) {
    return iIamClient.reSendOtp(reSendRequestDTO);
  }

  /**
   * Validate otp response entity.
   *
   * @param otpValidateRequestDTO the otp validate request dto
   * @return the response entity
   */
  public ResponseEntity<APIResponse<Object>> validateOtp(OTPValidateRequestDTO otpValidateRequestDTO) {
    return iIamClient.validateOtp(otpValidateRequestDTO);
  }

  /**
   * Gets user.
   *
   * @return the user
   */
  public UserDetailResponseDTO getUser()
  {
    String userId = String.valueOf(GemUtility.getGemContext().getUserContext().getKeycloakUserId());

    ResponseEntity<APIResponse<UmsProfileResponseDTO>> response = iIamClient.fetchUserDetails(userId);

    Optional<UmsProfileResponseDTO> user = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(APIResponse::getData);

    if (user.isEmpty()) {
      log.info("No Email Id and Phone Number found for the given parameters.");
      return new UserDetailResponseDTO(); // Handle the empty case appropriately
    }

    UmsProfileResponseDTO umsProfileResponseDTO = user.get();
    return UserDetailResponseDTO.builder()
      .emailId(umsProfileResponseDTO.getEmailId())
      .mobileNumber(umsProfileResponseDTO.getAadhaarMobileNumber())
      .build();
  }

  /**
   * Gets ip address.
   *
   * @return the ip address
   */
  public IpAddressResponseDTO getIpAddress()
  {
    String ipAddress = GemUtility.getGemContext().getHttpRequestContext().getIpAddress();
    return IpAddressResponseDTO.builder()
      .ipAddress(ipAddress)
      .build();
  }


}
