
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;


import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;


import in.gov.gem.app.vendorassessment.dto.request.VendorAssessmentNewRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.InitiateResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VendorAssessmentIdResponseDTO;
import in.gov.gem.app.vendorassessment.controller.IInitiateAssessmentController;
import in.gov.gem.app.vendorassessment.facade.IInitiateAssessmentFacade;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * The type Initiate assessment controller.
 */
@RestController
@AllArgsConstructor
public class InitiateAssessmentController extends BaseParentController implements IInitiateAssessmentController {

    private IInitiateAssessmentFacade vendorAssessmentFacade;

    public ResponseEntity<APIResponse<Object>> initiateVendorAssessment(@RequestBody VendorAssessmentNewRequestDTO request) {
        InitiateResponseDTO initiateResponseDTO = vendorAssessmentFacade.initiateVendorAssessment(request);
        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.CREATED_MESSAGE)
                .data(initiateResponseDTO)
                .build());
    }

    public ResponseEntity<APIResponse<Object>> fetchSupplementaryVAId() {
        VendorAssessmentIdResponseDTO vendorAssessmentIdDTO= vendorAssessmentFacade.fetchSupplementaryVAId();
        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.FETCH_MESSAGE)
                .data(vendorAssessmentIdDTO)
                .build());
    }

    public ResponseEntity<APIResponse<Object>> fetchBrandOemOspDashboardStatus(@RequestParam Long id) {
        boolean status = vendorAssessmentFacade.fetchBrandOemOspDashboardStatus(id);
        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.FETCH_MESSAGE)
                .data(status)
                .build());
    }
}




