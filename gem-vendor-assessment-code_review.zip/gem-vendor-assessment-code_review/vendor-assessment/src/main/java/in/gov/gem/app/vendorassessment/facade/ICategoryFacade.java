
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;

import in.gov.gem.app.vendorassessment.domain.entity.Category;
import in.gov.gem.app.vendorassessment.dto.request.CategoryRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.CategoryNewResponseDTO;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Interface for the CategoryFacade.
 * This interface defines the contract for managing product categories,
 * including creation, retrieval, bulk operations, and search functionality.
 */
public interface ICategoryFacade {

  /**
   * Creates a new category based on the provided DTO.
   *
   * @param requestDTO The CategoryRequestDTO containing the details of the new category.
   * @return A CategoryResponseDTO of the created category.
   */
  CategoryNewResponseDTO createCategory(CategoryRequestDTO requestDTO);

  /**
   * Retrieves a category by its unique ID.
   *
   * @param id The ID of the category to retrieve.
   * @return A CategoryResponseDTO if the category is found, otherwise returns null.
   */
  CategoryNewResponseDTO getCategoryById(String id);

  /**
   * Adds a list of categories in bulk, optionally associating them with a vaId.
   *
   * @param categoryRequests The list of CategoryRequestDTOs to be added.
   * @param vaId The optional vaId to associate with the new categories.
   * @throws IllegalArgumentException if a category in the list already exists.
   */
  void bulkAddCategories(List<CategoryRequestDTO> categoryRequests, String vaId);

  /**
   * Retrieves the hierarchical tree of categories.
   *
   * @param type An optional type to filter the category tree.
   * @param vaId An optional vaId to filter the category tree.
   * @return A list of top-level CategoryResponseDTOs, each containing its children.
   */
  List<CategoryNewResponseDTO> getCategoryTree(Optional<String> type, String vaId);

  /**
   * Checks for categories with similar names before a new category is added.
   *
   * @param categoryName A list of CategoryRequestDTOs to check.
   * @return An AddCategoryCheckResponse containing similar categories and a flag
   * indicating if confirmation is needed.
   */
  Map<String, Object> checkAndPrepareAddCategory(List<CategoryRequestDTO> categoryName);

  /**
   * Retrieves a list of all categories that are currently marked as "saved".
   *
   * @param vaId The vaId to filter saved categories.
   * @return A list of saved categories.
   */
  List<Category> getSavedCategories(String vaId);

  /**
   * Adds a category to the "saved" list.
   *
   * @param categoryId The ID of the category to save.
   * @param type The type of the category.
   * @param vaId The vaId to associate with the saved category.
   * @return True if the category was successfully added, false otherwise.
   */
  boolean addCategoryToSaved(Long categoryId, String type, String vaId);

  /**
   * Searches for eligible categories based on a set of criteria.
   *
   * @param type The type of the category.
   * @param name Optional: A partial, case-insensitive match for the category name.
   * @param parentId Optional: The parent category ID for an exact match.
   * @param exactMatch Optional: A flag to specify an exact name match.
   * @return A list of categories that match the provided criteria.
   */
  List<Category> searchEligibleCategoriesByCriteria(String type, String name, Long parentId, Boolean exactMatch);

  /**
   * Removes a category from the "saved" list.
   *
   * @param categoryId The ID of the category to remove.
   * @param type The type of the category.
   * @param vaId The vaId of the saved category.
   * @return True if the category was successfully removed, false otherwise.
   */
  boolean removeCategoryFromSaved(Long categoryId, String type, String vaId);

  /**
   * Searches within the "saved" categories based on a search query.
   *
   * @param query The search string.
   * @param type The type of the category.
   * @param vaId The vaId to filter the search.
   * @return A list of saved categories that match the query.
   */
  List<Category> searchSavedCategories(String query, String type, String vaId);
}
