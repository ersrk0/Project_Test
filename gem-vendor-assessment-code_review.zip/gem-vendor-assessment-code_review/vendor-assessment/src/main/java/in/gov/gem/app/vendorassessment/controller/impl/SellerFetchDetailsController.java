
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;

import com.fasterxml.jackson.core.JsonProcessingException;


import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.utility.MessageUtility;

import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressUpdateRequestDTO;


import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.controller.ISellerFetchDetailsController;
import in.gov.gem.app.vendorassessment.dto.response.*;
import in.gov.gem.app.vendorassessment.facade.Impl.SellerFetchDetailsFacade;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * The type Seller fetch details controller.
 */
@RestController
@AllArgsConstructor
public class SellerFetchDetailsController extends BaseParentController implements ISellerFetchDetailsController
{
  private ISellerClient iSellerClient;
  private MessageUtility messageUtility;

  private final SellerFetchDetailsFacade sellerFetchDetailsFacade;

  @Override
  public ResponseEntity<APIResponse<Object>> checkingProfile() {
    ResponseEntity<APIResponse<ProfileStatusResponseDTO>> apiResponseResponseEntity =
      iSellerClient.checkProfileCompletion();

    // Handle null for apiResponseResponseEntity and its body
    ProfileStatusResponseDTO data = Optional.ofNullable(apiResponseResponseEntity)
      .map(ResponseEntity::getBody)
      .map(APIResponse::getData)
      .orElse(null); // Assign null if any part of the chain is null

    if (data == null || !data.isConsentDeclared() || !data.isBusinessDetailsFilled() ||
      !data.isOfficeAddressSaved() || !data.isKeyPersonVerified()) {
      // If data is null, or any of the flags are false, throw ServiceException
      throw new ServiceException(MessageConstant.SELLER_PROFILE_NOT_COMPLETE,
        messageUtility.getMessage(MessageConstant.SELLER_PROFILE_NOT_COMPLETE),
        ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
    }

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_PROFILE_MESSAGE)
      .data(ApplicationConstant.FETCH_PROFILE_COMPLETE_SUCCESS)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getProfileFromSeller() throws JsonProcessingException {
    ProfileSellerResponseDTO profileFromSeller = sellerFetchDetailsFacade.getProfileFromSeller();

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(profileFromSeller)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getPanFromSeller() {
    PanResponseResponseDTO panFromSeller = sellerFetchDetailsFacade.getPanFromSeller();

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(panFromSeller)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getTanFromSeller(PaginationParams paginationParams) {
    List<TanResponseDTO> tanFromSeller = sellerFetchDetailsFacade.getTanFromSeller(paginationParams);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(tanFromSeller)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getBankFromSeller(PaginationParams paginationParams, @RequestHeader(
    name = "Accept-Language") String languageCode) {
    List<BankSellerResponseDTO> bankDetailFromSeller = sellerFetchDetailsFacade.getBankFromSeller(paginationParams, languageCode);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(bankDetailFromSeller)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getAddressFromSeller(PaginationParams paginationParams,@RequestParam(required = false)
  String vaNumber)
  {

    List<OfficeSellerResponseDTO> officeAddressesFromSeller =
      sellerFetchDetailsFacade.getAddressFromSeller(paginationParams,vaNumber);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(officeAddressesFromSeller)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getPreDefinedAddressFromSeller(PaginationParams paginationParams,
                                                                            @RequestParam(required = false) String vaNumber)
  {


    List<OfficePreSellerResponseDTO> officeAddressespredefined= sellerFetchDetailsFacade.getPreDefinedAddressFromSeller(paginationParams,
      vaNumber);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(officeAddressespredefined)
      .build());
  }
  @Override
  public ResponseEntity<APIResponse<Object>> saveAddressInSeller(@RequestBody OfficeAddressRequestDTO officeAddressRequestDTO)
  {
    OfficeVOResponseDTO officeVO = sellerFetchDetailsFacade.saveAddressInSeller(officeAddressRequestDTO);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.SAVE_SELLER_MESSAGE)
      .data(officeVO) // Assuming no data is returned after saving
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> deleteAddressInSeller(@RequestParam Long pvtOrgOfficeId)
  {
    sellerFetchDetailsFacade.deleteAddressInSeller(pvtOrgOfficeId);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.DELETE_SELLER_MESSAGE)
      .data(null) // Assuming no data is returned after saving
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> updateAddressInSeller(@RequestBody OfficeAddressUpdateRequestDTO officeAddressUpdateRequestDTO)
  {
    sellerFetchDetailsFacade.updateAddressInSeller(officeAddressUpdateRequestDTO);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.UPDATE_SELLER_MESSAGE)
      .data(null) // Assuming no data is returned after saving
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getRegisteredOfficeMobileList(PaginationParams paginationParams) {

    List<OfficeVOResponseDTO> registeredOfficeMobileList =
      sellerFetchDetailsFacade.getRegisteredOfficeMobileList(paginationParams);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(registeredOfficeMobileList)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getRegisteredOfficeEmailList(PaginationParams paginationParams) {


    List<OfficeVOResponseDTO> registeredOfficeEmailList =
      sellerFetchDetailsFacade.getRegisteredOfficeEmailList(paginationParams);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(registeredOfficeEmailList)
      .build());
  }


  @Override
  public ResponseEntity<APIResponse<Object>> getFinancialFromSeller(PaginationParams paginationParams) {
    List<TurnoverSellerResponseDTO> financialDetailsFromSeller = sellerFetchDetailsFacade.getFinancialFromSeller(paginationParams);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(financialDetailsFromSeller)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getTurnoverFromSeller() {
    TurnoverResponseDTO turnOverFromSeller = sellerFetchDetailsFacade.getTurnoverFromSeller();

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(turnOverFromSeller)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getUserDetails() {
    UserDetailResponseDTO user = sellerFetchDetailsFacade.getUserDetails();

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(user)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getIPAddress()
  {
    IpAddressResponseDTO ipAddressResponse = sellerFetchDetailsFacade.getIPAddress();

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_SELLER_MESSAGE)
      .data(ipAddressResponse)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getVerifyGstin(
    @Pattern(regexp = "^[0-9]{2}[A-Z]{3}[ABCFGHLJPTF]{1}[A-Z]{1}[0-9]{4}[A-Z]{1}[1-9]{1}[A-Z0-9]{2}$", message = "Invalid GSTIN format")
    @RequestParam String gstin) {
    boolean isValid = sellerFetchDetailsFacade.getVerifyGstin(gstin, false);

    return ResponseEntity.status(isValid ? HttpStatus.OK : HttpStatus.BAD_REQUEST).body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(isValid ? ApplicationConstant.AUTHORIZING_STATUS_SUCCESS : ApplicationConstant.AUTHORIZING_STATUS_FAILED)
      .data(isValid)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getVerifyManufacturingGstin(
    @Pattern(regexp = "^[0-9]{2}[A-Z]{3}[ABCFGHLJPTF]{1}[A-Z]{1}[0-9]{4}[A-Z]{1}[1-9]{1}[A-Z0-9]{2}$", message = "Invalid GSTIN format")
    @RequestParam String gstin) {
    boolean isValid = sellerFetchDetailsFacade.getVerifyGstin(gstin,false);

    return ResponseEntity.status(isValid ? HttpStatus.OK : HttpStatus.BAD_REQUEST).body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(isValid ? ApplicationConstant.FETCH_SELLER_MESSAGE : ApplicationConstant.INVALID_GSTIN)
      .data(isValid)
      .build());
  }
}