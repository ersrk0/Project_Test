
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.utility.CustomLoggerFactory;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.controller.IAssessmentRequestController;
import in.gov.gem.app.vendorassessment.facade.IAssessmentRequestFacade;
import in.gov.gem.app.vendorassessment.dto.request.AssessmentNewRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.AssessmentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OrganisationDetailsRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ReSendRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.MobileOtpValidationRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OTPValidateRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ManufacturingLocationDecisionRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.ResendOtpResponseDTO;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;


import java.util.Objects;

/**
 * REST Controller for managing Supplementary Assessment Requests.
 */
@RestController
@AllArgsConstructor
public class AssessmentRequestController extends BaseParentController implements IAssessmentRequestController {

    private final IAssessmentRequestFacade assessmentRequestFacadeInterface;

    private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(this.getClass());

    @Override
    public ResponseEntity<APIResponse<OrganisationDetailsRequestDTO>> getOrganizationDetails(String vaId) {
        log.info("Fetching organization details for VA ID: {}", vaId);
        OrganisationDetailsRequestDTO organisationDetails = assessmentRequestFacadeInterface.getOrganizationDetails(vaId);
        return ResponseEntity.ok().body(
                APIResponse.<OrganisationDetailsRequestDTO>builder()
                        .msId(ApplicationConstant.MSID)
                        .status(HttpStatus.OK.getReasonPhrase())
                        .httpStatus(HttpStatus.OK.value())
                        .message(ApplicationConstant.GET_ORGANIZATION_DETAIL)
                        .data(organisationDetails)
                        .build());
    }

    @Override
    public ResponseEntity<APIResponse<AssessmentNewRequestDTO>> createRequest(AssessmentRequestDTO requestDTO) {
        log.info("Creating assessment request with details: {}", requestDTO);
        AssessmentNewRequestDTO createdRequest = assessmentRequestFacadeInterface.createAssessmentRequest(requestDTO);
        return ResponseEntity.ok().body(
                APIResponse.<AssessmentNewRequestDTO>builder()
                        .msId(ApplicationConstant.MSID)
                        .status(HttpStatus.CREATED.getReasonPhrase())
                        .httpStatus(HttpStatus.CREATED.value())
                        .message(ApplicationConstant.SUBMIT_ORGANIZATION_DETAIL)
                        .data(createdRequest)
                        .build());
    }

    @Override
    public ResponseEntity<APIResponse<OtpResponseDTO>> sendOtpEmail(String email) {
        log.info("Sending OTP to email: {}", email);
        ResponseEntity<APIResponse<OtpResponseDTO>> otpResponse = assessmentRequestFacadeInterface.sendOtpInter(email);
        OtpResponseDTO otpRes = new OtpResponseDTO(Objects.requireNonNull(otpResponse.getBody()).getData().getReferenceId());
        return ResponseEntity.ok().body(
                APIResponse.<OtpResponseDTO>builder()
                        .status(HttpStatus.OK.getReasonPhrase())
                        .httpStatus(HttpStatus.OK.value())
                        .message(ApplicationConstant.GET_OTP)
                        .msId(ApplicationConstant.MSID)
                        .data(otpRes)
                        .build());
    }

    @Override
    public ResponseEntity<APIResponse<ResendOtpResponseDTO>> resendOtpEmail(ReSendRequestDTO reSendRequestDTO) {
        log.info("Resending OTP with details: {}", reSendRequestDTO);
        ResponseEntity<APIResponse<ResendOtpResponseDTO>> response = assessmentRequestFacadeInterface.resendOtpInter(reSendRequestDTO);
        ResendOtpResponseDTO res = Objects.requireNonNull(response.getBody()).getData();
        return ResponseEntity.ok().body(
                APIResponse.<ResendOtpResponseDTO>builder()
                        .msId(ApplicationConstant.MSID)
                        .status(HttpStatus.OK.getReasonPhrase())
                        .httpStatus(HttpStatus.OK.value())
                        .message(ApplicationConstant.RESEND_OTP)
                        .data(res)
                        .build());
    }

    @Override
    public ResponseEntity<APIResponse<String>> updateMobileNumber(String vaId, MobileOtpValidationRequestDTO mobileOtpValidationRequestDTO) {
        log.info("Updating mobile number for VA ID: {}, with details: {}", vaId, mobileOtpValidationRequestDTO);
        String isOtpValid = assessmentRequestFacadeInterface.validateOtpMobile(mobileOtpValidationRequestDTO, vaId, mobileOtpValidationRequestDTO.getMobile());
        return ResponseEntity.ok().body(
                APIResponse.<String>builder()
                        .msId(ApplicationConstant.MSID)
                        .status(HttpStatus.OK.getReasonPhrase())
                        .httpStatus(HttpStatus.OK.value())
                        .message(ApplicationConstant.MOBILE_UPDATED)
                        .data(isOtpValid)
                        .build());
    }

    @Override
    public ResponseEntity<APIResponse<String>> updateEmailId(String vaId, OTPValidateRequestDTO otpValidateRequestDTO) {
        log.info("Updating email ID for VA ID: {}, with details: {}", vaId, otpValidateRequestDTO);
        String isOtpValid = assessmentRequestFacadeInterface.validateOtp(otpValidateRequestDTO, vaId, otpValidateRequestDTO.getNewEmail());
        return ResponseEntity.ok().body(
                APIResponse.<String>builder()
                        .msId(ApplicationConstant.MSID)
                        .status(HttpStatus.OK.getReasonPhrase())
                        .httpStatus(HttpStatus.OK.value())
                        .message(ApplicationConstant.EMAIL_UPDATED)
                        .data(isOtpValid)
                        .build());
    }

    @Override
    public ResponseEntity<APIResponse<ManufacturingLocationDecisionRequestDTO>> updateManufacturingLocationDecision(
            ManufacturingLocationDecisionRequestDTO addNewLocation) {
        log.info("Updating manufacturing location decision with details: {}", addNewLocation);
        ManufacturingLocationDecisionRequestDTO updatedRequest = assessmentRequestFacadeInterface.updateManufacturingLocationDecision(addNewLocation);
        return ResponseEntity.ok().body(
                APIResponse.<ManufacturingLocationDecisionRequestDTO>builder()
                        .msId(ApplicationConstant.MSID)
                        .status(HttpStatus.OK.getReasonPhrase())
                        .httpStatus(HttpStatus.OK.value())
                        .message(ApplicationConstant.MANUFACTURING_LOCATION_DECISION)
                        .data(updatedRequest)
                        .build());
    }
}

