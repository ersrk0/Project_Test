
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.vendorassessment.dto.request.VendorAssessmentNewRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.InitiateResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VendorAssessmentIdResponseDTO;
import in.gov.gem.app.vendorassessment.facade.IInitiateAssessmentFacade;
import in.gov.gem.app.vendorassessment.service.IInitiateAssessmentService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * The type Initiate assessment facade.
 */
@Component
@AllArgsConstructor
public class InitiateAssessmentFacade implements IInitiateAssessmentFacade {
    private IInitiateAssessmentService vendorAssessmentService;

    public InitiateResponseDTO initiateVendorAssessment(VendorAssessmentNewRequestDTO request) {
        return vendorAssessmentService.initiateVendorAssessment(request);
    }

    public boolean fetchBrandOemOspDashboardStatus(Long id) {
        return vendorAssessmentService.fetchBrandOemOspDashboardStatus(id);
    }

    public VendorAssessmentIdResponseDTO fetchSupplementaryVAId() {
        return vendorAssessmentService.fetchSupplementaryVAId();
    }
}
