
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.dto.request.WorkExperienceNewRequestDTO;
import in.gov.gem.app.vendorassessment.controller.IWorkVendorExperienceController;
import in.gov.gem.app.vendorassessment.facade.IWorkVendorExperienceFacade;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * The type Work vendor experience controller.
 */
@RestController
@RequiredArgsConstructor
public class WorkVendorExperienceController extends BaseParentController implements IWorkVendorExperienceController {

  private final IWorkVendorExperienceFacade workVendorExperienceFacade;

  @Override
  public ResponseEntity<APIResponse<Object>> getOrgAllType(String acceptLanguage, PaginationParams paginationParams) {
    return ResponseEntity.ok(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.ORGANIZATION_TYPES_FETCHED_SUCCESS)
            .data(workVendorExperienceFacade.getOrgType(acceptLanguage, paginationParams))
            .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getOrgAllTypeWithlevel(String parentId, String acceptLanguage, PaginationParams paginationParams) {
    return ResponseEntity.ok(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.HEIRARCHY_FETCHED_SUCCESS)
            .data(workVendorExperienceFacade.getOrgTypeWithLevel(parentId, acceptLanguage, paginationParams))
            .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> createWorkExperience(WorkExperienceNewRequestDTO createRequest) {
    return ResponseEntity.ok(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.WORK_EXPERIENCE_CREATED)
            .data(workVendorExperienceFacade.createWorkExperience(createRequest))
            .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getWorkExperience(Long vaMasterFk) {
    return ResponseEntity.ok(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.WORK_EXPERIENCE_GET_SUCCESS)
            .data(workVendorExperienceFacade.findByVaMasterFk(vaMasterFk))
            .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> getVendorWorkExperience(Long vaMasterFk, PaginationParams paginationParams) {
    PageableApiResponse<List<WorkExperienceNewRequestDTO>> byVaMasterFk = workVendorExperienceFacade.findByVaMasterFk(vaMasterFk, paginationParams);
    return ResponseEntity.ok(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.WORK_EXPERIENCE_GET_SUCCESS)
            .data(byVaMasterFk.getData())
            .build());
  }
}