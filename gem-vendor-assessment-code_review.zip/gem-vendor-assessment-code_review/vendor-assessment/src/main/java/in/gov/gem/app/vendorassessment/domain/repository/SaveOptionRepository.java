
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.repository;




import in.gov.gem.app.service.core.repository.BaseRepository;
import in.gov.gem.app.vendorassessment.domain.entity.VAMasterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


/**
 * The interface Save option repository.
 */
@Repository

public interface SaveOptionRepository extends BaseRepository<VAMasterEntity,Long> {

}
