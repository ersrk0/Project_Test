
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;


import in.gov.gem.app.vendorassessment.controller.IRelaxationController;
import in.gov.gem.app.vendorassessment.dto.request.AddBodDocumentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.DocumentDetailResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.DocumentNewResponseDTO;
import in.gov.gem.app.vendorassessment.facade.IAdditionalOrganisationDetailFacade;
import in.gov.gem.app.vendorassessment.facade.IVaRelaxationExemptionFacade;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * The type Relaxation controller.
 */
@RestController
@AllArgsConstructor
@RequestMapping("/v1/exemptions")
public class RelaxationController extends BaseParentController implements IRelaxationController {

  private final IVaRelaxationExemptionFacade vaRelaxationExemptionFacade;
  private final IAdditionalOrganisationDetailFacade additionalOrganisationDetailFacade;


  @Override
  public ResponseEntity<APIResponse<Object>> addDocument(AddBodDocumentRequestDTO request
  ) {
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.SAVE_MESSAGE)
      .data(additionalOrganisationDetailFacade.addBodDocument(request))
      .build());

  }


  @Override
  public ResponseEntity<PageableApiResponse<List<DocumentNewResponseDTO>>> getAllDocuments(Long vaMasterId,
                                                                                           PaginationParams paginationParams) {

    Page<DocumentDetailResponseDTO> documentResponses = additionalOrganisationDetailFacade.ByVaMasterFk(vaMasterId, paginationParams);
    Page<DocumentNewResponseDTO> pageResponse = vaRelaxationExemptionFacade.convertToDocumentRes(documentResponses);
    return ResponseEntity.ok().body(PageableApiResponse.<List<DocumentNewResponseDTO>>pageableApiResponseBuilder()
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.FETCH_MESSAGE)
      .msId(ApplicationConstant.MSID)
      .data(pageResponse.getContent())
      .currentPage(pageResponse.getNumber())
      .totalPages(pageResponse.getTotalPages())
      .currentElements(pageResponse.getNumberOfElements())
      .hasNext(pageResponse.hasNext())
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> deleteDocument(Long vaMasterFk, String docName) {
    additionalOrganisationDetailFacade.deleteBodDocument(vaMasterFk, docName);
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.DELETE_VALUE_MESSAGE)
      .data(null)
      .build());
  }



}
