
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.facade;


import in.gov.gem.app.vendorassessment.dto.request.AuthorizeDetailRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ContractManufacturerRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.LookupRequestDTO;

import in.gov.gem.app.vendorassessment.dto.response.*;
import org.springframework.stereotype.Component;

/**
 * The interface Save assess option facade.
 */
@Component
public interface ISaveAssessOptionFacade {

  /**
   * Save option save assess response dto.
   *
   * @param lookupRequestDto the lookup request dto
   * @param skip             the skip
   * @return the save assess response dto
   */
  public SaveAssessResponseDTO saveOption(LookupRequestDTO lookupRequestDto, boolean skip) ;


  /**
   * Identify registration identify registration response dto.
   *
   * @return the identify registration response dto
   */
  public IdentifyRegistrationResponseDTO identifyRegistration() ;

  /**
   * Authorize detail save authorize response dto.
   *
   * @param authorizeDetailDTO the authorize detail dto
   * @return the authorize response dto
   */
  public AuthorizeResponseDTO authorizeDetailSave(AuthorizeDetailRequestDTO authorizeDetailDTO);

  /**
   * Contract manufacturer detail save contract manufacturer response dto.
   *
   * @param contractManufacturerDTO the contract manufacturer dto
   * @return the contract manufacturer response dto
   */
  public ContractManufacturerResponseDTO contractManufacturerDetailSave(ContractManufacturerRequestDTO contractManufacturerDTO) ;

  /**
   * Gets contract manufacturer detail.
   *
   * @param id the id
   * @return the contract manufacturer detail
   */
  public ContractManufacturerRequestDTO getContractManufacturerDetail(long id) ;

  /**
   * Gets authorize detail save.
   *
   * @param id the id
   * @return the authorize detail save
   */
  public AuthorizeDetailRequestDTO getAuthorizeDetailSave(long id) ;

  /**
   * Gets assess.
   *
   * @param id the id
   * @return the assess
   */
  public AssessResponseDTO getAssess(long id);
}
