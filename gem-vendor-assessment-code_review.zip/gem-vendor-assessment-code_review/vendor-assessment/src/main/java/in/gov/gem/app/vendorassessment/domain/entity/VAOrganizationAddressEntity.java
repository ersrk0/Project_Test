
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.entity;


import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * The type Va organization address entity.
 */
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@SuperBuilder
@Table(name = "va_organization_address", schema = "va_mgmt")
public class VAOrganizationAddressEntity extends BaseEntity
{

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "va_organization_detail_fk")
  private Long vaOrganizationDetailFk;

  @Column(name = "name")
  private String officeName;

  @Column(name = "type_lookup", length = 10)
  private String officeTypeLookup;

  @Column(name = "office_address")
  private String officeAddressLine1;

  @Column(name = "address_2")
  private String officeAddressLine2;

  @Column(name = "landmark")
  private String officeLandmark;

  @Column(name = "pincode_lookup")
  private String geographyLocationCode;

  @Column(name = "phone_number")
  private String contactNumber;

  @Column(name = "business_email")
  private String emailId;

  @Column(name = "gstn")
  private String gstinNumber;

  @Column(name = "assess_as_lookup_type", length = 10)
  private String assessAsLookupType;

  @Column(name = "gstn_flag")
  private boolean gstnFlag;

  @Column(name = "country_lookup")
  private String countryLookup;

  @Column(name = "taxpayer_type_lookup", length = 10)
  private String gstnType;

  @Column(name = "pvt_org_office_fk")
  private Long pvtOrgOfficeFk;
}
