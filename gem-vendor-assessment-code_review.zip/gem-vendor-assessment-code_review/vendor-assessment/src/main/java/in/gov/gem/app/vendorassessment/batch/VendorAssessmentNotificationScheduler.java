
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.batch;

import com.fasterxml.jackson.core.JsonProcessingException;

import in.gov.gem.app.utility.CustomLoggerFactory;
import in.gov.gem.app.vendorassessment.dto.request.VendorAssessRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.AssessmentValidityResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.SchedulerResponseDTO;

import in.gov.gem.app.vendorassessment.messaging.producer.VendorAssessmentValidityEvent;

import in.gov.gem.app.vendorassessment.messaging.producer.VendorAssessmentValidityEventProducer;
import in.gov.gem.app.vendorassessment.service.IVendorAssessmentValidityService;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.*;
import java.util.List;

/**
 * The type Vendor assessment notification scheduler.
 */
@Component
@RequiredArgsConstructor

public class VendorAssessmentNotificationScheduler {
    private final IVendorAssessmentValidityService vendorAssessmentValidityService;
    private final VendorAssessmentValidityEventProducer notificationEventProducer;

    private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(VendorAssessmentNotificationScheduler.class);

  /**
   * Check and send expiry notifications.
   *
   * @throws JsonProcessingException the json processing exception
   */
  @Scheduled(cron = "0 35 17 * * ?")
    public void checkAndSendExpiryNotifications() throws JsonProcessingException {
        // Scheduled task to check vendor assessment expiries
        log.info("Starting scheduled check for vendor assessment expiries");
        AssessmentValidityResponseDTO assessmentValidityExpire =   vendorAssessmentValidityService.assessmentValidityExpire();
        List<VendorAssessRequestDTO> vendorAssessments = assessmentValidityExpire.getVendorAssessments();
        Instant currentTime = assessmentValidityExpire.getCurrentTime();
        if (vendorAssessments.isEmpty()) {
            log.info("No vendor assessments found for expiry notifications");
            return;
        }
        else {
            for( VendorAssessRequestDTO assessment : vendorAssessments) {
                log.info("Found vendor assessment for expiry notification: {}", assessment.getId());
                Instant validUpTo = assessment.getValidUpTo();
                LocalDate date1 = currentTime.atZone(ZoneId.systemDefault()).toLocalDate();
                LocalDate date2 = validUpTo.atZone(ZoneId.systemDefault()).toLocalDate();

                Period period = Period.between(date1, date2);
                int months = period.getYears() * 12 + period.getMonths();
                checkThreeMonthExpiries(assessment,months);
            }
        }

        log.info("Completed scheduled check for vendor assessment expiries");
    }


  /**
   * Check three month expiries.
   *
   * @param vendorAssessment the vendor assessment
   * @param months           the months
   * @throws JsonProcessingException the json processing exception
   */
  void checkThreeMonthExpiries(VendorAssessRequestDTO vendorAssessment, int months) throws JsonProcessingException {
        String vendorId = vendorAssessment.getPvtOrgMasterFk().toString();
        String assessmentId = vendorAssessment.getVaNumber();
        SchedulerResponseDTO scheduler = SchedulerResponseDTO.builder()
                .vendorAssessmentId(assessmentId)
                .vendorId(vendorId)
                .validUpTo(vendorAssessment.getValidUpTo())
                .expiryWithinMonths(months)
                .build();

        notificationEventProducer.publishAssessmentExpiryEvent(
                scheduler, VendorAssessmentValidityEvent.AssessmentStatus.EXPIRED);

        log.info("Sent 3-month expiry reminder for vendor: {}", vendorId);
    }
}
