
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.repository.LookupRepository;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.client.ISellerClient;

import in.gov.gem.app.vendorassessment.dto.response.OrganizationDetailsResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VendorDashboardDTOResponseDTO;


import in.gov.gem.app.vendorassessment.constant.MessageConstant;

import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.utility.CustomLoggerFactory;
import in.gov.gem.app.vendorassessment.domain.entity.VAMasterEntity;
import in.gov.gem.app.vendorassessment.domain.repository.VendorAssessmentCategoryRepository;
import in.gov.gem.app.vendorassessment.domain.repository.VendorAssessmentRepository;
import in.gov.gem.app.vendorassessment.service.IVendorDashboardService;
import in.gov.gem.app.vendorassessment.utility.VendorDashboardUtil;
import in.gov.gem.app.vendorassessment.utility.ActionDeterminer;
import in.gov.gem.app.vendorassessment.utility.CategoryUtils;
import in.gov.gem.app.vendorassessment.utility.SearchUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The type Vendor dashboard service.
 */
@Service
@RequiredArgsConstructor
public class VendorDashboardService implements IVendorDashboardService {

    private final VendorAssessmentRepository vendorAssessmentRepository;
    private final VendorAssessmentCategoryRepository categoryRepository;
    private final MessageUtility messageUtility;
    private final VendorDashboardUtil vendorDashboardUtil;
    private final ISellerClient iSellerClient;
    private final LookupRepository lookupRepository;

    private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(VendorDashboardService.class);

    @Override
    @Transactional(readOnly = true)
    public Page<VendorDashboardDTOResponseDTO> getAllVendorAssessments(PaginationParams paginationParams) {

        ResponseEntity<APIResponse<OrganizationDetailsResponseDTO>> response = iSellerClient.getOrganizationDetails();
        OrganizationDetailsResponseDTO organizationDetails = Objects.requireNonNull(response.getBody()).getData();

        Long sellerId = organizationDetails.getGemPvtOrgId();

        List<Optional<VAMasterEntity>> assessmentPage = vendorAssessmentRepository.findByPvtOrgMasterFk(sellerId);

        List<VendorDashboardDTOResponseDTO> assessmentDTOs = assessmentPage.stream()
                .filter(Optional::isPresent)
                .map(Optional::get)
                .map(vendorAssessment -> {
                    Long categoryCount = categoryRepository.countByVendorAssessmentFk(
                            vendorAssessment.getId() != null ? vendorAssessment.getId() : 0L);

                    // Pass lookup values to mapper
                    String statusValue = lookupRepository.findByLookupCode(vendorAssessment.getVaStatusLookUp())
                            .map(Lookup::getLookupValue).orElse(null);
                    String subStatusValue = lookupRepository.findByLookupCode(vendorAssessment.getSubStatusLookUp())
                            .map(Lookup::getLookupValue).orElse(null);
                    String assessedAsValue = lookupRepository.findByLookupCode(vendorAssessment.getApplyAsLookUp())
                            .map(Lookup::getLookupValue).orElse(null);

                    return vendorDashboardUtil.mapToDTO(vendorAssessment, categoryCount,
                            statusValue, subStatusValue, assessedAsValue);
                })
                .filter(Objects::nonNull) // Filter out any null DTOs
                .collect(Collectors.toList());

        log.info("Mapped {} assessments to DTOs", assessmentDTOs.size());

        Comparator<VendorDashboardDTOResponseDTO> comparator = Comparator.comparing(VendorDashboardDTOResponseDTO::getId); // Replace with the desired field
        if ("desc".equalsIgnoreCase(String.valueOf(paginationParams.getSortOrder()))) {
            comparator = comparator.reversed();
        }
        assessmentDTOs.sort(comparator);

        // Apply pagination after mapping
        int page = paginationParams.getPageNumber();
        int size = paginationParams.getPageSize();
        int start = Math.min(page * size, assessmentDTOs.size());
        int end = Math.min(start + size, assessmentDTOs.size());
        String searchQuery = paginationParams.getSearchQuery();
        List<VendorDashboardDTOResponseDTO> paginatedList = assessmentDTOs.subList(start, end);


        // Return Page<VendorDashboardDTO> using PageImpl
        return new PageImpl<>( (searchQuery != null && !searchQuery.trim().isEmpty())
                ? SearchUtils.fuzzySearch(paginatedList, searchQuery)
                : paginatedList, PageRequest.of(page, size), assessmentDTOs.size());

    }

    @Override
    @Transactional(readOnly = true)
    public List<VendorDashboardDTOResponseDTO> getAllVendorAssessmentsWithouPage(Long sellerId) {

        List<Optional<VAMasterEntity>> assessmentPage = vendorAssessmentRepository.findByPvtOrgMasterFk(sellerId);

        List<VendorDashboardDTOResponseDTO> assessmentDTOs = assessmentPage.stream()
                .filter(Optional::isPresent)
                .map(Optional::get)
                .map(vendorAssessment -> {
                    Long categoryCount = categoryRepository.countByVendorAssessmentFk(
                            vendorAssessment.getId() != null ? vendorAssessment.getId() : 0L);

                    // Pass lookup values to mapper
                    String statusValue = lookupRepository.findByLookupCode(vendorAssessment.getVaStatusLookUp())
                            .map(Lookup::getLookupValue).orElse(null);
                    String subStatusValue = lookupRepository.findByLookupCode(vendorAssessment.getSubStatusLookUp())
                            .map(Lookup::getLookupValue).orElse(null);
                    String assessedAsValue = lookupRepository.findByLookupCode(vendorAssessment.getApplyAsLookUp())
                            .map(Lookup::getLookupValue).orElse(null);

                    return vendorDashboardUtil.mapToDTO(vendorAssessment, categoryCount,
                            statusValue, subStatusValue, assessedAsValue);
                })
                .filter(Objects::nonNull) // Filter out any null DTOs
                .toList();

        // Return Page<VendorDashboardDTO> using PageImpl
        return new ArrayList<>(assessmentDTOs);
    }

    @Override
    public VendorDashboardDTOResponseDTO getVendorAssessment(Long id) {
        Optional<VAMasterEntity> byId = vendorAssessmentRepository.findById(id);
        // VendorAssessment assessment = byId.get();

        VAMasterEntity assessment;
        if (byId.isPresent()) {
            assessment = byId.get();
            // Continue processing with assessment
        } else {
            // Handle the case when assessment is not found
            throw  new ServiceException(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND,
                    messageUtility.getMessage(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND),
                    ErrorConstant.CATEGORY.TH, ErrorConstant.SEVERITY.I);

        }
        Long categoryCount = categoryRepository.countByVendorAssessmentFk(
                assessment.getId() != null ? assessment.getId() : 0L);

        // Pass lookup values to mapper
        String statusValue = lookupRepository.findByLookupCode(assessment.getVaStatusLookUp())
                .map(Lookup::getLookupValue).orElse(null);
        String subStatusValue = lookupRepository.findByLookupCode(assessment.getSubStatusLookUp())
                .map(Lookup::getLookupValue).orElse(null);
        String assessedAsValue = lookupRepository.findByLookupCode(assessment.getApplyAsLookUp())
                .map(Lookup::getLookupValue).orElse(null);

        return vendorDashboardUtil.mapToDTO(assessment, categoryCount,
                statusValue, subStatusValue, assessedAsValue);
    }


    @Override
    @Transactional(readOnly = true)
    public Optional<VendorDashboardDTOResponseDTO> getVendorAssessmentByVaNumber(String vaNumber) {
        log.debug("Fetching vendor assessment details for VA number: {}", vaNumber);

        if (vaNumber == null || vaNumber.trim().isEmpty()) {
            throw new ServiceException(MessageConstant.INVALID_VA_NUMBER,
                    messageUtility.getMessage(MessageConstant.INVALID_VA_NUMBER),
                    ErrorConstant.CATEGORY.TH, ErrorConstant.SEVERITY.I);
        }

        Optional<VAMasterEntity> vendorAssessmentOptional = vendorAssessmentRepository.findByVaNumber(vaNumber);
        VAMasterEntity vendorAssessment = vendorAssessmentOptional
                .orElseThrow(() -> new ServiceException(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND,
                        messageUtility.getMessage(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND),
                        ErrorConstant.CATEGORY.TH, ErrorConstant.SEVERITY.I));

        log.info("Vendor assessment details fetched successfully for VA number: {}", vendorAssessment);
        return vendorAssessmentOptional.map(assessment -> {
            Long categoryCount = categoryRepository.countByVendorAssessmentFk(
                    assessment.getId() != null ? assessment.getId() : 0L);

            // Pass lookup values to mapper
            String statusValue = lookupRepository.findByLookupCode(assessment.getVaStatusLookUp())
                    .map(Lookup::getLookupValue).orElse(null);
            String subStatusValue = lookupRepository.findByLookupCode(assessment.getSubStatusLookUp())
                    .map(Lookup::getLookupValue).orElse(null);
            String assessedAsValue = lookupRepository.findByLookupCode(assessment.getApplyAsLookUp())
                    .map(Lookup::getLookupValue).orElse(null);

            return vendorDashboardUtil.mapToDTO(assessment, categoryCount,
                    statusValue, subStatusValue, assessedAsValue);
        });
    }

    @Override
    public List<Map<String, Object>> getCategories(String vaNumber) {
        log.info("Fetching categories for VA number: {}", vaNumber);

        if (vaNumber == null || vaNumber.trim().isEmpty()) {
            throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
        }

        List<Map<String, Object>> allCategories = CategoryUtils.getAllCategoriesForVA(vaNumber);
        return CategoryUtils.buildCategoryTree(allCategories);
    }

    @Override
    @Transactional
    public void deleteVendorAssessment(String vendorId) {
        log.info("Attempting to delete vendor assessment for vendor ID: {}", vendorId);

        if (vendorId == null || vendorId.trim().isEmpty()) {
            throw new ServiceException(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND,
                    messageUtility.getMessage(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND),
                    ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
        }

        Optional<VAMasterEntity> vendorAssessmentOptional = vendorAssessmentRepository.findByVaNumber(vendorId);

        VAMasterEntity vendorAssessment = vendorAssessmentOptional
                .orElseThrow(() -> new ServiceException(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND,
                        messageUtility.getMessage(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND),
                        ErrorConstant.CATEGORY.TH, ErrorConstant.SEVERITY.I));

        vendorAssessment.setDeleted(true);
        vendorAssessment.setUpdateTimestamp(Instant.now());

        vendorAssessmentRepository.save(vendorAssessment);
        log.info("Vendor assessment successfully marked as deleted for vendor ID: {}", vendorId);

    }
    public VendorDashboardDTOResponseDTO mapToDTO(VAMasterEntity vendorAssessment, Long categoryCount,
                                                  String statusValue, String subStatusValue, String assessedAsValue) {
        if (vendorAssessment.getVaNumber() == null) {
            log.warn("Vendor assessment is null, skipping mapping.");
            return null;
        }

        List<String> actions = ActionDeterminer.determineActions(statusValue, subStatusValue);
        if (actions.isEmpty()) {
            actions.add("View");
        }

        return VendorDashboardDTOResponseDTO.builder()
                .id(vendorAssessment.getId() != null ? vendorAssessment.getId() : 0L)
                .vaId(vendorAssessment.getVaNumber())
                .status(statusValue)
                .subStatus(subStatusValue)
                .assessedAs(assessedAsValue)
                .categoryCount(categoryCount.intValue())
                .assessedBy("Verifying Agency")
                .submittedOn(vendorAssessment.getCreatedTimestamp())
                .validUpTo(vendorAssessment.getValidUpTo())
                .actions(actions)
                .build();
    }
}



