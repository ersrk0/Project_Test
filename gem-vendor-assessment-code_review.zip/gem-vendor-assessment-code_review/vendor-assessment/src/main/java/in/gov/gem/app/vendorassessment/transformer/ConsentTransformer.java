
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.transformer;

import com.fasterxml.jackson.databind.ObjectMapper;
import in.gov.gem.app.vendorassessment.client.IConsentClient;
import in.gov.gem.app.vendorassessment.dto.request.SaveConsumerRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.ConsentResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.FileDetailsResponseDTO;


import in.gov.gem.app.utility.CustomLoggerFactory;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * The type Consent transformer.
 */
@Component
@AllArgsConstructor
public class ConsentTransformer
{
  private final IConsentClient consentClient;

  private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(ConsentTransformer.class);

  /**
   * Gets consent data.
   *
   * @param acceptLanguage the accept language
   * @param module         the module
   * @param functionality  the functionality
   * @return the consent data
   */
  public boolean getConsentData(String acceptLanguage, String module, String functionality)
  {

    log.debug("Calling consent service for name mismatch ");
    var response = consentClient.getMetaData(acceptLanguage, module, functionality).getBody();
    if (response != null)
    {
      var data = response.getData();
      if (data != null)
      {
        ObjectMapper objectMapper = new ObjectMapper();
        ConsentResponseDTO consentResponseDTO = objectMapper.convertValue(data, ConsentResponseDTO.class);
        List<FileDetailsResponseDTO> fileDetails = consentResponseDTO.getFileList();
        String consentCode = fileDetails.get(0).getConsentCode();
        String attachmentHash = fileDetails.get(0).getDocHash();

        SaveConsumerRequestDTO request = new SaveConsumerRequestDTO
          (consentCode, attachmentHash, "2025-01-22T18:55:13Z", "eng", false);
        var finalResponse = consentClient.saveConsumer(acceptLanguage, request).getBody();
        log.debug("Saving consent in consent DB");
        return (finalResponse != null && finalResponse.getHttpStatus() == HttpStatus.OK.value());

      }
    }
    log.warn("Consent metadata response was null or invalid");
    return false;
  }

  /**
   * Gets view data.
   *
   * @param consentCode    the consent code
   * @param acceptLanguage the accept language
   * @return the view data
   */
  public Object getViewData(String consentCode, String acceptLanguage)
  {
    var responseEntity = consentClient.viewData(acceptLanguage, consentCode);
    if (responseEntity != null && responseEntity.getBody() != null) {
      log.debug("Fetched view data for consentCode: {}", consentCode);
      return responseEntity.getBody();
    }
    return null;
  }




}
