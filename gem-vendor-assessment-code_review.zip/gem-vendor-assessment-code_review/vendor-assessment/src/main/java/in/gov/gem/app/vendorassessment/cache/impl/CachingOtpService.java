
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.cache.impl;

import in.gov.gem.app.cache.manager.GemCacheManager;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.cache.ICachingOtpService;
import in.gov.gem.app.vendorassessment.client.IOtpServiceClient;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.constant.CacheConstant;
import in.gov.gem.app.vendorassessment.dto.request.*;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseResenDResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseSendResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseValidateResponseDTO;
import in.gov.gem.app.vendorassessment.utility.Helper;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * The type Caching otp service.
 */
@Service
@AllArgsConstructor
public class CachingOtpService implements ICachingOtpService
{

  private final Helper requestUtil;
  private final IOtpServiceClient client ;
  private final GemCacheManager<String, String> gemCacheManager;

  @Override
  public ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> SentOtpViaEmail(AddEmailRequestDTO sendOtpRequestDto)
  {
    String cacheKey = CacheConstant.OTP_EMAIL + CacheConstant.COLON + sendOtpRequestDto.getEmailId();
    OtpGenerateRequestDTO otpRequestDTO = OtpGenerateRequestDTO.builder()
      .channelId(requestUtil.getChannelId())
      .email(sendOtpRequestDto.getEmailId())
      .functionalArea(ApplicationConstant.MICROSERVICE_NAME)
      .deliveryChannel(ApplicationConstant.OTP_PREFERENCE_EMAIL)
      .otpType(ApplicationConstant.OTP_TYPE_SAME)
      .templateId(ApplicationConstant.MICROSERVICE_NAME)
      .moduleName(ApplicationConstant.MODULE_NAME)
      .serviceReferenceId(String.valueOf(UUID.randomUUID()))
      .build();

    ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> response = client.generateOtp(otpRequestDTO);

    if (response.getBody() != null && response.getBody().getData() != null) {
      String referenceId = response.getBody().getData().getReferenceId();
      gemCacheManager.put(cacheKey, referenceId, 600, TimeUnit.SECONDS);
    }

    return response;
  }

  @Override
  public ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> ResendOtpViaEmail(
    OtpRegenerateRequestDTO otpRegenerateRequestDTO)
  {
    OtpRegenerateRequestDTO regenerate= OtpRegenerateRequestDTO.builder()
      .deliveryChannel(ApplicationConstant.OTP_PREFERENCE_EMAIL)
      .referenceId(otpRegenerateRequestDTO.getReferenceId())
      .build();

    return client.regenerateOtp(regenerate);
  }
  @Override
  public ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> ValidateOtpViaEmail(
    OtpValidationRequestDTO OtpValidationRequestDTO) {

    OtpRequestValidateRequestDTO emailOtpValidateRequestDTO = OtpRequestValidateRequestDTO.builder()
      .deliveryChannel(ApplicationConstant.OTP_PREFERENCE_EMAIL)
      .referenceId(OtpValidationRequestDTO.getReferenceId())
      .otp(String.valueOf(OtpValidationRequestDTO.getOtp()))
      .build();

    ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> dataResponse = client.otpValidate(emailOtpValidateRequestDTO);

    if (dataResponse == null || dataResponse.getBody() == null) {
      return ResponseEntity.status(500).body(APIResponse.<OtpResponseValidateResponseDTO>builder()
        .message("Invalid response from OTP validation service")
        .build());
    }
    return dataResponse;
  }

  @Override
  public ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> SentOtpViaMobile(AddMobileRequestDTO sendOtpRequestDto)
  {

    String cacheKey = CacheConstant.OTP_EMAIL + CacheConstant.COLON + sendOtpRequestDto.getMobileNumber();

    OtpGenerateRequestDTO otpRequestDTO = OtpGenerateRequestDTO.builder()
      .channelId(requestUtil.getChannelId())
      .mobileNumber(sendOtpRequestDto.getMobileNumber())
      .functionalArea(ApplicationConstant.MICROSERVICE_NAME)
      .deliveryChannel(ApplicationConstant.OTP_PREFERENCE_MOBILE)
      .otpType(ApplicationConstant.OTP_TYPE_SAME)
      .templateId(ApplicationConstant.MICROSERVICE_NAME)
      .moduleName(ApplicationConstant.MODULE_NAME)
      .serviceReferenceId(String.valueOf(UUID.randomUUID()))
      .build();

    ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> response= client.generateOtp(otpRequestDTO);

    if (response.getBody() != null && response.getBody().getData() != null) {
      String referenceId = response.getBody().getData().getReferenceId();
      gemCacheManager.put(cacheKey, referenceId, 600, TimeUnit.SECONDS);
    }

    return response;
  }

  @Override
  public ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> ValidateOtpViaMobile(
    MobileOtpValidationRequestDTO OtpValidationRequestDTO) {

    OtpRequestValidateRequestDTO mobileOtpValidateRequestDTO = OtpRequestValidateRequestDTO.builder()
      .deliveryChannel(ApplicationConstant.OTP_PREFERENCE_MOBILE)
      .referenceId(OtpValidationRequestDTO.getReferenceId())
      .otp(String.valueOf(OtpValidationRequestDTO.getOtp()))
      .build();

    ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> dataResponse = client.otpValidate(mobileOtpValidateRequestDTO);

    if (dataResponse == null || dataResponse.getBody() == null) {
      return ResponseEntity.status(500).body(APIResponse.<OtpResponseValidateResponseDTO>builder()
        .message("Invalid response from OTP validation service")
        .build());
    }
    return dataResponse;
  }


  @Override
  public ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> ResendOtpViaMobile(
    OtpRegenerateRequestDTO otpRegenerateRequestDTO)
  {
    OtpRegenerateRequestDTO regenerate= OtpRegenerateRequestDTO.builder()
      .deliveryChannel(ApplicationConstant.OTP_PREFERENCE_MOBILE)
      .referenceId(otpRegenerateRequestDTO.getReferenceId())
      .build();

    return client.regenerateOtp(regenerate);

  }

}
