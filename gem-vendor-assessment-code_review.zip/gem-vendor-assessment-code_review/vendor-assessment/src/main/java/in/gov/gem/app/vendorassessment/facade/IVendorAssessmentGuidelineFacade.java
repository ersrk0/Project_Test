
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;

import in.gov.gem.app.vendorassessment.dto.response.GuidelineResponseDTO;
import org.springframework.stereotype.Component;

/**
 * The interface Vendor assessment guideline facade.
 */
@Component
public interface IVendorAssessmentGuidelineFacade {
  /**
   * Fetch guidelines guideline response dto.
   *
   * @param lookupName the lookup name
   * @return the guideline response dto
   */
  public GuidelineResponseDTO fetchGuidelines(String lookupName);
}
