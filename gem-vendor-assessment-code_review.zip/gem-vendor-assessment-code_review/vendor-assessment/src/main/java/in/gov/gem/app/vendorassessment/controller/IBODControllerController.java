
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */
package in.gov.gem.app.vendorassessment.controller;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.response.BODDocumentResponseDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Tag(name = "BOD", description = "APIs for Board of Directors document management")
@RestController
@RequestMapping("/v1/bod")

public interface IBODControllerController {

  /**
   * Gets required BOD documents for a given Vendor Assessment ID.
   *
   * @param VendorAssessmentId the vendor assessment id
   * @return the required BOD documents
   */
  @Operation(summary = "Get Required BOD Documents", description = "Fetches required BOD documents for a given Vendor Assessment ID.")
  @Parameter(name = "VendorAssessmentId", description = "Vendor Assessment ID", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/documents")
  ResponseEntity<APIResponse<Object>> getRequiredBodDocuments(@RequestParam Long VendorAssessmentId);

  /**
   * Gets BOD documents for the user's organisation.
   *
   * @param vaMasterId the VA master id
   * @return the organisation BOD documents
   */
  @Operation(summary = "Get My Organisation BOD Documents", description = "Fetches BOD documents for the user's organisation.")
  @Parameter(name = "vaMasterId", description = "VA Master ID", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/myOrganisation")
  ResponseEntity<APIResponse<Object>> myOrganisationBodDocumentList(@RequestParam Long vaMasterId);

  /**
   * Gets BOD documents for the user's authorizing OEM/OSP.
   *
   * @param vaMasterId the VA master id
   * @return the authorizing OEM/OSP BOD documents
   */
  @Operation(summary = "Get My Authorizing OEM/OSP BOD Documents", description = "Fetches BOD documents for the user's authorizing OEM/OSP.")
  @Parameter(name = "vaMasterId", description = "VA Master ID", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/myAuthorizingOemOsp")
  ResponseEntity<APIResponse<Object>> myAuthorizingOemOspBodDocumentList(@RequestParam Long vaMasterId);

  /**
   * Gets BOD documents for the user's contract manufacturer.
   *
   * @param vaMasterId the VA master id
   * @return the contract manufacturer BOD documents
   */
  @Operation(summary = "Get My Contract Manufacturer BOD Documents", description = "Fetches BOD documents for the user's contract manufacturer.")
  @Parameter(name = "vaMasterId", description = "VA Master ID", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/myContractManufacturer")
  ResponseEntity<APIResponse<Object>> myContractManufacturerDocumentList(@RequestParam Long vaMasterId);

  /**
   * Deletes a BOD document for a given VA Master ID and document name.
   *
   * @param vaMasterId the VA master id
   * @param docName    the document name
   * @return the API response
   */
  @Operation(summary = "Delete BOD Document", description = "Deletes a BOD document for a given VA Master ID and document name.")
  @Parameter(name = "vaMasterId", description = "VA Master ID", in = ParameterIn.QUERY, required = true)
  @Parameter(name = "docName", description = "Document name", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @DeleteMapping("/deleteDocument")
  ResponseEntity<APIResponse<Object>> deleteBodDocument(@RequestParam Long vaMasterId, @RequestParam String docName);

  /**
   * Exports BOD documents to Excel.
   *
   * @param bodDocumentResponses the list of BOD document responses
   * @return the Excel file as byte array
   */
  @Operation(summary = "Export BOD Documents to Excel", description = "Exports BOD documents to Excel.")
  @ApiResponse(responseCode = "200", description = "Excel file generated successfully")
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/report")
  ResponseEntity<byte[]> exportUsersToExcel(@RequestBody List<BODDocumentResponseDTO> bodDocumentResponses);

  /**
   * Gets the last verified BOD document.
   *
   * @return the last verified BOD document
   */
  @Operation(summary = "Get Last Verified BOD Document", description = "Fetches the last verified BOD document.")
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/lastVerifiedBODDocument")
  ResponseEntity<APIResponse<Object>> getLastVerifiedBODDocument();

  /**
   * Saves remarks for a BOD document.
   *
   * @param remarks    the remarks to save
   * @param vaMasterFk the VA master foreign key
   * @return the API response
   */
  @Operation(summary = "Save Remarks", description = "Saves remarks for a BOD document.")
  @Parameter(name = "remarks", description = "Remarks to save", in = ParameterIn.QUERY, required = true)
  @Parameter(name = "vaMasterFk", description = "VA Master foreign key", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/saveRemarks")
  ResponseEntity<APIResponse<Object>> saveRemarks(@RequestParam String remarks, @RequestParam Long vaMasterFk);

  /**
   * Gets parent BOD documents for a given VA Master ID.
   *
   * @param vaMasterId the VA master id
   * @return the parent BOD documents
   */
  @Operation(summary = "Get Parent BOD Documents", description = "Fetches parent BOD documents for a given VA Master ID.")
  @Parameter(name = "vaMasterId", description = "VA Master ID", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/getParentBodDocuments")
  ResponseEntity<APIResponse<Object>> getParentBodDocuments(@RequestParam Long vaMasterId);

  /**
   * Gets parent organisation BOD document for a given VA Master ID.
   *
   * @param vaMasterId the VA master id
   * @return the parent organisation BOD document
   */
  @Operation(summary = "Get Parent Organisation BOD Document", description = "Fetches parent organisation BOD document for a given VA Master ID.")
  @Parameter(name = "vaMasterId", description = "VA Master ID", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/parentOrganisationBODDocument")
  ResponseEntity<APIResponse<Object>> getParentOrganisationBODDocument(@RequestParam Long vaMasterId);
}