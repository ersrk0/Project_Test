
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.repository;



import in.gov.gem.app.service.core.repository.BaseRepository;
import in.gov.gem.app.vendorassessment.domain.entity.AssessmentCategoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


/**
 * Repository for vendor assessment categories
 */
@Repository
public interface VendorAssessmentCategoryRepository extends BaseRepository<AssessmentCategoryEntity, Long> {

    /**
     * Count categories by vendor assessment foreign key
     *
     * @param vendorAssessmentFk The vendor assessment foreign key
     * @return Count of categories for the given vendor assessment
     */
    Long countByVendorAssessmentFk(Long vendorAssessmentFk);

//    List<AssessmentCategory> findByVendorAssessmentFk(Long vendorAssessmentFk);
}