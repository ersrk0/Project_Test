
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;


import in.gov.gem.app.vendorassessment.dto.enums.CriteriaType;
import in.gov.gem.app.vendorassessment.dto.request.DropdownItemRequestDTO;
import org.springframework.stereotype.Service;

/**
 * Service layer for fetching raw dropdown data.
 * This service would typically interact with repositories or configuration sources
 * to retrieve the basic data for dropdowns.
 */
@Service
public class DropdownService {


  /**
   * Gets document types by criterion.
   *
   * @param criterion the criterion
   * @return the document types by criterion
   */
  public DropdownItemRequestDTO getDocumentTypesByCriterion(CriteriaType criterion) {
        if (criterion == null) {
            // Return a default list if no criterion is provided or an invalid one
            return getDefaultDocumentTypes();
        }

        switch (criterion) {
            case OEM_BIS_LICENSE:
                return
                        new DropdownItemRequestDTO("BIS Certificate", "BIS Certificate having a License number.",
                                "NA");
            case CENTRAL_STATE_PSUS:
                // This is the one selected in the image
                return
                        new DropdownItemRequestDTO("Incorporation Certificate"
                                , "Please upload Incorporation Certificate or any other document that is applicable.","NA");
            case SELLER_500CR_TURNOVER:
                return
                        new DropdownItemRequestDTO("Recommendation Letter and Certificate", "Please upload recommendation." +
                                "letter and certificate issued by any CPSE/Government Departments requesting for a vendor assessment exemption","CPSE/Government Departments");
            case SOCIETIES_GOVT_AFFILIATION:
                return new DropdownItemRequestDTO("Society Registration Certificate"
                        , "Please upload Society Registration Certificate or Trust deed/agreement or any other document that is applicable.","NA");
            case KVIC:
                return
                        new DropdownItemRequestDTO("Valid Drug Licence", "Please upload Copy of valid drug licence" +
                                " from the issuing/concerned Drug Authority.","The issuing/concerned Drug Authority");
            case WDQ:
                return
                        new DropdownItemRequestDTO("Drug License", "Please upload Copy of valid drug licence from the issuing/concerned Drug Authority.\n" +
                                "The following documents need to be submitted with this application:\n" +
                                "\n" +
                                "1. Valid Drug License from the issuing / concerned Drug Authority.\n" +
                                "2. Undertaking as per the Document Template given above printed and notarized on a non-judicial stamp paper of Rs.10.\n" +
                                "\n" +
                                "Please Note: The two documents above should be combined and uploaded as a single document below.","Issuing/concerned Drug Authority")
                        ;
            case COIR:
                return
                        new DropdownItemRequestDTO("Manufacturing License", "Please upload Valid certified copy of" +
                                " manufacturing license from the issuing Licensing Authority for the specific medical device (exemption will be valid on only on product category level and not on entity level).","Issuing Licensing Authority");
            case TRIFED:
                return
                        new DropdownItemRequestDTO("3 Sales Invoices ", "1. Please upload 3 invoices for raw materials purchased and 3 sales invoices from any of the last 3 years for the applied categories. (with GSTIN)\t\t\n" +
                                "\t\t\n" +
                                "Note*:Please ensure that applied categories are reflected in the “Dealing in Goods and Services” section of the online GST portal.\t\t","NA");
            default:
                return getDefaultDocumentTypes();
        }
    }

    private DropdownItemRequestDTO getDefaultDocumentTypes() {
        // A fallback list if no specific criterion applies or is selected
        return
                new DropdownItemRequestDTO("GENERAL_DOC", "General Document",
                        "NA");
    }



}