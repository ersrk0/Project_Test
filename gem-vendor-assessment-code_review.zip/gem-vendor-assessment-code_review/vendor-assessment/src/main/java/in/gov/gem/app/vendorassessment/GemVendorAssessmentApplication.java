
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;


import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * The type Gem vendor assessment application.
 */
@SpringBootApplication
@ComponentScan("in.gov.gem")
@EntityScan(basePackages = "in.gov.gem.app")
@EnableFeignClients(basePackages = "in.gov.gem.app")
@EnableScheduling
@EnableKafka
public class GemVendorAssessmentApplication {

//    @Autowired
//    private SaveAssessOptionImpl saveAssessOptionService;

  /**
   * The entry point of application.
   *
   * @param args the input arguments
   */

  public static void main(String[] args) {
        SpringApplication.run(GemVendorAssessmentApplication.class, args);
    }


}