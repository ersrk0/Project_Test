
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.vendorassessment.dto.response.NonComplianceNewResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.NonComplianceResponseDTO;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.repository.LookupRepository;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.domain.entity.NCClosureEntity;
import in.gov.gem.app.vendorassessment.domain.repository.NonComplianceRepository;
import in.gov.gem.app.vendorassessment.service.INonComplianceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

import static in.gov.gem.app.vendorassessment.constant.LookupConstants.*;
import static org.apache.commons.compress.java.util.jar.Pack200.Packer.UNKNOWN_ATTRIBUTE;

/**
 * The type Non compliance service.
 */
@Service
@RequiredArgsConstructor

public class NonComplianceService implements INonComplianceService {

    private final NonComplianceRepository nonComplianceRepository;
    private final LookupRepository lookupRepository;
    private final MessageUtility messageUtility;

    @Override
    public NonComplianceNewResponseDTO fieldsWithOpenNonClosure(Long vaMasterFk) {
        try {
            NonComplianceNewResponseDTO response = new NonComplianceNewResponseDTO();

            List<Lookup> entityLookups = safeFindByLookupName(ENTITY_LOOKUP_NAME);
            String lookupCode = extractLookupCode(entityLookups, WORK_EXPERIENCE_DETAILS);

            List<Lookup> statusLookups = safeFindByLookupName(NON_COMPLIANCE_STATUS_LOOKUP_NAME);
            String nonComplianceStatusLookupOpen = extractLookupCode(statusLookups, STATUS_OPEN);
            String nonComplianceStatusLookupUnderReview = extractLookupCode(statusLookups, STATUS_UNDER_REVIEW);

            List<NCClosureEntity> nonComplianceEntities = safeFindByVaMasterFkAndStatusLookup(vaMasterFk, nonComplianceStatusLookupOpen);
            List<NCClosureEntity> underReviewEntities = safeFindByVaMasterFkAndStatusLookup(vaMasterFk, nonComplianceStatusLookupUnderReview);
            nonComplianceEntities.addAll(underReviewEntities);

            List<NonComplianceNewResponseDTO.Pair<String, String>> openFields = new ArrayList<>();
            List<NonComplianceNewResponseDTO.Pair<String, String>> closedFields = new ArrayList<>();

            for (NCClosureEntity nonComplianceEntity : nonComplianceEntities) {
                if (nonComplianceEntity.getEntityLookup() != null && nonComplianceEntity.getEntityLookup().equalsIgnoreCase(lookupCode)) {
                    NonComplianceNewResponseDTO.Pair<String, String> pair = NonComplianceNewResponseDTO.Pair.of(
                            safeFindLookupValueByCode(nonComplianceEntity.getEntityAttributeLookup(), UNKNOWN_ATTRIBUTE),
                            safeFindLookupValueByCode(nonComplianceEntity.getStatusLookup(), UNKNOWN_STATUS));
                    openFields.add(pair);
                }
            }

            List<Lookup> workExpAttributes = safeFindByLookupName(WORK_EXPERIENCE_DETAILS_ATTRIBUTE);
            for (Lookup lookup : workExpAttributes) {
                boolean found = false;
                for (NonComplianceNewResponseDTO.Pair<String, String> pair : openFields) {
                    if (pair.fieldName.equalsIgnoreCase(lookup.getLookupValue())) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    closedFields.add(NonComplianceNewResponseDTO.Pair.of(lookup.getLookupValue(), CLOSED));
                }
            }

            response.setNonComplianceOpenFields(openFields);
            response.setNonComplianceClosedFields(closedFields);

            return response;
        } catch (Exception e) {
            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
    }

    @Override
    public List<NonComplianceResponseDTO> nonCompliantFields(Long vaMasterFk) {
        try {
            List<NonComplianceResponseDTO> nonCompliantFields = new ArrayList<>();

            List<Lookup> statusLookups = safeFindByLookupName(NON_COMPLIANCE_STATUS_LOOKUP_NAME);
            String statusOpenCode = extractLookupCode(statusLookups, STATUS_OPEN);
            String statusUnderReviewCode = extractLookupCode(statusLookups, STATUS_UNDER_REVIEW);

            List<NCClosureEntity> openEntities = safeFindByVaMasterFkAndStatusLookup(vaMasterFk, statusOpenCode);
            List<NCClosureEntity> underReviewEntities = safeFindByVaMasterFkAndStatusLookup(vaMasterFk, statusUnderReviewCode);
            openEntities.addAll(underReviewEntities);

            for (NCClosureEntity entity : openEntities) {
                NonComplianceResponseDTO responseDTO = new NonComplianceResponseDTO();
                String entityName = safeFindLookupValueByCode(entity.getEntityLookup(), UNKNOWN_ATTRIBUTE);
                String attributeName = safeFindLookupValueByCode(entity.getEntityAttributeLookup(), UNKNOWN_ATTRIBUTE);

                responseDTO.setEntity(entityName);
                responseDTO.setFieldName(attributeName);
                responseDTO.setEntityAttribute(safeFindLookupValueByCode(entity.getStatusLookup(), UNKNOWN_STATUS));
                nonCompliantFields.add(responseDTO);
            }

            return nonCompliantFields;
        } catch (Exception e) {
            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
    }

    // Helper methods
    private List<Lookup> safeFindByLookupName(String name) {
        List<Lookup> list = lookupRepository.findByLookupName(name);
        return list != null ? list : new ArrayList<>();
    }

    private String extractLookupCode(List<Lookup> lookups, String value) {
        for (Lookup lookup : lookups) {
            if (lookup != null && lookup.getLookupValue().equalsIgnoreCase(value)) {
                return lookup.getLookupCode();
            }
        }
        return null;
    }

    private List<NCClosureEntity> safeFindByVaMasterFkAndStatusLookup(Long vaMasterFk, String statusLookup) {
        List<NCClosureEntity> list = nonComplianceRepository.findByVaMasterFkAndStatusLookup(vaMasterFk, statusLookup);
        return list != null ? list : new ArrayList<>();
    }

    private String safeFindLookupValueByCode(String code, String defaultValue) {
        return lookupRepository.findByLookupCode(code)
                .map(Lookup::getLookupValue)
                .orElse(defaultValue);
    }
}
