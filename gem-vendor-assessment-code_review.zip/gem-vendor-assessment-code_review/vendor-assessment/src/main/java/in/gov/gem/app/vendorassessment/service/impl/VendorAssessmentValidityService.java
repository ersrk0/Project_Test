
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;



import in.gov.gem.app.vendorassessment.dto.request.VendorAssessRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.AssessmentValidityResponseDTO;

import in.gov.gem.app.utility.CustomLoggerFactory;
import in.gov.gem.app.vendorassessment.domain.entity.VAMasterEntity;
import in.gov.gem.app.vendorassessment.domain.repository.VendorAssessmentRepository;
import in.gov.gem.app.vendorassessment.service.IVendorAssessmentValidityService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

/**
 * The type Vendor assessment validity service.
 */
@Service
@AllArgsConstructor
public class VendorAssessmentValidityService implements IVendorAssessmentValidityService
{

  /**
   * The Vendor assessment repository.
   */
  VendorAssessmentRepository vendorAssessmentRepository;

    private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(VendorAssessmentValidityService.class);


    @Override
    public AssessmentValidityResponseDTO assessmentValidityExpire() {
        log.info("Service enter");
        Instant currentInstant = Instant.now();
        Instant threeMonths= currentInstant.plusSeconds(3L * 30 * 24 * 60 * 60); // Adding 3 months in seconds
        List<VAMasterEntity> vendorAssessments=vendorAssessmentRepository.findByValidUpToBetween(currentInstant, threeMonths);
        List<VendorAssessRequestDTO> vendorAssess = vendorAssessments.stream()
                .map(assessment -> VendorAssessRequestDTO.builder()
                        .id(assessment.getId())
                        .vaNumber(assessment.getVaNumber())
                        .validUpTo(assessment.getValidUpTo())
                        .pvtOrgMasterFk(assessment.getPvtOrgMasterFk())
                        .build())
                .toList();
        if(vendorAssessments.isEmpty())
        {
            log.info("No vendor assessments found for expiry notifications");
            return AssessmentValidityResponseDTO.builder()
                    .vendorAssessments(vendorAssess)
                    .currentTime(currentInstant)
                    .build();
        }

        AssessmentValidityResponseDTO responseDTO = AssessmentValidityResponseDTO.builder()
                .vendorAssessments(vendorAssess)
                .currentTime(currentInstant)
                .build();
        return responseDTO;
    }
}
