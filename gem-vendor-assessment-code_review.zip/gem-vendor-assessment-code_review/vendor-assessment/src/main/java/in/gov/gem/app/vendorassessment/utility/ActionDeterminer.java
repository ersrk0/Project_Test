
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The type Action determiner.
 */
public class ActionDeterminer {

  /**
   * Determine actions list.
   *
   * @param statusLookupValue    the status lookup value
   * @param subStatusLookupValue the sub status lookup value
   * @return the list
   */
  public static List<String> determineActions(String statusLookupValue, String subStatusLookupValue) {
        List<String> actions = new ArrayList<>();

        if (statusLookupValue == null) {
            return actions;
        }

        // Normalize strings for comparison
        String status = statusLookupValue.trim();
        String subStatus = subStatusLookupValue != null ? subStatusLookupValue.trim() : "";

        // Determine actions based on status and substatus combinations
        switch (status.toLowerCase(Locale.ROOT)) {
            case "completed":
                if ("pass".equalsIgnoreCase(subStatus)) {
                    actions.add("View");
                    actions.add("Download Report");
                    actions.add("Feedback");
                } else if ("fail".equalsIgnoreCase(subStatus)) {
                    actions.add("View");
                    actions.add("Download Report");
                    actions.add("Feedback");
                } else {
                    // Default for complete status
                    actions.add("View");
                    actions.add("Download Report");
                    actions.add("Feedback");
                }
                break;

            case "da":
                if ("nc raised".equalsIgnoreCase(subStatus)) {
                    actions.add("Reply on NC");
                }
                break;

            case "cancelled":
                actions.add("View");
                actions.add("Download Report");
                break;

            case "draft":
                if ("incomplete application".equalsIgnoreCase(subStatus)) {
                    actions.add("Complete");
                    actions.add("Discard");
                }
                break;

            case "video assessment":
                if ("va pending".equalsIgnoreCase(subStatus)) {
                    actions.add("Schedule VA");
                    actions.add("Reschedule VA");
                }
                break;

            default:
                // Default actions for unknown status
                actions.add("View");
                break;
        }

        return actions;
    }

}
