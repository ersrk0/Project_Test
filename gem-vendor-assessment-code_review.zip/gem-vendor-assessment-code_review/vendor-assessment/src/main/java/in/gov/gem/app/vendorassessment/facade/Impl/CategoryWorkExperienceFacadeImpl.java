
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;


import in.gov.gem.app.vendorassessment.domain.entity.CategoryWorkExperience;
import in.gov.gem.app.vendorassessment.dto.response.CategoryNewResponseDTO;
import in.gov.gem.app.vendorassessment.dto.request.CategoryWorkExperienceRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.WorkExperienceCategoryMappingDTO;
import in.gov.gem.app.vendorassessment.dto.response.CategoryWorkExperienceResponseDTO;
import in.gov.gem.app.vendorassessment.facade.ICategoryFacade;
import in.gov.gem.app.vendorassessment.facade.ICategoryWorkExperienceFacade;

import in.gov.gem.app.vendorassessment.service.ICategoryWorkExperienceService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Implementation of the WorkExperienceFacade interface.
 * Handles DTO conversions and delegates to the WorkExperienceService and CategoryFacade.
 */
@Service
public class CategoryWorkExperienceFacadeImpl implements ICategoryWorkExperienceFacade {

  private final ICategoryWorkExperienceService workExperienceService;
  private final ICategoryFacade categoryFacade; // To get Category details for responses

  @Autowired
  public CategoryWorkExperienceFacadeImpl(ICategoryWorkExperienceService workExperienceService, ICategoryFacade categoryFacade) {
    this.workExperienceService = workExperienceService;
    this.categoryFacade = categoryFacade;
  }

  /**
   * Creates a new work experience.
   * @param requestDTO The DTO containing work experience details.
   * @return The response DTO for the created work experience.
   */
  @Override
  public CategoryWorkExperienceResponseDTO createWorkExperience(CategoryWorkExperienceRequestDTO requestDTO) {
    CategoryWorkExperience workExperience = convertToCategoryWorkExperience(requestDTO);
    CategoryWorkExperience createdWorkExperience = workExperienceService.createWorkExperience(workExperience);
    return convertToResponseDTO(createdWorkExperience, "Created");
  }

  /**
   * Retrieves a work experience by ID.
   * @param id The ID of the work experience.
   * @return The response DTO for the work experience, or null if not found.
   */
  @Override
  public CategoryWorkExperienceResponseDTO getWorkExperienceById(String id) {
    Optional<CategoryWorkExperience> workExperienceOptional = workExperienceService.getWorkExperienceById(id);
    return workExperienceOptional.map(we -> convertToResponseDTO(we, "Retrieved")).orElse(null);
  }

  /**
   * Retrieves all work experience entries.
   * @return A list of response DTOs for all work experiences.
   */
  @Override
  public List<CategoryWorkExperienceResponseDTO> getAllWorkExperiences() {
    List<CategoryWorkExperience> workExperiences = workExperienceService.getAllWorkExperiences();
    return workExperiences.stream()
        .map(we -> convertToResponseDTO(we, "Retrieved"))
        .collect(Collectors.toList());
  }

  /**
   * Updates an existing work experience.
   * @param id The ID of the work experience to update.
   * @param requestDTO The DTO with updated details.
   * @return The response DTO for the updated work experience, or null if not found.
   */
  @Override
  public CategoryWorkExperienceResponseDTO updateWorkExperience(String id, CategoryWorkExperienceRequestDTO requestDTO) {
    CategoryWorkExperience workExperience = convertToCategoryWorkExperience(requestDTO);
    Optional<CategoryWorkExperience> updatedWorkExperienceOptional = workExperienceService.updateWorkExperience(id, workExperience);
    return updatedWorkExperienceOptional.map(updatedWe -> convertToResponseDTO(updatedWe, "Updated")).orElse(null);
  }

  /**
   * Deletes a work experience by ID.
   * @param id The ID of the work experience to delete.
   * @return A response DTO indicating the deletion status.
   */
  @Override
  public CategoryWorkExperienceResponseDTO deleteWorkExperience(String id) {
    boolean deleted = workExperienceService.deleteWorkExperience(id);
    if (deleted) {
      return new CategoryWorkExperienceResponseDTO(id,"Deleted");
    }
    return new CategoryWorkExperienceResponseDTO(id, "Not Found or Failed to Delete");
  }

  /**
   * Maps categories to a specific work experience.
   * @param workExperienceId The ID of the work experience.
   * @param mappingDTO The DTO containing the list of category IDs to map.
   * @return The response DTO for the updated work experience with mapped categories, or null if not found.
   */
  @Override
  public CategoryWorkExperienceResponseDTO mapCategoriesToWorkExperience(String workExperienceId, WorkExperienceCategoryMappingDTO mappingDTO) {
    Optional<CategoryWorkExperience> updatedWorkExperienceOptional = workExperienceService.mapCategoriesToWorkExperience(workExperienceId, mappingDTO.getCategoryIds());
    return updatedWorkExperienceOptional.map(updatedWe -> getWorkExperienceWithMappedCategories(updatedWe.getId())).orElse(null);
  }

  /**
   * Retrieves the work experience along with its mapped categories.
   * @param workExperienceId The ID of the work experience.
   * @return The WorkExperienceResponseDTO including the mapped category details.
   */
  @Override
  public CategoryWorkExperienceResponseDTO getWorkExperienceWithMappedCategories(String workExperienceId) {
    Optional<CategoryWorkExperience> workExperienceOptional = workExperienceService.getWorkExperienceById(workExperienceId);

    return workExperienceOptional.map(we -> {
      CategoryWorkExperienceResponseDTO responseDTO = convertToResponseDTO(we, "Retrieved with Mapped Categories");
      List<String> mappedCategoryIds = we.getMappedCategoryIds();

      // Fetch full CategoryResponseDTOs for the mapped IDs
      List<CategoryNewResponseDTO> mappedCategories = mappedCategoryIds.stream()
          .map(categoryFacade::getCategoryById) // Use categoryFacade to get category DTOs
          .filter(java.util.Objects::nonNull) // Filter out any categories that might not exist
          .collect(Collectors.toList());

      responseDTO.setMappedCategories(mappedCategories);
      return responseDTO;
    }).orElse(null);
  }


  /**
   * Helper method to convert WorkExperienceRequestDTO to WorkExperience domain object.
   */
  private CategoryWorkExperience convertToCategoryWorkExperience(CategoryWorkExperienceRequestDTO requestDTO) {
    return new CategoryWorkExperience(
        requestDTO.getOrganisationType(),
        requestDTO.getDepartment(),
        requestDTO.getAuthName(),
        requestDTO.getContractNumber(),
        requestDTO.getAuthEmail(),
        requestDTO.getItemSupplied(),
        requestDTO.getSuppliedQuantity(),
        requestDTO.getDepartment(),
        requestDTO.getOrderNumber(),
            requestDTO.getOrderQuantity(),
        requestDTO.getOrderValue(),
        requestDTO.getOfficeZone(),
            requestDTO.getMinistry(),
            requestDTO.getOrganisation(),
            requestDTO.getOrderValue()

    );
  }

  /**
   * Helper method to convert WorkExperience domain object to WorkExperienceResponseDTO.
   * Does NOT populate mappedCategories in this method by default to avoid recursive calls
   * when only a basic WorkExperience is needed. Use getWorkExperienceWithMappedCategories
   * for full details.
   */
  private CategoryWorkExperienceResponseDTO convertToResponseDTO(CategoryWorkExperience workExperience, String status) {
    return new CategoryWorkExperienceResponseDTO(
        workExperience.getId(),
        workExperience.getOrganisationType(),
        workExperience.getDepartment(),
        workExperience.getOfficeZone(),
        workExperience.getContractNumber(),
        workExperience.getAuthEmail(),
        workExperience.getItemSupplied(),
        workExperience.getOrderQuantity(),
        workExperience.getOrderValue(),
        workExperience.getOrderNumber(),
        workExperience.getAcceptedValue(),
        workExperience.getMinistry(),
        workExperience.getOrganisation(),
        status,
            workExperience.getMappedCategoryIds().stream()
            .map(categoryFacade::getCategoryById)
            .filter(java.util.Objects::nonNull)
            .collect(Collectors.toList())
    );
  }
}
