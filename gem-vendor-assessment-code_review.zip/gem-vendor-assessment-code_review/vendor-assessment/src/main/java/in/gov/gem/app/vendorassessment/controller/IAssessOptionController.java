
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.request.AuthorizeDetailRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ContractManufacturerRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.LookupRequestDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@Tag(name = "Assessment Options", description = "APIs for vendor assessment options")
@RestController
@RequestMapping("/v1/assess")
/**
 * Provides APIs for vendor assessment options such as applying as a specific type,
 * saving authorization or contract manufacturer details, and retrieving assessment information.
 */
public interface IAssessOptionController {

  /**
   * Saves a lookup value for applying as a specific type.
   *
   * @param lookupRequestDto Details for the lookup value.
   * @param skip             Optional flag to skip certain steps.
   * @return API response with operation result.
   */
  @Operation(
    summary = "Save Lookup Value",
    description = "Apply as a specific type with optional skip flag."
  )
  @Parameter(
    name = "lookupRequestDto",
    description = "Lookup request details",
    in = ParameterIn.DEFAULT,
    required = true
  )
  @Parameter(
    name = "skip",
    description = "Skip flag",
    in = ParameterIn.QUERY,
    required = false,
    example = "false"
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/apply-as")
  ResponseEntity<APIResponse<Object>> saveLookupValue(
    @RequestBody LookupRequestDTO lookupRequestDto,
    @RequestParam(value = "skip", defaultValue = "false") boolean skip
  );

  /**
   * Saves authorization details.
   *
   * @param authorizeDetailDTO Authorization details to be saved.
   * @return API response with operation result.
   */
  @Operation(
    summary = "Authorize Detail",
    description = "Save authorization details."
  )
  @Parameter(
    name = "authorizeDetailDTO",
    description = "Authorization details",
    in = ParameterIn.DEFAULT,
    required = true
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/authorize/detail")
  ResponseEntity<APIResponse<Object>> authorizeDetail(
    @RequestBody AuthorizeDetailRequestDTO authorizeDetailDTO
  );

  /**
   * Saves contract manufacturer details.
   *
   * @param contractManufacturerDTO Contract manufacturer details to be saved.
   * @return API response with operation result.
   */
  @Operation(
    summary = "Contract Manufacturer Detail",
    description = "Save contract manufacturer details."
  )
  @Parameter(
    name = "contractManufacturerDTO",
    description = "Contract manufacturer details",
    in = ParameterIn.DEFAULT,
    required = true
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/contract-manufacturer/detail")
  ResponseEntity<APIResponse<Object>> contractManufacturerDetail(
    @RequestBody ContractManufacturerRequestDTO contractManufacturerDTO
  );

  /**
   * Identifies the registration type.
   *
   * @return API response with registration type information.
   */
  @Operation(
    summary = "Identify Registration",
    description = "Identify registration type."
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/identify")
  ResponseEntity<APIResponse<Object>> identifyRegistration();

  /**
   * Retrieves contract manufacturer details by ID.
   *
   * @param id ID of the contract manufacturer.
   * @return API response with contract manufacturer details.
   */
  @Operation(
    summary = "Get Contract Manufacturer Detail",
    description = "Get contract manufacturer details by ID."
  )
  @Parameter(
    name = "id",
    description = "ID of the contract manufacturer",
    in = ParameterIn.QUERY,
    required = true
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/contract-manufacturer/detail")
  ResponseEntity<APIResponse<Object>> getContractManufacturerDetail(
    @RequestParam long id
  );

  /**
   * Retrieves authorization details by ID.
   *
   * @param id ID of the authorization detail.
   * @return API response with authorization details.
   */
  @Operation(
    summary = "Get Authorize Detail",
    description = "Get authorization details by ID."
  )
  @Parameter(
    name = "id",
    description = "ID of the authorization detail",
    in = ParameterIn.QUERY,
    required = true
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/authorize/detail")
  ResponseEntity<APIResponse<Object>> getAuthorizeDetail(
    @RequestParam long id
  );

  /**
   * Retrieves assessment details by ID.
   *
   * @param id ID of the assessment.
   * @return API response with assessment details.
   */
  @Operation(
    summary = "Get Assess",
    description = "Get assessment by ID."
  )
  @Parameter(
    name = "id",
    description = "ID of the assessment",
    in = ParameterIn.QUERY,
    required = true
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/applied-as")
  ResponseEntity<APIResponse<Object>> getAssess(
    @RequestParam long id
  );
}
 