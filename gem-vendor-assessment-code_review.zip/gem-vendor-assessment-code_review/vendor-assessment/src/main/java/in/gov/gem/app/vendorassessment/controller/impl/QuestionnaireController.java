/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;


import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.controller.IQuestionnaireController;
import in.gov.gem.app.vendorassessment.dto.request.QuestionDto;
import in.gov.gem.app.vendorassessment.dto.request.QuestionRequestDto;
import in.gov.gem.app.vendorassessment.dto.request.SaveResponsesRequestDto;
import in.gov.gem.app.vendorassessment.dto.response.QuestionResponseDto;
import in.gov.gem.app.vendorassessment.facade.IQuestionnaireFacade;
import jakarta.validation.Valid;
import jakarta.validation.ValidationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class QuestionnaireController implements IQuestionnaireController {

    private final IQuestionnaireFacade questionnaireFacade;

    public QuestionnaireController(IQuestionnaireFacade questionnaireFacade) {
        this.questionnaireFacade = questionnaireFacade;
    }

    @Override
    public ResponseEntity<APIResponse<Object>> getQuestionsForCategory(Long categoryId) {
        List<QuestionDto> questions = questionnaireFacade.getQuestionsForCategory(categoryId);
        if (questions.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(APIResponse.builder()
                            .msId(ApplicationConstant.MSID)
                            .status(HttpStatus.NOT_FOUND.getReasonPhrase())
                            .httpStatus(HttpStatus.NOT_FOUND.value())
                            .message("No questions found for the specified category.")
                            .data(null)
                            .build());
        }
        return ResponseEntity.ok(APIResponse.<Object>builder()
                .msId("VCS")
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message("Fetched questions successfully.")
                .data(questions)
                .build());
    }

    @Override
    public ResponseEntity<APIResponse<Object>> saveQuestionnaireResponses(
            Long categoryId,
            @Valid SaveResponsesRequestDto requestDto) {
        questionnaireFacade.saveQuestionnaireResponses(categoryId, requestDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(APIResponse.builder()
                        .msId(ApplicationConstant.MSID)
                        .status(HttpStatus.CREATED.getReasonPhrase())
                        .httpStatus(HttpStatus.CREATED.value())
                        .message("Questionnaire responses saved successfully.")
                        .data(null)
                        .build());
    }

    @Override
    public ResponseEntity<APIResponse<Object>> getSavedQuestionnaireResponses(Long categoryId) {
        List<QuestionResponseDto> responses = questionnaireFacade.getSavedResponsesForCategory(categoryId);
        return ResponseEntity.ok(APIResponse.<Object>builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message("Fetched saved responses successfully.")
                .data(responses)
                .build());

    }

    @Override
    public ResponseEntity<APIResponse<Object>> createQuestion(
            Long categoryId,
            @Valid QuestionRequestDto questionRequestDto) {
        if (questionRequestDto.getQuestionId() != null) {
            throw new ValidationException("Question ID must be null for new question creation.");
        }
        QuestionDto newQuestion = questionnaireFacade.saveQuestion(categoryId, questionRequestDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(APIResponse.<Object>builder()
                        .msId(ApplicationConstant.MSID)
                        .status(HttpStatus.CREATED.getReasonPhrase())
                        .httpStatus(HttpStatus.CREATED.value())
                        .message("Question created successfully.")
                        .data(newQuestion)
                        .build());
    }

    @Override
    public ResponseEntity<APIResponse<Object>> updateQuestion(
            Long categoryId,
            Long questionId,
            @Valid QuestionRequestDto questionRequestDto) {
        if (questionRequestDto.getQuestionId() != null && !questionRequestDto.getQuestionId().equals(questionId)) {
            throw new ValidationException("Question ID in path must match ID in request body.");
        }
        questionRequestDto.setQuestionId(questionId);
        QuestionDto updatedQuestion = questionnaireFacade.saveQuestion(categoryId, questionRequestDto);
        return ResponseEntity.ok(APIResponse.<Object>builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message("Question updated successfully.")
                .data(updatedQuestion)
                .build());

    }

    @Override
    public ResponseEntity<APIResponse<Object>> deleteQuestion(
            Long categoryId,
            Long questionId) {
        questionnaireFacade.deleteQuestion(categoryId, questionId);
        return ResponseEntity.ok(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.NO_CONTENT.getReasonPhrase())
                .httpStatus(HttpStatus.NO_CONTENT.value())
                .message("Question deleted successfully.")
                .data(null)
                .build());
    }
}
