
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;



import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.dto.request.ExportDTORequestDTO;
import in.gov.gem.app.vendorassessment.controller.IFileServiceController;
import in.gov.gem.app.vendorassessment.facade.IFileFacade;
import lombok.AllArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.*;

import org.springframework.web.bind.annotation.*;


/**
 * The type File controller.
 */
@RestController
@AllArgsConstructor
public class FileController extends BaseParentController implements IFileServiceController {

    @Autowired
    private IFileFacade fileFacade;

    public ResponseEntity<byte[]> exportUsersToExcel(@RequestBody(required = false) ExportDTORequestDTO vendorDashboardDTOS, @RequestParam(required = false) boolean all) {
        return   fileFacade.exportUsersToExcel(vendorDashboardDTOS,all);
    }
}
