
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.repository;

import in.gov.gem.app.service.core.repository.BaseRepository;


import in.gov.gem.app.vendorassessment.domain.entity.VAMasterEntity;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.time.Instant;
import java.util.List;
import java.util.Optional;


/**
 * The interface Vendor assessment repository.
 */
@Repository
public interface VendorAssessmentRepository extends BaseRepository<VAMasterEntity,Long> {

    /**
     * Find id by va number string.
     *
     * @param vendorId the vendor id
     * @return the string
     */
    String findIdByVaNumber(String vendorId);

    //Page<VendorAssessment> findByUserFk(Long userFk, Pageable pageRequest);

    /**
     * Find by user fk list.
     *
     * @param userFk the user fk
     * @return the list
     */
    List<Optional<VAMasterEntity>> findByUserFk(Long userFk);

    /**
     * Find by va number optional.
     *
     * @param vaNumber the va number
     * @return the optional
     */
    Optional<VAMasterEntity> findByVaNumber(String vaNumber);

    /**
     * Find by pvt org master fk list.
     *
     * @param sellerId the seller id
     * @return the list
     */
    List<Optional<VAMasterEntity>> findByPvtOrgMasterFk(Long sellerId);

    //Page<VendorAssessment> findByPvtOrgMasterFk(Long userFk, Pageable pageRequest);


    /**
     * Exists by pvt org master fk and va status look up and apply as look up boolean.
     *
     * @param sellerId the seller id
     * @param status   the status
     * @param applyAs  the apply as
     * @return the boolean
     */
    boolean existsByPvtOrgMasterFkAndVaStatusLookUpAndApplyAsLookUp(Long sellerId, String status, String applyAs);

    /**
     * Exists by id and va status look up boolean.
     *
     * @param vendorAssessmentId the vendor assessment id
     * @param draft              the draft
     * @return the boolean
     */
    boolean existsByIdAndVaStatusLookUp(Long vendorAssessmentId, String draft);

    /**
     * Find by valid up to between list.
     *
     * @param currentInstant the current instant
     * @param threeMonths    the three months
     * @return the list
     */
    List<VAMasterEntity> findByValidUpToBetween(Instant currentInstant, Instant threeMonths);
}

