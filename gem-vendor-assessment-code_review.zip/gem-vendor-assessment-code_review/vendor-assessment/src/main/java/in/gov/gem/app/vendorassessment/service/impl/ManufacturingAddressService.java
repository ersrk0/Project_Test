
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.repository.LookupRepository;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;



import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.VAOrganizationAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.NewVAResponseOrganizationAddressDTO;
import in.gov.gem.app.vendorassessment.dto.response.VAResponseOrganizationAddressResponseDTO;

import in.gov.gem.app.vendorassessment.domain.entity.VAOrganizationAddressEntity;
import in.gov.gem.app.vendorassessment.domain.entity.VaOrganizationDetailEntity;
import in.gov.gem.app.vendorassessment.domain.repository.VaManufacturingAddressRepository;
import in.gov.gem.app.vendorassessment.domain.repository.VaOrganizationDetailRepository;
import in.gov.gem.app.vendorassessment.service.IManufacturingAddress;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * The type Manufacturing address service.
 */
@Service
@AllArgsConstructor
public class ManufacturingAddressService implements IManufacturingAddress
{

  private final VaManufacturingAddressRepository repository;

  private final VaOrganizationDetailRepository organizationDetailRepository;

  private final MessageUtility messageUtility;

  //private final ISaveAssessOptionService service;

  private ISellerClient sellerClient;

  private LookupRepository lookupRepository;

  @Override
  public VAOrganizationAddressRequestDTO saveManufacturingAddress(VAOrganizationAddressRequestDTO request)
  {
    VAOrganizationAddressEntity organizationAddressEntity = VAOrganizationAddressEntity.builder()
      .vaOrganizationDetailFk(request.getVaOrganizationDetailFk())
      .officeName(request.getOfficeName())
      .officeTypeLookup(request.getOfficeTypeLookup())
      .officeAddressLine1(request.getOfficeAddressLine1())
      .officeAddressLine2(request.getOfficeAddressLine2())
      .officeLandmark(request.getOfficeLandmark())
      .geographyLocationCode(request.getGeographyLocationCode())
      .contactNumber(request.getContactNumber())
      .emailId(request.getEmailId())
      .gstinNumber(request.getGstinNumber())
      .assessAsLookupType(request.getAssessAsLookupType())
      .build();

    VAOrganizationAddressEntity savedEntity = repository.save(organizationAddressEntity); // <--- Breakpoint here

    VAOrganizationAddressRequestDTO responseDTO = VAOrganizationAddressRequestDTO.builder()
      .id(savedEntity.getId())
      .vaOrganizationDetailFk(savedEntity.getVaOrganizationDetailFk())
      .officeName(savedEntity.getOfficeName())
      .officeTypeLookup(savedEntity.getOfficeTypeLookup())
      .officeAddressLine1(savedEntity.getOfficeAddressLine1())
      .officeAddressLine2(savedEntity.getOfficeAddressLine2())
      .officeLandmark(savedEntity.getOfficeLandmark())
      .geographyLocationCode(savedEntity.getGeographyLocationCode())
      .contactNumber(savedEntity.getContactNumber())
      .emailId(savedEntity.getEmailId())
      .gstinNumber(savedEntity.getGstinNumber())
      .assessAsLookupType(savedEntity.getAssessAsLookupType())
      .build();

    return responseDTO;

  }

  @Override
  public VAOrganizationAddressRequestDTO saveManufacturingAddressAssessAs(VAOrganizationAddressRequestDTO vaOrganizationAddress, String vaNumber) {

    //.SaveAssessResponseDTO option = service.getOption(vaNumber);
    //Optional<Lookup> byLookupCode = lookupRepository.findByLookupCode(option.getApplyAsLookUp());
    //byLookupCode.ifPresent(lookup -> option.setApplyAsLookUp(lookup.getLookupValue()));

    VAOrganizationAddressEntity organizationAddressEntity = VAOrganizationAddressEntity.builder()
      .vaOrganizationDetailFk(vaOrganizationAddress.getVaOrganizationDetailFk())
      .officeName(vaOrganizationAddress.getOfficeName())
      .officeTypeLookup(vaOrganizationAddress.getOfficeTypeLookup())
      .officeAddressLine1(vaOrganizationAddress.getOfficeAddressLine1())
      .officeAddressLine2(vaOrganizationAddress.getOfficeAddressLine2())
      .officeLandmark(vaOrganizationAddress.getOfficeLandmark())
      .geographyLocationCode(vaOrganizationAddress.getGeographyLocationCode())
      .contactNumber(vaOrganizationAddress.getContactNumber())
      .emailId(vaOrganizationAddress.getEmailId())
      .gstinNumber(vaOrganizationAddress.getGstinNumber())
      .assessAsLookupType(vaOrganizationAddress.getAssessAsLookupType())
      .build();

    VAOrganizationAddressEntity savedEntity = repository.save(organizationAddressEntity);

    VAOrganizationAddressRequestDTO responseDTO = VAOrganizationAddressRequestDTO.builder()
      .id(savedEntity.getId())
      .vaOrganizationDetailFk(savedEntity.getVaOrganizationDetailFk())
      .officeName(savedEntity.getOfficeName())
      .officeTypeLookup(savedEntity.getOfficeTypeLookup())
      .officeAddressLine1(savedEntity.getOfficeAddressLine1())
      .officeAddressLine2(savedEntity.getOfficeAddressLine2())
      .officeLandmark(savedEntity.getOfficeLandmark())
      .geographyLocationCode(savedEntity.getGeographyLocationCode())
      .contactNumber(savedEntity.getContactNumber())
      .emailId(savedEntity.getEmailId())
      .gstinNumber(savedEntity.getGstinNumber())
      //.assessAsLookupType(byLookupCode.map(Lookup::getLookupValue).orElse(null))
      .build();

    return responseDTO;
  }

  public VAOrganizationAddressRequestDTO saveAddressInVendorAndSeller(VAOrganizationAddressRequestDTO vendorAddressDTO, String vaNumber) {

    VAOrganizationAddressRequestDTO savedVendorAddress = saveManufacturingAddressAssessAs(vendorAddressDTO, vaNumber);

    OfficeAddressRequestDTO sellerRequestDTO = new OfficeAddressRequestDTO();
    sellerRequestDTO.setName(vendorAddressDTO.getOfficeName());
    sellerRequestDTO.setAddressOne(vendorAddressDTO.getOfficeAddressLine1());
    sellerRequestDTO.setAddressTwo(vendorAddressDTO.getOfficeAddressLine2());
    sellerRequestDTO.setLandmark(vendorAddressDTO.getOfficeLandmark());
    sellerRequestDTO.setMobile(vendorAddressDTO.getContactNumber());
    sellerRequestDTO.setEmail(vendorAddressDTO.getEmailId());
    sellerRequestDTO.setGstn(vendorAddressDTO.getGstinNumber());
    sellerRequestDTO.setTypeLookup(vendorAddressDTO.getOfficeTypeLookup());
    sellerRequestDTO.setPincode(vendorAddressDTO.getGeographyLocationCode());

    sellerClient.saveOfficeAddress(sellerRequestDTO);

    return savedVendorAddress;
  }

  @Override
  public List<VAOrganizationAddressRequestDTO> findByVaOrganizationDetailFk(Long vaOrganizationDetailFk)
  {
    List<VAOrganizationAddressEntity> organizationAddresses =
      repository.findByVaOrganizationDetailFk(vaOrganizationDetailFk);

    List<VAOrganizationAddressRequestDTO> organizationAddressDTOs = organizationAddresses.stream()
      .map(entity -> VAOrganizationAddressRequestDTO.builder()
        .id(entity.getId()) // Include the ID
        .vaOrganizationDetailFk(entity.getVaOrganizationDetailFk())
        .officeName(entity.getOfficeName())
        .officeTypeLookup(
          lookupRepository.findByLookupCode(entity.getOfficeTypeLookup())
            .map(Lookup::getLookupValue)
            .orElse(null)
        )
        .officeAddressLine1(entity.getOfficeAddressLine1())
        .officeAddressLine2(entity.getOfficeAddressLine2())
        .officeLandmark(entity.getOfficeLandmark())
        .geographyLocationCode(entity.getGeographyLocationCode())
        .contactNumber(entity.getContactNumber())
        .emailId(entity.getEmailId())
        .gstinNumber(entity.getGstinNumber())
        .assessAsLookupType(entity.getAssessAsLookupType())
        .build())
      .collect(Collectors.toList());

    return organizationAddressDTOs;

  }

  public PageableApiResponse<List<VAOrganizationAddressRequestDTO>> findByVaOrganizationDetailFk(PaginationParams paginationParams, Long vaOrganizationDetailFk)
  {
    PageRequest pageRequest = PageRequest.of(paginationParams.getPageNumber(), paginationParams.getPageSize(),
      Sort.by(paginationParams.getSortOrder(), paginationParams.getSortBy()));

    Page<VAOrganizationAddressEntity> page = repository.findByVaOrganizationDetailFk(vaOrganizationDetailFk, pageRequest);

    List<VAOrganizationAddressRequestDTO> dtoList = page.getContent().stream()
      .map(entity -> VAOrganizationAddressRequestDTO.builder()
        .id(entity.getId())
        .vaOrganizationDetailFk(entity.getVaOrganizationDetailFk())
        .officeName(entity.getOfficeName())
        .officeTypeLookup(
          lookupRepository.findByLookupCode(entity.getOfficeTypeLookup())
            .map(Lookup::getLookupValue)
            .orElse(null)
        )
        .officeAddressLine1(entity.getOfficeAddressLine1())
        .officeAddressLine2(entity.getOfficeAddressLine2())
        .officeLandmark(entity.getOfficeLandmark())
        .geographyLocationCode(entity.getGeographyLocationCode())
        .contactNumber(entity.getContactNumber())
        .emailId(entity.getEmailId())
        .gstinNumber(entity.getGstinNumber())
        .assessAsLookupType(entity.getAssessAsLookupType())
        .build())
      .collect(Collectors.toList());

    return PageableApiResponse.<List<VAOrganizationAddressRequestDTO>>pageableApiResponseBuilder()
      .currentElements(page.getNumberOfElements())
      .hasNext(page.hasNext())
      .totalPages(page.getTotalPages())
      .currentPage(page.getNumber())
      .data(dtoList)
      .build();
  }

  //-------------------------------------------------------------------------------------------------------------

  @Override
  public List<VAOrganizationAddressRequestDTO> findByVaMasterFk(Long vaMasterFk) {
    // Step 1: Find VaOrganizationDetail by vaMasterFk
    List<VaOrganizationDetailEntity> details = organizationDetailRepository.findByVaMasterFk(vaMasterFk);

    List<Long> detailIds = details.stream()
      .map(VaOrganizationDetailEntity::getId)
      .collect(Collectors.toList());

    List<VAOrganizationAddressEntity> addresses = repository.findByVaOrganizationDetailFkIn(detailIds);

    // Map to DTOs
    return addresses.stream()
      .map(entity -> VAOrganizationAddressRequestDTO.builder()
        .id(entity.getId())
        .vaOrganizationDetailFk(entity.getVaOrganizationDetailFk())
        .officeName(entity.getOfficeName())
        .officeTypeLookup(
          lookupRepository.findByLookupCode(entity.getOfficeTypeLookup())
            .map(Lookup::getLookupValue)
            .orElse(null)
        )
        .officeAddressLine1(entity.getOfficeAddressLine1())
        .officeAddressLine2(entity.getOfficeAddressLine2())
        .officeLandmark(entity.getOfficeLandmark())
        .geographyLocationCode(entity.getGeographyLocationCode())
        .contactNumber(entity.getContactNumber())
        .emailId(entity.getEmailId())
        .gstinNumber(entity.getGstinNumber())
        .assessAsLookupType(entity.getAssessAsLookupType())
        .build())
      .collect(Collectors.toList());
  }

  @Override
  public PageableApiResponse<List<VAOrganizationAddressRequestDTO>> findByVaMasterFk(PaginationParams paginationParams, Long vaMasterFk)
  {
    PageRequest pageRequest = PageRequest.of(paginationParams.getPageNumber(), paginationParams.getPageSize(),
      Sort.by(paginationParams.getSortOrder(), paginationParams.getSortBy()));

    Page<VaOrganizationDetailEntity> details = organizationDetailRepository.findByVaMasterFk(vaMasterFk, pageRequest);

    List<Long> detailIds = details.getContent().stream()
      .map(VaOrganizationDetailEntity::getId)
      .collect(Collectors.toList());

    List<VAOrganizationAddressEntity> addresses = repository.findByVaOrganizationDetailFkIn(detailIds);

    List<VAOrganizationAddressRequestDTO> dtoList = addresses.stream()
      .map(entity -> VAOrganizationAddressRequestDTO.builder()
        .id(entity.getId())
        .vaOrganizationDetailFk(entity.getVaOrganizationDetailFk())
        .officeName(entity.getOfficeName())
        .officeTypeLookup(
          lookupRepository.findByLookupCode(entity.getOfficeTypeLookup())
            .map(Lookup::getLookupValue)
            .orElse(null)
        )
        .officeAddressLine1(entity.getOfficeAddressLine1())
        .officeAddressLine2(entity.getOfficeAddressLine2())
        .officeLandmark(entity.getOfficeLandmark())
        .geographyLocationCode(entity.getGeographyLocationCode())
        .contactNumber(entity.getContactNumber())
        .emailId(entity.getEmailId())
        .gstinNumber(entity.getGstinNumber())
        .assessAsLookupType(entity.getAssessAsLookupType())
        .build())
      .collect(Collectors.toList());

    return PageableApiResponse.<List<VAOrganizationAddressRequestDTO>>pageableApiResponseBuilder()
      .currentElements(details.getNumberOfElements())
      .hasNext(details.hasNext())
      .totalPages(details.getTotalPages())
      .currentPage(details.getNumber())
      .data(dtoList)
      .build();
  }

  //------------------------------------------------------------------------------------------------\

  @Override
  public List<VAResponseOrganizationAddressResponseDTO> findById(Long id)
  {
    return repository.findById(id)
      .map(entity -> VAResponseOrganizationAddressResponseDTO.builder()
        .id(entity.getId())
        .vaOrganizationDetailFk(entity.getVaOrganizationDetailFk())
        .officeName(entity.getOfficeName())
        .officeTypeLookup(
          lookupRepository.findByLookupCode(entity.getOfficeTypeLookup())
            .map(Lookup::getLookupValue)
            .orElse(null)
        )
        .officeAddressLine1(entity.getOfficeAddressLine1())
        .officeAddressLine2(entity.getOfficeAddressLine2())
        .officeLandmark(entity.getOfficeLandmark())
        .geographyLocationCode(entity.getGeographyLocationCode())
        .contactNumber(entity.getContactNumber())
        .emailId(entity.getEmailId())
        .gstinNumber(entity.getGstinNumber())
        .assessAsLookupType(entity.getAssessAsLookupType())
        .action(List.of("edit", "delete"))
        .build())
      .map(List::of)
      .orElseGet(List::of);
  }

  @Override
  public List<NewVAResponseOrganizationAddressDTO> findByNewId(Long id) {
    return repository.findById(id)
      .map(entity -> NewVAResponseOrganizationAddressDTO.builder()
        .id(entity.getId())
        .vaOrganizationDetailFk(entity.getVaOrganizationDetailFk())
        .officeName(entity.getOfficeName())
        .officeType(
          lookupRepository.findByLookupCode(entity.getOfficeTypeLookup())
            .map(Lookup::getLookupValue)
            .orElse(null)
        )
        .officeAddress(entity.getOfficeAddressLine1())
        .officeLandmark(entity.getOfficeLandmark())
        .geographyLocationCode(entity.getGeographyLocationCode())
        .contactNumber(entity.getContactNumber())
        .emailId(entity.getEmailId())
        .gstinNumber(entity.getGstinNumber())
        .assessAsLookupType(entity.getAssessAsLookupType())
        .action(List.of("edit", "delete"))
        .build())
      .map(List::of)
      .orElseGet(List::of);
  }

  @Override
  public void deleteById(Long id)
  {
    if (repository.existsById(id)) {
      repository.deleteById(id);
    } else {
      throw new ServiceException(
        MessageConstant.UNEXPECTED_ERROR,
        messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
        ErrorConstant.CATEGORY.BV,
        ErrorConstant.SEVERITY.I);
    }
  }

  @Override
  public void updateById(Long id, VAOrganizationAddressRequestDTO request)
  {
    Optional<VAOrganizationAddressEntity> optionalEntity = repository.findById(id);
    if (optionalEntity.isPresent()) {
      VAOrganizationAddressEntity entity = optionalEntity.get();
      entity.setOfficeName(request.getOfficeName());
      entity.setOfficeTypeLookup(request.getOfficeTypeLookup());
      entity.setOfficeAddressLine1(request.getOfficeAddressLine1());
      entity.setOfficeAddressLine2(request.getOfficeAddressLine2());
      entity.setOfficeLandmark(request.getOfficeLandmark());
      entity.setGeographyLocationCode(request.getGeographyLocationCode());
      entity.setContactNumber(request.getContactNumber());
      entity.setEmailId(request.getEmailId());
      entity.setGstinNumber(request.getGstinNumber());
      entity.setAssessAsLookupType(request.getAssessAsLookupType());
      repository.save(entity);
    } else {
      throw new ServiceException(
        MessageConstant.UNEXPECTED_ERROR,
        messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
        ErrorConstant.CATEGORY.BV,
        ErrorConstant.SEVERITY.I);
    }
  }

}
