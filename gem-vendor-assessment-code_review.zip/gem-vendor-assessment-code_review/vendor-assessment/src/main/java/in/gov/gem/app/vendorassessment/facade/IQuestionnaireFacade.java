
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;



import in.gov.gem.app.vendorassessment.dto.request.QuestionDto;
import in.gov.gem.app.vendorassessment.dto.request.QuestionRequestDto;
import in.gov.gem.app.vendorassessment.dto.request.SaveResponsesRequestDto;
import in.gov.gem.app.vendorassessment.dto.response.QuestionResponseDto;

import java.util.List;

/**
 * Interface for the QuestionnaireFacade.
 * This interface defines the contract for managing questionnaire operations,
 * including fetching questions, saving responses, and managing individual questions.
 */
public interface IQuestionnaireFacade {

    /**
     * Retrieves all questions associated with a specific category.
     *
     * @param categoryId The unique ID of the category.
     * @return A list of QuestionDto objects representing the questions.
     */
    List<QuestionDto> getQuestionsForCategory(Long categoryId);

    /**
     * Retrieves saved questionnaire responses for a specific category.
     *
     * @param categoryId The unique ID of the category.
     * @return A list of QuestionResponseDto objects with the saved answers.
     */
    List<QuestionResponseDto> getSavedResponsesForCategory(Long categoryId);

    /**
     * Saves or updates a batch of questionnaire responses for a specific category.
     *
     * @param categoryId The unique ID of the category.
     * @param requestDto The DTO containing the responses to save.
     */
    void saveQuestionnaireResponses(Long categoryId, SaveResponsesRequestDto requestDto);

    /**
     * Creates or updates a question within a specified category.
     *
     * @param categoryId The unique ID of the category.
     * @param requestDto The DTO containing the question's details.
     * @return A QuestionDto representing the newly saved or updated question.
     */
    QuestionDto saveQuestion(Long categoryId, QuestionRequestDto requestDto);

    /**
     * Deletes a question from a category.
     *
     * @param categoryId The unique ID of the category.
     * @param questionId The unique ID of the question to delete.
     */
    void deleteQuestion(Long categoryId, Long questionId);
}
