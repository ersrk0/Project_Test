
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;

import in.gov.gem.app.service.dto.APIResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@Tag(name = "Vendor Consent", description = "APIs for vendor consent meta-data and document viewing")
@RestController
@RequestMapping("/v1/vendor")

public interface IConsentController
{

  /**
   * Gets consent meta-data for a given module and functionality.
   *
   * @param acceptLanguage the accept language header
   * @param module         the module name
   * @param functionality  the functionality name
   * @return the consent meta-data
   */
  @Operation(
    summary = "Get Consent Meta-Data",
    description = "Fetches consent meta-data for a given module and functionality.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "Accept-Language", description = "Accept language", in = ParameterIn.HEADER, required = true)
  @Parameter(name = "module", description = "Module name", in = ParameterIn.QUERY, required = true)
  @Parameter(name = "functionality", description = "Functionality name", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/consent/meta-data")
  ResponseEntity<APIResponse<Object>> getConsentMetaData(
    @RequestHeader(name = "Accept-Language") String acceptLanguage,
    @RequestParam String module,
    @RequestParam String functionality
  );

  /**
   * Downloads the consent document for a given consent code.
   *
   * @param consentCode    the consent code
   * @param acceptLanguage the accept language header
   * @return the consent document as a byte array
   */
  @Operation(
    summary = "Download Consent Document",
    description = "Downloads the consent document for a given consent code.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "consentCode", description = "Consent code", in = ParameterIn.QUERY, required = true)
  @Parameter(name = "Accept-Language", description = "Accept language", in = ParameterIn.HEADER, required = true)
  @ApiResponse(responseCode = "200", description = "Consent document downloaded successfully")
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/consent/view-data")
  ResponseEntity<byte[]> downloadDocument(
    @RequestParam String consentCode,
    @RequestHeader(name = "Accept-Language") String acceptLanguage
  );}
 