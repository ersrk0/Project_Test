
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;


import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.dto.response.BODDocumentResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OrganizationDetailsResponseDTO;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.controller.IBODControllerController;
import in.gov.gem.app.vendorassessment.domain.entity.VaDocumentDetailEntity;
import in.gov.gem.app.vendorassessment.facade.IBODFacade;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

/**
 * The type Bod controller.
 */
@RestController
@AllArgsConstructor

public class BODController extends BaseParentController implements IBODControllerController {

    private IBODFacade bodFacade;
    private final ISellerClient iSellerClient;

    @Override
    public  ResponseEntity<APIResponse<Object>>getRequiredBodDocuments(Long VendorAssessmentId) {

        return ResponseEntity.ok().body(APIResponse.builder()
          .msId(ApplicationConstant.MSID)
          .status(HttpStatus.OK.getReasonPhrase())
          .httpStatus(HttpStatus.OK.value())
          .message(ApplicationConstant.FETCH_MESSAGE)
          .data(bodFacade.getRequiredDocuments(VendorAssessmentId))
          .build());

    }
    @Override
    public ResponseEntity<APIResponse<Object>> myOrganisationBodDocumentList( Long vaMasterId){
        return ResponseEntity.ok().body(APIResponse.builder()
          .msId(ApplicationConstant.MSID)
          .status(HttpStatus.OK.getReasonPhrase())
          .httpStatus(HttpStatus.OK.value())
          .message(ApplicationConstant.FETCH_MESSAGE)
          .data(bodFacade.getMyOrganizationDocuments(vaMasterId))
          .build());
    }
    @Override
    public ResponseEntity<APIResponse<Object>> myAuthorizingOemOspBodDocumentList( Long vaMasterId){
        return ResponseEntity.ok().body(APIResponse.builder()
          .msId(ApplicationConstant.MSID)
          .status(HttpStatus.OK.getReasonPhrase())
          .httpStatus(HttpStatus.OK.value())
          .message(ApplicationConstant.FETCH_MESSAGE)
          .data(bodFacade.getAuthorizingOemOspDocuments(vaMasterId))
          .build());
    }
    @Override
    public ResponseEntity<APIResponse<Object>> myContractManufacturerDocumentList(Long vaMasterId){
        return ResponseEntity.ok().body(APIResponse.builder()
          .msId(ApplicationConstant.MSID)
          .status(HttpStatus.OK.getReasonPhrase())
          .httpStatus(HttpStatus.OK.value())
          .message(ApplicationConstant.FETCH_MESSAGE)
          .data(bodFacade.getContractManufacturerDocuments(vaMasterId))
          .build());
    }
    @Override
    public ResponseEntity<APIResponse<Object>> deleteBodDocument(Long vaMasterId, String docName) {
        bodFacade.deleteBodDocument(vaMasterId,docName);
        return ResponseEntity.ok().body(APIResponse.builder()
          .msId(ApplicationConstant.MSID)
          .status(HttpStatus.OK.getReasonPhrase())
          .httpStatus(HttpStatus.OK.value())
          .message(ApplicationConstant.DELETE_MESSAGE)
          .build());
    }


    @Override
    public ResponseEntity<byte[]> exportUsersToExcel(List<BODDocumentResponseDTO> bodDocumentResponses) {
        return bodFacade.exportToExcel(bodDocumentResponses);
    }
    @Override
    public ResponseEntity<APIResponse<Object>> getLastVerifiedBODDocument() {
        ResponseEntity<APIResponse<OrganizationDetailsResponseDTO>> response = iSellerClient.getOrganizationDetails();

        OrganizationDetailsResponseDTO organizationDetails = Objects.requireNonNull(response.getBody()).getData();
        Long sellerId = organizationDetails.getGemPvtOrgId();
        List<BODDocumentResponseDTO> bodDocument = bodFacade.getLastVerifiedBODDocument(sellerId);
        return ResponseEntity.ok().body(APIResponse.builder()
          .msId(ApplicationConstant.MSID)
          .status(HttpStatus.OK.getReasonPhrase())
          .httpStatus(HttpStatus.OK.value())
          .message(ApplicationConstant.FETCH_MESSAGE)
          .data(bodDocument)
          .build());
    }
    @Override
    public ResponseEntity<APIResponse<Object>> saveRemarks( String remarks,
                                                            Long vaMasterFk)  {
        VaDocumentDetailEntity documentDetailEntity= bodFacade.saveRemarks(remarks, vaMasterFk);
        return ResponseEntity.ok().body(APIResponse.builder()
          .msId(ApplicationConstant.MSID)
          .status(HttpStatus.OK.getReasonPhrase())
          .httpStatus(HttpStatus.OK.value())
          .data(documentDetailEntity)
          .message(ApplicationConstant.SAVE_MESSAGE)
          .build());
    }
    @Override
    public ResponseEntity<APIResponse<Object>> getParentBodDocuments(Long vaMasterId) {
        return ResponseEntity.ok().body(APIResponse.builder()
          .msId(ApplicationConstant.MSID)
          .status(HttpStatus.OK.getReasonPhrase())
          .httpStatus(HttpStatus.OK.value())
          .message(ApplicationConstant.FETCH_MESSAGE)
          .data(bodFacade.getParentBodDocuments(vaMasterId))
          .build());
    }
    @Override
    public ResponseEntity<APIResponse<Object>> getParentOrganisationBODDocument(Long vaMasterId) {
        return ResponseEntity.ok().body(APIResponse.builder()
          .msId(ApplicationConstant.MSID)
          .status(HttpStatus.OK.getReasonPhrase())
          .httpStatus(HttpStatus.OK.value())
          .message(ApplicationConstant.FETCH_MESSAGE)
          .data(bodFacade.getUploadedParentBODDocument(vaMasterId))
          .build());
    }

}
