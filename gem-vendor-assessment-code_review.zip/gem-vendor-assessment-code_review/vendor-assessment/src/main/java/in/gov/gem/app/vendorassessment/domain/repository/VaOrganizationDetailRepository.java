
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.repository;

import in.gov.gem.app.service.core.repository.BaseRepository;


import in.gov.gem.app.vendorassessment.domain.entity.VaOrganizationDetailEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * The interface Va organization detail repository.
 */
@Repository
public interface VaOrganizationDetailRepository extends BaseRepository<VaOrganizationDetailEntity, Long>
{
    /**
     * Find by va master fk list.
     *
     * @param vaMasterFk the va master fk
     * @return the list
     */
    List<VaOrganizationDetailEntity> findByVaMasterFk(Long vaMasterFk);

    /**
     * Find by va master fk page.
     *
     * @param vaOrganizationDetailFk the va organization detail fk
     * @param pageRequest            the page request
     * @return the page
     */
    Page<VaOrganizationDetailEntity> findByVaMasterFk(Long vaOrganizationDetailFk, Pageable pageRequest);

    /**
     * Find by va master fk and authorization type lookup va organization detail entity.
     *
     * @param id                the id
     * @param authorizationType the authorization type
     * @return the va organization detail entity
     */
    VaOrganizationDetailEntity findByVaMasterFkAndAuthorizationTypeLookup(long id, String authorizationType);
}
