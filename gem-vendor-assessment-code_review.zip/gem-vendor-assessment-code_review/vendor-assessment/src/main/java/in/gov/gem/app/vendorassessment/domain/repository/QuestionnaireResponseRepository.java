package in.gov.gem.app.vendorassessment.domain.repository;



import in.gov.gem.app.vendorassessment.dto.response.QuestionnaireResponse;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Component
public class QuestionnaireResponseRepository {
    private final Map<Long, QuestionnaireResponse> responses = new ConcurrentHashMap<>();
    private final AtomicLong idCounter = new AtomicLong();

    public QuestionnaireResponse save(QuestionnaireResponse response) {
        if (response.getId() == null) {
            response.setId(idCounter.incrementAndGet());
        }
        responses.put(response.getId(), response);
        return response;
    }

    public Optional<QuestionnaireResponse> findById(Long id) {
        return Optional.ofNullable(responses.get(id));
    }

    public List<QuestionnaireResponse> findByCategoryId(Long categoryId) {
        return responses.values().stream()
                .filter(r -> r.getCategoryId() != null && r.getCategoryId().equals(categoryId))
                .collect(Collectors.toList());
    }

    public Optional<QuestionnaireResponse> findByCategoryIdAndQuestionId(Long categoryId, Long questionId) {
        return responses.values().stream()
                .filter(r -> r.getCategoryId() != null && r.getCategoryId().equals(categoryId) &&
                        r.getQuestionId() != null && r.getQuestionId().equals(questionId))
                .findFirst();
    }

    public void deleteById(Long id) {
        responses.remove(id);
    }
}