
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.transformer;


import in.gov.gem.app.vendorassessment.client.IMdmClient;



import in.gov.gem.app.vendorassessment.dto.response.CountryResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.FetchLocationResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.LocationListResponseDTO;

import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.utility.CustomLoggerFactory;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * The type Mdm transformer.
 */
@Component
@AllArgsConstructor
public class MdmTransformer
{
  private IMdmClient iMdmClient;

  private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(MdmTransformer.class);

  /**
   * Gets location list from mdm.
   *
   * @param paginationParams the pagination params
   * @param locationCode     the location code
   * @param languageCode     the language code
   * @return the location list from mdm
   */
  public List<FetchLocationResponseDTO> getLocationListFromMdm(PaginationParams paginationParams,
                                                               String locationCode, String languageCode)
  {

    ResponseEntity<PageableApiResponse<List<LocationListResponseDTO>>> response =
      iMdmClient.getLocationList(paginationParams, locationCode, languageCode);

    List<LocationListResponseDTO> locationList = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(PageableApiResponse::getData)
      .orElse(Collections.emptyList());

    if (locationList.isEmpty()) {
      log.info("No Location details found for the given parameters.");
      return Collections.emptyList(); // Return an empty list if no data is available
    }

    return locationList.stream().map(itr -> FetchLocationResponseDTO.builder()
        .dataCode(itr.getDataCode())
        .district(itr.getDistrict())
        .pinCode(itr.getPinCode())
        .state(itr.getState())
        .subDistrict(itr.getSubDistrict())
        .village(itr.getVillage())
        .country(itr.getCountry())
        .build())
      .collect(Collectors.toList());
  }

  /**
   * Fetch country list list.
   *
   * @param paginationParams the pagination params
   * @param languageCode     the language code
   * @return the list
   */
  public List<CountryResponseDTO> fetchCountryList(PaginationParams paginationParams, String languageCode)
  {

    ResponseEntity<PageableApiResponse<List<CountryResponseDTO>>> response = iMdmClient.fetchCountryList(paginationParams, languageCode);

    List<CountryResponseDTO> locationList = Optional.ofNullable(response)
            .map(ResponseEntity::getBody)
            .map(PageableApiResponse::getData)
            .orElse(Collections.emptyList())
            .stream()
            .filter(c -> "C_001".equals(c.getDataCode()) || "C_002".equals(c.getDataCode()))
            .collect(Collectors.toList());

    if (locationList.isEmpty()) {
      log.info("No Country found for the given parameters.");
      return Collections.emptyList(); // Return an empty list if no data is available
    }

    return locationList.stream().map(itr -> CountryResponseDTO.builder()
                    .countryName(itr.getCountryName())
                    .countryIsdCode(itr.getCountryIsdCode())
                    .dataCode(itr.getDataCode())
                    .build())
            .collect(Collectors.toList());

  }
}
