
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;


import in.gov.gem.app.vendorassessment.dto.request.VendorAssessmentNewRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.InitiateResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VendorAssessmentIdResponseDTO;

import org.springframework.stereotype.Component;

/**
 * The interface Initiate assessment facade.
 */
@Component

public interface IInitiateAssessmentFacade {


  /**
   * Initiate vendor assessment initiate response dto.
   *
   * @param request the request
   * @return the initiate response dto
   */
  public InitiateResponseDTO initiateVendorAssessment(VendorAssessmentNewRequestDTO request);

  /**
   * Fetch brand oem osp dashboard status boolean.
   *
   * @param id the id
   * @return the boolean
   */
  public boolean fetchBrandOemOspDashboardStatus(Long id) ;


  /**
   * Fetch supplementary va id vendor assessment id response dto.
   *
   * @return the vendor assessment id response dto
   */
  public VendorAssessmentIdResponseDTO fetchSupplementaryVAId();
}


