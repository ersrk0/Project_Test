
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;


import in.gov.gem.app.vendorassessment.dto.request.AuthorizeDetailRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ContractManufacturerRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.LookupRequestDTO;

import in.gov.gem.app.vendorassessment.dto.response.*;
import in.gov.gem.app.vendorassessment.facade.ISaveAssessOptionFacade;
import in.gov.gem.app.vendorassessment.service.ISaveAssessOptionService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * The type Save assess option facade.
 */
@Component
@AllArgsConstructor
public class SaveAssessOptionFacade implements ISaveAssessOptionFacade {

    private ISaveAssessOptionService saveLookupOptionService;

    public SaveAssessResponseDTO saveOption(LookupRequestDTO lookupRequestDto, boolean skip) {
        return saveLookupOptionService.saveOption(lookupRequestDto,skip);
    }


    public IdentifyRegistrationResponseDTO identifyRegistration() {
        return saveLookupOptionService.identifyRegistration();
    }

    public AuthorizeResponseDTO authorizeDetailSave(AuthorizeDetailRequestDTO authorizeDetailDTO) {
        return saveLookupOptionService.authorizeDetailSave(authorizeDetailDTO);
    }

    public ContractManufacturerResponseDTO contractManufacturerDetailSave(ContractManufacturerRequestDTO contractManufacturerDTO) {
        return saveLookupOptionService.contractManufacturerDetailSave(contractManufacturerDTO);
    }

    public ContractManufacturerRequestDTO getContractManufacturerDetail(long id) {
        return saveLookupOptionService.getContractManufacturerDetail(id);
    }

    public AuthorizeDetailRequestDTO getAuthorizeDetailSave(long id) {
        return saveLookupOptionService.getAuthorizeDetailSave(id);
    }

    public AssessResponseDTO getAssess(long id) {
        return saveLookupOptionService.getAssess(id);
    }
}
