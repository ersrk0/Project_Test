
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import in.gov.gem.app.service.dto.APIResponse;

import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.utility.CustomLoggerFactory;

import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.dto.response.*;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


/**
 * The type Profile client transformer.
 */
@Component
@AllArgsConstructor
public class ProfileClientTransformer
{

  private final ISellerClient iSellerClient;

  private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(ProfileClientTransformer.class);

  /**
   * The Mapper.
   */
  ObjectMapper mapper = new ObjectMapper();

  /**
   * Gets profile from seller.
   *
   * @return the profile from seller
   * @throws JsonProcessingException the json processing exception
   */
  public ProfileSellerResponseDTO getProfileFromSeller() throws JsonProcessingException {
    ResponseEntity<APIResponse<ProfileDetailsResponseDTO>> response = iSellerClient.getProfile();

    Optional<ProfileDetailsResponseDTO> profileOpt = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(APIResponse::getData);

    if (profileOpt.isEmpty()) {
      log.info("No Organization details found for the given parameters.");
      return new ProfileSellerResponseDTO(); // Handle the empty list case appropriately
    }

    ProfileDetailsResponseDTO data = profileOpt.get();
    PanResponseResponseDTO panFromSeller = getPanFromSeller();

    String json_SubOrganizationType = mapper.writeValueAsString(data.getSubOrganizationType());
    JsonNode node_SubOrganizationType = mapper.readTree(json_SubOrganizationType);

    String json_OrganizationType = mapper.writeValueAsString(data.getOrganizationType());
    JsonNode node_OrganizationType = mapper.readTree(json_OrganizationType);

    ProfileSellerResponseDTO.ProfileSellerResponseDTOBuilder builder = ProfileSellerResponseDTO.builder()
      .id(data.getId())
      .organizationName(data.getOrganizationName())
      .organizationSubType(node_SubOrganizationType)
      .pan(panFromSeller.getPanofSeller())
      .organizationType(node_OrganizationType);

    Optional.ofNullable(data.getOrganizationType())
      .map(orgType -> orgType.getDescription())
      .ifPresent(description -> {
        if ("Company".equalsIgnoreCase(description)) {
          builder.CINANDFCRN(data.getEntityNumber());
        } else if ("Firm".equalsIgnoreCase(description)) {
          builder.LLPINANDFLLPIN(data.getEntityNumber());
        }
      });

    return builder.build();
  }

  /**
   * Gets pan from seller.
   *
   * @return the pan from seller
   */
  public PanResponseResponseDTO getPanFromSeller()
  {
    ResponseEntity<APIResponse<BusinessPanDetailsResponseDTO>> response = iSellerClient.getPan();

    Optional<BusinessPanDetailsResponseDTO> profileOpt = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(APIResponse::getData);

    if (profileOpt.isEmpty()) {
      log.info("No PAN details found for the given parameters.");
      return new PanResponseResponseDTO(); // Handle the empty case appropriately
    }

    BusinessPanDetailsResponseDTO data = profileOpt.get();
    return PanResponseResponseDTO.builder()
      .panofSeller(data.getPan())
      .build();
  }

  /**
   * Gets tan from seller.
   *
   * @param paginationParams the pagination params
   * @return the tan from seller
   */
  public List<TanResponseDTO> getTanFromSeller(PaginationParams paginationParams) {
    ResponseEntity<APIResponse<List<TanDetailsVOResponseDTO>>> response = iSellerClient.getTan(paginationParams);

    List<TanDetailsVOResponseDTO> profileOpt = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(APIResponse::getData)
      .orElse(Collections.emptyList());

    if (profileOpt.isEmpty()) {
      log.info("No Tan found for the given parameters.");
      return Collections.emptyList(); // Return an empty list instead of a single empty DTO
    }

    // Convert `List<TanDetailsVO>` into `List<TanResponse>`
    return profileOpt.stream().map(tanDetailsVO -> TanResponseDTO.builder()
        .Tan1(tanDetailsVO.getTan())
        .build())
      .collect(Collectors.toList());
  }

}
