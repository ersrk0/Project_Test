
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.messaging.producer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.gov.gem.app.client.avro.AssessmentValidityEvent;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.messaging.kafkaservice.KafkaProducer;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.utility.CustomLoggerFactory;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.dto.response.SchedulerResponseDTO;
import in.gov.gem.app.vendorassessment.transformer.BankTransformer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * Producer for Vendor Assessment Validity Events
 */
@Service
@RequiredArgsConstructor
public class VendorAssessmentValidityEventProducer {

    private final KafkaProducer<AssessmentValidityEvent> kafkaProducer;
    @Value("${kafka.topics.vendor-assessment-validity:vendor-assessment-validity}")
    private String topicName;
    private final MessageUtility messageUtility;

    private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(VendorAssessmentValidityEventProducer.class);


    /**
     * Publishes vendor assessment validity event to Kafka
     */
    public void publishAssessmentValidityEvent(VendorAssessmentValidityEvent event) throws JsonProcessingException {
        try {
            log.info("Publishing vendor assessment validity event for vendor: {} with assessment: {}",
                    event.getVendorId(), event.getAssessmentId());
            // Convert event to JSON string
//            String eventJson = objectMapper.writeValueAsString(event);
            AssessmentValidityEvent assessmentValidityEvent = AssessmentValidityEvent.newBuilder()
                    .setVendorId(event.getVendorId())
                    .setAssessmentId(event.getAssessmentId())
                    .setValidityEndDate(event.getValidityEndDate() != null ? event.getValidityEndDate().toString() : null)
                    .setExpiryWithinMonths(event.getExpiryWithinMonths())
                    .setEventType(event.getEventType())
                    .setTriggeredBy(event.getTriggeredBy())
                    .setRemarks(event.getRemarks())
                    .build();
            // Send the event to Kafka topic

            kafkaProducer.sendMessage(assessmentValidityEvent, topicName, event.getEventType());
        } catch (Exception ex) {
            throw new ServiceException(MessageConstant.REQUIRED_KAFKA_PROPERTY_FALSE,
                    messageUtility.getMessage(MessageConstant.REQUIRED_KAFKA_PROPERTY_FALSE), ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I);
        }
    }

    /**
     * Publishes assessment expiry event
     */
    public void publishAssessmentExpiryEvent(SchedulerResponseDTO schedulerResponseDTO,
                                             VendorAssessmentValidityEvent.AssessmentStatus status) throws JsonProcessingException {
        VendorAssessmentValidityEvent event = new VendorAssessmentValidityEvent();
        event.setVendorId(schedulerResponseDTO.getVendorId());
        event.setAssessmentId(schedulerResponseDTO.getVendorAssessmentId());
        event.setStatus(status);
        LocalDateTime localDateTime = LocalDateTime.ofInstant(schedulerResponseDTO.getValidUpTo(), ZoneId.systemDefault());
        event.setValidityEndDate(localDateTime);
        event.setExpiryWithinMonths(schedulerResponseDTO.getExpiryWithinMonths());
        event.setEventType("EXPIRY_UPDATE");
        event.setTriggeredBy("SYSTEM");
        event.setRemarks("Assessment validity expired");

        publishAssessmentValidityEvent(event);
    }

}