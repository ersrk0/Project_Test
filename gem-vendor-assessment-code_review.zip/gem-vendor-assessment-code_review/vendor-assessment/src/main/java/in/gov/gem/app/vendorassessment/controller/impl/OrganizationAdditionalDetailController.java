
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;


import in.gov.gem.app.service.dto.APIResponse;

import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.controller.IOrganizationAdditionalDetailController;
import in.gov.gem.app.vendorassessment.facade.IAdditionalOrganisationDetailFacade;
import jakarta.validation.Valid;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;

import in.gov.gem.app.vendorassessment.dto.request.AddBodDocumentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.AdditionalDocumentResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.DocumentDetailResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.SaveAdditionalDocumentResponseDTO;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * The type Organization additional detail controller.
 */
@RestController
public class OrganizationAdditionalDetailController extends BaseParentController implements IOrganizationAdditionalDetailController
{

  private final IAdditionalOrganisationDetailFacade additionalOrganisationDetailFacade;

  /**
   * Instantiates a new Organization additional detail controller.
   *
   * @param additionalOrganisationDetailFacade the additional organisation detail facade
   */
  public OrganizationAdditionalDetailController(IAdditionalOrganisationDetailFacade additionalOrganisationDetailFacade) {
    this.additionalOrganisationDetailFacade = additionalOrganisationDetailFacade;
  }

  @Override
  public ResponseEntity<APIResponse<Object>> additionaldocuments(@RequestParam String lookupCode)
  {
    String descriptionByNameOrCode =  additionalOrganisationDetailFacade.getAdditionalDocumentQuestion(lookupCode);

    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.ADDITIONAL_DEBARRED_QUESTION_SUCCESS)
      .data(descriptionByNameOrCode)
      .build());

  }

  @Override
  public ResponseEntity<APIResponse<Object>> addDocument(@RequestBody AddBodDocumentRequestDTO request) {
    SaveAdditionalDocumentResponseDTO response= additionalOrganisationDetailFacade.addBodDocument(request);
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.DOCUMENT_ADDED_SUCCESS)
      .data(response)
      .build());
  }

  @Override
  public ResponseEntity<byte[]> exportUsersToExcel(@RequestBody List<AdditionalDocumentResponseDTO> bodDocumentResponses) {
    return additionalOrganisationDetailFacade.exportToExcel(bodDocumentResponses);
  }

  @Override
  public ResponseEntity<APIResponse<Object>> deleteDocument(@RequestParam Long vaMasterFk, @RequestParam String docName) {
    additionalOrganisationDetailFacade.deleteBodDocument(vaMasterFk, docName);
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.DOCUMENT_DELETE_SUCCESS)
      .data(null)
      .build());

  }

  @Override
  public ResponseEntity<PageableApiResponse<List<DocumentDetailResponseDTO>>> getAdditionalDocuments(
    @RequestParam Long vaMasterId,
    @Valid @ModelAttribute PaginationParams paginationParams) {

    Page<DocumentDetailResponseDTO> pageResponse = additionalOrganisationDetailFacade.ByVaMasterFk(vaMasterId, paginationParams);

    return ResponseEntity.ok().body(PageableApiResponse.<List<DocumentDetailResponseDTO>>pageableApiResponseBuilder()
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.DOCUMENT_FETCHED_SUCCESS)
      .msId(ApplicationConstant.MSID)
      .data(pageResponse.getContent())
      .currentPage(pageResponse.getNumber())
      .totalPages(pageResponse.getTotalPages())
      .currentElements(pageResponse.getNumberOfElements())
      .hasNext(pageResponse.hasNext())
      .build());
  }

}
