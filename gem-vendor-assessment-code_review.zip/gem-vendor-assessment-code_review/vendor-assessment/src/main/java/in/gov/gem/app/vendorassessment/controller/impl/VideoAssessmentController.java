
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;


import in.gov.gem.app.vendorassessment.controller.IVideoAssessmentController;
import in.gov.gem.app.vendorassessment.facade.IVideoAssessmentFacade;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

;

/**
 * The type Video assessment controller.
 */
@RestController
@AllArgsConstructor
public class VideoAssessmentController extends BaseParentController implements IVideoAssessmentController {

  private IVideoAssessmentFacade videoAssessmentFacade;

  public ResponseEntity<APIResponse<Object>> getInstructions(@RequestParam String sellerId) {

    Object data=videoAssessmentFacade.getInstructions(sellerId);
    return ResponseEntity.ok().body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.FETCH_MESSAGE)
            .data(data)
            .build());
  }

  public ResponseEntity<APIResponse<Object>> getAppDownloadLink() {
    Object data= videoAssessmentFacade.getAppDownloadLink();
    return ResponseEntity.ok().body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.FETCH_MESSAGE)
            .data(data)
            .build());
  }

  public ResponseEntity<APIResponse<Object>> fetchScheduleAssessment() {
    Object date= videoAssessmentFacade.fetchScheduleAssessment();
    return ResponseEntity.ok().body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.FETCH_MESSAGE)
            .data(date)
            .build());
  }
}

