
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.dto.request.ExportDTORequestDTO;

import in.gov.gem.app.vendorassessment.dto.response.OrganizationDetailsResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VendorDashboardDTOResponseDTO;
import in.gov.gem.app.vendorassessment.facade.IFileFacade;
import in.gov.gem.app.vendorassessment.service.IFileService;
import in.gov.gem.app.vendorassessment.service.IVendorDashboardService;
import lombok.AllArgsConstructor;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;


/**
 * The type File facade.
 */
@Component
@AllArgsConstructor
public class FileFacade implements IFileFacade {

    private IFileService fileService;

    private final MessageUtility  messageUtility;

    private final ISellerClient iSellerClient;

    private IVendorDashboardService vendorDashboardService;


    public ResponseEntity<byte[]> exportUsersToExcel(ExportDTORequestDTO vendorDashboardDTOS, boolean all) {
        ResponseEntity<APIResponse<OrganizationDetailsResponseDTO>> organizationDetails = iSellerClient.getOrganizationDetails();

        OrganizationDetailsResponseDTO organizationDetailsResponseDTO = null;
        if (organizationDetails == null || organizationDetails.getBody() == null) {
            throw new ServiceException(
              MessageConstant.UNEXPECTED_ERROR,
              messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.I
            );
        }
        APIResponse<OrganizationDetailsResponseDTO> body = organizationDetails.getBody();
        if (body != null && body.getData() != null) {
            organizationDetailsResponseDTO = body.getData();
        }

        Long sellerId = null;
        if (organizationDetailsResponseDTO != null) {
            sellerId = organizationDetailsResponseDTO.getGemPvtOrgId();
        }
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Assessment_report");

            // Header
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("id");
            headerRow.createCell(1).setCellValue("vaId");
            headerRow.createCell(2).setCellValue("status");
            headerRow.createCell(3).setCellValue("subStatus");
            headerRow.createCell(4).setCellValue("assessedAs");
            headerRow.createCell(5).setCellValue("categoryCount");
            headerRow.createCell(6).setCellValue("assessedBy");
            headerRow.createCell(7).setCellValue("validUpTo");
            headerRow.createCell(8).setCellValue("submittedOn");
            headerRow.createCell(9).setCellValue("actions");

            // Data
            int rowIdx = 1;
            if (all || vendorDashboardDTOS == null) {
                List<VendorDashboardDTOResponseDTO> allVendorAssessments = vendorDashboardService.getAllVendorAssessmentsWithouPage(sellerId);
                for (VendorDashboardDTOResponseDTO vendorDashboardDTO : allVendorAssessments) {
                    rowIdx = populateRow(sheet, rowIdx, vendorDashboardDTO);
                }
            } else {
                List<Long> ids = vendorDashboardDTOS.getIds();
                for (Long id : ids) {
                    VendorDashboardDTOResponseDTO vendorDashboardDTO = vendorDashboardService.getVendorAssessment(id);
                    rowIdx = populateRow(sheet, rowIdx, vendorDashboardDTO);
                }
            }

            workbook.write(out);
            byte[] excelData = out.toByteArray();
            return ResponseEntity.ok()
              .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Assessment_report.xlsx")
              .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
              .body(excelData);

        } catch (IOException e) {
            throw new ServiceException(
              MessageConstant.UNEXPECTED_ERROR,
              messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.I
            );
        }
    }

    private int populateRow(Sheet sheet, int rowIdx, VendorDashboardDTOResponseDTO vendorDashboardDTO) {
        Row row = sheet.createRow(rowIdx++);
        row.createCell(0).setCellValue(vendorDashboardDTO.getId() != null ? vendorDashboardDTO.getId().toString() : "");
        row.createCell(1).setCellValue(vendorDashboardDTO.getVaId() != null ? vendorDashboardDTO.getVaId() : "");
        row.createCell(2).setCellValue(vendorDashboardDTO.getStatus() != null ? vendorDashboardDTO.getStatus() : "");
        row.createCell(3).setCellValue(vendorDashboardDTO.getSubStatus() != null ? vendorDashboardDTO.getSubStatus() : "");
        row.createCell(4).setCellValue(vendorDashboardDTO.getAssessedAs() != null ? vendorDashboardDTO.getAssessedAs() : "");
        row.createCell(5).setCellValue(vendorDashboardDTO.getCategoryCount() != null ? vendorDashboardDTO.getCategoryCount() : 0);
        row.createCell(6).setCellValue(vendorDashboardDTO.getAssessedBy() != null ? vendorDashboardDTO.getAssessedBy() : "");
        row.createCell(7).setCellValue(vendorDashboardDTO.getValidUpTo() != null ? vendorDashboardDTO.getValidUpTo().toString() : "");
        row.createCell(8).setCellValue(vendorDashboardDTO.getSubmittedOn() != null ? vendorDashboardDTO.getSubmittedOn().toString() : "");

        List<String> actions = vendorDashboardDTO.getActions();
        if (actions != null && !actions.isEmpty()) {
            StringBuilder actionsString = new StringBuilder();
            for (String action : actions) {
                actionsString.append(action).append(", ");
            }
            if (!actionsString.isEmpty()) {
                actionsString.setLength(actionsString.length() - 2);
            }
            row.createCell(9).setCellValue(actionsString.toString());
        } else {
            row.createCell(9).setCellValue("");
        }
        return rowIdx;
    }
}
