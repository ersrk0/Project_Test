
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.vendorassessment.client.IOtpServiceClient;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.dto.request.*;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseResenDResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseSendResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseValidateResponseDTO;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.facade.IIAMFacade;
import in.gov.gem.app.vendorassessment.facade.IOtpServiceFacade;
import in.gov.gem.app.vendorassessment.service.impl.OtpServiceadditionalService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * The type Otp service facade.
 */
@Component
@AllArgsConstructor
public class OtpServiceFacade implements IOtpServiceFacade
{
  private final IOtpServiceClient client ;
  private final OtpServiceadditionalService otpServiceadditionalService;
  private final IIAMFacade iamTransformer;

  @Override
  public ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> SentOtpViaEmail(AddEmailRequestDTO sendOtpRequestDto)
  {
    return otpServiceadditionalService.SentOtpViaEmail(sendOtpRequestDto);
  }

  @Override
  public ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> ValidateOtpViaEmail(
    OtpValidationRequestDTO OtpValidationRequestDTO)
  {
    AddEmailRequestDTO addEmailDto = AddEmailRequestDTO.builder()
      .emailId(OtpValidationRequestDTO.getEmail())
      .build();

    ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> dataResponse=
      otpServiceadditionalService.ValidateOtpViaEmail(OtpValidationRequestDTO);

    boolean isOtpValidated = Optional.ofNullable(dataResponse.getBody())
      .map(APIResponse::getData)
      .map(OtpResponseValidateResponseDTO::getOtpValidated)
      .orElse(false);

    if (dataResponse.getStatusCode() != null && dataResponse.getStatusCode().is2xxSuccessful() && isOtpValidated) {
      iamTransformer.addEmail("eng", addEmailDto);
    }

    return dataResponse;
  }


  @Override
  public ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> ResendOtpViaEmail(
    OtpRegenerateRequestDTO otpRegenerateRequestDTO)
  {
    return otpServiceadditionalService.ResendOtpViaEmail(otpRegenerateRequestDTO);

  }

  @Override
  public ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> SentOtpViaMobile(AddMobileRequestDTO sendOtpRequestDto) {
    return otpServiceadditionalService.SentOtpViaMobile(sendOtpRequestDto);
  }

  @Override
  public ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> ValidateOtpViaMobile(
    MobileOtpValidationRequestDTO OtpValidationRequestDTO) {

    ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> dataResponse= otpServiceadditionalService.ValidateOtpViaMobile(OtpValidationRequestDTO);
    AddMobileRequestDTO addMobile = AddMobileRequestDTO.builder()
      .mobileNumber(OtpValidationRequestDTO.getMobile())
      .build();

    boolean isOtpValidated = Optional.ofNullable(dataResponse.getBody())
      .map(APIResponse::getData)
      .map(OtpResponseValidateResponseDTO::getOtpValidated)
      .orElse(false);

    if (dataResponse.getStatusCode() != null && dataResponse.getStatusCode().is2xxSuccessful() && isOtpValidated) {
      iamTransformer.addMobile("eng", addMobile);
    }
    return dataResponse;
  }


  @Override
  public ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> ResendOtpViaMobile(
    OtpRegenerateRequestDTO otpRegenerateRequestDTO)
  {
    OtpRegenerateRequestDTO regenerate= OtpRegenerateRequestDTO.builder()
      .deliveryChannel(ApplicationConstant.OTP_PREFERENCE_MOBILE)
      .referenceId(otpRegenerateRequestDTO.getReferenceId())
      .build();

    return client.regenerateOtp(regenerate);

  }

}
