
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service;

import in.gov.gem.app.vendorassessment.dto.request.AuthorizeDetailRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ContractManufacturerRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.LookupRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.*;

/**
 * The interface Save assess option service.
 */
public interface ISaveAssessOptionService {


  /**
   * Save option save assess response dto.
   *
   * @param lookupRequestDto the lookup request dto
   * @param skip             the skip
   * @return the save assess response dto
   */
  SaveAssessResponseDTO saveOption(LookupRequestDTO lookupRequestDto, boolean skip);

  /**
   * Gets option.
   *
   * @param vaNumber the va number
   * @return the option
   */
  SaveAssessResponseDTO getOption(String vaNumber);

  /**
   * Identify registration identify registration response dto.
   *
   * @return the identify registration response dto
   */
  IdentifyRegistrationResponseDTO identifyRegistration();

  /**
   * Authorize detail save authorize response dto.
   *
   * @param authorizeDetailDTO the authorize detail dto
   * @return the authorize response dto
   */
  AuthorizeResponseDTO authorizeDetailSave(AuthorizeDetailRequestDTO authorizeDetailDTO);

  /**
   * Contract manufacturer detail save contract manufacturer response dto.
   *
   * @param contractManufacturerDTO the contract manufacturer dto
   * @return the contract manufacturer response dto
   */
  ContractManufacturerResponseDTO contractManufacturerDetailSave(ContractManufacturerRequestDTO contractManufacturerDTO);

  /**
   * Gets assess.
   *
   * @param id the id
   * @return the assess
   */
  AssessResponseDTO getAssess(long id);

  /**
   * Gets authorize detail save.
   *
   * @param id the id
   * @return the authorize detail save
   */
  AuthorizeDetailRequestDTO getAuthorizeDetailSave(long id);

  /**
   * Gets contract manufacturer detail.
   *
   * @param id the id
   * @return the contract manufacturer detail
   */
  ContractManufacturerRequestDTO getContractManufacturerDetail(long id);
}
