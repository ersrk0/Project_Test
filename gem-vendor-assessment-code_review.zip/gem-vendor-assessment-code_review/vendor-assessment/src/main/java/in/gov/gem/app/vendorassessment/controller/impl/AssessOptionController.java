
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;


import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;

import in.gov.gem.app.vendorassessment.dto.request.AuthorizeDetailRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ContractManufacturerRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.LookupRequestDTO;

import in.gov.gem.app.vendorassessment.controller.IAssessOptionController;
import in.gov.gem.app.vendorassessment.dto.response.*;
import in.gov.gem.app.vendorassessment.facade.ISaveAssessOptionFacade;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * The type Assess option controller.
 */
@RestController
@AllArgsConstructor
public class AssessOptionController extends BaseParentController implements IAssessOptionController {

    private ISaveAssessOptionFacade SaveLookupOptionFacade;

    public ResponseEntity<APIResponse<Object>> saveLookupValue(@RequestBody LookupRequestDTO lookupRequestDto, @RequestParam(value="skip",defaultValue="false") boolean skip) {

        SaveAssessResponseDTO saveAssessResponseDTO = SaveLookupOptionFacade.saveOption(lookupRequestDto,skip);

        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.CREATED_MESSAGE)
                .data(saveAssessResponseDTO)
                .build());
    }

    public ResponseEntity<APIResponse<Object>> authorizeDetail(@RequestBody AuthorizeDetailRequestDTO authorizeDetailDTO) {

        AuthorizeResponseDTO saveAssessResponseDTO = SaveLookupOptionFacade.authorizeDetailSave(authorizeDetailDTO);

        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.CREATED_MESSAGE)
                .data(saveAssessResponseDTO)
                .build());
    }

    public ResponseEntity<APIResponse<Object>> contractManufacturerDetail(@RequestBody ContractManufacturerRequestDTO contractManufacturerDTO) {

        ContractManufacturerResponseDTO contractManufacturerResponseDTO = SaveLookupOptionFacade.contractManufacturerDetailSave(contractManufacturerDTO);

        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.CREATED_MESSAGE)
                .data(contractManufacturerResponseDTO)
                .build());
    }



    public ResponseEntity<APIResponse<Object>> identifyRegistration(){
        IdentifyRegistrationResponseDTO available = SaveLookupOptionFacade.identifyRegistration();
        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.FETCH_MESSAGE)
                .data(available)
                .build());
    }


    public ResponseEntity<APIResponse<Object>> getContractManufacturerDetail(@RequestParam long id) {

        ContractManufacturerRequestDTO contractManufacturerResponseDTO = SaveLookupOptionFacade.getContractManufacturerDetail(id);

        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.FETCH_MESSAGE)
                .data(contractManufacturerResponseDTO)
                .build());
    }


    public ResponseEntity<APIResponse<Object>> getAuthorizeDetail(@RequestParam long id) {

        AuthorizeDetailRequestDTO authorizeDetailDTO = SaveLookupOptionFacade.getAuthorizeDetailSave(id);

        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.FETCH_MESSAGE)
                .data(authorizeDetailDTO)
                .build());
    }


    public ResponseEntity<APIResponse<Object>> getAssess(@RequestParam long id) {

        AssessResponseDTO assessResponseDTO = SaveLookupOptionFacade.getAssess(id);

        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.FETCH_MESSAGE)
                .data(assessResponseDTO)
                .build());
    }

}
