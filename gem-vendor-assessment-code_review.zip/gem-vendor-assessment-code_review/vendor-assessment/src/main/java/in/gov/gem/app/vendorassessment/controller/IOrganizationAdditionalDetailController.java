
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.request.AddBodDocumentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.AdditionalDocumentResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.DocumentDetailResponseDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Provides APIs for managing additional organization documents and related details.

 */
@Tag(name = "Organization Additional Detail", description = "APIs for managing additional organization documents and details")
@RestController
@RequestMapping("/v1")
public interface IOrganizationAdditionalDetailController
{

  /**
   * Fetches additional document questions by lookup code.
   *
   * @param lookupCode the lookup code
   * @return the API response with additional document questions
   */
  @Operation(
    summary = "Get Additional Document Questions",
    description = "Fetches additional document questions by lookup code.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "lookupCode", description = "Lookup code", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/additional/question")
  ResponseEntity<APIResponse<Object>> additionaldocuments(@RequestParam String lookupCode);

  /**
   * Adds a new document.
   *
   * @param request the add document request
   * @return the API response
   */
  @Operation(
    summary = "Add Document",
    description = "Adds a new document.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/add-document")
  ResponseEntity<APIResponse<Object>> addDocument(@RequestBody AddBodDocumentRequestDTO request);

  /**
   * Exports user documents to an Excel file.
   *
   * @param bodDocumentResponses the list of additional document responses
   * @return the Excel file as a byte array
   */
  @Operation(
    summary = "Export Users to Excel",
    description = "Exports user documents to an Excel file.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", description = "Excel file generated successfully")
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/report")
  ResponseEntity<byte[]> exportUsersToExcel(@RequestBody List<AdditionalDocumentResponseDTO> bodDocumentResponses);

  /**
   * Deletes a document by VA master FK and document name.
   *
   * @param vaMasterFk the VA master FK
   * @param docName    the document name
   * @return the API response
   */
  @Operation(
    summary = "Delete Document",
    description = "Deletes a document by VA master FK and document name.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaMasterFk", description = "VA Master FK", in = ParameterIn.QUERY, required = true)
  @Parameter(name = "docName", description = "Document name", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @DeleteMapping("/delete-document")
  ResponseEntity<APIResponse<Object>> deleteDocument(
    @RequestParam Long vaMasterFk,
    @RequestParam String docName
  );

  /**
   * Fetches uploaded additional documents with pagination.
   *
   * @param vaMasterId       the VA master ID
   * @param paginationParams pagination parameters
   * @return the pageable API response with document details
   */
  @Operation(
    summary = "Get Uploaded Additional Documents",
    description = "Fetches uploaded additional documents with pagination.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaMasterId", description = "VA Master ID", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/uploaded-documents")
  ResponseEntity<PageableApiResponse<List<DocumentDetailResponseDTO>>> getAdditionalDocuments(
    @RequestParam Long vaMasterId,
    @Valid @ModelAttribute PaginationParams paginationParams
  );

}
 