/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.entity;

import in.gov.gem.app.vendorassessment.dto.enums.CategoryType;
import in.gov.gem.app.vendorassessment.dto.enums.VAStatus;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;


@Data
@EqualsAndHashCode
public class Category {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String name;
  private String reservedFor;
  private boolean isDownForBuyer;
  private String description;
  private Long parentId;
  private int level;
  private String type;
  private String section;
  private String vaId;

  private List<Category> children = new ArrayList<>();
  @Enumerated(EnumType.STRING)
  private VAStatus vaStatus;
  public Category(Category other) {
    // Copy fields from 'other' to 'this'
  }


  public Category(Long id, String name, String reservedFor, boolean isDownForBuyer
      , VAStatus vaStatus) {
    this.id = id;
    this.name = name;
    this.reservedFor = reservedFor;
    this.isDownForBuyer = isDownForBuyer;

    this.vaStatus = vaStatus;
  }
  public Category( Long id,String name,String description,Long parentId,int level, String type
  ) {
    this.id=id;
    this.name = name;
    this.description = description;
    this.parentId = parentId;
    this.level =level;
    this.type = type;
  }

  public Category(String name, String description) {
    this.name= name;
    this.description=description;
  }
  public Category(Long id,String name, Long parentId, int level, String type) {
    this.id = id;
    this.name= name;
    this.parentId=parentId;
    this.level=level;
    this.type=type;
  }

  public Category() {

  }

    public Category(Long syntheticParentId, String description) {
        this.parentId = syntheticParentId;
        this.description = description;
    }

  public Category(long id, String categoryA, String desc, Long parentId, int level, CategoryType categoryType) {
    this.id = id;
    this.name = categoryA;
    this.description = desc;
    this.parentId = parentId;
    this.level = level;
    this.type = categoryType.name();
  }

    public Category(long l, String electronics, String desc, Long o, Integer o1, String name) {
        this.id = l;
        this.name = electronics;
        this.description = desc;
        this.parentId = o;
        this.level = o1;
        this.type = name; // Assuming 'name' is the type here
    }

  public Category(Long newInternalCategoryId, Long newInternalParentId, String name, String vaId, String description, String type,int level) {
    this.id = newInternalCategoryId;
    this.parentId = newInternalParentId;
    this.name = name;
    this.vaId = vaId;
    this.description = description;
    this.type = type;
    this.level= level;

  }

  public Category(long l) {
    this.id = l;
  }

  public Category(long l, String laptops, String s, long l1, int i) {
    this.id = l;
    this.name = laptops;
    this.description = s;
    this.parentId = l1;
    this.level = i;
  }

  /**
   * Adds a child category to this category's children list.
   * @param child The child category to add.
   */
  public void addChild(Category child) {
    this.children.add(child);
  }

  /**
   * Clears the children list. Useful when rebuilding hierarchy.
   */
  public void clearChildren() {
    this.children.clear();
  }


// Getters and Setters
}
