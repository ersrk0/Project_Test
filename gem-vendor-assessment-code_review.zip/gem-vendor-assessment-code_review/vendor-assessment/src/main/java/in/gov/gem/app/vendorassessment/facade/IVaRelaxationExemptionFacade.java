
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;


import in.gov.gem.app.vendorassessment.domain.entity.VaRelaxationExemptionEntity;
import in.gov.gem.app.vendorassessment.dto.request.CommonVaDocumentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.*;
import org.springframework.data.domain.Page;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * Interface for the VaRelaxationExemptionFacade.
 * Provides a simplified interface for managing VA Relaxation Exemption entities,
 * abstracting away direct service interactions.
 */
public interface IVaRelaxationExemptionFacade {

  /**
   * Creates a new VA Relaxation Exemption.
   * @param commonVaDocumentRequest The request containing details for the exemption.
   * @param files List of files associated with the exemption.
   * @return The created exemption entity.
   */
  VaRelaxationExemptionEntity createRelaxationExemption(CommonVaDocumentRequestDTO commonVaDocumentRequest, List<MultipartFile> files);

  /**
   * Retrieves a VA Relaxation Exemption by its ID.
   * @param id The ID of the exemption to retrieve.
   * @return The exemption entity if found.
   * @throws RuntimeException if the exemption is not found.
   */
  VaRelaxationExemptionResponseDto getRelaxationExemptionById(Long id, String lookUpCode);

  /**
   * Updates an existing VA Relaxation Exemption.
   * @param id The ID of the exemption to update.
   * @param entity The entity with updated details.
   * @return The updated exemption entity.
   * @throws RuntimeException if the exemption is not found.
   */
  VaRelaxationExemptionEntity updateRelaxationExemption(Long id, CommonVaDocumentRequestDTO entity, List<MultipartFile> files);

  /**
   * Deletes a VA Relaxation Exemption by its ID.
   * @param id The ID of the exemption to delete.
   * @return true if the exemption was successfully deleted, false otherwise.
   */
  boolean deleteRelaxationExemption(Long id, String lookUpCode);

  /**
   * Retrieves a paginated list of VA Relaxation Exemptions.
   * @param pageResponse The pagination request containing page number and size.
   * @return A paginated response containing the exemptions.
   */
  Page<DocumentNewResponseDTO> convertToDocumentRes(Page<DocumentDetailResponseDTO> pageResponse) throws RuntimeException;

  CriteriaLicenseInfoResponseDTO getIssuingAuthorities(String lookUpCode);

  List<CriteriaTypeResponseDTO> checkEligibilityByFlag(boolean eligible);

  DraftEligibilityResponseDTO getDraftEligibility(Long vAId);
}
