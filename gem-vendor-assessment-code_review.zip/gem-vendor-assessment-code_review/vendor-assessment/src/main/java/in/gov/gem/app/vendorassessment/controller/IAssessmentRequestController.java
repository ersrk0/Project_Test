
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.request.AssessmentNewRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.AssessmentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OrganisationDetailsRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ReSendRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.MobileOtpValidationRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OTPValidateRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ManufacturingLocationDecisionRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.ResendOtpResponseDTO;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PutMapping;

/**
 * The interface Assessment request.
 */
@RestController
@RequestMapping("/v1/supplementaryAssessment")
public interface IAssessmentRequestController {

    /**
     * Gets organization details.
     *
     * @param vaId the va id
     * @return the organization details
     */
    @GetMapping("/organizationDetails")
    public ResponseEntity<APIResponse<OrganisationDetailsRequestDTO>> getOrganizationDetails(@RequestParam String vaId);

    /**
     * Create request response entity.
     *
     * @param requestDTO the request dto
     * @return the response entity
     */
    @PostMapping("/createAssessment")
    public ResponseEntity<APIResponse<AssessmentNewRequestDTO>> createRequest(@RequestBody AssessmentRequestDTO requestDTO);

    /**
     * Send otp email response entity.
     *
     * @param email the email
     * @return the response entity
     */
    @GetMapping("/send/emailOtp")
    public ResponseEntity<APIResponse<OtpResponseDTO>> sendOtpEmail(@Valid @RequestParam String email);

    /**
     * Resend otp email response entity.
     *
     * @param reSendRequestDTO the re send request dto
     * @return the response entity
     */
    @PostMapping("/resend/emailOtp")
    public ResponseEntity<APIResponse<ResendOtpResponseDTO>> resendOtpEmail(@Valid @RequestBody ReSendRequestDTO reSendRequestDTO);

    /**
     * Update mobile number response entity.
     *
     * @param vaId                          the va id
     * @param mobileOtpValidationRequestDTO the mobile otp validation request dto
     * @return the response entity
     */
    @PutMapping("/mobileNumber")
    public ResponseEntity<APIResponse<String>> updateMobileNumber(@RequestParam String vaId, @RequestBody MobileOtpValidationRequestDTO mobileOtpValidationRequestDTO);

    /**
     * Update email id response entity.
     *
     * @param vaId                  the va id
     * @param otpValidateRequestDTO the otp validate request dto
     * @return the response entity
     */
    @PutMapping("/emailId")
    public ResponseEntity<APIResponse<String>> updateEmailId(@RequestParam String vaId, @RequestBody OTPValidateRequestDTO otpValidateRequestDTO);

    /**
     * Update manufacturing location decision response entity.
     *
     * @param addNewLocation the add new location
     * @return the response entity
     */
    @PostMapping("/manufacturingLocationDecision")
    public ResponseEntity<APIResponse<ManufacturingLocationDecisionRequestDTO>> updateManufacturingLocationDecision(
            @RequestBody ManufacturingLocationDecisionRequestDTO addNewLocation);
}
