
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */
package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.dto.request.*;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseResenDResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseSendResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseValidateResponseDTO;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.controller.IAdditionalDetailsController;
import in.gov.gem.app.vendorassessment.facade.IOtpServiceFacade;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * The type Additional details controller.
 */
@RestController
@AllArgsConstructor
public class AdditionalDetailsController extends BaseParentController implements IAdditionalDetailsController {


  private final IOtpServiceFacade iOtpServiceFacade;

  @Override
  public ResponseEntity<APIResponse<Object>> sendOtpOnEmail(@Valid @RequestBody AddEmailRequestDTO addEmailDto,
                                                            @RequestHeader(value = "accept-language", required = false) String acceptLanguage) {

    ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> send = iOtpServiceFacade.SentOtpViaEmail(addEmailDto);

    OtpResponseSendResponseDTO responseData = null;
    if (send != null) {
      APIResponse<OtpResponseSendResponseDTO> body = send.getBody();
      if (body != null) {
        responseData = body.getData();
      }
    }
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.OTP_SENT_EMAIL_SUCESS)
      .data(responseData)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> verifytpOnEmail(@Valid @RequestBody OtpValidationRequestDTO profileOtpValidationRequestDTO,
                                                             @RequestHeader(value = "accept-language", required = false) String acceptLanguage) {

    ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> verify = iOtpServiceFacade.ValidateOtpViaEmail(profileOtpValidationRequestDTO);
    OtpResponseValidateResponseDTO responseData = null;
    if (verify != null) {
      APIResponse<OtpResponseValidateResponseDTO> body = verify.getBody();
      if (body != null) {
        responseData = body.getData();
      }
    }
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.OTP_VERIFY_EMAIL_SUCESS)
      .data(responseData)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> resendOtpOnEmail(@RequestBody OtpRegenerateRequestDTO otpRegenerateRequestDTO,
                                                              @RequestHeader(value = "accept-language", required = false) String acceptLanguage) {

    ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> resend = iOtpServiceFacade.ResendOtpViaEmail(otpRegenerateRequestDTO);


    OtpResponseResenDResponseDTO responseData = null;
    if (resend != null) {
      APIResponse<OtpResponseResenDResponseDTO> body = resend.getBody();
      if (body != null) {
        responseData = body.getData();
      }
    }
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.OTP_RESEND_SUCESS)
      .data(responseData)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> sendOtpOnMobile(@Valid @RequestBody AddMobileRequestDTO sendOtpRequestDto,
                                                             @RequestHeader(value = "accept-language", required = false) String acceptLanguage) {

    ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> send = iOtpServiceFacade.SentOtpViaMobile(sendOtpRequestDto);


    OtpResponseSendResponseDTO responseData = null;
    if (send != null) {
      APIResponse<OtpResponseSendResponseDTO> body = send.getBody();
      if (body != null) {
        responseData = body.getData();
      }
    }
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.OTP_SENT_MOBILE_SUCESS)
      .data(responseData)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> verifyotpOnMobile(@Valid @RequestBody MobileOtpValidationRequestDTO OtpValidationRequestDTO,
                                                               @RequestHeader(value = "accept-language", required = false) String acceptLanguage) {

    ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> verify = iOtpServiceFacade.ValidateOtpViaMobile(OtpValidationRequestDTO);


    OtpResponseValidateResponseDTO responseData = null;
    if (verify != null) {
      APIResponse<OtpResponseValidateResponseDTO> body = verify.getBody();
      if (body != null) {
        responseData = body.getData();
      }
    }
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.OTP_VERIFY_MOBILE_SUCESS)
      .data(responseData)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> resendOtpOnMobile(@RequestBody OtpRegenerateRequestDTO otpRegenerateRequestDTO,
                                                               @RequestHeader(value = "accept-language", required = false) String acceptLanguage) {

    ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> resend = iOtpServiceFacade.ResendOtpViaMobile(otpRegenerateRequestDTO);
    OtpResponseResenDResponseDTO responseData = null;
    if (resend != null) {
      APIResponse<OtpResponseResenDResponseDTO> body = resend.getBody();
      if (body != null) {
        responseData = body.getData();
      }
    }
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(ApplicationConstant.OTP_RESEND_SUCESS)
      .data(responseData)
      .build());
  }
}