
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.request.VendorAssessmentNewRequestDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Provides APIs for initiating and managing vendor assessments.
 */
@Tag(name = "Initiate Assessment", description = "APIs for initiating and managing vendor assessments")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/v1/initiate-assessment")
public interface IInitiateAssessmentController {
  /**
   * Initiates a new vendor assessment.
   *
   * @param request the vendor assessment request
   * @return the API response with assessment details
   */
  @Operation(
    summary = "Initiate Vendor Assessment",
    description = "Initiates a new vendor assessment.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/new")
  ResponseEntity<APIResponse<Object>> initiateVendorAssessment(
    @RequestBody VendorAssessmentNewRequestDTO request
  );

  /**
   * Fetches the supplementary vendor assessment ID.
   *
   * @return the API response with supplementary assessment ID
   */
  @Operation(
    summary = "Fetch Supplementary Assessment ID",
    description = "Fetches the supplementary vendor assessment ID.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/supplementary")
  ResponseEntity<APIResponse<Object>> fetchSupplementaryVAId();

  /**
   * Fetches the Brand-OEM/OSP dashboard status for a given ID.
   *
   * @param id the assessment ID
   * @return the API response with dashboard status
   */
  @Operation(
    summary = "Fetch Brand-OEM/OSP Dashboard Status",
    description = "Fetches the Brand-OEM/OSP dashboard status for a given ID.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "id", description = "Assessment ID", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/brand-oem-osp-dashboard")
  ResponseEntity<APIResponse<Object>> fetchBrandOemOspDashboardStatus(
    @RequestParam Long id
  );
}
 