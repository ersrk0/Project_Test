
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service;


import in.gov.gem.app.vendorassessment.dto.response.BODDocumentNewResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.BODDocumentResponseDTO;
import in.gov.gem.app.vendorassessment.domain.entity.VaDocumentDetailEntity;
import org.springframework.http.ResponseEntity;

import java.util.List;

/**
 * The interface Ibod service.
 */
public interface IBODService {

  /**
   * Gets required documents.
   *
   * @param vendorAssessmentId the vendor assessment id
   * @return the required documents
   */
  List<BODDocumentNewResponseDTO> getRequiredDocuments(Long vendorAssessmentId);

  /**
   * Gets my organisation documents.
   *
   * @param vaMasterId the va master id
   * @return the my organisation documents
   */
  List<BODDocumentResponseDTO> getMyOrganisationDocuments(Long vaMasterId);

  /**
   * Gets authorizing oem osp documents.
   *
   * @param vaMasterId the va master id
   * @return the authorizing oem osp documents
   */
  List<BODDocumentResponseDTO> getAuthorizingOemOspDocuments(Long vaMasterId);

  /**
   * Gets contract manufacturer documents.
   *
   * @param vaMasterId the va master id
   * @return the contract manufacturer documents
   */
  List<BODDocumentResponseDTO> getContractManufacturerDocuments(Long vaMasterId);

  /**
   * Delete bod document.
   *
   * @param vaMasterFk the va master fk
   * @param docName    the doc name
   */
  void deleteBodDocument(Long vaMasterFk, String docName);

  /**
   * Export to excel response entity.
   *
   * @param bodDocumentResponses the bod document responses
   * @return the response entity
   */
  ResponseEntity<byte[]> exportToExcel(List<BODDocumentResponseDTO> bodDocumentResponses);

  /**
   * Gets last verified bod document.
   *
   * @param sellerID the seller id
   * @return the last verified bod document
   */
  List<BODDocumentResponseDTO> getLastVerifiedBODDocument(Long sellerID);

  /**
   * Save remarks va document detail entity.
   *
   * @param remarks    the remarks
   * @param vaMasterFk the va master fk
   * @return the va document detail entity
   */
  VaDocumentDetailEntity saveRemarks(String remarks, Long vaMasterFk);

  /**
   * Gets parent bod documents.
   *
   * @param vaMasterId the va master id
   * @return the parent bod documents
   */
  List<BODDocumentResponseDTO> getParentBodDocuments(Long vaMasterId);

  /**
   * Gets uploaded parent bod document.
   *
   * @param sellerId the seller id
   * @return the uploaded parent bod document
   */
  List<BODDocumentNewResponseDTO> getUploadedParentBODDocument(Long sellerId);
}
