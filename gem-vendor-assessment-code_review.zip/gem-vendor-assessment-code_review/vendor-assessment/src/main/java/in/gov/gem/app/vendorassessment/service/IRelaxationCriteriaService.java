
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.service;


import in.gov.gem.app.vendorassessment.dto.request.DocumentOldRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.DocumentNewResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.RelaxationOptionResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.*;

import java.util.List;

/**
 * The interface Relaxation criteria service.
 */
public interface IRelaxationCriteriaService {
  /**
   * Add document document response.
   *
   * @param request the request
   * @return the document response
   */
  DocumentNewResponseDTO addDocument(DocumentOldRequestDTO request);

  /**
   * Gets all documents.
   *
   * @param criteria the criteria
   * @return the all documents
   */
  List<DocumentNewResponseDTO> getAllDocuments(String criteria);

  /**
   * Delete document document response.
   *
   * @param id the id
   * @return the document response
   */
  DocumentNewResponseDTO deleteDocument(Long id);


  /**
   * Validate criteria object.
   *
   * @param eligible the eligible
   * @return the object
   */
  Object validateCriteria(boolean eligible);

  /**
   * Is eligible for admin exemption boolean.
   *
   * @param sellerId the seller id
   * @return the boolean
   */
  boolean isEligibleForAdminExemption(String sellerId);

  /**
   * Is eligible for system exemption boolean.
   *
   * @param sellerId the seller id
   * @return the boolean
   */
  boolean isEligibleForSystemExemption(String sellerId);

  /**
   * Gets options by criteria.
   *
   * @param criteria the criteria
   * @return the options by criteria
   */
  List<RelaxationOptionResponseDTO> getOptionsByCriteria(String criteria);

  /**
   * Fetch eligible relaxation option eligible relaxation response dto.
   *
   * @return the eligible relaxation response dto
   */
  EligibleRelaxationResponseDTO fetchEligibleRelaxationOption();


  //-------------------------------------------

  //public List<LicenseCertificateDetail> getLicenseCertificateDetails(String vendorId);

  /**
   * Gets license certificate details.
   *
   * @param vendorAssessmentId the vendor assessment id
   * @param type               the type
   * @return the license certificate details
   */
  List<LicenseCertificateDetailResponseDTO> getLicenseCertificateDetails(String vendorAssessmentId, String type);

  /**
   * Gets issuing authorities.
   *
   * @param criteriaType the criteria type
   * @return the issuing authorities
   */
  List<IssuingAuthorityResponseDTO> getIssuingAuthorities(String criteriaType);

  /**
   * Gets consolidated exemptions.
   *
   * @param vendorAssessmentId the vendor assessment id
   * @return the consolidated exemptions
   */
  ConsolidatedExemptionResponseDTO getConsolidatedExemptions(String vendorAssessmentId);

  /**
   * Gets previous eligibility.
   *
   * @param vendorAssessmentId the vendor assessment id
   * @return the previous eligibility
   */
  PreviousEligibilityResponseDTO getPreviousEligibility(String vendorAssessmentId);

  /**
   * Gets draft eligibility.
   *
   * @param vendorAssessmentId the vendor assessment id
   * @return the draft eligibility
   */
  DraftEligibilityResponseDTO getDraftEligibility(Long vendorAssessmentId);

  //DocumentResponse deleteDocumentRelaxation(Long documentId);


}
