
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.repository;

import in.gov.gem.app.service.core.repository.BaseRepository;


import in.gov.gem.app.vendorassessment.domain.entity.VAOrganizationAddressEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * The interface Va manufacturing address repository.
 */
@Repository
public interface VaManufacturingAddressRepository extends BaseRepository<VAOrganizationAddressEntity, Long>
{

  /**
   * Find by va organization detail fk list.
   *
   * @param vaOrganizationDetailFk the va organization detail fk
   * @return the list
   */
  List<VAOrganizationAddressEntity> findByVaOrganizationDetailFk(Long vaOrganizationDetailFk);

  /**
   * Find by va organization detail fk page.
   *
   * @param vaOrganizationDetailFk the va organization detail fk
   * @param pageRequest            the page request
   * @return the page
   */
  Page<VAOrganizationAddressEntity> findByVaOrganizationDetailFk(Long vaOrganizationDetailFk, Pageable pageRequest);

  /**
   * Find by va organization detail fk in list.
   *
   * @param vaOrganizationDetailFks the va organization detail fks
   * @return the list
   */
  List<VAOrganizationAddressEntity> findByVaOrganizationDetailFkIn(List<Long> vaOrganizationDetailFks);

  Optional<VAOrganizationAddressEntity> findById(Long id);

  // Optional<VAOrganizationAddress> findById(Long id, Pageable pageRequest);


}
