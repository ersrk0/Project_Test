
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service;


import in.gov.gem.app.vendorassessment.dto.request.CategoryManufacturingAddressDTO;

import java.util.List;
import java.util.Optional;

/**
 * Interface for the Manufacturing Address Service layer.
 * Defines business operations for Manufacturing Addresses.
 */
public interface ICategoryManufacturingAddressService {

  /**
   * Creates a new manufacturing address entry.
   * @param address The manufacturing address object to create.
   * @return The created manufacturing address with its ID.
   */
   CategoryManufacturingAddressDTO createManufacturingAddress(CategoryManufacturingAddressDTO address);

  /**
   * Retrieves a manufacturing address by its ID.
   * @param id The ID of the manufacturing address.
   * @return An Optional containing the manufacturing address if found.
   */
  Optional<CategoryManufacturingAddressDTO> getManufacturingAddressById(String id);

  /**
   * Retrieves all manufacturing address entries.
   * @return A list of all manufacturing addresses.
   */
  List<CategoryManufacturingAddressDTO> getAllManufacturingAddresses();

  /**
   * Updates an existing manufacturing address.
   * @param id The ID of the manufacturing address to update.
   * @param address The manufacturing address object with updated details.
   * @return An Optional containing the updated manufacturing address if found.
   */
  Optional<CategoryManufacturingAddressDTO> updateManufacturingAddress(String id, CategoryManufacturingAddressDTO address);

  /**
   * Deletes a manufacturing address by its ID.
   * @param id The ID of the manufacturing address to delete.
   * @return True if deleted, false otherwise.
   */
  boolean deleteManufacturingAddress(String id);

  /**
   * Maps a list of category IDs to a specific manufacturing address.
   * @param addressId The ID of the manufacturing address.
   * @param categoryIds A list of category IDs to map.
   * @return An Optional containing the updated manufacturing address if found.
   */
  Optional<CategoryManufacturingAddressDTO> mapCategoriesToManufacturingAddress(String addressId, List<String> categoryIds);

  /**
   * Retrieves the mapped category IDs for a specific manufacturing address.
   * @param addressId The ID of the manufacturing address.
   * @return A list of category IDs mapped to the manufacturing address.
   */
  List<String> getMappedCategoryIds(String addressId);
}

