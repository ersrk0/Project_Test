
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;


import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.dto.request.VendorAssessmentNewRequestDTO;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;




import in.gov.gem.app.vendorassessment.dto.response.InitiateResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OrganizationDetailsResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VendorAssessmentIdResponseDTO;

import in.gov.gem.app.utility.CustomLoggerFactory;
import in.gov.gem.app.vendorassessment.domain.entity.VAMasterEntity;
import in.gov.gem.app.vendorassessment.domain.repository.VendorAssessmentRepository;
import in.gov.gem.app.vendorassessment.service.IInitiateAssessmentService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * The type Vendor assessment service.
 */
@Service
@AllArgsConstructor
public class VendorAssessmentService implements IInitiateAssessmentService {


    private VendorAssessmentRepository vendorAssessmentRepository;
    private final ISellerClient iSellerClient;
    private final MessageUtility messageUtility;

    private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(VendorAssessmentService.class);


    public InitiateResponseDTO initiateVendorAssessment(VendorAssessmentNewRequestDTO request) {
        try {
            ResponseEntity<APIResponse<OrganizationDetailsResponseDTO>> response = iSellerClient.getOrganizationDetails();
            OrganizationDetailsResponseDTO organizationDetails = Objects.requireNonNull(response.getBody()).getData();

            if (organizationDetails == null) {
                log.error("Failed to fetch gemPvtOrgId from organization details.");
                throw new ServiceException(
                        MessageConstant.UNEXPECTED_ERROR,
                        messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                        ErrorConstant.CATEGORY.BV,
                        ErrorConstant.SEVERITY.I
                );
            }
            long sellerId = organizationDetails.getGemPvtOrgId();
            log.info("Fetched gemPvtOrgId: {}", sellerId);
            request.setSellerId(sellerId);
            String applyAs = request.getAssessmentType();
            sellerId = request.getSellerId();
            boolean status = vendorAssessmentRepository.existsByPvtOrgMasterFkAndVaStatusLookUpAndApplyAsLookUp(sellerId, "Draft", applyAs);
            String message;
            InitiateResponseDTO initiateResponseDTO = new InitiateResponseDTO();
            if (status) {
                message = "Sellers with a draft VA request will not be allowed to initiate a new application in the same “Assess As” type until the draft is either submitted or discarded. ";
                initiateResponseDTO.setRaiseNewRequest(false);
                initiateResponseDTO.setMessage(message);
                return initiateResponseDTO;
            } else {
                message = "Seller can raise a new request";
                initiateResponseDTO.setRaiseNewRequest(true);
                initiateResponseDTO.setMessage(message);
                return initiateResponseDTO;
            }
        }
        catch(Exception ex){
            throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
        }

    }


    // Fetch Brand-OEM/OSP Dashboard Status
    public boolean fetchBrandOemOspDashboardStatus(Long id) {
        try {
            Optional<VAMasterEntity> byVendorId = vendorAssessmentRepository.findById(id);
            if (byVendorId.isPresent()) {
                VAMasterEntity vendorAssessment = byVendorId.get();
                return !vendorAssessment.getNeedDashboard();
            }
            return false;
        }
        catch(Exception ex){
            throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
        }
    }


//        @Override
//        public VAResponseDTO initiateAssessment(VAssessmentRequest request) {
//        try {
//            VAResponseDTO response = new VAResponseDTO();
//            response.setStatus("INITIATED");
//            response.setRequestId(UUID.randomUUID().toString());
//            return response;
//        }
//        catch(Exception ex){
//            throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
//                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
//                    ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
//        }
//        }



    @Override
    public VendorAssessmentIdResponseDTO fetchSupplementaryVAId() {
        try{
        ResponseEntity<APIResponse<OrganizationDetailsResponseDTO>> response = iSellerClient.getOrganizationDetails();
        OrganizationDetailsResponseDTO organizationDetails = Objects.requireNonNull(response.getBody()).getData();

        if (organizationDetails == null) {
            log.error("Failed to fetch gemPvtOrgId from organization details.");
            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }

        Long sellerId = organizationDetails.getGemPvtOrgId();
        log.info("Fetched gemPvtOrgId: {}", sellerId);
        List<Optional<VAMasterEntity>> byPvtOrgMasterFk = vendorAssessmentRepository.findByPvtOrgMasterFk(sellerId);
        ArrayList<String> vaNumbers = new ArrayList<>();
        for (Optional<VAMasterEntity> vendorAssessment : byPvtOrgMasterFk) {
            if (vendorAssessment.isPresent()) {
                VAMasterEntity va = vendorAssessment.get();
                String vaNumber = va.getVaNumber();
                vaNumbers.add(vaNumber);
            }
        }
        VendorAssessmentIdResponseDTO vendorAssessmentIdDTO = new VendorAssessmentIdResponseDTO();
        vendorAssessmentIdDTO.setVendorAssessmentIds(vaNumbers);

        return vendorAssessmentIdDTO;
    }
        catch(Exception ex) {
            throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
        }
    }

}
