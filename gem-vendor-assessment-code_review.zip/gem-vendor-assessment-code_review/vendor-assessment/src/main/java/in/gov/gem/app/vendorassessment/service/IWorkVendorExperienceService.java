
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service;


import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.request.WorkExperienceNewRequestDTO;

import java.util.List;

/**
 * The interface Work vendor experience service.
 */
public interface IWorkVendorExperienceService
{
  /**
   * Create work experience work experience new request dto.
   *
   * @param createRequest the create request
   * @return the work experience new request dto
   */
  public WorkExperienceNewRequestDTO createWorkExperience(WorkExperienceNewRequestDTO createRequest);

  /**
   * Find by va master fk pageable api response.
   *
   * @param vaMasterFk       the va master fk
   * @param paginationParams the pagination params
   * @return the pageable api response
   */
  public PageableApiResponse<List<WorkExperienceNewRequestDTO>> findByVaMasterFk(Long vaMasterFk, PaginationParams paginationParams);

  /**
   * Find by va master fk list.
   *
   * @param vaMasterFk the va master fk
   * @return the list
   */
  public List<WorkExperienceNewRequestDTO> findByVaMasterFk(Long vaMasterFk);
}
