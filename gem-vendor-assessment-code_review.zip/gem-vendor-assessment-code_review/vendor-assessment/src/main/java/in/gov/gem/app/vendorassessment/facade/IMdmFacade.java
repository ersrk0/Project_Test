
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;

import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.response.CountryResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.FetchLocationResponseDTO;

import java.util.List;

/**
 * The interface Mdm facade.
 */
public interface IMdmFacade
{
  /**
   * Gets location list from mdm.
   *
   * @param paginationParams the pagination params
   * @param locationCode     the location code
   * @param languageCode     the language code
   * @return the location list from mdm
   */
  public List<FetchLocationResponseDTO> getLocationListFromMdm(PaginationParams paginationParams,
                                                               String locationCode, String languageCode);

  /**
   * Fetch country list list.
   *
   * @param paginationParams the pagination params
   * @param languageCode     the language code
   * @return the list
   */
  public List<CountryResponseDTO> fetchCountryList(PaginationParams paginationParams, String languageCode);
}
