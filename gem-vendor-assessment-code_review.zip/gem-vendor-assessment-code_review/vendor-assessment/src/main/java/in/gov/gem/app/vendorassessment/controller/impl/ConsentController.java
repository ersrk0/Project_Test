
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.controller.IConsentController;
import in.gov.gem.app.vendorassessment.facade.IConsentFacade;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * The type Consent controller.
 */
@RestController
@AllArgsConstructor
public class ConsentController extends BaseParentController implements IConsentController
{

  private final IConsentFacade consentFacade;

  @Override
  public ResponseEntity<APIResponse<Object>> getConsentMetaData(@RequestHeader(name="Accept-Language") String acceptLanguage,
                                                                @RequestParam  String module,
                                                                @RequestParam String functionality) {
    boolean success = consentFacade.getConsentData(acceptLanguage, module, functionality);

    return ResponseEntity.status(success ? HttpStatus.OK : HttpStatus.BAD_REQUEST).body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message(success ? ApplicationConstant.CONSENT_SAVED_SUCCESS : ApplicationConstant.CONSENT_NOT_SAVED)
      .data(null)
      .build());
  }

  @Override
  public ResponseEntity<byte[]> downloadDocument(@RequestParam String consentCode,
                                                 @RequestHeader(name="Accept-Language") String acceptLanguage) {
    byte[] bytes = (byte[]) consentFacade.getViewData(consentCode,acceptLanguage);
    return ResponseEntity.ok()
      .header("Content-Disposition", "attachment; filename=\"" + consentCode + ".pdf\"")
      .header("Content-Type", "application/pdf")
      .body(bytes != null ? bytes : new byte[0]);
  }

}
