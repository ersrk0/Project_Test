package in.gov.gem.app.vendorassessment.controller;

import in.gov.gem.app.service.dto.APIResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/lookup")
public interface IAssess {
    @GetMapping("assess/types")
    public ResponseEntity<APIResponse<Object>> fetchAssessType() ;


    @GetMapping("/description")
    public ResponseEntity<APIResponse<Object>> fetchDescription(@RequestParam String lookupValue) ;

    @GetMapping("/question")
    public ResponseEntity<APIResponse<Object>> fetchQuestionByAssess(@RequestParam String assess) ;
}
