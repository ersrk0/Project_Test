
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;

import in.gov.gem.app.vendorassessment.dto.request.*;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseResenDResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseSendResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseValidateResponseDTO;
import in.gov.gem.app.service.dto.APIResponse;
import org.springframework.http.ResponseEntity;

/**
 * The interface Otp service facade.
 */
public interface IOtpServiceFacade
{
  /**
   * Sent otp via email response entity.
   *
   * @param sendOtpRequestDto the send otp request dto
   * @return the response entity
   */
  public ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> SentOtpViaEmail(AddEmailRequestDTO sendOtpRequestDto);

  /**
   * Validate otp via email response entity.
   *
   * @param profileOtpValidationRequestDTO the profile otp validation request dto
   * @return the response entity
   */
  public ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> ValidateOtpViaEmail(
    OtpValidationRequestDTO profileOtpValidationRequestDTO);

  /**
   * Resend otp via email response entity.
   *
   * @param otpRegenerateRequestDTO the otp regenerate request dto
   * @return the response entity
   */
  public ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> ResendOtpViaEmail(
    OtpRegenerateRequestDTO otpRegenerateRequestDTO);

  //---------------------------------------------------------------------------------

  /**
   * Sent otp via mobile response entity.
   *
   * @param sendOtpRequestDto the send otp request dto
   * @return the response entity
   */
  public ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> SentOtpViaMobile(AddMobileRequestDTO sendOtpRequestDto);

  /**
   * Validate otp via mobile response entity.
   *
   * @param profileOtpValidationRequestDTO the profile otp validation request dto
   * @return the response entity
   */
  public ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> ValidateOtpViaMobile(
    MobileOtpValidationRequestDTO profileOtpValidationRequestDTO);

  /**
   * Resend otp via mobile response entity.
   *
   * @param otpRegenerateRequestDTO the otp regenerate request dto
   * @return the response entity
   */
  public ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> ResendOtpViaMobile(
    OtpRegenerateRequestDTO otpRegenerateRequestDTO);

}
