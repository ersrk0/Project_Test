
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.request.CategoryWorkExperienceRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.WorkExperienceCategoryMappingDTO;
import in.gov.gem.app.vendorassessment.dto.response.CategoryWorkExperienceResponseDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/v1/work-experiences")
@Tag(name = "Work Experience Management", description = "Endpoints for managing work experiences and their category mappings.")
public interface ICategoryWorkExperienceController {

    @PostMapping
    @Operation(
        summary = "Create a new work experience",
        description = "Creates a new work experience entry.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Work experience created successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryWorkExperienceResponseDTO.class)))
        }
    )
    ResponseEntity<APIResponse<Object>> createWorkExperience(
        @Parameter(description = "The DTO containing work experience details", required = true) @RequestBody CategoryWorkExperienceRequestDTO requestDTO
    );

    @GetMapping("/getWorkExperienceById")
    @Operation(
        summary = "Retrieve a work experience by ID",
        description = "Retrieves a single work experience entry by its unique ID.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Work experience retrieved successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryWorkExperienceResponseDTO.class))),
            @ApiResponse(responseCode = "404", description = "Work experience not found")
        }
    )
    ResponseEntity<APIResponse<Object>> getWorkExperienceById(
        @Parameter(description = "The ID of the work experience", required = true) @RequestParam String id
    );

    @GetMapping
    @Operation(
        summary = "Retrieve all work experience entries",
        description = "Retrieves a list of all work experience entries.",
        responses = {
            @ApiResponse(responseCode = "200", description = "All work experiences retrieved successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = List.class)))
        }
    )
    ResponseEntity<APIResponse<Object>> getAllWorkExperiences();

    @PutMapping
    @Operation(
        summary = "Update an existing work experience",
        description = "Updates the details of an existing work experience by its ID.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Work experience updated successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryWorkExperienceResponseDTO.class))),
            @ApiResponse(responseCode = "404", description = "Work experience not found")
        }
    )
    ResponseEntity<APIResponse<Object>> updateWorkExperience(
        @Parameter(description = "The ID of the work experience to update", required = true) @RequestParam String id,
        @Parameter(description = "The DTO with updated work experience details", required = true) @RequestBody CategoryWorkExperienceRequestDTO requestDTO
    );

    @DeleteMapping
    @Operation(
        summary = "Delete a work experience",
        description = "Deletes a work experience entry by its ID.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Work experience deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Work experience not found")
        }
    )
    ResponseEntity<APIResponse<Object>> deleteWorkExperience(
        @Parameter(description = "The ID of the work experience to delete", required = true) @RequestParam String id
    );

    @PostMapping("/map-categories")
    @Operation(
        summary = "Map categories to a work experience",
        description = "Associates a list of categories with a specific work experience.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Categories mapped successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryWorkExperienceResponseDTO.class))),
            @ApiResponse(responseCode = "404", description = "Work experience not found")
        }
    )
    ResponseEntity<APIResponse<Object>> mapCategoriesToWorkExperience(
        @Parameter(description = "The ID of the work experience", required = true) @RequestParam String workExperienceId,
        @Parameter(description = "The DTO containing the list of category IDs to map", required = true)
        @RequestBody WorkExperienceCategoryMappingDTO mappingDTO
    );

    @GetMapping("/with-categories")
    @Operation(
        summary = "Retrieve a work experience with mapped categories",
        description = "Retrieves a work experience and includes the details of all its mapped categories.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Work experience with categories retrieved successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryWorkExperienceResponseDTO.class))),
            @ApiResponse(responseCode = "404", description = "Work experience not found")
        }
    )
    ResponseEntity<APIResponse<Object>> getWorkExperienceWithMappedCategories(
        @Parameter(description = "The ID of the work experience", required = true) @RequestParam String id
    );
}
