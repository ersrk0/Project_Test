
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;

import in.gov.gem.app.vendorassessment.dto.request.CategoryManufacturingAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ManufacturingAddressCategoryMappingDTO;

import in.gov.gem.app.vendorassessment.dto.response.CategoryManufacturingAddressResponseDTO;


import java.util.List;

/**
 * Interface for the Manufacturing Address Facade layer.
 * Simplifies interaction for the controller, handles DTO conversions.
 */
public interface ICategoryManufacturingAddressFacade {

  /**
   * Creates a new manufacturing address.
   * @param requestDTO The DTO containing manufacturing address details.
   * @return The response DTO for the created manufacturing address.
   */
  CategoryManufacturingAddressResponseDTO createManufacturingAddress(CategoryManufacturingAddressRequestDTO requestDTO);

  /**
   * Retrieves a manufacturing address by ID.
   * @param id The ID of the manufacturing address.
   * @return The response DTO for the manufacturing address, or null if not found.
   */
  CategoryManufacturingAddressResponseDTO getManufacturingAddressById(String id);

  /**
   * Retrieves all manufacturing address entries.
   * @return A list of response DTOs for all manufacturing addresses.
   */
  List<CategoryManufacturingAddressResponseDTO> getAllManufacturingAddresses();

  /**
   * Updates an existing manufacturing address.
   * @param id The ID of the manufacturing address to update.
   * @param requestDTO The DTO with updated details.
   * @return The response DTO for the updated manufacturing address, or null if not found.
   */
  CategoryManufacturingAddressResponseDTO updateManufacturingAddress(String id, CategoryManufacturingAddressRequestDTO requestDTO);

  /**
   * Deletes a manufacturing address by ID.
   * @param id The ID of the manufacturing address to delete.
   * @return A response DTO indicating the deletion status.
   */
  CategoryManufacturingAddressResponseDTO deleteManufacturingAddress(String id);

  /**
   * Maps categories to a specific manufacturing address.
   * @param addressId The ID of the manufacturing address.
   * @param mappingDTO The DTO containing the list of category IDs to map.
   * @return The response DTO for the updated manufacturing address with mapped categories, or null if not found.
   */
  CategoryManufacturingAddressResponseDTO mapCategoriesToManufacturingAddress(String addressId, ManufacturingAddressCategoryMappingDTO mappingDTO);

  /**
   * Retrieves the manufacturing address along with its mapped categories.
   * @param addressId The ID of the manufacturing address.
   * @return The ManufacturingAddressResponseDTO including the mapped category details.
   */
  CategoryManufacturingAddressResponseDTO getManufacturingAddressWithMappedCategories(String addressId);
}

