
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;
import in.gov.gem.app.vendorassessment.dto.request.ExportDTORequestDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Document Export", description = "APIs for exporting user data to Excel")
@RestController
@RequestMapping("/v1/document")
public interface IFileServiceController {

  /**
   * Exports user data to an Excel file.
   *
   * @param vendorDashboardDTOS the export request data (optional)
   * @param all                 flag to export all data (optional)
   * @return the Excel file as a byte array
   */
  @Operation(
    summary = "Export Users to Excel",
    description = "Exports user data to an Excel file.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(
    name = "all",
    description = "Flag to export all data",
    in = ParameterIn.QUERY,
    required = false
  )
  @ApiResponse(responseCode = "200", description = "Excel file generated successfully")
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/report")
  ResponseEntity<byte[]> exportUsersToExcel(
    @RequestBody(required = false) ExportDTORequestDTO vendorDashboardDTOS,
    @RequestParam(required = false) boolean all
  );}
 