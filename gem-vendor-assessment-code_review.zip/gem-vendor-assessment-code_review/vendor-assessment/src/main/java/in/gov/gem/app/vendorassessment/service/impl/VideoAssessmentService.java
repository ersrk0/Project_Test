
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;


import in.gov.gem.app.vendorassessment.dto.response.VideoInstructionsDTOResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VideoScheduleTimeDTOResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.VideoUrlDTOResponseDTO;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.service.core.repository.LookupRepository;


import in.gov.gem.app.vendorassessment.service.IVideoAssessmentService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

/**
 * The type Video assessment service.
 */
@Service
@AllArgsConstructor
public class VideoAssessmentService implements IVideoAssessmentService {

  /**
   * The Lookup repository.
   */
  public final LookupRepository lookupRepository;
  private final MessageUtility messageUtility;


  @Override
  public Object fetchInstructions(String sellerId) {
    // Return VA instructions if schedule is accepted
    try {
      VideoInstructionsDTOResponseDTO videoInstructionsDTO = new VideoInstructionsDTOResponseDTO();
      Optional<Lookup> lookupValues = lookupRepository.findByLookupCode(ApplicationConstant.VIDEO_INSTRUCTIONS_LOOKUP_CODE);
      if(lookupValues.isEmpty())
      {
        throw new ServiceException(MessageConstant.Lookup_NOT_FOUND,
                messageUtility.getMessage(MessageConstant.Lookup_NOT_FOUND),
                ErrorConstant.CATEGORY.TH, ErrorConstant.SEVERITY.I);
      }
      videoInstructionsDTO.setInstructions(lookupValues.get().getDescription());
      return videoInstructionsDTO;
    } catch (Exception e) {
      throw new ServiceException(MessageConstant.Lookup_NOT_FOUND,
              messageUtility.getMessage(MessageConstant.Lookup_NOT_FOUND),
              ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
    }
  }

  @Override
  public Object fetchAppDownloadLink() {
    // Fetch from config/db

    try{
      VideoUrlDTOResponseDTO videoUrlDTO = new VideoUrlDTOResponseDTO();
      videoUrlDTO.setVideoUrl( ApplicationConstant.APP_DOWNLOAD_LINK);
      return videoUrlDTO;
    } catch (Exception e) {
      throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
              messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
              ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
    }
  }



  @Override
  public Object fetchScheduleAssessmentDateTime() {
    try{
      VideoScheduleTimeDTOResponseDTO videoScheduleTimeDTO = new VideoScheduleTimeDTOResponseDTO();

      Instant instant = Instant.now(); // Replace with actual scheduled time
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
              .withZone(ZoneId.systemDefault());
      videoScheduleTimeDTO.setScheduleTime(formatter.format(instant));
      videoScheduleTimeDTO.setNumberOfDays(ApplicationConstant.NO_OF_DAYS_FOR_VIDEO_ASSESSMENT);
      return videoScheduleTimeDTO;
    } catch (Exception e) {
      throw new ServiceException(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND,
              messageUtility.getMessage(MessageConstant.VENDOR_ASSESSMENT_NOT_FOUND),
              ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
    }

  }
}


