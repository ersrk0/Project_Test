
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.controller;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.request.AddBodDocumentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.DocumentNewResponseDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Provides APIs for managing vendor exemptions and relaxation criteria.

 */
@Tag(name = "Relaxation and Exemption Management", description = "API for managing vendor exemptions and relaxation criteria.")
@RestController
@RequestMapping("/api/exemptions")
public interface IRelaxationController {

  @PostMapping("/add")
  @Operation(
    summary = "Add a new document",
    description = "Adds a new document associated with an exemption request.",
    responses = {
      @ApiResponse(responseCode = "201", description = "Document added successfully.",
        content = @Content(mediaType = "application/json",
          schema = @Schema(implementation = APIResponse.class))),

      @ApiResponse(responseCode = "400", description = "Invalid request payload.")
    }
  )
  public ResponseEntity<APIResponse<Object>> addDocument(AddBodDocumentRequestDTO request
  );

  @GetMapping("/all")
  @Operation(
    summary = "Get all documents for a given criteria",
    description = "Retrieves a list of all documents that match the specified criteria.",
    responses = {
      @ApiResponse(responseCode = "200", description = "Documents fetched successfully.",
        content = @Content(mediaType = "application/json",
          schema = @Schema(implementation = APIResponse.class))),
      @ApiResponse(responseCode = "404", description = "No documents found for the criteria.")
    }
  )
  public ResponseEntity<PageableApiResponse<List<DocumentNewResponseDTO>>> getAllDocuments(Long vaMasterId,
                                                                                           PaginationParams paginationParams);

  @DeleteMapping("/delete")
  @Operation(
    summary = "Delete a document by its ID",
    description = "Permanently deletes a document from the system.",
    responses = {
      @ApiResponse(responseCode = "200", description = "Document deleted successfully.",
        content = @Content(mediaType = "application/json",
          schema = @Schema(implementation = APIResponse.class))),
      @ApiResponse(responseCode = "404", description = "Document not found.")
    }
  )

  public ResponseEntity<APIResponse<Object>> deleteDocument(Long vaMasterFk, String docName);


}
 