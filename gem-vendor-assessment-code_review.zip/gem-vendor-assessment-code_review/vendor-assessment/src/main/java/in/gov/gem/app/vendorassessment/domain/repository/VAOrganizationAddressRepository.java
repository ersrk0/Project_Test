
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.repository;

import in.gov.gem.app.service.core.repository.BaseRepository;

import in.gov.gem.app.vendorassessment.domain.entity.VAOrganizationAddressEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * The interface Va organization address repository.
 */
@Repository
public interface VAOrganizationAddressRepository extends BaseRepository<VAOrganizationAddressEntity, Long> {
    /**
     * Find by va organization detail fk va organization address entity.
     *
     * @param vaOrganizationId the va organization id
     * @return the va organization address entity
     */
// Additional query methods can be defined here if needed
    VAOrganizationAddressEntity findByVaOrganizationDetailFk(Long vaOrganizationId);
}
