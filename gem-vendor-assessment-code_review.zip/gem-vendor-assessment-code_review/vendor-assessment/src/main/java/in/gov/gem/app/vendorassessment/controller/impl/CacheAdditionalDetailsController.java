
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;


import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;

import in.gov.gem.app.vendorassessment.dto.request.*;
import in.gov.gem.app.vendorassessment.controller.ICacheAdditionalDetailsController;
import in.gov.gem.app.vendorassessment.facade.ICacheAdditionalDetailsFacade;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * The type Cache additional details controller.
 */
@RestController
@AllArgsConstructor
public class CacheAdditionalDetailsController extends BaseParentController implements ICacheAdditionalDetailsController
{
  private final ICacheAdditionalDetailsFacade cacheAdditionalDetailsFacade;


  @Override
  public ResponseEntity<APIResponse<Object>> sendresendOtpOnEmail(@RequestBody AddEmailRequestDTO addEmailDto,
                                                                  @RequestHeader(value = "accept-language", required = false) String acceptLanguage) {

    Object data = cacheAdditionalDetailsFacade.sendOrResendOtpOnEmail(addEmailDto, acceptLanguage);
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message("OTP Cache Send/Resend Successfully on Email")
      .data(data)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> validateotpOnEmail(@RequestBody OtpValidationRequestDTO profileOtpValidationRequestDTO,
                                                                @RequestHeader(value = "accept-language", required = false) String acceptLanguage)
  {

    Object data = cacheAdditionalDetailsFacade.validateOtpOnEmail(profileOtpValidationRequestDTO, acceptLanguage);
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message("OTP VERIFY SUCCESSFULLY and Email Added Successfully")
      .data(data)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> sendresendOtpOnMobile(@RequestBody AddMobileRequestDTO sendOtpRequestDto,
                                                                   @RequestHeader(value = "accept-language", required = false) String acceptLanguage)
  {

    Object data = cacheAdditionalDetailsFacade.sendOrResendOtpOnMobile(sendOtpRequestDto, acceptLanguage);
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message("OTP Cache Send/Resend Successfully on Mobile")
      .data(data)
      .build());
  }

  @Override
  public ResponseEntity<APIResponse<Object>> validateotpOnMobile(@RequestBody MobileOtpValidationRequestDTO OtpValidationRequestDTO,
                                                                 @RequestHeader(value = "accept-language", required = false) String acceptLanguage)  {

    Object data = cacheAdditionalDetailsFacade.validateOtpOnMobile(OtpValidationRequestDTO, acceptLanguage);
    return ResponseEntity.ok().body(APIResponse.builder()
      .msId(ApplicationConstant.MSID)
      .status(HttpStatus.OK.getReasonPhrase())
      .httpStatus(HttpStatus.OK.value())
      .message("OTP Cache VERIFY SUCCESSFULLY AND MOBILE ADDED SUCCESSFULLY")
      .data(data)
      .build());
  }
}
