package in.gov.gem.app.vendorassessment.controller.impl;


import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;

import in.gov.gem.app.vendorassessment.controller.IAssess;
import in.gov.gem.app.vendorassessment.dto.response.AssessDescriptionResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.LookupResponseResponseDTO;
import in.gov.gem.app.vendorassessment.facade.IAssessFacade;
import lombok.AllArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * The type Lookup controller.
 */
@RestController
@AllArgsConstructor
public class AssessController implements IAssess {

    @Autowired
    private IAssessFacade assessFacade;


    public ResponseEntity<APIResponse<Object>> fetchAssessType() {

        LookupResponseResponseDTO description = assessFacade.getLookupValueByLookupName();

        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.FETCH_MESSAGE)
                .data(description)
                .build());
    }


    public ResponseEntity<APIResponse<Object>> fetchDescription(@RequestParam String lookupValue) {


        AssessDescriptionResponseDTO description = assessFacade.getDescriptionByLookupValue(lookupValue);

        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.FETCH_MESSAGE)
                .data(description)
                .build());
    }

    public ResponseEntity<APIResponse<Object>> fetchQuestionByAssess(@RequestParam String assess) {


        List<Map<String ,String>> question = assessFacade.fetchQuestionByAssess(assess);

        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.FETCH_MESSAGE)
                .data(question)
                .build());
    }

}
