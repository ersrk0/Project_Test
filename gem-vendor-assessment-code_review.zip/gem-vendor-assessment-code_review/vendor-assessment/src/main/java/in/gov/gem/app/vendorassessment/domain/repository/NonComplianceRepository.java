
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.repository;

import in.gov.gem.app.service.core.repository.BaseRepository;
import in.gov.gem.app.vendorassessment.domain.entity.NCClosureEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * The interface Non compliance repository.
 */
@Repository
public interface NonComplianceRepository extends BaseRepository<NCClosureEntity, Long> {

    /**
     * Find by va master fk and status lookup list.
     *
     * @param vaMasterFk   the va master fk
     * @param statusLookup the status lookup
     * @return the list
     */
    List<NCClosureEntity>  findByVaMasterFkAndStatusLookup(Long vaMasterFk,
                                                               String statusLookup);

    /**
     * Find by va master fk and status lookup in list.
     *
     * @param vendorAssessmentId the vendor assessment id
     * @param statuses           the statuses
     * @return the list
     */
    List<NCClosureEntity> findByVaMasterFkAndStatusLookupIn(Long vendorAssessmentId, List<String> statuses);

    /**
     * Find by va master fk list.
     *
     * @param vaMasterFk the va master fk
     * @return the list
     */
    List<NCClosureEntity> findByVaMasterFk(Long vaMasterFk);
}