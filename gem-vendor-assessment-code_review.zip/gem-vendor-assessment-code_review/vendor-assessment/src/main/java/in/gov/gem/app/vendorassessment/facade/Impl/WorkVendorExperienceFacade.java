
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.vendorassessment.dto.request.WorkExperienceNewRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.HierarchyMasterResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.HierarchyResponseDTO;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.facade.IWorkVendorExperienceFacade;
import in.gov.gem.app.vendorassessment.service.IWorkVendorExperienceService;
import in.gov.gem.app.vendorassessment.transformer.BuyerTransformer;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * The type Work vendor experience facade.
 */
@AllArgsConstructor
@Component
public class WorkVendorExperienceFacade implements IWorkVendorExperienceFacade
{

  private final IWorkVendorExperienceService workVendorExperience;

  private final BuyerTransformer buyerTransformer;

  @Override
  public WorkExperienceNewRequestDTO createWorkExperience(WorkExperienceNewRequestDTO createRequest)
  {

    return workVendorExperience.createWorkExperience(createRequest);
  }

  @Override
  public PageableApiResponse<List<WorkExperienceNewRequestDTO>> findByVaMasterFk(Long vaMasterFk, PaginationParams paginationParams)
  {

    return workVendorExperience.findByVaMasterFk(vaMasterFk, paginationParams);
  }

  @Override
  public List<WorkExperienceNewRequestDTO> findByVaMasterFk(Long vaMasterFk)
  {

    return workVendorExperience.findByVaMasterFk(vaMasterFk);
  }

  public HierarchyMasterResponseDTO getOrgType(String acceptLanguage, PaginationParams paginationParams )
  {
   return buyerTransformer.getOrgType(acceptLanguage, paginationParams);

  }

  public HierarchyResponseDTO getOrgTypeWithLevel(String parentId, String acceptLanguage,
                                                  PaginationParams paginationParams)
  {
    return buyerTransformer.getOrgTypeWithLevel(parentId, acceptLanguage, paginationParams);
  }

}
