
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.cache.manager.GemCacheManager;
import in.gov.gem.app.vendorassessment.cache.impl.CachingOtpService;
import in.gov.gem.app.vendorassessment.constant.CacheConstant;
import in.gov.gem.app.vendorassessment.dto.request.*;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseResenDResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseSendResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseValidateResponseDTO;
import in.gov.gem.app.vendorassessment.facade.ICacheAdditionalDetailsFacade;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Optional;


/**
 * The type Cache additional details facade.
 */
@Component
@AllArgsConstructor
public class CacheAdditionalDetailsFacade implements ICacheAdditionalDetailsFacade
{

  private final GemCacheManager<String, String> gemCacheManager;
  private final CachingOtpService cachingOtpService;
  private final IAMFacade iamFacade;

  @Override
  public Object sendOrResendOtpOnEmail(AddEmailRequestDTO addEmailDto, String acceptLanguage) {
    Optional<String> cachedReferenceId = gemCacheManager.get(CacheConstant.OTP_EMAIL + CacheConstant.COLON +
      addEmailDto.getEmailId());

    if (cachedReferenceId.isPresent()) {
      OtpRegenerateRequestDTO regenerateRequestDTO = OtpRegenerateRequestDTO.builder()
        .referenceId(cachedReferenceId.get())
        .build();
      ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> response = cachingOtpService.ResendOtpViaEmail(regenerateRequestDTO);
      return (response != null && response.getBody() != null) ? response.getBody().getData() : null;
    } else {
      ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> response = cachingOtpService.SentOtpViaEmail(addEmailDto);
      return (response != null && response.getBody() != null) ? response.getBody().getData() : null;
    }
  }

  @Override
  public Object validateOtpOnEmail(OtpValidationRequestDTO profileOtpValidationRequestDTO, String acceptLanguage)
  {

    ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> dataResponse = cachingOtpService.ValidateOtpViaEmail(profileOtpValidationRequestDTO);

    AddEmailRequestDTO addEmailDto = AddEmailRequestDTO.builder()
      .emailId(profileOtpValidationRequestDTO.getEmail())
      .build();

    boolean isOtpValidated = Optional.ofNullable(dataResponse.getBody())
      .map(APIResponse::getData)
      .map(OtpResponseValidateResponseDTO::getOtpValidated)
      .orElse(false);

    if (dataResponse.getStatusCode() != null && dataResponse.getStatusCode().is2xxSuccessful() && isOtpValidated)
    {
      iamFacade.addEmail("eng", addEmailDto);
    }
    return (dataResponse != null && dataResponse.getBody() != null) ? dataResponse.getBody().getData() : null;
  }

  @Override
  public Object sendOrResendOtpOnMobile(AddMobileRequestDTO sendOtpRequestDto, String acceptLanguage) {
    Optional<String> cachedReferenceId = gemCacheManager.get(CacheConstant.OTP_EMAIL + CacheConstant.COLON +
      sendOtpRequestDto.getMobileNumber());

    if (cachedReferenceId.isPresent()) {
      OtpRegenerateRequestDTO regenerateRequestDTO = OtpRegenerateRequestDTO.builder()
        .referenceId(cachedReferenceId.get())
        .build();
      ResponseEntity<APIResponse<OtpResponseResenDResponseDTO>> response = cachingOtpService.ResendOtpViaMobile(regenerateRequestDTO);
      return (response != null && response.getBody() != null) ? response.getBody().getData() : null;
    } else {
      ResponseEntity<APIResponse<OtpResponseSendResponseDTO>> response = cachingOtpService.SentOtpViaMobile(sendOtpRequestDto);
      return (response != null && response.getBody() != null) ? response.getBody().getData() : null;
    }
  }

  @Override
  public Object validateOtpOnMobile(MobileOtpValidationRequestDTO OtpValidationRequestDTO, String acceptLanguage)
  {
    ResponseEntity<APIResponse<OtpResponseValidateResponseDTO>> dataResponse = cachingOtpService.ValidateOtpViaMobile(OtpValidationRequestDTO);

    AddMobileRequestDTO addMobile = AddMobileRequestDTO.builder()
      .mobileNumber(OtpValidationRequestDTO.getMobile())
      .build();

    boolean isOtpValidated = Optional.ofNullable(dataResponse.getBody())
      .map(APIResponse::getData)
      .map(OtpResponseValidateResponseDTO::getOtpValidated)
      .orElse(false);

    if (dataResponse.getStatusCode() != null && dataResponse.getStatusCode().is2xxSuccessful() && isOtpValidated) {
      iamFacade.addMobile("eng", addMobile);
    }
    return (dataResponse != null && dataResponse.getBody() != null) ? dataResponse.getBody().getData() : null;
  }
}

