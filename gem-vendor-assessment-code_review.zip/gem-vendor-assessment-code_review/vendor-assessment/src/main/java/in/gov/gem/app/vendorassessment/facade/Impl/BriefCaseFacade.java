
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;


import in.gov.gem.app.vendorassessment.dto.response.UploadResponseDTO;
import in.gov.gem.app.vendorassessment.facade.IBriefCaseFacade;
import in.gov.gem.app.vendorassessment.service.IBriefCaseService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


/**
 * The type Brief case facade.
 */
@Component
@AllArgsConstructor
public class BriefCaseFacade implements IBriefCaseFacade
{
  private final IBriefCaseService briefCaseService;

  @Override
  public ResponseEntity<List<UploadResponseDTO>> uploadDocument(List<MultipartFile> files, String documentType)
  {

    ResponseEntity<List<UploadResponseDTO>> uploaddocument =  briefCaseService.uploadDocument(files, documentType);

    return uploaddocument;

  }


  @Override
  public byte[] downloadDocument_(String fileName)
  {
    return briefCaseService.downloadDocument_(fileName);
  }
}
