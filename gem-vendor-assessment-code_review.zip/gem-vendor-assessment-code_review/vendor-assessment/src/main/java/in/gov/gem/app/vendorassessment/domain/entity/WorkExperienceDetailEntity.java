
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

/**
 * The type Work experience detail entity.
 */
@Entity
@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Table(name = "work_experience_detail",schema = "va_mgmt")
public class WorkExperienceDetailEntity extends BaseEntity
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    @Column(name="va_master_fk")
    private Long vaMasterFk;
    @Column(name="hierarchy_id")
    private Long hierarchyId;
    @Column(name = "department_name")
    private String departmentName;
    @Column(name = "email_id")
    private String emailId;
    @Column(name = "order_value")
    private BigDecimal orderValue;
    @Column(name = "official_name")
    private String officialName;
    @Column(name = "quantity_supplied")
    private Integer quantitySupplied;
    @Column(name = "contact_number")
    private String contactNumber;
    @Column(name = "completion_letter_number")
    private String completionLetterNumber;
    @Column(name = "item_supplied")
    private String itemSupplied;
}
