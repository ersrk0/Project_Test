
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.vendorassessment.dto.request.AddBodDocumentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.AdditionalDocumentResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.DocumentDetailResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.SaveAdditionalDocumentResponseDTO;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.facade.IAdditionalOrganisationDetailFacade;
import in.gov.gem.app.vendorassessment.service.IOrganizationAdditionalDetailService;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


/**
 * The type Additional organisation detail facade.
 */
@Component
@AllArgsConstructor
public class AdditionalOrganisationDetailFacade implements IAdditionalOrganisationDetailFacade
{

  private final IOrganizationAdditionalDetailService organizationAdditionalDetail;

  @Override
  public String getAdditionalDocumentQuestion(String lookupCode)
  {
    return organizationAdditionalDetail.getAdditionalDocumentQuestion(lookupCode);
  }

  @Override
  public void deleteBodDocument(Long vaMasterFk, String docName)
  {
    organizationAdditionalDetail.deleteBodDocument(vaMasterFk, docName);
  }

  // Java
  @Override
  public SaveAdditionalDocumentResponseDTO addBodDocument(AddBodDocumentRequestDTO request) {
   return organizationAdditionalDetail.addBodDocument(request);
  }

  @Override
  @Transactional(readOnly = true)
  public Page<DocumentDetailResponseDTO> ByVaMasterFk(Long vaMasterFk, PaginationParams paginationParams)
  {
    return organizationAdditionalDetail.ByVaMasterFk(vaMasterFk, paginationParams);
  }

  @Override
  public ResponseEntity<byte[]> exportToExcel(List<AdditionalDocumentResponseDTO> bodDocumentResponses)
  {

    return organizationAdditionalDetail.exportToExcel(bodDocumentResponses);
  }


}
