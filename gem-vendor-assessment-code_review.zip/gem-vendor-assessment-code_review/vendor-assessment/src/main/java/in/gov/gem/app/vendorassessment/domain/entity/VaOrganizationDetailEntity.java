
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

/**
 * The type Va organization detail entity.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "va_organization_detail", schema = "va_mgmt")
public class VaOrganizationDetailEntity extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "va_master_fk")
    private Long vaMasterFk;

    @Column(name = "organization_name", length = 255)
    private String organizationName;

    @Column(name = "organization_type_lookup", length = 10)
    private String organizationTypeLookup;

    @Column(name = "organization_sub_type_lookup", length = 10)
    private String organizationSubTypeLookup;

    @Column(name = "organization_pan", length = 255)
    private String organizationPan;

    @Column(name = "organization_tan", length = 255)
    private String organizationTan;

    @Column(name = "organization_cin", length = 255)
    private String organizationCin;

    @Column(name = "primary_contact_number", length = 255)
    private String primaryContactNumber;

    @Column(name = "primary_email_id", length = 255)
    private String primaryEmailId;

    @Column(name = "secondary_contact_number", length = 255)
    private String secondaryContactNumber;

    @Column(name = "secondary_email_id", length = 255)
    private String secondaryEmailId;

    @Column(name="authorization_type_lookup",length = 10)
    private String authorizationTypeLookup;
}