
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.repository.LookupRepository;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.utility.CustomLoggerFactory;
import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressUpdateRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.*;
import in.gov.gem.app.vendorassessment.service.ISaveAssessOptionService;

import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


/**
 * The type Office address client facade.
 */
@Component
@AllArgsConstructor
public class OfficeAddressClientFacade
{
  private final ISellerClient iSellerClient;

  private final ISaveAssessOptionService service;

  private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(OfficeAddressClientFacade.class);

  private LookupRepository lookupRepository;

  /**
   * Gets office addresses from seller.
   *
   * @param paginationParams the pagination params
   * @param vaNumber         the va number
   * @return the office addresses from seller
   */
  public List<OfficeSellerResponseDTO> getOfficeAddressesFromSeller(PaginationParams paginationParams, String vaNumber) {
    // Call seller client to get office address data
    ResponseEntity<PageableApiResponse<List<OfficeResponseDTO>>> response =
      iSellerClient.getOfficeAddress(paginationParams);

    // Extract office address list safely
    List<OfficeResponseDTO> officeList = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(PageableApiResponse::getData)
      .orElse(Collections.emptyList());

    if (officeList.isEmpty()) {
      log.info("No Office Address details found for the given parameters.");
      return Collections.emptyList();
    }

    SaveAssessResponseDTO option = service.getOption(vaNumber);
    Optional<Lookup> byLookupCode = lookupRepository.findByLookupCode(option.getApplyAsLookUp());
    byLookupCode.ifPresent(lookup -> option.setApplyAsLookUp(lookup.getLookupValue()));

    // Convert List<OfficeResponseDTO> into List<OfficeSellerResponseDTO>
    return officeList.stream()
      .map(office -> OfficeSellerResponseDTO.builder()
        .id(office.getId())
        .OfficeName(office.getName())
        .gstin(office.getGstn())
        .officeAddress(office.getOfficeAddress())

        .officeType(office.getTypeLookup())
        //.AddressType(office.getTypeLookup())
        .ManufacturingAddress(office.getAddress1())
        .mobile(office.getMobile())
        .email(office.getEmail())
        .assessAsType(byLookupCode.map(Lookup::getLookupValue).orElse(null))
        .action(Collections.emptyList())
        .build())
      .collect(Collectors.toList());
  }

  /**
   * Gets office addressespredefined.
   *
   * @param paginationParams the pagination params
   * @param vaNumber         the va number
   * @return the office addressespredefined
   */
  public List<OfficePreSellerResponseDTO> getOfficeAddressespredefined(PaginationParams paginationParams,
                                                                       String vaNumber) {
    // Call seller client to get office address data
    ResponseEntity<PageableApiResponse<List<OfficeResponseDTO>>> response =
      iSellerClient.getOfficeAddress(paginationParams);

    // Extract office address list safely
    List<OfficeResponseDTO> officeList = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(PageableApiResponse::getData)
      .orElse(Collections.emptyList());

    if (officeList.isEmpty()) {
      log.info("No Office Address details found for the given parameters.");
      return Collections.emptyList();
    }

    SaveAssessResponseDTO option = service.getOption(vaNumber);
    Optional<Lookup> byLookupCode = lookupRepository.findByLookupCode(option.getApplyAsLookUp());
    byLookupCode.ifPresent(lookup -> option.setApplyAsLookUp(lookup.getLookupValue()));

    // Convert List<OfficeResponseDTO> to List<OfficePreSellerResponseDTO>
    return officeList.stream()
      .map(office -> OfficePreSellerResponseDTO.builder()
        .id(office.getId())
        .OfficeName(office.getName())
        .ManufacturingAddress(office.getAddress1())
        .gstin(office.getGstn())
        .officeAddress(office.getOfficeAddress())
        .officeType(office.getTypeLookup())
        .mobile(office.getMobile())
        .email(office.getEmail())
        .assessAsType(byLookupCode.map(Lookup::getLookupValue).orElse(null))
        .pincode(office.getPincodeLookUp())
        .country(office.getCountryLookup())
        .action(Collections.emptyList())
        .build())
      .collect(Collectors.toList());
  }

  /**
   * Save office address office vo response dto.
   *
   * @param officeAddressRequestDTO the office address request dto
   * @return the office vo response dto
   */
  public OfficeVOResponseDTO saveOfficeAddress(OfficeAddressRequestDTO officeAddressRequestDTO)
  {
    ResponseEntity<APIResponse<OfficeVOResponseDTO>> response= iSellerClient.saveOfficeAddress(officeAddressRequestDTO);
    return Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(APIResponse::getData)
      .orElse(null);
  }

  /**
   * Delete office address.
   *
   * @param pvtOrgOfficeId the pvt org office id
   */
  public void deleteOfficeAddress(Long pvtOrgOfficeId)
  {
    iSellerClient.deleteOfficeAddress(pvtOrgOfficeId);
  }

  /**
   * Update office address.
   *
   * @param officeAddressUpdateRequestDTO the office address update request dto
   */
  public void updateOfficeAddress(OfficeAddressUpdateRequestDTO officeAddressUpdateRequestDTO)
  {
    iSellerClient.updateOfficeAddress(officeAddressUpdateRequestDTO);
  }


  /**
   * Gets registered office mobile list.
   *
   * @param paginationParams the pagination params
   * @return the registered office mobile list
   */
  public List<OfficeVOResponseDTO> getRegisteredOfficeMobileList(PaginationParams paginationParams)
  {
    ResponseEntity<PageableApiResponse<List<OfficeVOResponseDTO>>> response =
      iSellerClient.getRegisteredOfficeMobileList(paginationParams);

    List<OfficeVOResponseDTO> mobileList = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(PageableApiResponse::getData)
      .orElse(Collections.emptyList());
    return mobileList;

  }

  /**
   * Gets registered office email list.
   *
   * @param paginationParams the pagination params
   * @return the registered office email list
   */
  public List<OfficeVOResponseDTO> getRegisteredOfficeEmailList(PaginationParams paginationParams)
  {
    ResponseEntity<PageableApiResponse<List<OfficeVOResponseDTO>>> response =
      iSellerClient.getRegisteredOfficeEmailList(paginationParams);

    List<OfficeVOResponseDTO> emailList = Optional.ofNullable(response)
      .map(ResponseEntity::getBody)
      .map(PageableApiResponse::getData)
      .orElse(Collections.emptyList());
    return emailList;

  }



}
