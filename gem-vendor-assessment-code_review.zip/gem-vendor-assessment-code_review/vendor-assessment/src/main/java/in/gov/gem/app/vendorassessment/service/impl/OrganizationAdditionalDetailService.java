
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */
package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.vendorassessment.utility.SearchUtils;
import org.springframework.transaction.annotation.Transactional;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.repository.LookupRepository;
import in.gov.gem.app.service.core.utility.MessageUtility;

import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;


import in.gov.gem.app.vendorassessment.dto.request.AddBodDocumentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.AdditionalDocumentResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.DocumentDetailResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.SaveAdditionalDocumentResponseDTO;


import in.gov.gem.app.vendorassessment.domain.entity.VaDocumentDetailEntity;
import in.gov.gem.app.vendorassessment.domain.repository.DocumentDetailRepository;
import in.gov.gem.app.vendorassessment.service.IOrganizationAdditionalDetailService;
import lombok.AllArgsConstructor;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static org.apache.kafka.common.requests.DeleteAclsResponse.log;

/**
 * The type Organization additional detail service.
 */
@Service
@AllArgsConstructor
public class OrganizationAdditionalDetailService implements IOrganizationAdditionalDetailService
{

  private final LookupRepository lookupRepository;

  private final MessageUtility messageUtility;

  private final DocumentDetailRepository documentDetailRepository;

  @Override
  public String getAdditionalDocumentQuestion(String lookupCode)
  {
    if (lookupCode != null && !lookupCode.trim().isEmpty()) {
      return lookupRepository.findByLookupCode(lookupCode)
        .map(Lookup::getDescription)
        .orElse(null);
    }
    return null;
  }

  @Override
  public void deleteBodDocument(Long vaMasterFk, String docName) {
    try {
      documentDetailRepository.deleteByVaMasterFkAndDocumentName(vaMasterFk, docName);
    } catch (Exception e) {
      log.error("Error occurred while deleting BOD document with vaMasterFk: {} and docName: {}", vaMasterFk, docName, e);
      throw new ServiceException(
        MessageConstant.UNEXPECTED_ERROR,
        messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
        ErrorConstant.CATEGORY.BV,
        ErrorConstant.SEVERITY.I
      );
    }
  }

  // Java
  @Override
  public SaveAdditionalDocumentResponseDTO addBodDocument(AddBodDocumentRequestDTO request) {
    VaDocumentDetailEntity entity = new VaDocumentDetailEntity();
    entity.setVaMasterFk(request.getVaMasterFk());
    entity.setDocumentName(request.getDocumentName());
    entity.setDocumentTypeLookup(request.getDocumentTypeLookup());
    entity.setDocumentExtensionLookup(request.getDocumentExtensionLookup());
    entity.setDocumentPath(request.getDocumentPath());
    entity.setSizeInMb(request.getSizeInMb());
    entity.setRemark(request.getRemark());
    entity.setNoOfPage(request.getNoOfPage());
    entity.setUploadBy(request.getUploadBy());
    documentDetailRepository.save(entity);

    SaveAdditionalDocumentResponseDTO response = new SaveAdditionalDocumentResponseDTO();
    response.setDocName(entity.getDocumentName());
    response.setDocType(entity.getDocumentTypeLookup());
    response.setFileSize(entity.getSizeInMb());
    response.setNoOfPages(entity.getNoOfPage());
    response.setLastUpdatedOn(entity.getUpdateTimestamp() != null
      ? Instant.parse(entity.getUpdateTimestamp().toString())
      : null);
    return response;
  }

  @Override
  @Transactional(readOnly = true)
  public Page<DocumentDetailResponseDTO> ByVaMasterFk(Long vaMasterFk, PaginationParams paginationParams) {

    PageRequest pageRequest = PageRequest.of(paginationParams.getPageNumber(), paginationParams.getPageSize());
    Page<VaDocumentDetailEntity> page = documentDetailRepository.findByVaMasterFk(vaMasterFk, pageRequest);

    String searchQuery = paginationParams.getSearchQuery();

    List<DocumentDetailResponseDTO> dtos = page.getContent().stream()
      .map(entity -> {
        DocumentDetailResponseDTO dto = new DocumentDetailResponseDTO();
        dto.setId(entity.getId());
        dto.setVaMasterFk(entity.getVaMasterFk());
        dto.setDocumentName(entity.getDocumentName());
        dto.setDocumentTypeLookup(lookupRepository.findByLookupCode(entity.getDocumentTypeLookup())
          .map(Lookup::getLookupValue).orElse("Unknown Type"));
        dto.setDocumentExtensionLookup(lookupRepository.findByLookupCode(entity.getDocumentExtensionLookup())
          .map(Lookup::getLookupValue).orElse("Unknown Extension"));
        dto.setDocumentPath(entity.getDocumentPath());
        dto.setSizeInMb(entity.getSizeInMb());
        dto.setRemark(entity.getRemark());
        dto.setNoOfPage(entity.getNoOfPage());
        dto.setUploadBy(entity.getUploadBy());
        dto.setUploadedOn(entity.getUpdateTimestamp() != null
          ? entity.getUpdateTimestamp().toString()
          : null);
        return dto;
      })
      .filter(Objects::nonNull)
      .collect(Collectors.toList());

    log.info("Mapped {} documents to DTOs", dtos.size());

    // If search query is present, filter the DTOs and create a new PageImpl with correct total
    if (searchQuery != null && !searchQuery.trim().isEmpty()) {
      List<DocumentDetailResponseDTO> filtered = SearchUtils.fuzzySearch(dtos, searchQuery);
      int pageNum = paginationParams.getPageNumber();
      int size = paginationParams.getPageSize();
      int start = Math.min(pageNum * size, filtered.size());
      int end = Math.min(start + size, filtered.size());
      List<DocumentDetailResponseDTO> paged = filtered.subList(start, end);
      return new PageImpl<>(paged, pageRequest, filtered.size());
    }

    // Otherwise, return the mapped DTOs as a page, preserving original pagination
    return new PageImpl<>(dtos, pageRequest, page.getTotalElements());
  }

  @Override
  public ResponseEntity<byte[]> exportToExcel(List<AdditionalDocumentResponseDTO> bodDocumentResponses) {
    try {
      // Validate input
      if (bodDocumentResponses == null) {
        bodDocumentResponses = new ArrayList<>();
      }

      try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
        Sheet sheet = workbook.createSheet("Assessment_report");

        // Header
        createExcelHeader(sheet);

        // Data
        int rowIdx = 1;
        for (AdditionalDocumentResponseDTO bodDocumentResponse : bodDocumentResponses) {
          if (bodDocumentResponse == null) {
            continue; // Skip null responses
          }
          createExcelDataRow(sheet, rowIdx++, bodDocumentResponse);
        }

        workbook.write(out);
        byte[] excelData = out.toByteArray();

        return ResponseEntity.ok()
          .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Assessment_report.xlsx")
          .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
          .body(excelData);
      }
    } catch (IOException e) {
      log.error("IO error occurred while exporting to Excel", e);
      throw new ServiceException(
        MessageConstant.UNEXPECTED_ERROR,
        messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
        ErrorConstant.CATEGORY.BV,
        ErrorConstant.SEVERITY.I
      );
    } catch (Exception e) {
      log.error("Unexpected error occurred while exporting to Excel", e);
      throw new ServiceException(
        MessageConstant.UNEXPECTED_ERROR,
        messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
        ErrorConstant.CATEGORY.BV,
        ErrorConstant.SEVERITY.I
      );
    }
  }


  private void createExcelHeader(Sheet sheet) {
    Row headerRow = sheet.createRow(0);
    headerRow.createCell(0).setCellValue("Document Name");
    headerRow.createCell(1).setCellValue("Document Type");
    headerRow.createCell(2).setCellValue("Uploaded On");
    headerRow.createCell(3).setCellValue("File Size (MB)");
  }

  private void createExcelDataRow(Sheet sheet, int rowIdx, AdditionalDocumentResponseDTO bodDocumentResponse) {
    Row row = sheet.createRow(rowIdx);
    row.createCell(0).setCellValue(Optional.ofNullable(bodDocumentResponse.getDocName()).orElse(""));
    row.createCell(1).setCellValue(Optional.ofNullable(bodDocumentResponse.getDocType()).orElse(""));
    row.createCell(2).setCellValue(Optional.ofNullable(bodDocumentResponse.getUploadedOn()).orElse(""));
    row.createCell(3).setCellValue(Optional.ofNullable(bodDocumentResponse.getFileSize()).orElse(0.0));
  }


}
