/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.entity;

import in.gov.gem.app.vendorassessment.dto.response.QuestionnaireResponse;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
  public class Question {
    private Long id;
    private String questionText;
    private String questionType;
    private boolean isRequired;
    private String associatedInfoMessage;
    private String subHeading; // Optional sub-heading for the question

    // Storing category ID instead of object to avoid circular dependencies in simple in-memory repo
    private Long categoryId;
    private Category category; // Transient field for convenience, set when retrieved

    private List<Document> documents = new ArrayList<>();
    private List<QuestionnaireResponse> responses = new ArrayList<>();

  public Question(Long id, String text, String type,String associatedInfoMessage,String subHeading,boolean isRequired) {
    this.id = id;
    this.questionText = text;
    this.questionType = type;
    this.associatedInfoMessage = associatedInfoMessage;
    this.subHeading = subHeading;
    this.isRequired = isRequired;

  }

  public Question() {

  }

    public Question(long l) {
    this.id = l;
    }
}



