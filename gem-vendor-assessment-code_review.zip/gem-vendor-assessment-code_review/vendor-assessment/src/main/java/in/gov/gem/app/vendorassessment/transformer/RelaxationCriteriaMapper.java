
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.transformer;



import in.gov.gem.app.vendorassessment.dto.response.LicenseCertificateDetailResponseDTO;
import in.gov.gem.app.vendorassessment.domain.entity.VaRelaxationExemptionEntity;
import org.springframework.stereotype.Component;

/**
 * The type Relaxation criteria mapper.
 */
@Component
public class RelaxationCriteriaMapper
{
  /**
   * To license certificate detail license certificate detail response dto.
   *
   * @param exemption the exemption
   * @return the license certificate detail response dto
   */
  public LicenseCertificateDetailResponseDTO toLicenseCertificateDetail(VaRelaxationExemptionEntity exemption) {
    LicenseCertificateDetailResponseDTO detail = new LicenseCertificateDetailResponseDTO();
    //detail.setCertificateNumber(exemption.getLicenseDetail());
    detail.setType(exemption.getRelaxationTypeLookup());
    detail.setIssuingAuthority(exemption.getIssuingAuthority());
    detail.setExpiryDate(exemption.getExpiryDate());
    detail.setStatus(exemption.getStatusLookup());
    return detail;
  }

}
