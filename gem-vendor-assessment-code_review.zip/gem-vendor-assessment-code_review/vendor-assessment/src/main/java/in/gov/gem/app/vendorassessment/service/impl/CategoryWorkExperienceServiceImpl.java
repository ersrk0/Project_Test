
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;


import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.domain.entity.CategoryWorkExperience;
import in.gov.gem.app.vendorassessment.service.ICategoryWorkExperienceService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Implementation of the WorkExperienceService interface.
 * Uses an in-memory map to store work experience data.
 */
@Service
public class CategoryWorkExperienceServiceImpl implements ICategoryWorkExperienceService {

  private final Map<String, CategoryWorkExperience> workExperienceStore = new ConcurrentHashMap<>();
  private final AtomicLong idCounter = new AtomicLong();
    private final MessageUtility messageUtility;

  public CategoryWorkExperienceServiceImpl(MessageUtility messageUtility) {
    this.messageUtility = messageUtility;
  }

  /**
   * Creates a new work experience entry.
   * @param workExperience The work experience object to create.
   * @return The created work experience with its ID.
   */
  @Override
  public CategoryWorkExperience createWorkExperience(CategoryWorkExperience workExperience) {
    if (workExperience == null) {
      throw new ServiceException(
              MessageConstant.INVALID_WORK_EXPERIENCE,
              messageUtility.getMessage(MessageConstant.INVALID_WORK_EXPERIENCE),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.I
      );
    }
    String newId = String.valueOf(idCounter.incrementAndGet());
    workExperience.setId(newId);
    workExperienceStore.put(newId, workExperience);
    return workExperience;
  }


  /**
   * Retrieves a work experience by its ID.
   * @param id The ID of the work experience.
   * @return An Optional containing the work experience if found.
   */
  @Override
  public Optional<CategoryWorkExperience> getWorkExperienceById(String id) {

    if (id == null || id.isEmpty()) {
      throw new ServiceException(
              MessageConstant.WORK_EXPERIENCE_ID_NOT_FOUND,
              messageUtility.getMessage(MessageConstant.WORK_EXPERIENCE_ID_NOT_FOUND),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.I
      );
    }
    return Optional.ofNullable(workExperienceStore.get(id));
  }

  /**
   * Retrieves all work experience entries.
   * @return A list of all work experiences.
   */
  @Override
  public List<CategoryWorkExperience> getAllWorkExperiences() {
    return new ArrayList<>(workExperienceStore.values());
  }

  /**
   * Updates an existing work experience.
   * @param id The ID of the work experience to update.
   * @param workExperience The work experience object with updated details.
   * @return An Optional containing the updated work experience if found.
   */
  @Override
  public Optional<CategoryWorkExperience> updateWorkExperience(String id, CategoryWorkExperience workExperience) {
    if (id == null || id.isEmpty() || workExperience == null) {
      throw new ServiceException(
              MessageConstant.INVALID_WORK_EXPERIENCE,
              messageUtility.getMessage(MessageConstant.INVALID_WORK_EXPERIENCE),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.I
      );
    }

    if (workExperienceStore.containsKey(id)) {
      workExperience.setId(id);
      workExperienceStore.put(id, workExperience);
      return Optional.of(workExperience);
    }
    return Optional.empty();
  }


  /**
   * Deletes a work experience by its ID.
   * @param id The ID of the work experience to delete.
   * @return True if deleted, false otherwise.
   */
  @Override
  public boolean deleteWorkExperience(String id) {
    if (id == null || id.isEmpty()) {
      throw new ServiceException(
              MessageConstant.WORK_EXPERIENCE_ID_NOT_FOUND,
              messageUtility.getMessage(MessageConstant.WORK_EXPERIENCE_ID_NOT_FOUND),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.I
      );
    }

    if (workExperienceStore.containsKey(id)) {
      workExperienceStore.remove(id);
      return true;
    }
    return false;
  }


  /**
   * Maps a list of category IDs to a specific work experience.
   * Overwrites any existing mappings for that work experience.
   * @param workExperienceId The ID of the work experience.
   * @param categoryIds A list of category IDs to map.
   * @return An Optional containing the updated work experience if found.
   */
  @Override
  public Optional<CategoryWorkExperience> mapCategoriesToWorkExperience(String workExperienceId, List<String> categoryIds) {
    if (workExperienceId == null || workExperienceId.isEmpty()) {
      throw new ServiceException(
              MessageConstant.WORK_EXPERIENCE_ID_NOT_FOUND,
              messageUtility.getMessage(MessageConstant.WORK_EXPERIENCE_ID_NOT_FOUND),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.I
      );
    }

    if (categoryIds == null) {
      throw new ServiceException(
              MessageConstant.INVALID_CATEGORY_IDS,
              messageUtility.getMessage(MessageConstant.INVALID_CATEGORY_IDS),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.I
      );
    }

    return Optional.ofNullable(workExperienceStore.get(workExperienceId))
            .map(workExperience -> {
              workExperience.setMappedCategoryIds(new ArrayList<>(categoryIds));
              return workExperience;
            });
  }


  /**
   * Retrieves the mapped category IDs for a specific work experience.
   * @param workExperienceId The ID of the work experience.
   * @return A list of category IDs mapped to the work experience.
   */
  @Override
  public List<String> getMappedCategoryIds(String workExperienceId) {
    return Optional.ofNullable(workExperienceStore.get(workExperienceId))
        .map(CategoryWorkExperience::getMappedCategoryIds)
        .orElse(new ArrayList<>());
  }
}

