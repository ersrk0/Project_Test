
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.repository.LookupRepository;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.domain.entity.VaRelaxationExemptionEntity;
import in.gov.gem.app.vendorassessment.domain.repository.VendorRelaxationExemptionRepository;
import in.gov.gem.app.vendorassessment.dto.response.CriteriaTypeResponseDTO;
import in.gov.gem.app.vendorassessment.service.IVaRelaxationExemptionService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;


/**
 * Implementation of the VaRelaxationExemptionService.
 * This class handles the business logic for VaRelaxationExemption entities.
 * It simulates interaction with a repository for data operations.
 */
@Service
@AllArgsConstructor
@Slf4j
public class VaRelaxationExemptionService implements IVaRelaxationExemptionService
{
  // In-memory store to simulate a database repository
  private  final VendorRelaxationExemptionRepository vendorRelaxationExemptionRepository;
  private final MessageUtility messageUtility;
  private final LookupRepository lookupRepository;

  /**
   * Creates a new VaRelaxationExemptionEntity.
   * Assigns a unique ID and stores it.
   * @param entity The entity to be created.
   * @return The created entity with its assigned ID.
   */
  @Override
  public VaRelaxationExemptionEntity create(VaRelaxationExemptionEntity entity) {
    vendorRelaxationExemptionRepository.save(entity);
    return entity;
  }

  /**
   * Retrieves a VaRelaxationExemptionEntity by its ID.
   * @param id The ID of the entity to retrieve.
   * @return An Optional containing the entity if found, or empty if not.
   */
  @Override
  public Optional<VaRelaxationExemptionEntity> getById(Long id) {

    return vendorRelaxationExemptionRepository.findById(id);
  }

  /**
   * Retrieves all VaRelaxationExemptionEntity instances associated with a specific vendor assessment.
   * @param vendorAssessmentFk The foreign key referencing the vendor assessment.
   * @return A list of entities matching the vendor assessment ID.
   */
  @Override
  public List<VaRelaxationExemptionEntity> getAllByVaMasterFk(Long vendorAssessmentFk) {
    return vendorRelaxationExemptionRepository.findByVendorAssessmentFk(String.valueOf(vendorAssessmentFk));
  }

  @Override
  public List<CriteriaTypeResponseDTO> getAllCriteriaByLookUpCode(String lookUpCode){
    log.info("Fetching all criteria types for lookup code: {}", lookUpCode);
    List<Lookup> lookups= lookupRepository.findByLookupName(lookUpCode);
    if (lookups.isEmpty()) {
      throw new ServiceException(MessageConstant.LOOKUP_NOT_FOUND,
        messageUtility.getMessage(MessageConstant.LOOKUP_NOT_FOUND),
        ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
    }
    return lookups.stream()
      .map(lookup -> new CriteriaTypeResponseDTO(lookup.getLookupCode(), lookup.getLookupValue()))
      .toList();

  }

  /**
   * Updates an existing VaRelaxationExemptionEntity.
   * @param id The ID of the entity to update.
   * @param entity The entity with updated details.
   * @return The updated entity.
   * @throws IllegalArgumentException if the entity with the given ID is not found.
   */
  @Override
  public VaRelaxationExemptionEntity update(Long id, VaRelaxationExemptionEntity entity) {
    Optional<VaRelaxationExemptionEntity> existingEntityOpt = getById(id);
    if (existingEntityOpt.isPresent()) {
      VaRelaxationExemptionEntity existingEntity = existingEntityOpt.get();
      // Update fields (excluding ID which should not change)
      existingEntity.setLicenseDetail(entity.getLicenseDetail());
      existingEntity.setRelaxationTypeLookup(entity.getRelaxationTypeLookup());
      existingEntity.setExpiryDate(entity.getExpiryDate());
      existingEntity.setStatusLookup(entity.getStatusLookup());
      existingEntity.setIssuingAuthority(entity.getIssuingAuthority());
      existingEntity.setExpiredAt(entity.getExpiredAt());
      existingEntity.setBriefcaseFk(entity.getBriefcaseFk());
      // vendorAssessmentFk is typically not updated here, but if needed:
      //existingEntity.setVaMasterFk(entity.getVaMasterFk());
      return existingEntity;
    } else {
      throw new IllegalArgumentException("VaRelaxationExemptionEntity with ID " + id + " not found.");
    }
  }

  /**
   * Deletes a VaRelaxationExemptionEntity by its ID.
   * @param id The ID of the entity to delete.
   * @return true if the entity was successfully deleted, false otherwise.
   */
  @Override
  public boolean delete(Long id) {
    log.debug("Deactivating RelaxationExemption with id: {}", id);
    VaRelaxationExemptionEntity vaRelaxationExemption = vendorRelaxationExemptionRepository.findById(id)
      .orElseThrow(() -> new ServiceException(MessageConstant.VA_RELAXATION_EXEMPTION_NOT_FOUND,
        messageUtility.getMessage(MessageConstant.VA_RELAXATION_EXEMPTION_NOT_FOUND),
        ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I));

    if (!vaRelaxationExemption.isDeleted()) {
      vaRelaxationExemption.setDeleted(true);
      vaRelaxationExemption.setDeletedAt(Instant.now());
      vendorRelaxationExemptionRepository.save(vaRelaxationExemption);

      log.info("RelaxationExemption with relaxationExemptionId: {} successfully deactivated", id);

      return true;
    }

    log.error("RelaxationExemption with relaxationExemptionId: {} is already inactive", id);
    throw new ServiceException(MessageConstant.VA_RELAXATION_EXEMPTION_ALREADY_INACTIVE,
      messageUtility.getMessage(MessageConstant.VA_RELAXATION_EXEMPTION_ALREADY_INACTIVE),
      ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);

  }




}
