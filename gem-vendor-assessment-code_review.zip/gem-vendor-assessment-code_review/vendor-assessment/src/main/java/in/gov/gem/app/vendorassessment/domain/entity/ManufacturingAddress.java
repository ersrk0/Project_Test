/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.entity;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class ManufacturingAddress {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String officeName;        // Office Name
  private String officeAddress;     // Office Address
  private String officeType;        // Office Type
  private String contactNumber;     // Contact Number
  private String emailId;           // Email ID
  private String gstinNo;           // GSTIN No.
  private String assessAs;          // Assess As
  private String action;

  @Column(name="seller_fk")
  private Long sellerFk;

  // Getters and Setters
}
