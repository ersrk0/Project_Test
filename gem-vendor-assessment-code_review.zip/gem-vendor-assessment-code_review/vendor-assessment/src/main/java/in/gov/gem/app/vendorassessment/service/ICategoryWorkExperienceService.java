
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service;


import in.gov.gem.app.vendorassessment.domain.entity.CategoryWorkExperience;

import java.util.List;
import java.util.Optional;

/**
 * Interface for the Work Experience Service layer.
 * Defines business operations for Work Experiences.
 */
public interface ICategoryWorkExperienceService {

  /**
   * Creates a new work experience entry.
   * @param workExperience The work experience object to create.
   * @return The created work experience with its ID.
   */
  CategoryWorkExperience createWorkExperience(CategoryWorkExperience workExperience);

  /**
   * Retrieves a work experience by its ID.
   * @param id The ID of the work experience.
   * @return An Optional containing the work experience if found.
   */
  Optional<CategoryWorkExperience> getWorkExperienceById(String id);

  /**
   * Retrieves all work experience entries.
   * @return A list of all work experiences.
   */
  List<CategoryWorkExperience> getAllWorkExperiences();

  /**
   * Updates an existing work experience.
   * @param id The ID of the work experience to update.
   * @param workExperience The work experience object with updated details.
   * @return An Optional containing the updated work experience if found.
   */
  Optional<CategoryWorkExperience> updateWorkExperience(String id, CategoryWorkExperience workExperience);

  /**
   * Deletes a work experience by its ID.
   * @param id The ID of the work experience to delete.
   * @return True if deleted, false otherwise.
   */
  boolean deleteWorkExperience(String id);

  /**
   * Maps a list of category IDs to a specific work experience.
   * @param workExperienceId The ID of the work experience.
   * @param categoryIds A list of category IDs to map.
   * @return An Optional containing the updated work experience if found.
   */
  Optional<CategoryWorkExperience> mapCategoriesToWorkExperience(String workExperienceId, List<String> categoryIds);

  /**
   * Retrieves the mapped category IDs for a specific work experience.
   * @param workExperienceId The ID of the work experience.
   * @return A list of category IDs mapped to the work experience.
   */
  List<String> getMappedCategoryIds(String workExperienceId);
}

