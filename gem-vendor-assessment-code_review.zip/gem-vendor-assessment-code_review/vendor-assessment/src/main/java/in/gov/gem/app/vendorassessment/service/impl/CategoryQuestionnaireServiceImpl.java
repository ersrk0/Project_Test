
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;


import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.utility.MessageUtility;

import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.domain.entity.Category;
import in.gov.gem.app.vendorassessment.domain.entity.Question;
import in.gov.gem.app.vendorassessment.domain.repository.CategoryRepository;
import in.gov.gem.app.vendorassessment.domain.repository.QuestionRepository;
import in.gov.gem.app.vendorassessment.domain.repository.QuestionnaireResponseRepository;
import in.gov.gem.app.vendorassessment.dto.response.QuestionnaireResponse;
import in.gov.gem.app.vendorassessment.service.IQuestionnaireService;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
import static in.gov.gem.app.vendorassessment.constant.ApplicationConstant.DEFAULT_QUESTIONS;


@Service
public class CategoryQuestionnaireServiceImpl implements IQuestionnaireService {


  private final AtomicLong questionIdCounter = new AtomicLong(0);
  private final MessageUtility messageUtility;

  private final QuestionRepository questionRepository;
  private final QuestionnaireResponseRepository responseRepository;
  private final CategoryRepository categoryRepository;

  @PostConstruct
  public void initDefaultQuestions() {
    DEFAULT_QUESTIONS.forEach(q ->
            addQuestion(q[0], q[1], q[2], q[3])
    );
  }

  // Helper method to add questions, assigning a unique ID
  private void addQuestion(String text, String type,String associatedInfoMessage, String subHeading) {
    Long id = questionIdCounter.incrementAndGet();
    questionRepository.save(new Question(id, text, type,associatedInfoMessage,
            subHeading,true));
  }

  public CategoryQuestionnaireServiceImpl(MessageUtility messageUtility, QuestionRepository questionRepository,
                                  QuestionnaireResponseRepository responseRepository,
                                  CategoryRepository categoryRepository) {
      this.messageUtility = messageUtility;
      this.questionRepository = questionRepository;
    this.responseRepository = responseRepository;
    this.categoryRepository = categoryRepository;
  }

  @Override
  public List<Question> getQuestionsForCategory(Long categoryId) {
      return questionRepository.findAll();
  }

  @Override
  public Optional<Question> getQuestionById(Long questionId) {
      return questionRepository.findById(questionId);
  }

  @Override
  public List<QuestionnaireResponse> getResponsesForCategory(Long categoryId) {
      // You might want to fetch and set the Question/Category objects here if needed for further processing
    return responseRepository.findByCategoryId(categoryId);
  }

  @Override
  public QuestionnaireResponse saveOrUpdateResponse(Long categoryId, Long questionId, String answer) {
    Optional<QuestionnaireResponse> existingResponse = responseRepository.findByCategoryIdAndQuestionId(categoryId, questionId);

    QuestionnaireResponse response;
    if (existingResponse.isPresent()) {
      response = existingResponse.get();
      response.setAnswer(answer);
      response.setResponseDate(LocalDateTime.now());
    } else {
      response = new QuestionnaireResponse();
      response.setCategoryId(categoryId);
      response.setQuestionId(questionId);
      response.setAnswer(answer);
      response.setResponseDate(LocalDateTime.now());
    }
    return responseRepository.save(response);
  }


  @Override
  public Question saveQuestion(Long categoryId, Question question) {
    Category category = categoryRepository.findById(categoryId)
            .orElseThrow(() -> new ServiceException(
            MessageConstant.CATEGORY_NOT_FOUND,
            messageUtility.getMessage(MessageConstant.CATEGORY_NOT_FOUND),
            ErrorConstant.CATEGORY.BV,
            ErrorConstant.SEVERITY.I
    ));

    question.setCategoryId(categoryId);
    question.setCategory(category); // For convenience (transient field)

    return questionRepository.save(question);
  }

  @Override
  public void deleteQuestion(Long questionId) {
       questionRepository.deleteById(questionId);
  }
}
