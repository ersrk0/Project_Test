
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.request.VAOrganizationAddressRequestDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Provides APIs for managing manufacturing addresses and related lookups.

 */
@Tag(name = "Manufacturing Address", description = "APIs for managing manufacturing addresses and related lookups")
@RestController
@RequestMapping("/v1")
public interface IManufacturingAddressController
{

  /**
   * Fetches location details by location code.
   *
   * @param paginationParams pagination parameters
   * @param locationCode     the location code
   * @param languageCode     the language code
   * @return the API response with location details
   */
  @Operation(
    summary = "Get Location",
    description = "Fetches location details by location code.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "locationCode", description = "Location code", in = ParameterIn.QUERY, required = true)
  @Parameter(name = "Accept-Language", description = "Language code", in = ParameterIn.HEADER, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/location")
  ResponseEntity<APIResponse<Object>> getLocation(
    PaginationParams paginationParams,
    @RequestParam String locationCode,
    @Valid @RequestHeader(name = "Accept-Language") String languageCode
  );

  /**
   * Fetches pincode details by location code.
   *
   * @param paginationParams pagination parameters
   * @param locationCode     the location code
   * @param languageCode     the language code
   * @return the API response with pincode details
   */
  @Operation(
    summary = "Get Pincode",
    description = "Fetches pincode details by location code.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "locationCode", description = "Location code", in = ParameterIn.QUERY, required = true)
  @Parameter(name = "Accept-Language", description = "Language code", in = ParameterIn.HEADER, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/pincode")
  ResponseEntity<APIResponse<Object>> getPincode(
    PaginationParams paginationParams,
    @RequestParam String locationCode,
    @Valid @RequestHeader(name = "Accept-Language") String languageCode
  );

  /**
   * Fetches the list of countries.
   *
   * @param paginationParams pagination parameters
   * @param languageCode     the language code
   * @return the API response with countries
   */
  @Operation(
    summary = "Get Countries",
    description = "Fetches the list of countries.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "Accept-Language", description = "Language code", in = ParameterIn.HEADER, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/countries")
  ResponseEntity<APIResponse<Object>> getCountries(
    PaginationParams paginationParams,
    @Valid @RequestHeader(name = "Accept-Language") String languageCode
  );

  /**
   * Saves a new manufacturing address.
   *
   * @param vaOrganizationAddressDTO the address DTO
   * @return the API response
   */
  @Operation(
    summary = "Save Manufacturing Address",
    description = "Saves a new manufacturing address.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/vendor/manufacturing-address")
  ResponseEntity<APIResponse<Object>> saveManufacturingAddress(
    @RequestBody VAOrganizationAddressRequestDTO vaOrganizationAddressDTO
  );

  /**
   * Saves an assessment as a manufacturing address.
   *
   * @param vaOrganizationAddressDTO the address DTO
   * @param vaNumber                 the VA number
   * @return the API response
   */
  @Operation(
    summary = "Save Assess As Manufacturing Address",
    description = "Saves an assessment as a manufacturing address.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaNumber", description = "VA Number", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/vendor/saveAssessAs/manufacturing-address")
  ResponseEntity<APIResponse<Object>> saveAssessAsManufacturingAddress(
    @RequestBody VAOrganizationAddressRequestDTO vaOrganizationAddressDTO,
    @RequestParam String vaNumber
  );

  /**
   * Saves a vendor seller manufacturing address.
   *
   * @param vaOrganizationAddressDTO the address DTO
   * @param vaNumber                 the VA number
   * @return the API response
   */
  @Operation(
    summary = "Save Vendor Seller Manufacturing Address",
    description = "Saves a vendor seller manufacturing address.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaNumber", description = "VA Number", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/vendor/seller/manufacturing-address")
  ResponseEntity<APIResponse<Object>> saveVendorSellerManufacturingAddress(
    @RequestBody VAOrganizationAddressRequestDTO vaOrganizationAddressDTO,
    @RequestParam String vaNumber
  );

  /**
   * Fetches manufacturing address by organization detail FK.
   *
   * @param vaOrganizationDetailFk the organization detail FK
   * @return the API response
   */
  @Operation(
    summary = "Get Manufacturing Address",
    description = "Fetches manufacturing address by organization detail FK.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaOrganizationDetailFk", description = "Organization Detail FK", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/vendor/manufacturing-address")
  ResponseEntity<APIResponse<Object>> getManufacturingAddress(
    @RequestParam Long vaOrganizationDetailFk
  );

  /**
   * Fetches paginated manufacturing addresses by organization detail FK.
   *
   * @param vaOrganizationDetailFk the organization detail FK
   * @param paginationParams       pagination parameters
   * @return the API response
   */
  @Operation(
    summary = "Get Paginated Manufacturing Address",
    description = "Fetches paginated manufacturing addresses by organization detail FK.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaOrganizationDetailFk", description = "Organization Detail FK", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/vendor/pagination/manufacturing-address")
  ResponseEntity<APIResponse<Object>> getManufactureAddress(
    @RequestParam Long vaOrganizationDetailFk,
    PaginationParams paginationParams
  );

  /**
   * Fetches master manufacturing address by master FK.
   *
   * @param vaMasterFk the master FK
   * @return the API response
   */
  @Operation(
    summary = "Get Master Manufacturing Address",
    description = "Fetches master manufacturing address by master FK.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaMasterFk", description = "Master FK", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/vendor/master/manufacturing-address")
  ResponseEntity<APIResponse<Object>> getManufactureMasterAddress(
    @RequestParam Long vaMasterFk
  );

  /**
   * Fetches paginated master manufacturing addresses by master FK.
   *
   * @param vaMasterFk       the master FK
   * @param paginationParams pagination parameters
   * @return the API response
   */
  @Operation(
    summary = "Get Master Paging Manufacturing Address",
    description = "Fetches paginated master manufacturing addresses by master FK.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaMasterFk", description = "Master FK", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/vendor/masterpaging/manufacturing-address")
  ResponseEntity<APIResponse<Object>> getManufactureMasterPagingAddress(
    @RequestParam Long vaMasterFk,
    PaginationParams paginationParams
  );

  /**
   * Fetches manufacturing address by pre ID.
   *
   * @param id the pre ID
   * @return the API response
   */
  @Operation(
    summary = "Get Manufacturing PreId Address",
    description = "Fetches manufacturing address by pre ID.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "id", description = "Pre ID", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/vendor/PreId/manufacturing-address")
  ResponseEntity<APIResponse<Object>> getManufacturingPreIdAddress(
    @RequestParam Long id
  );

  /**
   * Fetches new manufacturing address by pre ID.
   *
   * @param id the pre ID
   * @return the API response
   */
  @Operation(
    summary = "Get New Manufacturing PreId Address",
    description = "Fetches new manufacturing address by pre ID.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "id", description = "Pre ID", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/vendor/NewPreId/manufacturing-address")
  ResponseEntity<APIResponse<Object>> NewgetManufacturingPreIdAddress(
    @RequestParam Long id
  );

  /**
   * Deletes manufacturing address by pre ID.
   *
   * @param id the pre ID
   * @return the API response
   */
  @Operation(
    summary = "Delete Manufacturing PreId Address",
    description = "Deletes manufacturing address by pre ID.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "id", description = "Pre ID", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @DeleteMapping("/vendor/preId/manufacturing-address")
  ResponseEntity<APIResponse<Object>> deleteManufacturingPreAddress(
    @RequestParam Long id
  );

  /**
   * Updates manufacturing address by pre ID.
   *
   * @param id      the pre ID
   * @param request the address DTO
   * @return the API response
   */
  @Operation(
    summary = "Update Manufacturing PreId Address",
    description = "Updates manufacturing address by pre ID.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "id", description = "Pre ID", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PutMapping("/vendor/preId/manufacturing-address")
  ResponseEntity<APIResponse<Object>> updateManufacturingPreIdAddress(
    @RequestParam Long id,
    @RequestBody VAOrganizationAddressRequestDTO request
  );
}
 