
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */package in.gov.gem.app.vendorassessment.service.impl;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;

import in.gov.gem.app.vendorassessment.dto.enums.NonComplianceStatus;
import in.gov.gem.app.service.core.repository.LookupRepository;
import in.gov.gem.app.vendorassessment.dto.response.BODDocumentNewResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.BODDocumentResponseDTO;

import in.gov.gem.app.utility.CustomLoggerFactory;
import in.gov.gem.app.vendorassessment.domain.entity.NCClosureEntity;
import in.gov.gem.app.vendorassessment.domain.entity.VAMasterEntity;
import in.gov.gem.app.vendorassessment.domain.entity.VaDocumentDetailEntity;
import in.gov.gem.app.vendorassessment.domain.repository.DocumentDetailRepository;
import in.gov.gem.app.vendorassessment.domain.repository.NonComplianceRepository;
import in.gov.gem.app.vendorassessment.domain.repository.VendorAssessmentRepository;
import in.gov.gem.app.vendorassessment.service.IBODService;
import lombok.AllArgsConstructor;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.Instant;
import java.util.*;

import static in.gov.gem.app.vendorassessment.constant.LookupConstants.*;
import static in.gov.gem.app.vendorassessment.constant.MessageConstant.Unknown;

/**
 * The type Bod service.
 */
@Service
@AllArgsConstructor
public class BODService implements IBODService {

    private VendorAssessmentRepository vendorAssessmentRepository;
    private NonComplianceRepository nonComplianceRepository;
    private DocumentDetailRepository documentDetailRepository;
    private LookupRepository lookupRepository;
    private final MessageUtility messageUtility;

    private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(BODService.class);

    @Override
    public List<BODDocumentNewResponseDTO> getRequiredDocuments(Long vendorAssessmentId) {
        try {
            Map<String, BODDocumentNewResponseDTO> documentMap = new HashMap<>();

            List<Lookup> lookups = lookupRepository.findByLookupName(NON_COMPLIANCE_STATUS);
            String openLookupCode = null;
            String underReviewLookupCode = null;

            for (Lookup lookup : lookups) {
                if (lookup != null && OPEN.equals(lookup.getLookupValue())) {
                    openLookupCode = lookup.getLookupCode();
                } else if (lookup != null && UNDER_REVIEW.equals(lookup.getLookupValue())) {
                    underReviewLookupCode = lookup.getLookupCode();
                }
            }

            List<String> statuses = new ArrayList<>();
            if (openLookupCode != null) statuses.add(openLookupCode);
            if (underReviewLookupCode != null) statuses.add(underReviewLookupCode);

            List<NCClosureEntity> nonComplianceEntities = nonComplianceRepository.findByVaMasterFkAndStatusLookupIn(vendorAssessmentId, statuses);
            HashSet<String> lookupCodes = new HashSet<>();

            List<Lookup> lookupEntitiesList = lookupRepository.findByLookupName(BOD_DOCUMENTS);
            for (Lookup lookupEntity : lookupEntitiesList) {
                if (lookupEntity != null) {
                    lookupCodes.add(lookupEntity.getLookupCode());
                }
            }

            List<String> expectedAttributes = new ArrayList<>();
            List<Lookup> bodDocumentAttributes = lookupRepository.findByLookupName(BOD_DOCUMENT);
            for (Lookup lookupEntity : bodDocumentAttributes) {
                if (lookupEntity != null) {
                    expectedAttributes.add(lookupEntity.getLookupValue());
                }
            }

            String lookupCode = null;
            List<Lookup> documentGroupLookups = lookupRepository.findByLookupName(DOCUMENTS);
            for (Lookup lookupEntity : documentGroupLookups) {
                if (lookupEntity != null && BOD_DOCUMENTS.equals(lookupEntity.getLookupValue())) {
                    lookupCode = lookupEntity.getLookupCode();
                }
            }

            for (NCClosureEntity nonCompliance : nonComplianceEntities) {
                if (nonCompliance.getEntityAttributeLookup() != null && lookupCode != null &&
                        lookupCode.equals(nonCompliance.getEntityLookup())) {

                    String documentNameLookupCode = nonCompliance.getEntityAttributeLookup();
                    Optional<Lookup> documentNameLookup = lookupRepository.findByLookupCode(documentNameLookupCode);
                    if (documentNameLookup.isEmpty()) {
                        continue;
                    }
                    String documentName = documentNameLookup.get().getLookupValue();

                    String statusLookupCode = nonCompliance.getStatusLookup() != null
                            ? nonCompliance.getStatusLookup()
                            : null;

                    String statusValue = "Unknown";
                    if (statusLookupCode != null) {
                        Optional<Lookup> statusLookup = lookupRepository.findByLookupCode(statusLookupCode);
                        if (statusLookup.isPresent()) {
                            statusValue = statusLookup.get().getLookupValue();
                        }
                    }

                    BODDocumentNewResponseDTO bodDocument = new BODDocumentNewResponseDTO();
                    bodDocument.setDocName(documentName);
                    bodDocument.setNonComplianceStatus(statusValue);
                    documentMap.put(documentName, bodDocument);
                }
            }

            int i=0;
            for (String expectedAttribute : expectedAttributes) {
                if (!documentMap.containsKey(expectedAttribute)) {
                    BODDocumentNewResponseDTO bodDocument = new BODDocumentNewResponseDTO();
                    bodDocument.setDocName(expectedAttribute);
                    bodDocument.setNonComplianceStatus(NonComplianceStatus.OPEN.toString());
                    i++;
                    if(i==7)
                        bodDocument.setNonComplianceStatus(NonComplianceStatus.CLOSED.toString());
                    documentMap.put(expectedAttribute, bodDocument);
                }
            }

            return new ArrayList<>(documentMap.values());
        } catch (Exception e) {
            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
    }

    @Override
    public List<BODDocumentResponseDTO> getMyOrganisationDocuments(Long vaMasterId) {
        try {
            return getDocumentsByLookupValue(ORGANISATION_DOCUMENT, vaMasterId);
        } catch (Exception e) {

            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
    }

    @Override
    public List<BODDocumentResponseDTO> getAuthorizingOemOspDocuments(Long vaMasterId) {
        try {
            return getDocumentsByLookupValue(AUTHORIZING_OEM_OSP_DOCUMENT, vaMasterId);
        } catch (Exception e) {

            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
    }

    @Override
    public List<BODDocumentResponseDTO> getContractManufacturerDocuments(Long vaMasterId) {
        try {
            return getDocumentsByLookupValue(CONTRACT_MANUFACTURER_DOCUMENT, vaMasterId);
        } catch (Exception e) {

            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
    }

    private List<BODDocumentResponseDTO> getDocumentsByLookupValue(String lookupValue, Long vaMasterId) {
        List<BODDocumentResponseDTO> bodDocumentResponses = new ArrayList<>();

        // Find the lookup code for the given lookupValue from "BOD document" lookup name
        String targetLookupCode = null;
        List<Lookup> bodDocumentLookups = Optional.ofNullable(lookupRepository.findByLookupName(BOD_DOCUMENT))
                .orElse(new ArrayList<>());

        for (Lookup lookup : bodDocumentLookups) {
            if (lookup != null && lookupValue.equals(lookup.getLookupValue())) {
                targetLookupCode = lookup.getLookupCode();
                break;
            }
        }

        if (targetLookupCode == null) {

            return bodDocumentResponses;
        }

        // Find documents with the target lookup code in documentTypeLookup
        List<VaDocumentDetailEntity> documentDetails = Optional.ofNullable(
                        documentDetailRepository.findByDocumentTypeLookup(targetLookupCode))
                .orElse(new ArrayList<>());

        for (VaDocumentDetailEntity documentDetail : documentDetails) {
            if (documentDetail.getVaMasterFk() == null || !documentDetail.getVaMasterFk().equals(vaMasterId)) {
                continue; // Skip if the document does not belong to the specified vaMasterId
            }

            BODDocumentResponseDTO bodDocumentResponse = createBODDocumentResponse(documentDetail);

            if (VERIFIED.equalsIgnoreCase(bodDocumentResponse.getStatus())) {

                bodDocumentResponses.add(bodDocumentResponse);
            }
        }

        return bodDocumentResponses;
    }

    /**
     * Extract lookup codes list.
     *
     * @param lookupEntities the lookup entities
     * @return the list
     */
    public List<String> extractLookupCodes(List<Lookup> lookupEntities) {
        List<String> lookupCodes = new ArrayList<>();
        for (Lookup lookupEntity : lookupEntities) {
            if (lookupEntity != null) {
                lookupCodes.add(lookupEntity.getLookupCode());
            }
        }
        return lookupCodes;
    }

    private BODDocumentResponseDTO createBODDocumentResponse(VaDocumentDetailEntity documentDetail) {
        BODDocumentResponseDTO bodDocumentResponse = new BODDocumentResponseDTO();
        bodDocumentResponse.setDocName(documentDetail.getDocumentName());
        bodDocumentResponse.setDocType(
                lookupRepository.findByLookupCode(documentDetail.getDocumentExtensionLookup())
                        .map(Lookup::getLookupValue)
                        .orElse("Unknown Type")
        );
        bodDocumentResponse.setUploadedOn(String.valueOf(documentDetail.getUpdateTimestamp()));
        bodDocumentResponse.setStatus(
                lookupRepository.findByLookupCode(documentDetail.getStatusLookup())
                        .map(Lookup::getLookupValue)
                        .orElse("Unknown Status")
        );
        bodDocumentResponse.setFilePath(
                Optional.ofNullable(documentDetail.getDocumentPath())
                        .orElse("No file path available")
        );
        bodDocumentResponse.setFileSize(
                Optional.ofNullable(documentDetail.getSizeInMb()).orElse(0.0)
        );
        bodDocumentResponse.setBodType(lookupRepository.findByLookupCode(documentDetail.getDocumentTypeLookup())
                .map(Lookup::getLookupValue)
                .orElse("Unknown Type"));
        return bodDocumentResponse;
    }

    @Override
    public void deleteBodDocument(Long vaMasterFk, String docName) {
        try {
            documentDetailRepository.deleteByVaMasterFkAndDocumentName(vaMasterFk, docName);
        } catch (Exception e) {
            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
    }

    @Override
    public ResponseEntity<byte[]> exportToExcel(List<BODDocumentResponseDTO> bodDocumentResponses) {
        try {
            // Validate input
            if (bodDocumentResponses == null) {
                bodDocumentResponses = new ArrayList<>();
            }

            try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                Sheet sheet = workbook.createSheet("Assessment_report");

                // Header
                createExcelHeader(sheet);

                // Data
                int rowIdx = 1;
                for (BODDocumentResponseDTO bodDocumentResponse : bodDocumentResponses) {
                    if (bodDocumentResponse == null) {
                        continue; // Skip null responses
                    }
                    createExcelDataRow(sheet, rowIdx++, bodDocumentResponse);
                }

                workbook.write(out);
                byte[] excelData = out.toByteArray();

                return ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Assessment_report.xlsx")
                        .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                        .body(excelData);
            }
        } catch (IOException e) {
            log.error("IO error occurred while exporting to Excel", e);
            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        } catch (Exception e) {
            log.error("Unexpected error occurred while exporting to Excel", e);
            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
    }

    private void createExcelHeader(Sheet sheet) {
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Document Name");
        headerRow.createCell(1).setCellValue("Document Type");
        headerRow.createCell(2).setCellValue("Uploaded On");
        headerRow.createCell(3).setCellValue("Status");
        headerRow.createCell(4).setCellValue("File Path");
        headerRow.createCell(5).setCellValue("File Size (MB)");
    }

    private void createExcelDataRow(Sheet sheet, int rowIdx, BODDocumentResponseDTO bodDocumentResponse) {
        Row row = sheet.createRow(rowIdx);
        row.createCell(0).setCellValue(Optional.ofNullable(bodDocumentResponse.getDocName()).orElse(""));
        row.createCell(1).setCellValue(Optional.ofNullable(bodDocumentResponse.getDocType()).orElse(""));
        row.createCell(2).setCellValue(Optional.ofNullable(bodDocumentResponse.getUploadedOn()).orElse(""));
        row.createCell(3).setCellValue(Optional.ofNullable(bodDocumentResponse.getStatus()).orElse(""));
        row.createCell(4).setCellValue(Optional.ofNullable(bodDocumentResponse.getFilePath()).orElse(""));
        row.createCell(5).setCellValue(Optional.ofNullable(bodDocumentResponse.getFileSize()).orElse(0.0));
    }

    @Override
    public VaDocumentDetailEntity saveRemarks(String remarks, Long vaMasterId) {
        try {
            VaDocumentDetailEntity documentDetailEntity = new VaDocumentDetailEntity();
            documentDetailEntity.setVaMasterFk(vaMasterId);
            documentDetailEntity.setRemark(remarks);
            documentDetailRepository.save(documentDetailEntity);
            return documentDetailEntity;
        } catch (Exception e) {

            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
    }

    @Override
    public List<BODDocumentResponseDTO> getParentBodDocuments(Long vaMasterId) {
        try {

            return getDocumentsByLookupValue(PARENT_DOCUMENT, vaMasterId);
        } catch (Exception e) {

            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
    }

    @Override
    public List<BODDocumentNewResponseDTO> getUploadedParentBODDocument(Long vaMasterId) {
        try {
            List<BODDocumentNewResponseDTO> bodDocuments = new ArrayList<>();

            // Find Parent BOD documents lookup code
            List<Lookup> lookupEntities = lookupRepository.findByLookupName(DOCUMENTS);
            String docTypeLookupCode = null;
            for (Lookup lookup : lookupEntities) {
                if (PARENT_BOD_DOCUMENTS.equalsIgnoreCase(lookup.getLookupValue())) {
                    docTypeLookupCode = lookup.getLookupCode();
                    break;
                }
            }

            if (docTypeLookupCode == null) {

                return bodDocuments;
            }

            // Get non-compliance status lookup codes for OPEN and UNDER_REVIEW
            List<Lookup> lookups = lookupRepository.findByLookupName(NON_COMPLIANCE_STATUS);
            String openLookupCode = null;
            String underReviewLookupCode = null;

            for (Lookup lookup : lookups) {
                if (lookup != null && OPEN.equals(lookup.getLookupValue())) {
                    openLookupCode = lookup.getLookupCode();
                } else if (lookup != null && UNDER_REVIEW.equals(lookup.getLookupValue())) {
                    underReviewLookupCode = lookup.getLookupCode();
                }
            }

            List<String> statuses = new ArrayList<>();
            if (openLookupCode != null) statuses.add(openLookupCode);
            if (underReviewLookupCode != null) statuses.add(underReviewLookupCode);


            // Get non-compliance entities for the vendor assessment
            List<NCClosureEntity> nonComplianceEntities = nonComplianceRepository.findByVaMasterFkAndStatusLookupIn(vaMasterId, statuses);

            // Create map for quick lookup of non-compliance status by document name

            Map<String, String> nonComplianceStatusMap = new HashMap<>();
            for (NCClosureEntity nonCompliance : nonComplianceEntities) {
                if (nonCompliance.getEntityAttributeLookup() != null && docTypeLookupCode.equals(nonCompliance.getEntityLookup())) {

                    String documentNameLookupCode = nonCompliance.getEntityAttributeLookup();
                    Optional<Lookup> documentNameLookup = lookupRepository.findByLookupCode(documentNameLookupCode);
                    if (documentNameLookup.isEmpty()) {
                        continue;
                    }
                    String documentName = documentNameLookup.get().getLookupValue();

                    String statusLookupCode = nonCompliance.getStatusLookup() != null
                            ? nonCompliance.getStatusLookup()
                            : null;

                    String statusValue = Unknown;
                    if (statusLookupCode != null) {
                        Optional<Lookup> statusLookup = lookupRepository.findByLookupCode(statusLookupCode);
                        if (statusLookup.isPresent()) {
                            statusValue = statusLookup.get().getLookupValue();
                        }
                    }

                    nonComplianceStatusMap.put(documentName, statusValue);
                }
            }

            // Get uploaded document details
            List<VaDocumentDetailEntity> documentDetails = documentDetailRepository.findByVaMasterFkAndDocumentTypeLookup(vaMasterId, docTypeLookupCode);

            for (VaDocumentDetailEntity documentDetail : documentDetails) {
                BODDocumentNewResponseDTO bodDocument = new BODDocumentNewResponseDTO();
                bodDocument.setDocName(documentDetail.getDocumentName());

                // Set non-compliance status - check if document has non-compliance, otherwise default to CLOSED
                String nonComplianceStatus = nonComplianceStatusMap.get(documentDetail.getDocumentName());
                if (nonComplianceStatus != null) {
                    bodDocument.setNonComplianceStatus(nonComplianceStatus);
                } else {
                    bodDocument.setNonComplianceStatus(NonComplianceStatus.CLOSED.toString());
                }

                bodDocuments.add(bodDocument);
            }

            return bodDocuments;
        } catch (Exception e) {

            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
    }

    @Override
    public List<BODDocumentResponseDTO> getLastVerifiedBODDocument(Long sellerID) {
        try {
            List<Optional<VAMasterEntity>> vendorAssessments = fetchVendorAssessments(sellerID);
            Long vendorAssessmentId = getLatestVendorAssessmentId(vendorAssessments);


            if (vendorAssessmentId == null) {
                return Collections.emptyList();
            }

            String verifiedLookupCode = getVerifiedLookupCode();
            if (verifiedLookupCode == null) {
                return Collections.emptyList();
            }

            List<VaDocumentDetailEntity> documentDetailEntityList = fetchDocumentDetails(vendorAssessmentId, verifiedLookupCode);


            List<BODDocumentResponseDTO> lastVerifiedBODDocument = new ArrayList<>();
            for (VaDocumentDetailEntity doc : documentDetailEntityList) {
                BODDocumentResponseDTO response = createBODDocumentResponse(doc);
                lastVerifiedBODDocument.add(response);
            }

            return lastVerifiedBODDocument;
        } catch (Exception e) {

            throw new ServiceException(
                    MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
    }

    private List<Optional<VAMasterEntity>> fetchVendorAssessments(Long sellerID) {
        return vendorAssessmentRepository.findByPvtOrgMasterFk(sellerID);
    }

    private Long getLatestVendorAssessmentId(List<Optional<VAMasterEntity>> vendorAssessments) {
        Long vendorAssessmentId = null;
        Instant createdOn = null;
        for (Optional<VAMasterEntity> assessment : vendorAssessments) {
            if (assessment.isPresent()) {
                if (createdOn == null || createdOn.isBefore(assessment.get().getUpdateTimestamp())) {
                    vendorAssessmentId = assessment.get().getId();
                    createdOn = assessment.get().getCreatedTimestamp();
                }
            }
        }
        return vendorAssessmentId;
    }

    private String getVerifiedLookupCode() {
        List<Lookup> lookupEntities = lookupRepository.findByLookupName(STATUS);
        for (Lookup lookup : lookupEntities) {
            if (VERIFIED.equalsIgnoreCase(lookup.getLookupValue())) {
                return lookup.getLookupCode();
            }
        }
        return null;
    }

    private List<VaDocumentDetailEntity> fetchDocumentDetails(Long vendorAssessmentId, String verifiedLookupCode) {
        return documentDetailRepository.findByVaMasterFkAndStatusLookup(vendorAssessmentId, verifiedLookupCode);
    }


}
