
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;
import in.gov.gem.app.service.dto.APIResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * REST controller interface for vendor document upload and download operations.
 * Provides endpoints for uploading and downloading vendor documents.
 */

@Tag(name = "Vendor Briefcase", description = "APIs for vendor document upload and download")
@SecurityRequirement(name = "bearerAuth")
@RestController
@RequestMapping("/v1/vendor")
public interface IBriefCaseController
{
  /**
   * Uploads one or more documents for the vendor.
   *
   * @param files        the list of files to upload
   * @param documentType the document type header
   * @return the API response with upload result
   */
  @Operation(
    summary = "Upload Document",
    description = "Uploads one or more documents for the vendor.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(
    name = "files",
    description = "List of files to upload",
    required = true
  )
  @Parameter(
    name = "documentType",
    description = "Document type",
    in = ParameterIn.HEADER,
    required = true
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @PostMapping("/upload")
  ResponseEntity<APIResponse<Object>> uploadDocument(
    @RequestPart("files") List<MultipartFile> files,
    @RequestHeader("documentType") String documentType
  );

  /**
   * Downloads a document by file name.
   *
   * @param fileName the file name to download
   * @return the file as a byte array
   */
  @Operation(
    summary = "Download Document",
    description = "Downloads a document by file name.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(
    name = "fileName",
    description = "File name to download",
    in = ParameterIn.QUERY,
    required = true
  )
  @ApiResponse(responseCode = "200", description = "File downloaded successfully")
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized - Invalid or missing token", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/download")
  ResponseEntity<byte[]> downloadDocument(@RequestParam String fileName);
}
 