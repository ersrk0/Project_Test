
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.facade.Impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.dto.response.AssessDescriptionResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.LookupResponseResponseDTO;

import in.gov.gem.app.vendorassessment.facade.IAssessFacade;
import in.gov.gem.app.vendorassessment.service.IAssessService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.*;



/**
 * The type Assess facade.
 */
@Component
@AllArgsConstructor
public class AssessFacade implements IAssessFacade {

    private final MessageUtility messageUtility;
    private final CoreLookupService coreLookupService;

    public LookupResponseResponseDTO getLookupValueByLookupName() {
//            Map<String, Map<String, String>> lookupValue = new HashMap<>();
            Map<String, Map<String, String>> lookupValue = new LinkedHashMap<>();
            List<String> assessName = new ArrayList<>(List.of(ApplicationConstant.PRODUCTS_BASED, ApplicationConstant.SERVICE_BASED, ApplicationConstant.FORWARD_AUCTION_BASED));
            for (String name : assessName) {
//                List<Lookup> type = lookupRepository.findByLookupName(name);
                List<CoreLookupDto> type = coreLookupService.findByLookupName(name)
                        .stream()
                        .sorted(Comparator.comparing(CoreLookupDto::getLookupName))
                        .toList();
                for (CoreLookupDto lookup : type) {
                    String lookupValue1 = lookup.getLookupValue();
                    String lookupCode = lookup.getLookupCode();
                    String name1=name.replace("based","").trim();
                    if (lookupValue.containsKey(name1)) {
                        lookupValue.get(name1).put(lookupValue1, lookupCode);
                    } else {
//                        Map<String, String> lookupMap = new HashMap<>();
                        Map<String, String> lookupMap = new LinkedHashMap<>();
                        lookupMap.put(lookupValue1, lookupCode);
                        lookupValue.put(name1, lookupMap);
                    }
                }
            }
            return LookupResponseResponseDTO.builder()
                    .assess(lookupValue).build();
    }

    public AssessDescriptionResponseDTO getDescriptionByLookupValue(String lookupValue) {

        try {
            List<CoreLookupDto> coreLookupDtos = coreLookupService.findAllByLookupValueIgnoreCase(lookupValue);
            if (coreLookupDtos.isEmpty()) {
                return null;
            }
            CoreLookupDto lookups = coreLookupDtos.getFirst();
            if (lookups == null) {
                throw new ServiceException(MessageConstant.Lookup_NOT_FOUND,
                        messageUtility.getMessage(MessageConstant.Lookup_NOT_FOUND),
                        ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
            }
            AssessDescriptionResponseDTO descriptionDTO = new AssessDescriptionResponseDTO();
            descriptionDTO.setDescription(lookups.getDescription());
            return descriptionDTO;
        } catch(Exception ex){
            throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
                    messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                    ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
        }
    }

    public List<Map<String, String>> fetchQuestionByAssess(String assessCode) {
        List<CoreLookupDto> byLookupValue = coreLookupService.findByLookupName(assessCode);
            List<Map<String, String>> result = new ArrayList<>();
            for (CoreLookupDto lookup : byLookupValue) {
                Map<String, String> map = new HashMap<>();
                String questionCode = lookup.getLookupCode();
                String question = lookup.getDescription();
                map.put(questionCode, question);
                result.add(map);
            }
            return result;
    }
}
