
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.repository;



import in.gov.gem.app.service.core.repository.BaseRepository;
import in.gov.gem.app.vendorassessment.domain.entity.VaDocumentDetailEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * The interface Document detail repository.
 */
@Repository
public interface DocumentDetailRepository extends BaseRepository<VaDocumentDetailEntity, Long> {
  /**
   * Find document name by document type lookup list.
   *
   * @param DocumentTypeLookup the document type lookup
   * @return the list
   */
  List<VaDocumentDetailEntity> findDocumentNameByDocumentTypeLookup(String DocumentTypeLookup);

  /**
   * Find by document type lookup in list.
   *
   * @param lookupCodes the lookup codes
   * @return the list
   */
  List<VaDocumentDetailEntity> findByDocumentTypeLookupIn(List<String> lookupCodes);

  /**
   * Delete by va master fk and document name.
   *
   * @param vaMasterFk the va master fk
   * @param docName    the doc name
   */
  @Transactional
    @Modifying
    @Query("UPDATE VaDocumentDetailEntity d SET d.isDeleted = true WHERE d.vaMasterFk = :vaMasterFk AND d.documentName = :docName")
    void deleteByVaMasterFkAndDocumentName(@Param("vaMasterFk") Long vaMasterFk, @Param("docName") String docName);

  /**
   * Find by va master fk and status lookup list.
   *
   * @param vaMasterFk   the va master fk
   * @param statusLookup the status lookup
   * @return the list
   */
// void deleteByVaMasterFkAndDocumentTypeLookup(Long vaMasterFk, String docTypeLookup);
    List<VaDocumentDetailEntity> findByVaMasterFkAndStatusLookup(Long vaMasterFk, String statusLookup);

  /**
   * Find by document type lookup list.
   *
   * @param targetLookupCode the target lookup code
   * @return the list
   */
  List<VaDocumentDetailEntity> findByDocumentTypeLookup(String targetLookupCode);

  /**
   * Find by va master fk and document type lookup list.
   *
   * @param vaMasterId        the va master id
   * @param docTypeLookupCode the doc type lookup code
   * @return the list
   */
  List<VaDocumentDetailEntity> findByVaMasterFkAndDocumentTypeLookup(Long vaMasterId, String docTypeLookupCode);

  /**
   * Find by va master fk page.
   *
   * @param vaMasterFk  the va master fk
   * @param pageRequest the page request
   * @return the page
   */
  Page<VaDocumentDetailEntity> findByVaMasterFk(Long vaMasterFk, PageRequest pageRequest);

  /**
   * Find by va master fk and status lookup in list.
   *
   * @param vaMasterId  the va master id
   * @param targetCodes the target codes
   * @return the list
   */
  List<VaDocumentDetailEntity> findByVaMasterFkAndStatusLookupIn(Long vaMasterId, List<String> targetCodes);
}