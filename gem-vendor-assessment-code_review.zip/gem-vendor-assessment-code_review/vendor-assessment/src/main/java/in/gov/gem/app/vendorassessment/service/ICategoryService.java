
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service;

import in.gov.gem.app.vendorassessment.domain.entity.Category;
import in.gov.gem.app.vendorassessment.dto.request.CategoryRequestDTO;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface ICategoryService {

  /**
   * Creates a new category.
   *
   * @param category The category domain object to create.
   * @return The created category with its assigned ID.
   */
  Category createCategory(Category category);

  /**
   * Retrieves a category by its ID.
   *
   * @param id The ID of the category.
   * @return An Optional containing the category if found, or empty if not.
   */
  Optional<Category> getCategoryById(String id);



  /**
   * Builds the full hierarchical tree for all categories.
   * @return A list of top-level categories, with their children populated recursively.
   */
  List<Category> buildCategoryTree( Optional<String> type,String vaId);




    Map<String, Object> findSimilarCategoriesByName(List<CategoryRequestDTO> categoryName);

    /**
     * Saves a list of categories.
     *
     * @param categoryRequests The list of category requests to save.
     * @return A list of IDs of the saved categories.
     */
   List<Long> saveCategories(List<Category> categoryRequests);

    List<Category> getSavedCategories(String vaId);

    boolean addCategoryToSaved(Long categoryId, String type, String vaId);

    boolean removeCategoryFromSaved(Long categoryId, String type, String vaId);

    List<Category> searchSavedCategories(String query, String type, String vaId);

    List<Category> searchEligibleCategoriesByCriteria(String type,String name, Long parentId, Boolean exactMatch);


    boolean existsById(Long id,String vaId);
}
