
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.transformer;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.client.IEkycClient;
import in.gov.gem.app.vendorassessment.client.ISellerClient;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.dto.request.GstinClientRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.BusinessPanDetailsResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.GstinClientResponseDTO;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * The type Ekyc transformer.
 */
@Component
@AllArgsConstructor
public class EkycTransformer
{
  private final IEkycClient ekcClient;

  private final ISellerClient sellerClient;;

  /**
   * Verify gstin boolean.
   *
   * @param gstin the gstin
   * @return the boolean
   */
  public boolean verifyGstin(String gstin)
  {
      //String pan= gstin.substring(2, 12);
      GstinClientRequestDTO request = GstinClientRequestDTO.builder()
              .gstin(gstin)
              .action(ApplicationConstant.MICROSERVICE_NAME)
              .projectId(ApplicationConstant.MICROSERVICE_NAME)
              .userTxnId(UUID.randomUUID().toString() + ApplicationConstant.MICROSERVICE_NAME)
              .build();

      ResponseEntity<APIResponse<GstinClientResponseDTO>> gstinresponse = ekcClient.getGstin(request);

    ResponseEntity<APIResponse<BusinessPanDetailsResponseDTO>> panresponse= sellerClient.getPan();


    APIResponse<GstinClientResponseDTO> gstinbody = gstinresponse != null ? gstinresponse.getBody() : null;
    APIResponse<BusinessPanDetailsResponseDTO> panbody = panresponse != null ? panresponse.getBody() : null;

    if (gstinbody != null && panbody != null) {
      return false; // not applicable, as both GSTIN and PAN are present
    } else if (gstinbody != null && panbody == null) {
      return true;  // applicable, as GSTIN is present and PAN is not
    }
    return false;
  }

  /**
   * Verify gstin for manufacturing boolean.
   *
   * @param gstin the gstin
   * @return the boolean
   */
  public boolean verifyGstinForManufacturing(String gstin) {
    GstinClientRequestDTO request = GstinClientRequestDTO.builder()
      .gstin(gstin)
      .action(ApplicationConstant.MICROSERVICE_NAME)
      .projectId(ApplicationConstant.MICROSERVICE_NAME)
      .userTxnId(UUID.randomUUID().toString() + ApplicationConstant.MICROSERVICE_NAME)
      .build();

    ResponseEntity<APIResponse<GstinClientResponseDTO>> gstinresponse = ekcClient.getGstin(request);

    if (gstinresponse != null) {
      APIResponse<GstinClientResponseDTO> body = gstinresponse.getBody();
      if (body != null && body.getData() != null) {
        return true;
      }
    }
    return false;
  }



}

