
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;


import in.gov.gem.app.vendorassessment.facade.IVideoAssessmentFacade;
import in.gov.gem.app.vendorassessment.service.IVideoAssessmentService;
import lombok.AllArgsConstructor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * The type Video assessment facade.
 */
@Component
@AllArgsConstructor
@Slf4j
public class VideoAssessmentFacade implements IVideoAssessmentFacade {

  private IVideoAssessmentService videoAssessmentService;


  public Object getInstructions(String sellerId) {
    return videoAssessmentService.fetchInstructions(sellerId);
  }


  public Object getAppDownloadLink() {
    return videoAssessmentService.fetchAppDownloadLink();
  }


  public Object fetchScheduleAssessment(){
    return videoAssessmentService.fetchScheduleAssessmentDateTime();
  }
}


