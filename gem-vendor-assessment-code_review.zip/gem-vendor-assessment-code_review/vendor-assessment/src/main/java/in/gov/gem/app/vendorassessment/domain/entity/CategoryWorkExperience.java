package in.gov.gem.app.vendorassessment.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Work Experience entry.
 * This entity would typically be mapped to a database table.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryWorkExperience {
  private String id;
  private String organisationType;
  private String organisation;
  private String ministry;
  private String department;
  private String officeZone;
  private String authName;
  private String authContact;
  private String authEmail;
  private double orderValue;
  private double acceptedValue;
  private int orderQuantity;
  private int suppliedQuantity;
  private String itemSupplied;
  private String orderNumber;
  private String contractNumber;


  // This list will store IDs of categories mapped to this work experience.
  // In a real database, this would be a separate many-to-many join table.
  private List<String> mappedCategoryIds = new ArrayList<>();



  public CategoryWorkExperience(String organisationType, String department, String authName, String contractNumber, String authEmail, String itemSupplied, int suppliedQuantity, String department1, String orderNumber, int orderQuantity, double orderValue, String officeZone, String ministry, String organisation, double orderValue1) {
    this.organisationType = organisationType;
    this.department = department;
    this.authName = authName;
    this.contractNumber = contractNumber;
    this.authEmail = authEmail;
    this.itemSupplied = itemSupplied;
    this.suppliedQuantity = suppliedQuantity;
    this.department = department1;
    this.orderNumber = orderNumber;
    this.orderQuantity = orderQuantity;
    this.orderValue = orderValue;
    this.officeZone = officeZone;
    this.ministry = ministry;
    this.organisation = organisation;
    this.orderValue = orderValue1;
  }
}
