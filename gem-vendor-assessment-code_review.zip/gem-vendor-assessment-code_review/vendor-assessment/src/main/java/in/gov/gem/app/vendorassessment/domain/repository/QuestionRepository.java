package in.gov.gem.app.vendorassessment.domain.repository;



import in.gov.gem.app.vendorassessment.domain.entity.Question;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Component
public class QuestionRepository {
    private final Map<Long, Question> questions = new ConcurrentHashMap<>();
    private final AtomicLong idCounter = new AtomicLong();

    public Question save(Question question) {
        if (question.getId() == null) {
            question.setId(idCounter.incrementAndGet());
        }
        questions.put(question.getId(), question);
        return question;
    }

    public Optional<Question> findById(Long id) {
        return Optional.ofNullable(questions.get(id));
    }

    public List<Question> findByCategoryId(Long categoryId) {
        return questions.values().stream()
                .filter(q -> q.getCategoryId() != null && q.getCategoryId().equals(categoryId))
                .collect(Collectors.toList());

    }
    public List<Question> findAll() {
        return questions.values().stream()
                .collect(Collectors.toList());

    }

    public List<Question> findAllById(Iterable<Long> ids) {
        List<Question> foundQuestions = new ArrayList<>();
        for (Long id : ids) {
            Optional.ofNullable(questions.get(id)).ifPresent(foundQuestions::add);
        }
        return foundQuestions;
    }

    public void deleteById(Long id) {
        questions.remove(id);
    }
}

