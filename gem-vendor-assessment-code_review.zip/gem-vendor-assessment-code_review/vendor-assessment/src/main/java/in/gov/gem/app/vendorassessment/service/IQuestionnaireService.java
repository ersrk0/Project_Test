
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service;



import in.gov.gem.app.vendorassessment.domain.entity.Question;
import in.gov.gem.app.vendorassessment.dto.response.QuestionnaireResponse;

import java.util.List;
import java.util.Optional;

public interface IQuestionnaireService {
    List<Question> getQuestionsForCategory(Long categoryId);
    Optional<Question> getQuestionById(Long questionId);
    List<QuestionnaireResponse> getResponsesForCategory(Long categoryId);
    QuestionnaireResponse saveOrUpdateResponse(Long categoryId, Long questionId, String answer);
    Question saveQuestion(Long categoryId, Question question); // Method to save/update a question
    void deleteQuestion(Long questionId);
}
