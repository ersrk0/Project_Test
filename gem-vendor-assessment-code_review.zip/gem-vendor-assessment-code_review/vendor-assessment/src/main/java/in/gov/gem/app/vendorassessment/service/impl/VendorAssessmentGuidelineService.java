
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.vendorassessment.constant.MessageConstant;


import in.gov.gem.app.vendorassessment.dto.response.GuidelineResponseDTO;

import in.gov.gem.app.utility.CustomLoggerFactory;
import in.gov.gem.app.vendorassessment.service.IVendorAssessmentGuidelineService;
import in.gov.gem.app.vendorassessment.utility.LookUpUtility;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * The type Vendor assessment guideline service.
 */
@Service
@AllArgsConstructor
public class VendorAssessmentGuidelineService implements IVendorAssessmentGuidelineService {
        private final MessageUtility messageUtility;
    private final LookUpUtility lookUpUtility;

    private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(VendorAssessmentGuidelineService.class);
        public GuidelineResponseDTO fetchGuidelines (String lookupName) {
            try {
                List<CoreLookupDto> byLookupCode = lookUpUtility.getLookupByLookUpName(lookupName);
                GuidelineResponseDTO guidelineResponseDTO = new GuidelineResponseDTO();
                List<String> guidelines = new ArrayList<>();
                if (byLookupCode.isEmpty()) {
                    log.error("No guidelines found for lookup name: {}", lookupName);
                    guidelines.add("No guidelines found");
                    guidelineResponseDTO.setGuidelines(guidelines);
                    return guidelineResponseDTO;
                }
                // Return the link for guidelines
                for (CoreLookupDto lookup : byLookupCode) {
                    guidelines.add(lookup.getDescription());
                }
                guidelineResponseDTO.setGuidelines(guidelines);
                return guidelineResponseDTO;
            } catch (Exception ex) {
                throw new ServiceException(MessageConstant.UNEXPECTED_ERROR,
                        messageUtility.getMessage(MessageConstant.UNEXPECTED_ERROR),
                        ErrorConstant.CATEGORY.BV, ErrorConstant.SEVERITY.I);
            }
        }
}
