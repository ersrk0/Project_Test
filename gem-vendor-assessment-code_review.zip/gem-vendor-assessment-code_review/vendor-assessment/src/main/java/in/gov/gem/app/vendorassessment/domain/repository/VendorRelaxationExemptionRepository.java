
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */
package in.gov.gem.app.vendorassessment.domain.repository;

import in.gov.gem.app.service.core.repository.BaseRepository;


import in.gov.gem.app.vendorassessment.domain.entity.VaRelaxationExemptionEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * The interface Vendor relaxation exemption repository.
 */
@Repository
public interface VendorRelaxationExemptionRepository extends BaseRepository<VaRelaxationExemptionEntity,Long>
{


  // Optional<VendorRelaxationExemption> findByVendorAssessmentFk(String vendorAssessmentFk);

  /**
   * Find by vendor assessment fk list.
   *
   * @param vendorAssessmentId the vendor assessment id
   * @return the list
   */
  List<VaRelaxationExemptionEntity> findByVendorAssessmentFk(String vendorAssessmentId);

  /**
   * Find by vendor assessment fk and relaxation type lookup list.
   *
   * @param vendorAssessmentId the vendor assessment id
   * @param relaxationType     the relaxation type
   * @return the list
   */
  List<VaRelaxationExemptionEntity> findByVendorAssessmentFkAndRelaxationTypeLookup(
    String vendorAssessmentId, String relaxationType);

  /**
   * Find distinct relaxation types list.
   *
   * @return the list
   */
  @Query("SELECT DISTINCT e.relaxationTypeLookup FROM VaRelaxationExemptionEntity e")
  List<String> findDistinctRelaxationTypes();

  List<VaRelaxationExemptionEntity> findByVaMasterFk(Long vendorAssessmentFk);
}
