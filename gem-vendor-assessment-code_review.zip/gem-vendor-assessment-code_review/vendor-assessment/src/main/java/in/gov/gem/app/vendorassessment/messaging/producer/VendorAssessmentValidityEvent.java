
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.messaging.producer;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * The type Vendor assessment validity event.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Component
public class VendorAssessmentValidityEvent {

    private String vendorId;
    private String assessmentId;
    private String vendorType; // OEM, DEEMED_OEM, RESELLER, OSP, DEEMED_OSP, SERVICE_PROVIDER
    private List<CategoryAssessment> categories;
    private AssessmentStatus status; // PASSED, FAILED, EXPIRED
    private Integer expiryWithinMonths; // Months before expiry to notify

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime assessmentDate;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime validityStartDate;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime validityEndDate;

    private String eventType; // NEW_ASSESSMENT, REASSESSMENT, EXPIRY_UPDATE
    private String triggeredBy; // SYSTEM, USER
    private String remarks;

  /**
   * The type Category assessment.
   */
  @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CategoryAssessment {
        private String categoryId;
        private String categoryName;
        private AssessmentStatus status;

        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private LocalDateTime validityStartDate;

        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private LocalDateTime validityEndDate;

        private String previousValidityEndDate;
    }

  /**
   * The enum Assessment status.
   */
  public enum AssessmentStatus {
    /**
     * Passed assessment status.
     */
    PASSED,
    /**
     * Failed assessment status.
     */
    FAILED,
    /**
     * Expired assessment status.
     */
    EXPIRED,
    /**
     * Active assessment status.
     */
    ACTIVE,
    /**
     * Pending assessment status.
     */
    PENDING
    }
}

