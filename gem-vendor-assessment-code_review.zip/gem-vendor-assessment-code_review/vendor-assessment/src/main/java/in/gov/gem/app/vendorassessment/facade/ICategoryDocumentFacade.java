
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;

import in.gov.gem.app.vendorassessment.dto.request.CatDocumentUploadRequestDto;
import in.gov.gem.app.vendorassessment.dto.request.CategoryDocumentDto;
import in.gov.gem.app.vendorassessment.dto.response.CategoryDocumentResponse;

import java.io.IOException;

/**
 * Interface for the DocumentFacade.
 * This interface defines the contract for managing document-related
 * operations, such as getting, uploading, downloading, and deleting documents
 * associated with specific questions.
 */
public interface ICategoryDocumentFacade {

    /**
     * Retrieves all documents associated with a specific question.
     *
     * @param categoryId The ID of the category.
     * @param questionId The ID of the question.
     * @return A DocumentResponse containing the question's details and its associated documents.
     */
    CategoryDocumentResponse getDocumentsForQuestion(Long categoryId, Long questionId);

    /**
     * Uploads a new document for a specific question.
     *
     * @param categoryId The ID of the category.
     * @param questionId The ID of the question.
     * @param requestDto The DTO containing the file and document type.
     * @return A DocumentDto representing the newly uploaded document.
     * @throws IOException if an error occurs during file upload.
     */
    CategoryDocumentDto uploadDocument(Long categoryId, Long questionId, CatDocumentUploadRequestDto requestDto) throws IOException;

    /**
     * Deletes a document.
     *
     * @param categoryId The ID of the category.
     * @param questionId The ID of the question.
     * @param documentId The ID of the document to delete.
     * @throws IOException if an error occurs during file deletion.
     */
    void deleteDocument(Long categoryId, Long questionId, Long documentId) throws IOException;

    /**
     * Downloads a document.
     *
     * @param categoryId The ID of the category.
     * @param questionId The ID of the question.
     * @param documentId The ID of the document to download.
     * @return A byte array containing the document's content.
     * @throws IOException if an error occurs during file download.
     */
    byte[] downloadDocument(Long categoryId, Long questionId, Long documentId) throws IOException;
}
