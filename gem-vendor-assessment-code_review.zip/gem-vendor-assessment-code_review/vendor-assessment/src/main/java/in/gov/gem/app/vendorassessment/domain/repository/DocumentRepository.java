/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.repository;


import in.gov.gem.app.vendorassessment.domain.entity.Document;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Component
public class DocumentRepository {
    private final Map<Long, Document> documents = new ConcurrentHashMap<>();
    private final AtomicLong idCounter = new AtomicLong();

    public Document save(Document document) {
        if (document.getId() == null) {
            document.setId(idCounter.incrementAndGet());
        }
        documents.put(document.getId(), document);
        return document;
    }

    public Optional<Document> findById(Long id) {
        return Optional.ofNullable(documents.get(id));
    }

    public List<Document> findByQuestionId(Long questionId) {
        return documents.values().stream()
                .filter(doc -> doc.getQuestionId() != null && doc.getQuestionId().equals(questionId))
                .collect(Collectors.toList());
    }

    public void deleteById(Long id) {
        documents.remove(id);
    }
}