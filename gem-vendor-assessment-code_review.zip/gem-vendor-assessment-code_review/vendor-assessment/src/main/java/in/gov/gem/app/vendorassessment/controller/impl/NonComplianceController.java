
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.dto.response.NonComplianceNewResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.NonComplianceResponseDTO;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.controller.INonComplianceController;

import in.gov.gem.app.vendorassessment.facade.INonComplianceFacade;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * The type Non compliance controller.
 */
@RestController
@RequestMapping("/v1/non-compliance")
@RequiredArgsConstructor

public class NonComplianceController extends BaseParentController implements INonComplianceController {

    private final INonComplianceFacade nonComplianceFacade;

    @Override
    public ResponseEntity<APIResponse<NonComplianceNewResponseDTO>> fieldsWithOpenNonClosure(
           Long sellerId) {


            NonComplianceNewResponseDTO response = nonComplianceFacade.fieldsWithOpenNonClosure(sellerId);
            return ResponseEntity.ok().body(APIResponse.<NonComplianceNewResponseDTO>builder()
                    .msId(ApplicationConstant.MSID) // Replace with actual MSID if needed
                    .status(HttpStatus.OK.getReasonPhrase())
                    .httpStatus(HttpStatus.OK.value())
                    .message(ApplicationConstant.Field_NC_SUCCESS)
                    .data(response)
                    .build());


    }

@Override
    public ResponseEntity<APIResponse<List<NonComplianceResponseDTO>>> nonCompliantFields(
            Long vaMasterFk) {



        List<NonComplianceResponseDTO> response = nonComplianceFacade.nonCompliantFields(vaMasterFk);
        return ResponseEntity.ok().body(APIResponse.<List<NonComplianceResponseDTO>>builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.Field_NC_SUCCESS)
                .data(response)
                .build());
    }
}
