
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.domain.entity.Category;
import in.gov.gem.app.vendorassessment.dto.request.CategoryRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.CategoryNewResponseDTO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;


@RequestMapping("/v1/categories")
@Tag(name = "Category Management", description = "Endpoints for managing product categories.")
public interface ICategoryController {

    @PostMapping
    @Operation(
        summary = "Create a new category",
        description = "Creates a new category for a specific type.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Category created successfully",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryNewResponseDTO.class))),
            @ApiResponse(responseCode = "400", description = "Invalid category type provided")
        }
    )
    ResponseEntity<APIResponse<Object>> createCategory(
        @Parameter(description = "The type of the category (e.g., 'VA_CATEGORY')", required = true)
        @RequestParam String type,
        @RequestBody CategoryRequestDTO requestDTO
    );

    @PostMapping("/check-similarity")
    @Operation(
        summary = "Check for similar categories",
        description = "Checks if a list of categories to be added already have similar existing categories.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Similar categories found or not found",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Map.class)))
        }
    )
    ResponseEntity<APIResponse<Object>> checkCategorySimilarity(
        @RequestBody List<CategoryRequestDTO> request
    );

    @PostMapping("/bulk-add")
    @Operation(
        summary = "Bulk add categories",
        description = "Adds a list of categories in bulk, optionally with a `vaId`.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Categories added successfully",
                content = @Content(mediaType = "application/json"))
        }
    )
    ResponseEntity<APIResponse<Object>> bulkAddCategories(
        @RequestBody List<CategoryRequestDTO> request,
        @Parameter(description = "Optional vaId for the categories")
        @RequestParam(required = false) String vaId
    );



    @GetMapping("/tree")
    @Operation(
        summary = "Get category tree",
        description = "Retrieves the full hierarchical tree of categories, filtered by type and vaId.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved category tree",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = CategoryNewResponseDTO.class))),
            @ApiResponse(responseCode = "400", description = "Invalid category type provided")
        }
    )
    ResponseEntity<APIResponse<Object>> getCategoryTree(
        @Parameter(description = "The type of the category (e.g., 'VA_CATEGORY')", required = true)
        @RequestParam Optional<String> type,
        @Parameter(description = "Optional vaId to filter the tree")
        @RequestParam(required = false) String vaId
    );


    @GetMapping("/filtered-search")
    @Operation(
        summary = "Search categories by criteria",
        description = "Searches for categories based on a query, parent ID, and exact match flag.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved matching categories",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Category.class))),
            @ApiResponse(responseCode = "400", description = "Invalid category type provided")
        }
    )
    ResponseEntity<APIResponse<Object>> searchEligibleCategories(
        @Parameter(description = "The type of the category (e.g., 'VA_CATEGORY')")
        @RequestParam(required = false) String type,
        @Parameter(description = "Search query string")
        @RequestParam(required = false) String query,
        @Parameter(description = "Parent category ID")
        @RequestParam(required = false) Long parentId,
        @Parameter(description = "Boolean for exact match")
        @RequestParam(required = false) Boolean exactMatch
    );




    @GetMapping("/saved-categories")
    @Operation(
        summary = "Get saved categories",
        description = "Retrieves a list of all categories currently marked as 'saved', optionally filtered by vaId.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved saved categories",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Category.class))),
            @ApiResponse(responseCode = "204", description = "No saved categories found")
        }
    )
    ResponseEntity<APIResponse<Object>> getSavedCategories(
        @Parameter(description = "Optional vaId to filter saved categories")
        @RequestParam(required = false) String vaId
    );

    @PostMapping("/saved-categories")
    @Operation(
        summary = "Add category to saved list",
        description = "Adds a category to the 'saved' list by its ID.",
        responses = {
            @ApiResponse(responseCode = "201", description = "Category added to saved list successfully"),
            @ApiResponse(responseCode = "409", description = "Category already exists in saved list or does not exist")
        }
    )
    ResponseEntity<APIResponse<Object>> addCategoryToSaved(
        @Parameter(description = "The ID of the category to save", required = true)
        @RequestParam Long id,
        @Parameter(description = "The type of the category")
        @RequestParam(required = false) String type,
        @Parameter(description = "Optional vaId for the saved category")
        @RequestParam(required = false) String vaId
    );

    @DeleteMapping("/saved-categories")
    @Operation(
        summary = "Remove category from saved list",
        description = "Removes a category from the 'saved' list by its ID.",
        responses = {
            @ApiResponse(responseCode = "204", description = "Category removed from saved list successfully"),
            @ApiResponse(responseCode = "404", description = "Category not found in saved list")
        }
    )
    ResponseEntity<APIResponse<Object>> removeCategoryFromSaved(
        @Parameter(description = "The ID of the category to remove", required = true)
        @RequestParam Long id,
        @Parameter(description = "The type of the category")
        @RequestParam(required = false) String type,
        @Parameter(description = "Optional vaId of the saved category")
        @RequestParam(required = false) String vaId
    );

    @GetMapping("/saved-categories/search")
    @Operation(
        summary = "Search saved categories",
        description = "Searches within the 'saved' categories based on a query, type, and vaId.",
        responses = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved matching saved categories",
                content = @Content(mediaType = "application/json",
                    schema = @Schema(implementation = Category.class)))
        }
    )
    ResponseEntity<APIResponse<Object>> searchSavedCategories(
        @Parameter(description = "Search query string")
        @RequestParam(required = false) String query,
        @Parameter(description = "The type of the category")
        @RequestParam(required = false) String type,
        @Parameter(description = "Optional vaId to filter the search")
        @RequestParam(required = false) String vaId
    );
}
