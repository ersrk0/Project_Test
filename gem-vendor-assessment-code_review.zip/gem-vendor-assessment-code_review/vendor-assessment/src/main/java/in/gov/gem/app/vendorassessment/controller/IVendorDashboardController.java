
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.response.VendorDashboardDTOResponseDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Provides APIs for vendor assessment dashboard operations.
 */
@Tag(name = "Vendor Dashboard", description = "APIs for vendor assessment dashboard operations")
@RequestMapping("/v1/dashboard")
@RestController
public interface IVendorDashboardController {

  /**
   * Fetches all vendor assessments with pagination.
   *
   * @param paginationParams pagination parameters
   * @return pageable API response with list of vendor assessments
   */
  @Operation(
    summary = "Get All Vendor Assessments",
    description = "Fetches all vendor assessments with pagination.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping
  ResponseEntity<PageableApiResponse<List<VendorDashboardDTOResponseDTO>>> getAllVendorAssessments(
    @Valid @ModelAttribute PaginationParams paginationParams);

  /**
   * Fetches a vendor assessment by VA number.
   *
   * @param vaNumber the VA number
   * @return API response with vendor assessment details
   */
  @Operation(
    summary = "Get Vendor Assessment by VA Number",
    description = "Fetches a vendor assessment by VA number.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaNumber", description = "VA number", in = ParameterIn.QUERY, required = true)
  @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/by-Va-Number")
  ResponseEntity<APIResponse<VendorDashboardDTOResponseDTO>> getVendorAssessmentByVaNumber(
    @Valid @RequestParam String vaNumber);

  /**
   * Fetches category details for a given VA number.
   *
   * @param vaNumber the VA number
   * @return API response with category details
   */
  @Operation(
    summary = "Get Category Details by VA Number",
    description = "Fetches category details for a given VA number.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vaNumber", description = "VA number", in = ParameterIn.QUERY, required = true) @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @GetMapping("/getCategoryDetails")
  ResponseEntity<APIResponse<List<Map<String, Object>>>> getCategoryDetails(
    @RequestParam String vaNumber);

  /**
   * Deletes a vendor assessment by vendor ID.
   *
   * @param vendorId the vendor ID
   * @return API response with deletion status
   */
  @Operation(
    summary = "Delete Vendor Assessment",
    description = "Deletes a vendor assessment by vendor ID.",
    security = @SecurityRequirement(name = "bearerAuth")
  )
  @Parameter(name = "vendorId", description = "Vendor ID", in = ParameterIn.QUERY, required = true) @ApiResponse(responseCode = "200", useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400", description = "Invalid Request", content = @Content)
  @ApiResponse(responseCode = "401", description = "Unauthorized", content = @Content)
  @ApiResponse(responseCode = "404", description = "Resource not found", content = @Content)
  @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content)
  @DeleteMapping("/delete")
  ResponseEntity<APIResponse<String>> deleteVendorAssessment(
    @RequestParam String vendorId);

}
 