
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade.Impl;


import in.gov.gem.app.vendorassessment.domain.entity.Category;
import in.gov.gem.app.vendorassessment.dto.request.CategoryRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.CategoryNewResponseDTO;
import in.gov.gem.app.vendorassessment.facade.ICategoryFacade;
import in.gov.gem.app.vendorassessment.service.ICategoryService;
import in.gov.gem.app.vendorassessment.transformer.CategoryHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class CategoryFacadeImpl implements ICategoryFacade {

  private  final CategoryHelper categoryHelper;
  private final ICategoryService categoryService;
@Autowired
    public CategoryFacadeImpl(CategoryHelper categoryHelper, ICategoryService categoryService) {
        this.categoryHelper = categoryHelper;
        this.categoryService = categoryService;
    }


    /**
   * Constructor for CategoryFacadeImpl.
   *
   * @param categoryService The injected CategoryService.
   */

  /**
   * Creates a new category.
   *
   * @param requestDTO The CategoryRequestDTO.
   * @return A CategoryResponseDTO of the created category.
   */
  @Override
  public CategoryNewResponseDTO createCategory(CategoryRequestDTO requestDTO) {
    Category category = categoryHelper.convertToCategory(requestDTO);
    Category createdCategory = categoryService.createCategory(category);
    return categoryHelper.convertToResponseDTO(createdCategory, "Created");
  }

  /**
   * Retrieves a category by ID.
   *
   * @param id The ID of the category.
   * @return A CategoryResponseDTO if found, null otherwise.
   */
  @Override
  public CategoryNewResponseDTO getCategoryById(String id) {
    Optional<Category> categoryOptional = categoryService.getCategoryById(id);
    return categoryOptional.map(category -> categoryHelper.convertToResponseDTO(category, "Retrieved")).orElse(null);
  }

  @Override
  public void bulkAddCategories(List<CategoryRequestDTO> categoryRequests,String vaId) throws IllegalArgumentException {
    List<Category> categories = new ArrayList<>();
    for (CategoryRequestDTO categoryRequestDTO:categoryRequests){
      if (categoryService.existsById(categoryRequestDTO.getId(), vaId)) {
        break;
     } else {
        Category category = categoryHelper.convertToCategory(categoryRequestDTO);
        category.setVaId(vaId); // Set the vaId for the category
        categories.add(category);
        categoryService.saveCategories(categories);
      }

    }

  }



  /**
   * Retrieves the hierarchical tree of categories.
   *
   * @return A list of top-level CategoryResponseDTOs with children.
   */
  @Override
  public List<CategoryNewResponseDTO> getCategoryTree(Optional<String> type, String vaId) {
    List<Category> topLevelCategories = categoryService.buildCategoryTree(type, vaId);
    return topLevelCategories.stream()
        .map(category -> {
          CategoryNewResponseDTO dto = categoryHelper.convertToResponseDTOWithChildren(category);
          dto.setStatus("Retrieved");
          return dto;
        })
        .toList();
  }


  /**
   * Initiates the process of adding a category by first checking for similar ones.
   * This method is designed to be called by the Controller.
   * @param categoryName The name of the category to be added.
   * @return An AddCategoryCheckResponse indicating if confirmation is needed and listing similar categories.
   */
  @Override
  public Map<String, Object> checkAndPrepareAddCategory(List<CategoryRequestDTO> categoryName) {
      return categoryService.findSimilarCategoriesByName(categoryName);
  }


  /**
   * Gets all categories currently marked as "saved".
   * @return A list of saved categories.
   */
  @Override
  public List<Category> getSavedCategories(String vaId) {
    return categoryService.getSavedCategories(vaId);
  }

  /**
   * Adds a category to the "saved" list.
   * @param categoryId The ID of the category to save.
   * @return True if added, false if not found or already saved.
   */
  @Override
  public boolean addCategoryToSaved(Long categoryId, String type, String vaId) {
    return categoryService.addCategoryToSaved(categoryId, type, vaId);
  }


  /**
   * Searches for eligible categories based on provided criteria (general pool).
   * @param name Optional: partial, case-insensitive match for category name.
   * @param parentId Optional: exact match for parent category ID.
   * @param exactMatch Optional: if true, name must be an exact, case-insensitive match.
   * @return A list of categories matching the criteria.
   */
  @Override
  public List<Category> searchEligibleCategoriesByCriteria(String type,String name, Long parentId, Boolean exactMatch) {
    return categoryService.searchEligibleCategoriesByCriteria(type,name, parentId, exactMatch);
  }

  /**
   * Removes a category from the "saved" list.
   * @param categoryId The ID of the category to remove.
   * @return True if removed, false if not found in saved list.
   */
  @Override
  public boolean removeCategoryFromSaved(Long categoryId,String type,String vaId) {
    return categoryService.removeCategoryFromSaved(categoryId, type, vaId);
  }

  /**
   * Searches within the "saved" categories based on a query string.
   * @param query The search string.
   * @return A list of saved categories matching the query.
   */
  @Override
  public List<Category> searchSavedCategories(String query,String type, String vaId) {
    return categoryService.searchSavedCategories(query,type, vaId);
  }


}
