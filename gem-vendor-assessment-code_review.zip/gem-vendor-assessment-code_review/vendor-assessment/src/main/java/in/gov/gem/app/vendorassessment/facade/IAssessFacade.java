
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;

import in.gov.gem.app.vendorassessment.dto.response.AssessDescriptionResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.LookupResponseResponseDTO;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * The interface Assess facade.
 */
@Component
public interface IAssessFacade {

  /**
   * Gets lookup value by lookup name.
   *
   * @return the lookup value by lookup name
   */
  public LookupResponseResponseDTO getLookupValueByLookupName() ;

  /**
   * Gets description by lookup value.
   *
   * @param lookupValue the lookup value
   * @return the description by lookup value
   */
  public AssessDescriptionResponseDTO getDescriptionByLookupValue(String lookupValue) ;

  /**
   * Fetch question by assess list.
   *
   * @param assessCode the assess code
   * @return the list
   */
  public List<Map<String, String>> fetchQuestionByAssess(String assessCode) ;
}
