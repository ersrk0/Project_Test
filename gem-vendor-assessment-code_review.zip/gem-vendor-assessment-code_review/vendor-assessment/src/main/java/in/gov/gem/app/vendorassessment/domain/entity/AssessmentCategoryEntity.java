
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

/**
 * The type Assessment category entity.
 */
@Entity
@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor

@Table(name = "assessment_category",schema = "va_mgmt")
public class AssessmentCategoryEntity extends BaseEntity
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "va_master_fk")
    private Long vendorAssessmentFk;

    @Column(name = "category_fk")
    private Long categoryFk;

    @Column(name = "oem_authorization")
    private Boolean oemAuthorization;

    @Column(name = "supply_capacity")
    private String supplyCapacity;

    @Column(name = "offer_type")
    private String offerType;

    @Column(name = "description")
    private String description;

    @Column(name = "status_lookup")
    private String statusLookup;
}
