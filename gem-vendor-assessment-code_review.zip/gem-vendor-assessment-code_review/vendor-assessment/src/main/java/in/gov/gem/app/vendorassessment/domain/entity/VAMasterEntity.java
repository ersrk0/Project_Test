
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.entity;

import jakarta.persistence.*;
import lombok.*;
import in.gov.gem.app.service.core.entity.BaseEntity;

import java.time.Instant;


/**
 * The type Va master entity.
 */
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity


@Table(name = "va_master",schema = "va_mgmt")
public class VAMasterEntity extends BaseEntity
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "va_number")
    private String vaNumber;

    @Column(name = "user_fk")
    private Long userFk;

    @Column(name = "pvt_org_master_fk")
    private Long pvtOrgMasterFk;

    @Column(name = "briefcase_fk")
    private Long briefCaseFk;

    @Column(name = "va_status_lookup")
    private String vaStatusLookUp;

    @Column(name="payment_fk")
    private Long paymentFk;

    @Column(name="apply_as_lookup")
    private String applyAsLookUp;

    @Column(name="assessor_status_lookup")
    private String assessorStatusLookUp;

    @Column(name="is_exemption")
    private Boolean isExemption;

    @Column(name="type_lookup")
    private String typeLookUp;

    @Column(name="valid_upto")
    private Instant validUpTo;

    @Column(name="need_dashboard")
    private Boolean needDashboard;

    @Column(name="dashboard_type_lookup")
    private String dashboardTypeLookUp;

    @Column(name="is_contract_manufacturer")
    private Boolean isContractManufacturer;

    @Column(name="sub_status_lookup")
    private String subStatusLookUp;
}
