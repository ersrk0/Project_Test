
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.facade;

import com.fasterxml.jackson.core.JsonProcessingException;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressUpdateRequestDTO;
import in.gov.gem.app.vendorassessment.dto.response.*;

import java.util.List;

/**
 * The interface Seller fetch details facade.
 */
public interface ISellerFetchDetailsFacade {
  /**
   * Checking profile.
   */
  void checkingProfile();

  /**
   * Gets profile from seller.
   *
   * @return the profile from seller
   * @throws JsonProcessingException the json processing exception
   */
  ProfileSellerResponseDTO getProfileFromSeller() throws JsonProcessingException;

  /**
   * Gets pan from seller.
   *
   * @return the pan from seller
   */
  PanResponseResponseDTO getPanFromSeller();

  /**
   * Gets tan from seller.
   *
   * @param paginationParams the pagination params
   * @return the tan from seller
   */
  List<TanResponseDTO> getTanFromSeller(PaginationParams paginationParams);

  /**
   * Gets bank from seller.
   *
   * @param paginationParams the pagination params
   * @param languageCode     the language code
   * @return the bank from seller
   */
  List<BankSellerResponseDTO> getBankFromSeller(PaginationParams paginationParams, String languageCode);

  /**
   * Gets address from seller.
   *
   * @param paginationParams the pagination params
   * @param vaNumber         the va number
   * @return the address from seller
   */
  List<OfficeSellerResponseDTO> getAddressFromSeller(PaginationParams paginationParams, String vaNumber);

  /**
   * Gets pre defined address from seller.
   *
   * @param paginationParams the pagination params
   * @param vaNumber         the va number
   * @return the pre defined address from seller
   */
  List<OfficePreSellerResponseDTO> getPreDefinedAddressFromSeller(PaginationParams paginationParams, String vaNumber);

  /**
   * Save address in seller office vo response dto.
   *
   * @param officeAddressRequestDTO the office address request dto
   * @return the office vo response dto
   */
  OfficeVOResponseDTO saveAddressInSeller(OfficeAddressRequestDTO officeAddressRequestDTO);

  /**
   * Delete address in seller.
   *
   * @param pvtOrgOfficeId the pvt org office id
   */
  void deleteAddressInSeller(Long pvtOrgOfficeId);

  /**
   * Update address in seller.
   *
   * @param officeAddressUpdateRequestDTO the office address update request dto
   */
  void updateAddressInSeller(OfficeAddressUpdateRequestDTO officeAddressUpdateRequestDTO);

  /**
   * Gets registered office mobile list.
   *
   * @param paginationParams the pagination params
   * @return the registered office mobile list
   */
  List<OfficeVOResponseDTO> getRegisteredOfficeMobileList(PaginationParams paginationParams);

  /**
   * Gets registered office email list.
   *
   * @param paginationParams the pagination params
   * @return the registered office email list
   */
  List<OfficeVOResponseDTO> getRegisteredOfficeEmailList(PaginationParams paginationParams);

  /**
   * Gets financial from seller.
   *
   * @param paginationParams the pagination params
   * @return the financial from seller
   */
  List<TurnoverSellerResponseDTO> getFinancialFromSeller(PaginationParams paginationParams);

  /**
   * Gets turnover from seller.
   *
   * @return the turnover from seller
   */
  TurnoverResponseDTO getTurnoverFromSeller();

  /**
   * Gets user details.
   *
   * @return the user details
   */
  UserDetailResponseDTO getUserDetails();

  /**
   * Gets ip address.
   *
   * @return the ip address
   */
  IpAddressResponseDTO getIPAddress();

  /**
   * Gets verify gstin.
   *
   * @param gstin           the gstin
   * @param isManufacturing the is manufacturing
   * @return the verify gstin
   */
  boolean getVerifyGstin(String gstin, boolean isManufacturing);
}