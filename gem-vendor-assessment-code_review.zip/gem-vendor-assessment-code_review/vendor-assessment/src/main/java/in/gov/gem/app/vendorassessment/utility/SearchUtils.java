
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.utility;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

/**
 * The type Search utils.
 */
public class SearchUtils {

  /**
   * Fuzzy search list.
   *
   * @param <T>        the type parameter
   * @param dtos       the dtos
   * @param searchTerm the search term
   * @return the list
   */
  public static <T> List<T> fuzzySearch(List<T> dtos, String searchTerm){
        return dtos.stream()
                .filter(dto ->
                        isFuzzyMatch(dto, searchTerm)).toList();
    }

    private static <T> boolean isFuzzyMatch(T dto, String searchTerm){
        for(var field: dto.getClass().getDeclaredFields()){
            Object value = getFieldValue(dto, field.getName());
            if(value instanceof String strValue){
                if(strValue.toLowerCase().contains(searchTerm.toLowerCase())){
                    return true;
                }
            }
        }
        return false;
    }

    private static Object getFieldValue(Object ob, String fieldName){
        try{
            for(PropertyDescriptor pd: Introspector.getBeanInfo(ob.getClass()).getPropertyDescriptors()) {
                if(pd.getName().equals(fieldName)){
                    return pd.getReadMethod().invoke(ob);
                }
            }
        } catch (IntrospectionException | IllegalAccessException | InvocationTargetException e){
            throw new RuntimeException(e);
        }
        throw new RuntimeException("Field not found: " + fieldName + " in class: " + ob.getClass().getName());
    }
}
