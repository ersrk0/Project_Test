
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service;

import in.gov.gem.app.vendorassessment.domain.entity.VaRelaxationExemptionEntity;
import in.gov.gem.app.vendorassessment.dto.response.CriteriaTypeResponseDTO;

import java.util.List;
import java.util.Optional;



public interface IVaRelaxationExemptionService
{
  /**
   * Creates a new VaRelaxationExemptionEntity.
   * @param entity The entity to be created.
   * @return The created entity with its assigned ID.
   */
  VaRelaxationExemptionEntity create(VaRelaxationExemptionEntity entity);

  /**
   * Retrieves a VaRelaxationExemptionEntity by its ID.
   * @param id The ID of the entity to retrieve.
   * @return An Optional containing the entity if found, or empty if not.
   */
  Optional<VaRelaxationExemptionEntity> getById(Long id);


  /**
   * Updates an existing VaRelaxationExemptionEntity.
   * @param id The ID of the entity to update.
   * @param entity The entity with updated details.
   * @return The updated entity.
   * @throws IllegalArgumentException if the entity with the given ID is not found.
   */
  VaRelaxationExemptionEntity update(Long id, VaRelaxationExemptionEntity entity);

  /**
   * Deletes a VaRelaxationExemptionEntity by its ID.
   * @param id The ID of the entity to delete.
   * @return true if the entity was successfully deleted, false otherwise.
   */
  boolean delete(Long id);


  List<VaRelaxationExemptionEntity> getAllByVaMasterFk(Long vendorAssessmentFk);

  List<CriteriaTypeResponseDTO> getAllCriteriaByLookUpCode(String lookUpCode);

}
