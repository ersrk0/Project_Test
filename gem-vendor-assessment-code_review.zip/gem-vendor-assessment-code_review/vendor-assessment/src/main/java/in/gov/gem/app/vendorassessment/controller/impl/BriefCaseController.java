
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.pack.controller.BaseParentController;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.dto.response.UploadResponseDTO;

import in.gov.gem.app.vendorassessment.controller.IBriefCaseController;
import in.gov.gem.app.vendorassessment.facade.IBriefCaseFacade;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * The type Brief case controller.
 */
@AllArgsConstructor
@RestController
public class BriefCaseController extends BaseParentController  implements IBriefCaseController
{

    private final IBriefCaseFacade briefCaseFacade;

    @Override
    public ResponseEntity<APIResponse<Object>> uploadDocument(
            @RequestPart("files") List<MultipartFile> files,
            @RequestHeader("documentType") String documentType) {

        ResponseEntity<List<UploadResponseDTO>> listResponseEntity = briefCaseFacade.uploadDocument(files, documentType);
        return ResponseEntity.ok().body(APIResponse.builder()
                .msId(ApplicationConstant.MSID)
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(ApplicationConstant.DOCUMENT_UPLOAD_SUCCESS)
                .data(listResponseEntity.getBody())
                .build());
    }

    @Override
    public ResponseEntity<byte[]> downloadDocument(@RequestParam String fileName) {
        byte[] bytes = briefCaseFacade.downloadDocument_(fileName);
        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=\"" + fileName + ".pdf\"")
                .header("Content-Type", "application/pdf")
                .body(bytes != null ? bytes : new byte[0]);

    }
}
