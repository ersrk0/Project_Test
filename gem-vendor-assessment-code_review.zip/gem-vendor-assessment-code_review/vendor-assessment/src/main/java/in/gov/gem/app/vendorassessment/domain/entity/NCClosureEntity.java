
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

/**
 * The type Nc closure entity.
 */
@Entity
@Getter
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "nc_closure",schema = "va_mgmt")
public class NCClosureEntity extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "va_master_fk")
    private Long vaMasterFk;

    @Column(name = "nc_description")
    private String ncDescription;


    @Column(name = "status_lookup")
    private String statusLookup;

    @Column(name = "closure_date")
    private LocalDateTime closureDate;

    @Column(name = "entity_lookup")
    private String entityLookup;

    @Column(name = "entity_attribute_lookup")
    private  String entityAttributeLookup;

}

