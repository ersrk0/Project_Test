
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.controller.impl;

import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.constant.ApplicationConstant;
import in.gov.gem.app.vendorassessment.controller.ICategoryManufacturingAddressController;
import in.gov.gem.app.vendorassessment.dto.request.CategoryManufacturingAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ManufacturingAddressCategoryMappingDTO;
import in.gov.gem.app.vendorassessment.dto.response.CategoryManufacturingAddressResponseDTO;
import in.gov.gem.app.vendorassessment.facade.ICategoryManufacturingAddressFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CategoryManufacturingController implements ICategoryManufacturingAddressController {

  private final ICategoryManufacturingAddressFacade manufacturingAddressFacade;

  @Autowired
  public CategoryManufacturingController(ICategoryManufacturingAddressFacade manufacturingAddressFacade) {
    this.manufacturingAddressFacade = manufacturingAddressFacade;
  }

  /**
   * Creates a new manufacturing address entry.
   *
   * @param requestDTO The DTO containing manufacturing address details.
   * @return ResponseEntity with the created ManufacturingAddressResponseDTO and HTTP status 201 (Created).
   */
  @Override
  public ResponseEntity<APIResponse<CategoryManufacturingAddressResponseDTO>> createManufacturingAddress(CategoryManufacturingAddressRequestDTO requestDTO) {
    CategoryManufacturingAddressResponseDTO responseDTO = manufacturingAddressFacade.createManufacturingAddress(requestDTO);
    return ResponseEntity.ok().body(APIResponse.<CategoryManufacturingAddressResponseDTO>builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.FETCH_MESSAGE)
            .data(responseDTO)
            .build());
  }

  /**
   * Retrieves a manufacturing address by its ID.
   * @param addressId The ID of the manufacturing address from the path variable.
   * @return ResponseEntity with the ManufacturingAddressResponseDTO and HTTP status 200 (OK),
   * or 404 (Not Found) if the manufacturing address does not exist.
   */
  @Override
  public ResponseEntity<APIResponse<CategoryManufacturingAddressResponseDTO> >getManufacturingAddressById(String addressId) {
    CategoryManufacturingAddressResponseDTO responseDTO = manufacturingAddressFacade.getManufacturingAddressById(addressId);
    return ResponseEntity.ok().body(APIResponse.<CategoryManufacturingAddressResponseDTO>builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.FETCH_MESSAGE)
            .data(responseDTO)
            .build());
  }

  /**
   * Retrieves all manufacturing address entries.
   * @return ResponseEntity with a list of ManufacturingAddressResponseDTOs and HTTP status 200 (OK).
   */
  @Override
  public ResponseEntity<APIResponse<Object>> getAllManufacturingAddresses() {

    return ResponseEntity.ok().body(APIResponse.builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.FETCH_MESSAGE)
            .data(manufacturingAddressFacade.getAllManufacturingAddresses())
            .build());
  }

  /**
   * Updates an existing manufacturing address.
   * @param id The ID of the manufacturing address to update from the path variable.
   * @param requestDTO The DTO with updated details from the request body.
   * @return ResponseEntity with the updated ManufacturingAddressResponseDTO and HTTP status 200 (OK),
   * or 404 (Not Found) if the manufacturing address does not exist.
   */
  @Override
  public ResponseEntity<APIResponse<CategoryManufacturingAddressResponseDTO>> updateManufacturingAddress(String id, CategoryManufacturingAddressRequestDTO requestDTO) {
    CategoryManufacturingAddressResponseDTO responseDTO = manufacturingAddressFacade.updateManufacturingAddress(id, requestDTO);
    return ResponseEntity.ok().body(APIResponse.<CategoryManufacturingAddressResponseDTO>builder()
            .msId(ApplicationConstant.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(ApplicationConstant.FETCH_MESSAGE)
            .data(responseDTO)
            .build());
  }

  /**
   * Deletes a manufacturing address by its ID.
   * @param id The ID of the manufacturing address to delete from the path variable.
   * @return ResponseEntity with HTTP status 204 (No Content) on successful deletion,
   * or 404 (Not Found) if the manufacturing address does not exist.
   */
  @Override
  public ResponseEntity<Void> deleteManufacturingAddress(String id) {
    CategoryManufacturingAddressResponseDTO responseDTO = manufacturingAddressFacade.deleteManufacturingAddress(id);
    if (responseDTO != null && "Deleted".equals(responseDTO.getStatus())) {
      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
  }

  /**
   * Maps categories to a specific manufacturing address.
   * @param addressId The ID of the manufacturing address to map categories to.
   * @param mappingDTO The DTO containing the list of category IDs.
   * @return ResponseEntity with the updated CategoryManufacturingAddressResponseDTO including mapped categories
   * and HTTP status 200 (OK), or 404 (Not Found) if the manufacturing address does not exist.
   */
  @Override
  public ResponseEntity<CategoryManufacturingAddressResponseDTO> mapCategoriesToManufacturingAddress(
          String addressId,
          ManufacturingAddressCategoryMappingDTO mappingDTO) {
    return new ResponseEntity<>(manufacturingAddressFacade.mapCategoriesToManufacturingAddress(addressId, mappingDTO), HttpStatus.OK);

  }

  /**
   * Retrieves a manufacturing address along with its mapped categories.
   * @param id The ID of the manufacturing address.
   * @return ResponseEntity with the CategoryManufacturingAddressResponseDTO including mapped category details
   * and HTTP status 200 (OK), or 404 (Not Found) if the manufacturing address does not exist.
   */
  @Override
  public ResponseEntity<CategoryManufacturingAddressResponseDTO> getManufacturingAddressWithMappedCategories(String id) {

    return new ResponseEntity<>(manufacturingAddressFacade.getManufacturingAddressWithMappedCategories(id), HttpStatus.OK);
  }
}
