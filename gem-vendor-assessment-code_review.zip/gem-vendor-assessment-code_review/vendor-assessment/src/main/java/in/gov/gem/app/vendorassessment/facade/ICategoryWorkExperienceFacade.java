
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.facade;

import in.gov.gem.app.vendorassessment.dto.request.CategoryWorkExperienceRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.WorkExperienceCategoryMappingDTO;
import in.gov.gem.app.vendorassessment.dto.response.CategoryWorkExperienceResponseDTO;

import java.util.List;

/**
 * Interface for the Work Experience Facade layer.
 * Simplifies interaction for the controller, handles DTO conversions.
 */
public interface ICategoryWorkExperienceFacade {

  /**
   * Creates a new work experience.
   * @param requestDTO The DTO containing work experience details.
   * @return The response DTO for the created work experience.
   */
  CategoryWorkExperienceResponseDTO createWorkExperience(CategoryWorkExperienceRequestDTO requestDTO);

  /**
   * Retrieves a work experience by ID.
   * @param id The ID of the work experience.
   * @return The response DTO for the work experience, or null if not found.
   */
  CategoryWorkExperienceResponseDTO getWorkExperienceById(String id);

  /**
   * Retrieves all work experience entries.
   * @return A list of response DTOs for all work experiences.
   */
  List<CategoryWorkExperienceResponseDTO> getAllWorkExperiences();

  /**
   * Updates an existing work experience.
   * @param id The ID of the work experience to update.
   * @param requestDTO The DTO with updated details.
   * @return The response DTO for the updated work experience, or null if not found.
   */
  CategoryWorkExperienceResponseDTO updateWorkExperience(String id, CategoryWorkExperienceRequestDTO requestDTO);

  /**
   * Deletes a work experience by ID.
   * @param id The ID of the work experience to delete.
   * @return A response DTO indicating the deletion status.
   */
  CategoryWorkExperienceResponseDTO deleteWorkExperience(String id);

  /**
   * Maps categories to a specific work experience.
   * @param workExperienceId The ID of the work experience.
   * @param mappingDTO The DTO containing the list of category IDs to map.
   * @return The response DTO for the updated work experience with mapped categories, or null if not found.
   */
  CategoryWorkExperienceResponseDTO mapCategoriesToWorkExperience(String workExperienceId, WorkExperienceCategoryMappingDTO mappingDTO);

  /**
   * Retrieves the work experience along with its mapped categories.
   * @param workExperienceId The ID of the work experience.
   * @return The CategoryWorkExperienceResponseDTO including the mapped category details.
   */
  CategoryWorkExperienceResponseDTO getWorkExperienceWithMappedCategories(String workExperienceId);
}

