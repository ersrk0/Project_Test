
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.transformer;

import in.gov.gem.app.vendorassessment.dto.request.AssessmentNewRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.AssessmentRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.ManufacturingLocationDecisionRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OrganisationDetailsRequestDTO;
import in.gov.gem.app.service.core.entity.Lookup;
import in.gov.gem.app.service.core.repository.LookupRepository;

import in.gov.gem.app.utility.CustomLoggerFactory;
import in.gov.gem.app.vendorassessment.domain.entity.VaOrganizationDetailEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Mapper class for converting between DTOs and Entities for Assessment Request operations.
 */
@Component
@RequiredArgsConstructor
public class AssessmentRequestTransformer {

    private final LookupRepository lookupRepository;

    private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(AssessmentRequestTransformer.class);

  /**
   * Maps AssessmentRequestDTO to AssessmentRequest entity
   *
   * @param dto the dto
   * @return the assessment new request dto
   */
  public AssessmentNewRequestDTO mapDtoToEntity(AssessmentRequestDTO dto) {
        if (dto == null) {
            return null;
        }

        AssessmentNewRequestDTO entity = new AssessmentNewRequestDTO();
        entity.setVaId(dto.getVaId());
        entity.setOrganizationChangeRequested(dto.isOrganizationChangeRequested());
        entity.setExperienceDocumentsChangeRequested(dto.isExperienceDocumentsChangeRequested());
        entity.setLicenseDocumentChangeRequested(dto.isLicenseDocumentChangeRequested());

        return entity;
    }

  /**
   * Maps VaOrganizationDetailEntity to OrganisationDetails
   *
   * @param entity the entity
   * @return the organisation details request dto
   */
  public OrganisationDetailsRequestDTO mapEntityToOrganisationDetails(VaOrganizationDetailEntity entity) {
        if (entity == null) {
            return null;
        }

        OrganisationDetailsRequestDTO details = new OrganisationDetailsRequestDTO();
        details.setNameOfOrganisation(entity.getOrganizationName());
        details.setOrganisationPAN(entity.getOrganizationPan());
        details.setOrganisationTAN(entity.getOrganizationTan());
        details.setCinFcrnLlpinFllpin(entity.getOrganizationCin());
        details.setPrimaryContactNumber(entity.getPrimaryContactNumber());
        details.setPrimaryEmailId(entity.getPrimaryEmailId());

        // Map organization type lookup
        Optional<Lookup> orgTypeLookup = lookupRepository.findByLookupCode(entity.getOrganizationTypeLookup());
        if (orgTypeLookup.isPresent()) {
            details.setOrganisationType(orgTypeLookup.get().getLookupValue());
        } else {
            //log.warn("Organization type lookup not found for code: {}", entity.getOrganizationTypeLookup());
        }

        // Map organization sub-type lookup
        Optional<Lookup> orgSubTypeLookup = lookupRepository.findByLookupCode(entity.getOrganizationSubTypeLookup());
        if (orgSubTypeLookup.isPresent()) {
            details.setOrganisationSubType(orgSubTypeLookup.get().getLookupValue());
        } else {
            //log.warn("Organization sub-type lookup not found for code: {}", entity.getOrganizationSubTypeLookup());
        }

        return details;
    }

  /**
   * Creates ManufacturingLocationDecision from input parameters
   *
   * @param vaId           the va id
   * @param addNewLocation the add new location
   * @return the manufacturing location decision request dto
   */
  public ManufacturingLocationDecisionRequestDTO createManufacturingLocationDecision(String vaId, boolean addNewLocation) {
        ManufacturingLocationDecisionRequestDTO decision = new ManufacturingLocationDecisionRequestDTO();
        decision.setVaId(vaId);
        decision.setAddNewLocation(addNewLocation);
        return decision;
    }
}