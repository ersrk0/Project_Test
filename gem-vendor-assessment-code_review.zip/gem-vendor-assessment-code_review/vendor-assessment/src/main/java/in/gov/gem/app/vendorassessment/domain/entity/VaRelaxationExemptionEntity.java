
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import java.sql.Timestamp;

@Entity
@Getter
@Setter
@NoArgsConstructor

@EqualsAndHashCode(callSuper = false)
@Table(name = "va_relaxation_exemption",schema = "va_mgmt")
public class VaRelaxationExemptionEntity extends BaseEntity
{
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private Long id;

  @Column(name = "va_master_fk")
  private Long vaMasterFk;

  @Column(name = "license_detail")
  private String licenseDetail;

  @Column(name = "relaxation_type_lookup")
  private String relaxationTypeLookup;

  @Column(name = "expiry_date")
  private Timestamp expiryDate;

  @Column(name = "status_lookup")
  private String statusLookup;

  @Column(name = "issuing_authority")
  private String issuingAuthority;

  @Column(name = "expired_at")
  private Timestamp expiredAt;

  @Column(name = "briefcase_fk")
  private Long briefcaseFk;


}