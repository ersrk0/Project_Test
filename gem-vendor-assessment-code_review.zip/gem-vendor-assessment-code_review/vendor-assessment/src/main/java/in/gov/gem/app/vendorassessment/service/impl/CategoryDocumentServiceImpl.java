
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.service.impl;


import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.service.core.utility.MessageUtility;

import in.gov.gem.app.vendorassessment.constant.MessageConstant;
import in.gov.gem.app.vendorassessment.domain.entity.Document;
import in.gov.gem.app.vendorassessment.domain.repository.DocumentRepository;

import in.gov.gem.app.vendorassessment.service.ICategoryDocumentsService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@AllArgsConstructor
public class CategoryDocumentServiceImpl implements ICategoryDocumentsService {


    private final DocumentRepository documentRepository;

    private final MessageUtility messageUtility;

    @Value("${document.upload-dir}")
    private String uploadDir;

    public CategoryDocumentServiceImpl(MessageUtility messageUtility, DocumentRepository documentRepository) {
        this.messageUtility = messageUtility;
        this.documentRepository = documentRepository;
    }

    @Override
    public List<Document> getDocumentsForQuestion(Long questionId) {
        if (questionId == null) {
            throw new ServiceException(
                    MessageConstant.QUESTION_ID_NOT_FOUND,
                    messageUtility.getMessage(MessageConstant.QUESTION_ID_NOT_FOUND),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
        return documentRepository.findByQuestionId(questionId);
    }

    @Override
    public Document uploadDocument(Long questionId, MultipartFile file, String documentType, Instant validUpto) throws IOException {
        if (file.isEmpty()) {
            throw new ServiceException(
                    MessageConstant.FILE_EMPTY,
                    messageUtility.getMessage(MessageConstant.FILE_EMPTY),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
        String originalFileName = file.getOriginalFilename();
        // Sanitize filename to prevent directory traversal attacks
        String sanitizedFileName = (originalFileName == null ? "unknown" : originalFileName.replaceAll("[^a-zA-Z0-9_\\-\\.]", "_"));

        String uniqueFileName = UUID.randomUUID() + "_" + sanitizedFileName;

        // Create the upload directory if it doesn't exist
        Path uploadPath = Paths.get(System.getProperty("user.dir"), uploadDir).toAbsolutePath().normalize();
        Files.createDirectories(uploadPath); // This creates all necessary but nonexistent parent directories

        Path filePath = uploadPath.resolve(uniqueFileName);
        Files.copy(file.getInputStream(), filePath);

        Document document = new Document();
        document.setQuestionId(questionId); // Link by ID
        document.setDocumentName(originalFileName);
        document.setDocumentType(documentType);
        document.setDocumentSizeKb(Files.size(filePath)/1024);
        // Convert bytes to KB
        document.setStoragePath(filePath.toAbsolutePath().toString());
        String datePattern = "yyyy-MM-dd";
        ZoneId kolkataZone = ZoneId.of("Asia/Kolkata"); // UTC+5:30
        Instant utcInstantFromDateOnly = toUtcInstantFromLocalDateString(LocalDate.now().toString(), datePattern, kolkataZone);
        document.setUploadedOn(utcInstantFromDateOnly); // Set current time in UTC
        document.setValidUpto(validUpto);

        return documentRepository.save(document);
    }
    public static Instant toUtcInstantFromLocalDateString(String dateString, String formatPattern, ZoneId sourceZoneId) {
        if (dateString == null || formatPattern == null || sourceZoneId == null) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(formatPattern);
        LocalDate localDate = LocalDate.parse(dateString, formatter);
        ZonedDateTime zonedDateTime = localDate.atStartOfDay(sourceZoneId);
        return zonedDateTime.toInstant();
    }

    @Override
    public void deleteDocument(Long documentId) throws IOException {
        Document document = documentRepository.findById(documentId)
                .orElseThrow(() ->  new ServiceException(
                MessageConstant.DOCUMENT_ID_NOT_FOUND,
                messageUtility.getMessage(MessageConstant.DOCUMENT_ID_NOT_FOUND),
                ErrorConstant.CATEGORY.BV,
                ErrorConstant.SEVERITY.I
        ));

        Path filePath = Paths.get(document.getStoragePath());
        if (Files.exists(filePath)) {
            Files.delete(filePath);
        }
        documentRepository.deleteById(documentId);
    }

    @Override
    public Optional<Document> getDocumentById(Long documentId) {
        if (documentId == null) {
            throw new ServiceException(
                    MessageConstant.DOCUMENT_ID_NOT_FOUND,
                    messageUtility.getMessage(MessageConstant.DOCUMENT_ID_NOT_FOUND),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I);

        }
        return documentRepository.findById(documentId);
    }


    @Override
    public byte[] downloadDocument(Long documentId) throws IOException {
        Document document = documentRepository.findById(documentId)
                .orElseThrow(() -> new ServiceException(
                        MessageConstant.DOCUMENT_NOT_FOUND,
                        messageUtility.getMessage(MessageConstant.DOCUMENT_NOT_FOUND),
                        ErrorConstant.CATEGORY.BV,
                        ErrorConstant.SEVERITY.I
                ));

        Path filePath = Paths.get(document.getStoragePath());
        if (!Files.exists(filePath)) {
            throw new ServiceException(
                    MessageConstant.DOCUMENT_NOT_FOUND,
                    messageUtility.getMessage(MessageConstant.DOCUMENT_NOT_FOUND),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.I
            );
        }
        return Files.readAllBytes(filePath);

    }

}
