
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.utility;



import in.gov.gem.app.vendorassessment.dto.response.VendorDashboardDTOResponseDTO;

import in.gov.gem.app.utility.CustomLoggerFactory;
import in.gov.gem.app.vendorassessment.domain.entity.VAMasterEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * The type Vendor dashboard transformer.
 */
@Component
@RequiredArgsConstructor

public class VendorDashboardUtil
{
    private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(VendorDashboardUtil.class);

  /**
   * Map to dto vendor dashboard dto.
   *
   * @param vendorAssessment the vendor assessment
   * @param categoryCount    the category count
   * @param statusValue      the status value
   * @param subStatusValue   the sub status value
   * @param assessedAsValue  the assessed as value
   * @return the vendor dashboard dto
   */
  public VendorDashboardDTOResponseDTO mapToDTO(VAMasterEntity vendorAssessment, Long categoryCount,
                                                String statusValue, String subStatusValue, String assessedAsValue) {
        if (vendorAssessment.getVaNumber() == null) {
            log.warn("Vendor assessment is null, skipping mapping.");
            return null;
        }

            List<String> actions = ActionDeterminer.determineActions(statusValue, subStatusValue);
            if (actions.isEmpty()) {
                actions.add("View");
            }

            return VendorDashboardDTOResponseDTO.builder()
                    .id(vendorAssessment.getId() != null ? vendorAssessment.getId() : 0L)
                    .vaId(vendorAssessment.getVaNumber())
                    .status(statusValue)
                    .subStatus(subStatusValue)
                    .assessedAs(assessedAsValue)
                    .categoryCount(categoryCount.intValue())
                    .assessedBy("Verifying Agency")
                    .submittedOn(vendorAssessment.getCreatedTimestamp())
                    .validUpTo(vendorAssessment.getValidUpTo())
                    .actions(actions)
                    .build();
    }
}