
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.client;

import in.gov.gem.app.service.core.config.FeignClientConfig;
import in.gov.gem.app.service.core.utility.RetrieveMessageErrorDecoder;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressRequestDTO;
import in.gov.gem.app.vendorassessment.dto.request.OfficeAddressUpdateRequestDTO;

import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.response.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * The interface Seller client.
 */
@FeignClient(name = "${seller.servicename}" , path="${seller.context-path}"
  , configuration = {RetrieveMessageErrorDecoder.class, FeignClientConfig.class})

public interface ISellerClient
{
  /**
   * Check profile completion response entity.
   *
   * @return the response entity
   */
  @GetMapping(value="${seller.left-panel}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<APIResponse<ProfileStatusResponseDTO>> checkProfileCompletion();

  /**
   * Gets profile.
   *
   * @return the profile
   */
  @GetMapping(value="${seller.organization}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<APIResponse<ProfileDetailsResponseDTO>> getProfile();

  /**
   * Gets pan.
   *
   * @return the pan
   */
  @GetMapping(value="${seller.pan}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<APIResponse<BusinessPanDetailsResponseDTO>> getPan();

  /**
   * Gets tan.
   *
   * @param paginationParams the pagination params
   * @return the tan
   */
  @GetMapping(value="${seller.tan}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<APIResponse<List<TanDetailsVOResponseDTO>>> getTan(@RequestParam PaginationParams paginationParams);

  /**
   * Get bank details response entity.
   *
   * @param paginationParams the pagination params
   * @return the response entity
   */
  @GetMapping(value="${seller.bank}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<PageableApiResponse<List<BankResponseDTO>>>getBankDetails(@RequestParam PaginationParams paginationParams);

  /**
   * Gets office address.
   *
   * @param paginationParams the pagination params
   * @return the office address
   */
  @GetMapping(value="${seller.office}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<PageableApiResponse<List<OfficeResponseDTO>>> getOfficeAddress(@RequestParam PaginationParams paginationParams);

  /**
   * Save office address response entity.
   *
   * @param officeAddressRequestDTO the office address request dto
   * @return the response entity
   */
  @PostMapping(value="${seller.office}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<APIResponse<OfficeVOResponseDTO>> saveOfficeAddress(@RequestBody OfficeAddressRequestDTO officeAddressRequestDTO);

  /**
   * Delete office address response entity.
   *
   * @param pvtOrgOfficeId the pvt org office id
   * @return the response entity
   */
  @DeleteMapping(value="${seller.office}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<APIResponse<Void>>deleteOfficeAddress(@RequestParam Long pvtOrgOfficeId);

  /**
   * Update office address response entity.
   *
   * @param officeAddressUpdateRequestDTO the office address update request dto
   * @return the response entity
   */
  @PutMapping(value="${seller.office}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<APIResponse<Object>>updateOfficeAddress(@RequestBody OfficeAddressUpdateRequestDTO officeAddressUpdateRequestDTO);

  /**
   * Gets registered office mobile list.
   *
   * @param paginationParams the pagination params
   * @return the registered office mobile list
   */
  @GetMapping(value = "${seller.office-mobile}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<PageableApiResponse<List<OfficeVOResponseDTO>>> getRegisteredOfficeMobileList(@RequestParam PaginationParams paginationParams);

  /**
   * Gets registered office email list.
   *
   * @param paginationParams the pagination params
   * @return the registered office email list
   */
  @GetMapping(value = "${seller.office-email}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<PageableApiResponse<List<OfficeVOResponseDTO>>> getRegisteredOfficeEmailList(@RequestParam PaginationParams paginationParams);

  /**
   * Gets financial itr address.
   *
   * @param paginationParams the pagination params
   * @return the financial itr address
   */
  @GetMapping(value = "${seller.tax-assessment}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<PageableApiResponse<List<PvtOrgItrVOResponseDTO>>> getFinancialItrAddress(@RequestParam PaginationParams paginationParams);

  /**
   * Gets turn over.
   *
   * @return the turn over
   */
  @GetMapping(value="${seller.turnover}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<APIResponse<TurnoverResponseDTO>> getTurnOver();

  /**
   * Gets organization details.
   *
   * @return the organization details
   */
  @GetMapping(value="${seller.organization}", consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<APIResponse<OrganizationDetailsResponseDTO>> getOrganizationDetails();
}

