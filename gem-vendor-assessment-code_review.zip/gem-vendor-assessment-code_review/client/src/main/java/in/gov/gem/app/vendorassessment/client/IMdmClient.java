
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.client;


import in.gov.gem.app.service.core.config.FeignClientConfig;
import in.gov.gem.app.service.core.utility.RetrieveMessageErrorDecoder;
import in.gov.gem.app.service.dto.APIResponse;

import in.gov.gem.app.vendorassessment.dto.response.BankAddressResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.CountryResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.LocationListResponseDTO;

import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import jakarta.validation.Valid;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * The interface Mdm client.
 */
@FeignClient(name = "${mdm.servicename}" , path="${mdm.context-path}"
  , configuration = {RetrieveMessageErrorDecoder.class, FeignClientConfig.class})
public interface IMdmClient
{

  /**
   * Gets bank address.
   *
   * @param ifscCode     the ifsc code
   * @param languageCode the language code
   * @return the bank address
   */
  @GetMapping(value="${mdm.bank-details}", consumes = MediaType.APPLICATION_JSON_VALUE)

  ResponseEntity<APIResponse<BankAddressResponseDTO>> getBankAddress(@RequestParam String ifscCode,
                                                                     @Valid @RequestHeader(name = "Accept-Language")
                                                                     String languageCode);


  /**
   * Gets location list.
   *
   * @param paginationParams the pagination params
   * @param locationCode     the location code
   * @param languageCode     the language code
   * @return the location list
   */
  @GetMapping(value="${mdm.locations}", consumes = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<PageableApiResponse<List<LocationListResponseDTO>>> getLocationList(@RequestParam PaginationParams
                                                                                       paginationParams,
                                                                                     @RequestParam String locationCode,
                                                                                     @Valid @RequestHeader(
                                                                                       name = "Accept-Language")
                                                                                     String languageCode);

  /**
   * Fetch country list response entity.
   *
   * @param paginationParams the pagination params
   * @param languageCode     the language code
   * @return the response entity
   */
  @GetMapping(value="${mdm.countries}", consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<PageableApiResponse<List<CountryResponseDTO>>> fetchCountryList(@RequestParam PaginationParams
                                                                                          paginationParams,
                                                                                        @Valid @RequestHeader
                                                                                          (name = "Accept-Language")
                                                                                        String languageCode);

}
