
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.client;


import in.gov.gem.app.service.core.config.FeignClientConfig;
import in.gov.gem.app.service.core.utility.RetrieveMessageErrorDecoder;
import in.gov.gem.app.vendorassessment.dto.response.UploadResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


/**
 * The interface Briefcase client.
 */
@FeignClient(name = "${briefcase.servicename}" , path="${briefcase.context-path}"
  , configuration = {FeignClientConfig.class, RetrieveMessageErrorDecoder.class})

public interface IBriefcaseClient
{

  /**
   * Uploaddocument response entity.
   *
   * @param files        the files
   * @param documentType the document type
   * @return the response entity
   */
  @PostMapping(value = "${briefcase.upload}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
  ResponseEntity<List<UploadResponseDTO>> Uploaddocument(
          @RequestPart("files") List<MultipartFile> files,
          @RequestHeader("documentType") String documentType
  );


  /**
   * Downloaddocument response entity.
   *
   * @param fileName the file name
   * @return the response entity
   */
  @GetMapping(value = "${briefcase.download}")
  ResponseEntity<byte[]> Downloaddocument_(
          @RequestParam("fileName") String fileName
  );
}
