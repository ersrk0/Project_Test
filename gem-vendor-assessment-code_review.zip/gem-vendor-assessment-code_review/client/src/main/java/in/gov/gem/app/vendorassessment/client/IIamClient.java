
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.client;


import in.gov.gem.app.service.core.config.FeignClientConfig;
import in.gov.gem.app.vendorassessment.dto.request.*;
import in.gov.gem.app.vendorassessment.dto.response.OtpResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.ResendOtpResponseDTO;
import in.gov.gem.app.service.core.config.InternalFeignClientConfig;
import in.gov.gem.app.service.core.utility.RetrieveMessageErrorDecoder;
import in.gov.gem.app.service.dto.APIResponse;

import in.gov.gem.app.vendorassessment.dto.response.UmsProfileResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


/**
 * The interface Iam client.
 */
@FeignClient(name = "${iam.servicename}" , path="${iam.context-path}"
  , configuration = {RetrieveMessageErrorDecoder.class, FeignClientConfig.class})
public interface IIamClient {
  /**
   * Save additional mobile response entity.
   *
   * @param acceptLanguage the accept language
   * @param contactRequest the contact request
   * @return the response entity
   */
  @PostMapping(value = "${iam.mobile}", consumes = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<APIResponse<Void>> saveAdditionalMobile(@RequestHeader(value = "accept-language", required = false) String acceptLanguage,
                                                         @RequestBody AddMobileRequestDTO contactRequest);

  /**
   * Save additional email response entity.
   *
   * @param acceptLanguage the accept language
   * @param contactRequest the contact request
   * @return the response entity
   */
  @PostMapping(value = "${iam.email}", consumes = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<APIResponse<Void>> saveAdditionalEmail(@RequestHeader(value = "accept-language", required = false) String acceptLanguage,
                                                        @RequestBody AddEmailRequestDTO contactRequest);

  /**
   * Send otp response entity.
   *
   * @param sendOtpRequestDTO the send otp request dto
   * @return the response entity
   */
  @PostMapping(value = "${otp.send-iam}")
  ResponseEntity<APIResponse<OtpResponseDTO>> sendOtp(@RequestBody SendOtpRequestDTO sendOtpRequestDTO);

  /**
   * Re send otp response entity.
   *
   * @param sendOtpRequestDTO the send otp request dto
   * @return the response entity
   */
  @PostMapping(value = "${otp.resend-iam}")
  ResponseEntity<APIResponse<ResendOtpResponseDTO>> reSendOtp(@RequestBody ReSendRequestDTO sendOtpRequestDTO);

  /**
   * Validate otp response entity.
   *
   * @param otpValidateRequestDTO the otp validate request dto
   * @return the response entity
   */
  @PostMapping(value = "${otp.validate-iam}")
  ResponseEntity<APIResponse<Object>> validateOtp(@RequestBody OTPValidateRequestDTO otpValidateRequestDTO);

  /**
   * Update mobile response entity.
   *
   * @param updateMobileDto the update mobile dto
   * @return the response entity
   */
  @PutMapping(value = "${iam.mobile}")
  ResponseEntity<APIResponse<Void>> updateMobile(@RequestBody UpdateMobileRequestDTO updateMobileDto);

  /**
   * Fetch user details response entity.
   *
   * @param keycloakId the keycloak id
   * @return the response entity
   */
  @GetMapping(value="${iam.fetchuser}")
  ResponseEntity<APIResponse<UmsProfileResponseDTO>> fetchUserDetails(@RequestParam String keycloakId);

}
