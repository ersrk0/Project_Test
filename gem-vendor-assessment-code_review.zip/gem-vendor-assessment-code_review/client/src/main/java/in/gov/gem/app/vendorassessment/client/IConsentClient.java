
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.client;

import in.gov.gem.app.service.core.config.FeignClientConfig;
import in.gov.gem.app.service.core.utility.RetrieveMessageErrorDecoder;
import in.gov.gem.app.vendorassessment.dto.request.SaveConsumerRequestDTO;
import in.gov.gem.app.service.dto.APIResponse;

import jakarta.validation.Valid;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * The interface Consent client.
 */
@FeignClient(name = "${consent.servicename}" , path="${consent.context-path}"
  ,configuration = {RetrieveMessageErrorDecoder.class, FeignClientConfig.class})
public interface IConsentClient
{

  /**
   * Gets meta data.
   *
   * @param acceptLanguage the accept language
   * @param module         the module
   * @param functionality  the functionality
   * @return the meta data
   */
  @GetMapping(value = "${consent.meta-details}", consumes = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<APIResponse<Object>> getMetaData(
    @RequestHeader(name="Accept-Language") String acceptLanguage,
    String module,
    String functionality);


  /**
   * Save consumer response entity.
   *
   * @param acceptLanguage      the accept language
   * @param saveConsumerRequest the save consumer request
   * @return the response entity
   */
  @PostMapping(value ="${consent.save}", consumes = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<APIResponse<Object>> saveConsumer(
    @RequestHeader(name="Accept-Language") String acceptLanguage,
    @Valid @RequestBody SaveConsumerRequestDTO saveConsumerRequest);


  /**
   * View data response entity.
   *
   * @param acceptLanguage the accept language
   * @param consentCode    the consent code
   * @return the response entity
   */
  @GetMapping(value = "${consent.view}", produces = "application/pdf")
  ResponseEntity<byte[]> viewData(@RequestHeader(name="Accept-Language") String acceptLanguage,
                                  @RequestParam String consentCode);




}
