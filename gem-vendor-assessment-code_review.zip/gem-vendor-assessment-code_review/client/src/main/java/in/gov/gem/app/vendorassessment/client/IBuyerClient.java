
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.client;


import in.gov.gem.app.service.core.config.FeignClientConfig;
import in.gov.gem.app.service.core.utility.RetrieveMessageErrorDecoder;


import in.gov.gem.app.service.dto.PageableApiResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.vendorassessment.dto.response.HierarchyMasterResponseDTO;
import in.gov.gem.app.vendorassessment.dto.response.HierarchyResponseDTO;
import jakarta.validation.Valid;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * The interface Buyer client.
 */
@FeignClient(name = "${buyer.servicename}" , path="${buyer.context-path}"
  , configuration = {RetrieveMessageErrorDecoder.class, FeignClientConfig.class})
public interface IBuyerClient
{

  /**
   * Find allorg type response entity.
   *
   * @param acceptLanguage   the accept language
   * @param paginationParams the pagination params
   * @return the response entity
   */
  @GetMapping(value="${buyer.findorgtype}", consumes = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<PageableApiResponse<HierarchyMasterResponseDTO>> findAllorgType(
    @RequestHeader("Accept-Language") String acceptLanguage, @RequestParam PaginationParams paginationParams);


  /**
   * Find hierarchywithlevel response entity.
   *
   * @param parentId         the parent id
   * @param acceptLanguage   the accept language
   * @param paginationParams the pagination params
   * @return the response entity
   */
  @GetMapping(value="${buyer.hierarchy}", consumes = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<PageableApiResponse<HierarchyResponseDTO>> findHierarchywithlevel(
    @Valid @RequestParam(name = "parent")
    String parentId, @RequestHeader("Accept-Language") String acceptLanguage,
    @RequestParam PaginationParams paginationParams);

}

