
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.constant;


import java.util.List;

/**
 * The type Application constant.
 */
public final class ApplicationConstant {

    /**
     * The constant MSID.
     */
    public static final String MSID = "VAS";

    /**
     * The constant FETCH_MESSAGE.
     */
    public static final String FETCH_MESSAGE = "Value Fetched Successfully";

    /**
     * The constant FETCH_SELLER_MESSAGE.
     */
    public static final String FETCH_SELLER_MESSAGE = "Seller Details Fetched Successfully";

    /**
     * The constant SAVE_SELLER_MESSAGE.
     */
    public static final String SAVE_SELLER_MESSAGE = "Seller Details Save Successfully";

    /**
     * The constant CREATED_MESSAGE.
     */
    public static final String CREATED_MESSAGE = "Data Inserted Successfully";

    /**
     * The constant DASHBOARD_MESSAGE.
     */
    public static final String DASHBOARD_MESSAGE = "Dashboard data fetched Successfully";

    /**
     * The constant VENDOR_ASSESSMENT_MAPPING_ERROR.
     */
    public static final String VENDOR_ASSESSMENT_MAPPING_ERROR = "Failed to map vendor assessment to DTO";

    /**
     * The constant UPDATE_MESSAGE.
     */
    public static final String UPDATE_MESSAGE = "lookup Update Successfully";

    /**
     * The constant DEACTIVATE_MESSAGE.
     */
    public static final String DEACTIVATE_MESSAGE = "lookup Deactivate Successfully";


    /**
     * The constant TENANT_TYPE_LOOKUP_BUYER.
     */
    public static final String TENANT_TYPE_LOOKUP_BUYER = "Vendor";

    /**
     * The constant TENANT_STATUS_LOOKUP_ACTIVE.
     */
    public static final String TENANT_STATUS_LOOKUP_ACTIVE = "Active";
    /**
     * The constant FETCH_PROFILE_MESSAGE.
     */
    public static final String FETCH_PROFILE_MESSAGE = "Seller Profile Complete";
    /**
     * The constant FETCH_PROFILE_COMPLETE_SUCCESS.
     */
    public static final String FETCH_PROFILE_COMPLETE_SUCCESS = "Completed";

    /**
     * The constant WORK_EXPERIENCE_CREATED.
     */
    public static final String WORK_EXPERIENCE_CREATED= "Work experience created successfully";

    /**
     * The constant WORK_EXPERIENCE_UPDATED.
     */
    public static final String WORK_EXPERIENCE_UPDATED= "Work experience updated successfully";

    //----------------------------------------------------------------------------------------


    /**
     * The constant MODULE_NAME.
     */
    public static final String MODULE_NAME = "VENDOR_MOD";
    /**
     * The constant MICROSERVICE_NAME.
     */
    public static final String MICROSERVICE_NAME = "MS_VAS";
    /**
     * The constant OTP_PREFERENCE_MOBILE.
     */
    public static final String OTP_PREFERENCE_MOBILE = "LCOM000002";
    /**
     * The constant OTP_PREFERENCE_EMAIL.
     */
    public static final String OTP_PREFERENCE_EMAIL = "LCOM000003";
    /**
     * The constant OTP_PREFERENCE_BOTH.
     */
    public static final String OTP_PREFERENCE_BOTH = "LCOM000001";
    /**
     * The constant OTP_TYPE_DIFFERENT.
     */
    public static final String OTP_TYPE_DIFFERENT = "LCOM000005";
    /**
     * The constant OTP_TYPE_SAME.
     */
    public static final String OTP_TYPE_SAME = "LCOM000004";

    /**
     * The constant OTP_TEMPLATE_ID.
     */
    public static final String OTP_TEMPLATE_ID = "0909";

    /**
     * The constant OTP.
     */
    public static final String OTP = "123456";

    /**
     * The constant DELETE_MESSAGE.
     */
    public static final String DELETE_MESSAGE = "File Deleted Successfully";
    /**
     * The constant SAVE_MESSAGE.
     */
    public static final String SAVE_MESSAGE = "File Saved Successfully" ;
    /**
     * The constant DELETE_SELLER_MESSAGE.
     */
    public static final String DELETE_SELLER_MESSAGE = "Seller Details Delete Successfully";
    /**
     * The constant UPDATE_SELLER_MESSAGE.
     */
    public static final String UPDATE_SELLER_MESSAGE = "Seller Details Update Successfully";

    /**
     * The constant APP_DOWNLOAD_LINK.
     */
    public static final String APP_DOWNLOAD_LINK = "https://gem.gov.in/download-va-app" ;

    /**
     * The constant VIDEO_INSTRUCTIONS_LOOKUP_CODE.
     */
    public static final String VIDEO_INSTRUCTIONS_LOOKUP_CODE = "LCVA1172";
    public static final String DELETE_VALUE_MESSAGE = "File Deleted Successfully";
    public static final String WORK_EXPERIENCE_CREATED_MESSAGE = "Work Experience Created Successfully";

    public static final String PRODUCTS_BASED = "Products based";
    public static final String SERVICE_BASED = "Service based";
    public static final String FORWARD_AUCTION_BASED = "Forward Auction based";

    /**
     * The constant NO_OF_DAYS_FOR_VIDEO_ASSESSMENT.
     */
    public static Integer NO_OF_DAYS_FOR_VIDEO_ASSESSMENT = 3;

    /**
     * The constant GET_ORGANIZATION_DETAIL.
     */
    public static final String GET_ORGANIZATION_DETAIL = "Organization details fetched successfully";

    /**
     * The constant SUBMIT_ORGANIZATION_DETAIL.
     */
    public static final String SUBMIT_ORGANIZATION_DETAIL = "Supplementary assessment request created successfully";

    /**
     * The constant GET_OTP.
     */
    public static final String GET_OTP = "OTP sent successfully";

    /**
     * The constant RESEND_OTP.
     */
    public static final String RESEND_OTP = "OTP Resent successfully";

    /**
     * The constant EMAIL_UPDATED.
     */
    public static final String EMAIL_UPDATED = "Email updated successfully";

    /**
     * The constant MOBILE_UPDATED.
     */
    public static final String MOBILE_UPDATED = "Mobile number updated successfully";

    /**
     * The constant MANUFACTURING_LOCATION_DECISION.
     */
    public static final String MANUFACTURING_LOCATION_DECISION = "Manufacturing location decision updated successfully";

    /**
     * The constant CHANNEL_ID.
     */
    public static final String CHANNEL_ID = "CI001";

    /**
     * The constant CATEGORIES_FETCHED.
     */
    public static final String CATEGORIES_FETCHED = "Categories fetched successfully";

    /**
     * The constant CATEGORIES_FETCHED_EMPTY.
     */
    public static final String CATEGORIES_FETCHED_EMPTY = "No categories found";

    /**
     * The constant VENDOR_ASSESSMENT_FETCHED.
     */
    public static final String VENDOR_ASSESSMENT_FETCHED = "Vendor assessment fetched successfully";

    //-------------------------------------------------

    /**
     * The constant OTP_SENT_EMAIL_SUCESS.
     */
    public static final String OTP_SENT_EMAIL_SUCESS= "OTP Send Successfully On Email: 654321";

    /**
     * The constant OTP_VERIFY_EMAIL_SUCESS.
     */
    public static final String OTP_VERIFY_EMAIL_SUCESS="OTP Verify Successfully and Email Added Successfully";

    /**
     * The constant OTP_RESEND_SUCESS.
     */
    public static final String OTP_RESEND_SUCESS="OTP Resend Successfully";

    /**
     * The constant OTP_SENT_MOBILE_SUCESS.
     */
    public static final String OTP_SENT_MOBILE_SUCESS= "OTP Send Successfully Mobile: 123456";

    /**
     * The constant OTP_VERIFY_MOBILE_SUCESS.
     */
    public static final String OTP_VERIFY_MOBILE_SUCESS= "OTP Verify Successfully And Mobile Added Successfully";

    /**
     * The constant DOCUMENT_UPLOAD_SUCCESS.
     */
    public static final String DOCUMENT_UPLOAD_SUCCESS="Documents uploaded successfully";

    //---------------------------------

    /**
     * The constant OTP_CACHE_RESEND_SUCESS.
     */
    public static final String OTP_CACHE_RESEND_SUCESS="OTP Cache RESEND SUCCESSFULLY";

    /**
     * The constant OTP_CACHE_SENT_MOBILE_SUCESS.
     */
    public static final String OTP_CACHE_SENT_MOBILE_SUCESS= "OTP Cache send successfully on mobile: 123456";

    /**
     * The constant OTP_CACHE_VERIFY_MOBILE_SUCESS.
     */
    public static final String OTP_CACHE_VERIFY_MOBILE_SUCESS= "OTP Cache VERIFY SUCCESSFULLY AND MOBILE ADDED SUCCESSFULLY";

    /**
     * The constant OTP_CACHE_SENT_EMAIL_SUCESS.
     */
    public static final String OTP_CACHE_SENT_EMAIL_SUCESS= "OTP Cache send successfully on email: 654321";

    /**
     * The constant OTP_CACHE_VERIFY_EMAIL_SUCESS.
     */
    public static final String OTP_CACHE_VERIFY_EMAIL_SUCESS= "OTP VERIFY SUCCESSFULLY and Email Added Successfully";

    /**
     * The constant CONSENT_SAVED_SUCCESS.
     */
    public static final String CONSENT_SAVED_SUCCESS="Consent Saved Successfully";

    /**
     * The constant CONSENT_NOT_SAVED.
     */
    public static final String CONSENT_NOT_SAVED="Consent Not Saved";

    /**
     * The constant ORGANIZATION_TYPES_FETCHED_SUCCESS.
     */
    public static final String ORGANIZATION_TYPES_FETCHED_SUCCESS="Organization Types fetched successfully";

    /**
     * The constant HEIRARCHY_FETCHED_SUCCESS.
     */
    public static final String HEIRARCHY_FETCHED_SUCCESS="Heirarchy Organisation fetched successfully";

    /**
     * The constant WORK_EXPERIENCE_CREATED_SUCCESS.
     */
    public static final String  WORK_EXPERIENCE_CREATED_SUCCESS="Work Experience created successfully";

    /**
     * The constant WORK_EXPERIENCE_GET_SUCCESS.
     */
    public static final String WORK_EXPERIENCE_GET_SUCCESS="Work Experience get successfully";

    /**
     * The constant MANUFACTURING_ADDRESS_GET_SUCCESS.
     */
    public static final String MANUFACTURING_ADDRESS_GET_SUCCESS ="Manufacturing Address get successfully";

    /**
     * The constant MANUFACTURING_ADDRESS_SAVE_SUCCESS.
     */
    public static final String MANUFACTURING_ADDRESS_SAVE_SUCCESS ="Manufacturing Address Save successfully";

    /**
     * The constant MANUFACTURING_ADDRESS_DELETE_SUCCESS.
     */
    public static final String MANUFACTURING_ADDRESS_DELETE_SUCCESS="Manufacturing address deleted successfully";

    /**
     * The constant MANUFACTURING_ADDRESS_UPDATE_SUCCESS.
     */
    public static final String MANUFACTURING_ADDRESS_UPDATE_SUCCESS="Manufacturing address updated successfully";

    /**
     * The constant ADDITIONAL_DEBARRED_QUESTION_SUCCESS.
     */
    public static final String ADDITIONAL_DEBARRED_QUESTION_SUCCESS="Additional Debarred Question successfully";

    /**
     * The constant DOCUMENT_ADDED_SUCCESS.
     */
    public static final String DOCUMENT_ADDED_SUCCESS="Document added successfully";

    /**
     * The constant DOCUMENT_DELETE_SUCCESS.
     */
    public static final String DOCUMENT_DELETE_SUCCESS="Document deleted successfully";

    /**
     * The constant DOCUMENT_FETCHED_SUCCESS.
     */
    public static final String  DOCUMENT_FETCHED_SUCCESS="Document Fetched Successfully";

    /**
     * The constant CRITERIA_FETCHED_SUCCESS.
     */
    public static final String CRITERIA_FETCHED_SUCCESS="Criteria fetched successfully";

    /**
     * The constant DELETED_VENDOR_ASSESSMENT.
     */
    public static final String DELETED_VENDOR_ASSESSMENT = "Vendor assessment deleted successfully";

    /**
     * The constant Field_NC_SUCCESS.
     */
    public static final String Field_NC_SUCCESS="Fields with open non-compliance retrieved successfully";

    /**
     * The constant AUTHORIZING_STATUS_SUCCESS.
     */
    public static final String AUTHORIZING_STATUS_SUCCESS="You Can Apply Authorizing OEM OSP Details";

    /**
     * The constant AUTHORIZING_STATUS_FAILED.
     */
    public static final String AUTHORIZING_STATUS_FAILED="You Cannot Apply Authorizing OEM OSP Details";

    /**
     * The constant INVALID_GSTIN.
     */
    public static final String INVALID_GSTIN = "Invalid GSTIN";

    public static final String MESSAGE ="message" ;
    public static final String DATA = "data";
    public static final Object CATEGORIES_NOT_AVAILABLE = "No categories provided.";
    public static final Object SIMILAR_CATEGORIES_FOUND = "\"In addition to your selected categories, these similar categories will also be considered for assessment.\"";
    public static final String WORK_EXPERIENCE_NOT_FOUND_MESSAGE = "Work Experience Not Found";
    public static final String WORK_EXPERIENCE_DELETED_MESSAGE = "Work Experience Deleted Successfully";
    public static final String WORK_EXPERIENCE_CATEGORIES_MAPPED_MESSAGE = "Work Experience Categories Mapped Successfully";


    public static final List<String[]> DEFAULT_QUESTIONS = List.of(
            new String[]{"Do you have affiliation certificate", "boolean", "Please provide your response", "Affliation Certificate"},
            new String[]{"Do you have any License documents", "boolean", "Please provide your response", "License Documents"},
            new String[]{"Do you have any Experience other documents", "boolean", "Please provide your response", "Experience Documents"},
            new String[]{"Are you registered under the Performance Linked Incentive(PLI) scheme?", "boolean", "Please provide your response", "PLI Scheme Registration"}
    );

    public static final String CATEGORY_ADD_SUCCESS = "Categories added successfully!";
    public static final String CATEGORY_ALREADY_EXISTS = "Category already exists.";
    public static final String CATEGORY_ADD_FAILED = "Failed to add categories.";
    public static final String VALIDATION_ERROR = "Validation Error";
    public static final String SUBCATEGORY_MAP_SUCCESS = "Subcategories mapped successfully!";
    public static final String SUBCATEGORY_MAP_FAILED = "Failed to map subcategories.";
    public static final String CATEGORIES_FETCH_SUCCESS = "Categories fetched successfully!"; // New constant
    public static final String CATEGORIES_FETCH_FAILED = "Failed to fetch categories."; // New constant


}

