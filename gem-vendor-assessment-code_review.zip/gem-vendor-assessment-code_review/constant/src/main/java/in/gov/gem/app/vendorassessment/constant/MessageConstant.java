
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.constant;

/**
 * The type Message constant.
 */
public class MessageConstant {

    /**
     * The constant Lookup_NOT_FOUND.
     */
    public static final String Lookup_NOT_FOUND = "E-TR-BV-I-0400001";


    /**
     * The constant SELLER_PROFILE_NOT_COMPLETE.
     */
    public static final String SELLER_PROFILE_NOT_COMPLETE = "E-VA-BV-I-4000001";

    /**
     * The constant SELLER_PROFILE_NOT_FOUND.
     */
    public static final String SELLER_PROFILE_NOT_FOUND = "E-VA-BV-I-4000002";

    /**
     * The constant BANK_DETAILS_NOT_FOUND.
     */
    public static final String BANK_DETAILS_NOT_FOUND = "E-VA-BV-I-4000003";

    /**
     * The constant OFFICE_ADDRESS_NOT_FOUND.
     */
    public static final String OFFICE_ADDRESS_NOT_FOUND = "E-VA-BV-I-4000004";

    /**
     * The constant FINANCIAL_DETAILS_NOT_FOUND.
     */
    public static final String FINANCIAL_DETAILS_NOT_FOUND = "E-VA-BV-I-4000005";

    /**
     * The constant VENDOR_ASSESSMENT_MAPPING_ERROR.
     */
    public static final String VENDOR_ASSESSMENT_MAPPING_ERROR = "E-VA-BV-I-4000006";
    /**
     * The constant INVALID_PAGE_NUMBER.
     */
    public static final String INVALID_PAGE_NUMBER = "E-VA-BV-I-4000007";
    /**
     * The constant INVALID_PAGE_SIZE.
     */
    public static final String INVALID_PAGE_SIZE = "E-VA-BV-I-4000008";
    /**
     * The constant DATABASE_ACCESS_ERROR.
     */
    public static final String DATABASE_ACCESS_ERROR = "E-VA-TS-I-4000009";
    /**
     * The constant UNEXPECTED_ERROR.
     */
    public static final String UNEXPECTED_ERROR = "E-VA-BV-I-4000010";
    /**
     * The constant INVALID_VA_NUMBER.
     */
    public static final String INVALID_VA_NUMBER = "E-VA-TH-I-4000011";
    /**
     * The constant VENDOR_ASSESSMENT_NOT_FOUND.
     */
    public static final String VENDOR_ASSESSMENT_NOT_FOUND = "E-VA-TH-I-4000012";
    /**
     * The constant NO_SUCH_FIELD.
     */
    public static final String NO_SUCH_FIELD = "E-VA-TH-I-4000013";

    /**
     * The constant BODY_NULL_MSG.
     */
//-----------------------------------------------------------------------------------
    public static final String BODY_NULL_MSG = "E-VA-TH-I-4000021";

    /**
     * The constant OTP_SENT_SUCCESSFULLY.
     */
    public static final String OTP_SENT_SUCCESSFULLY = "S-VA-TH-I-4000022";
    /**
     * The constant INVALID_OTP.
     */
    public static final String INVALID_OTP = "E-VA-TH-I-4000023";

    /**
     * The constant VERIFIED_SUCCESSFULLY.
     */
    public static final String VERIFIED_SUCCESSFULLY = "S-VA-TH-I-4000024";
    /**
     * The constant EMAIL_ID_VERIFICATION.
     */
    public static final String EMAIL_ID_VERIFICATION = "E-VA-TH-I-4000025";

    /**
     * The constant MOBILE_VERIFICATION.
     */
    public static final String MOBILE_VERIFICATION="S-VA-TH-I-4000025";

    /**
     * The constant LOOKUP_NOT_FOUND.
     */
    public static final String LOOKUP_NOT_FOUND = "E-TR-BV-I-0400001" ;

    /**
     * The constant REQUIRED_KAFKA_PROPERTY_FALSE.
     */
    public static final String REQUIRED_KAFKA_PROPERTY_FALSE = "E-VA-BV-I-4000044";

    /**
     * The constant Unknown.
     */
    public static final String Unknown = "E-TR-BV-I-0400007";

    /**
     * The constant DOCUMENT_NOT_FOUND.
     */
    public static final String DOCUMENT_NOT_FOUND = "E-VA-BV-I-4000045";


    public static final String FILE_EMPTY = "E-VA-BV-I-4000046";
    public static final String QUESTION_ID_NOT_FOUND = "E-VA-BV-I-4000047";
    public static final String SELLER_TYPE_NOT_ELIGIBLE = "E-VA-BV-I-4000048";
    public static final String ATLEAST_ONE_CATEGORY_REQUIRED = "E-VA-BV-I-4000049";
    public static final String SOME_CATEGORIES_INVALID = "E-VA-BV-I-4000055";
    public static final String REQUIRED_DOCUMENTS_MISSING = "E-VA-BV-I-4000050";
    public static final String INVALID_DOCUMENT_TYPE = "E-VA-BV-I-4000051";
    public static final String CATEGORY_NOT_FOUND = "E-VA-BV-I-4000052";
    public static final String SELLER_NOT_OPTED_FOR_VA_BRAND_DASHBOARD = "E-VA-BV-I-4000053";
    public static final String DOCUMENT_ID_NOT_FOUND = "E-VA-BV-I-4000054";
    public static final String WORK_EXPERIENCE_ID_NOT_FOUND = "E-VA-BV-I-4000056";
    public static final String INVALID_CATEGORY_IDS = "E-VA-BV-I-4000057";
    public static final String INVALID_WORK_EXPERIENCE = "E-VA-BV-I-4000058";

    /**
     * The constant FILE_EMPTY.
     */

    public static final String CRITERIA_NOT_FOUND = "E-VA-BV-I-4000073";
    public static final String VA_RELAXATION_EXEMPTION_NOT_FOUND = "E-VA-BV-I-4000074";
    public static final String VA_MASTER_FK_NOT_FOUND = "E-VA-BV-I-4000075";
    public static final String VA_RELAXATION_EXEMPTION_ALREADY_INACTIVE = "E-VA-BV-I-4000076";
    public static final String VA_RELAXATION_EXEMPTION_DEACTIVATED = "E-VA-BV-I-4000077";
    public static final String DOCUMENT_ALREADY_INACTIVE = "E-VA-BV-I-4000078";

}
