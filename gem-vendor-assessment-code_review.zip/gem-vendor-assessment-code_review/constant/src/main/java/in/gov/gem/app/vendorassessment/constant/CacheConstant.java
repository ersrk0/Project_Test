
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */


package in.gov.gem.app.vendorassessment.constant;

/**
 * The type Cache constant.
 */
public class CacheConstant
{
  /**
   * Private constructor to prevent instantiation of the CacheConstant class.
   * Since this class contains only static constants, it should not be instantiated.
   *
   * @throws UnsupportedOperationException if this constructor is called, indicating
   * the class is not meant to be instantiated.
   */
  private CacheConstant() {
    throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
  }

  /**
   * The constant OTP_EMAIL.
   */
  public static final String OTP_EMAIL = "OTP_EMAIL";

  /**
   * The constant OTP_MOBILE.
   */
  public static final String OTP_MOBILE = "OTP_MOBILE";


  /**
   * The constant COLON.
   */
  public static final String COLON = ":";
}
