
/*
 * This source code and all associated intellectual property rights are
 * exclusively owned by Government e-Marketplace (GeM) and are protected
 * under applicable intellectual property laws. Any unauthorized use,
 * reproduction,modification, or distribution of this code, in whole or
 * in part,is strictly prohibited without the express prior written
 * consent of GeM.
 */

package in.gov.gem.app.vendorassessment.constant;

/**
 * The type Lookup constants.
 */
public final class LookupConstants
{
    /**
     * The constant nonComplianceStatus.
     */
     public static final String NON_COMPLIANCE_STATUS = "nonComplianceStatus";
    /**
     * The constant OPEN.
     */
    public static final String OPEN = "OPEN";
    /**
     * The constant UNDER_REVIEW.
     */
    public static final String UNDER_REVIEW = "UNDER_REVIEW";
    /**
     * The constant BOD_documents.
     */
    public static final String BOD_DOCUMENTS = "BOD documents";
    /**
     * The constant BOD_document.
     */
    public static final String BOD_DOCUMENT = "BOD document";
    /**
     * The constant documents.
     */
    public static final String DOCUMENTS = "documents";
    /**
     * The constant organisationDocument.
     */
    public static final String ORGANISATION_DOCUMENT ="organisationDocument";
    /**
     * The constant authorizingOemOspDocument.
     */
    public static final String AUTHORIZING_OEM_OSP_DOCUMENT = "authorizingOemOspDocument";
    /**
     * The constant contractManufacturerDocument.
     */
    public static final String CONTRACT_MANUFACTURER_DOCUMENT = "contractManufacturerDocument";
    /**
     * The constant verified.
     */
    public static final String VERIFIED = "verified";
    /**
     * The constant status.
     */
    public static final String STATUS = "status";
    /**
     * The constant Parent_BOD_documents.
     */
    public static final String PARENT_BOD_DOCUMENTS = "Parent BOD documents";
    /**
     * The constant parentDocument.
     */
    public static final String PARENT_DOCUMENT="parentDocument";

    /**
     * The constant UNKNOWN_STATUS.
     */
    public static final String UNKNOWN_STATUS = "Unknown Status";
    /**
     * The constant ENTITY_LOOKUP_NAME.
     */
    public static final String ENTITY_LOOKUP_NAME = "Entity";
    /**
     * The constant WORK_EXPERIENCE_DETAILS.
     */
    public static final String WORK_EXPERIENCE_DETAILS = "Work experience details";
    /**
     * The constant NON_COMPLIANCE_STATUS_LOOKUP_NAME.
     */
    public static final String NON_COMPLIANCE_STATUS_LOOKUP_NAME = "nonComplianceStatus";
    /**
     * The constant STATUS_OPEN.
     */
    public static final String STATUS_OPEN = "OPEN";
    /**
     * The constant STATUS_UNDER_REVIEW.
     */
    public static final String STATUS_UNDER_REVIEW = "UNDER_REVIEW";
    /**
     * The constant WORK_EXPERIENCE_DETAILS_ATTRIBUTE.
     */
    public static final String WORK_EXPERIENCE_DETAILS_ATTRIBUTE = "Work Experience Details Attribute";
    /**
     * The constant CLOSED.
     */
    public static final String CLOSED = "Closed";


}


