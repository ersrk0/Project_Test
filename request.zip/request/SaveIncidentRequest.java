package in.gov.gem.app.incident.dto.request;

import in.gov.gem.app.incident.dto.request.*;
import lombok.Data;
import java.util.List;

/**
 * Vendor-style request: all children are LISTS.
 * This provides the getters your Facade already calls:
 * getPreContract(), getPostContract(), getDocMaster(),
 * getAttachment(), getDebarment(), getStatusLog()
 */
@Data
public class SaveIncidentRequest {

  private IncidentMasterDTO master;

  // Children as lists (names match vendor & existing Facade calls)
  private List<PreContractIncidentDTO> preContract;
  private List<PostContractIncidentDTO> postContract;
  private List<IncidentDocMasterDTO> docMaster;
  private List<IncidentAttachmentDTO> attachment;
  private List<DebarmentDetailDTO> debarment;
  private List<IncidentStatusLogDTO> statusLog;
}
