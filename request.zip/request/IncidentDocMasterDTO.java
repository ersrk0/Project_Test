package in.gov.gem.app.incident.dto.request;
import lombok.Getter; import lombok.Setter;
import java.util.List;

@Getter @Setter
public class IncidentDocMasterDTO {
  private java.util.UUID docId;
  private java.util.List<IncidentAttachmentDTO> incidentAttachmentList;
}