package in.gov.gem.app.incident.dto.request;
import lombok.Getter; import lombok.Setter;
import java.util.List;

@Getter @Setter
public class PostContractIncidentDTO {
  private String auctionId;
  private String bidId;
  private String contractNo;
  private String invoiceId;
  private String traderId;
  private String panNo;
  private Boolean isDebarred;
  private java.util.List<DebarmentDetailDTO> debarmentList;
}