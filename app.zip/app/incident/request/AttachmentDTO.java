package in.gov.gem.app.incident.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class AttachmentDTO {
    private UUID attachmentPk;          // PK
   // @NotNull
    private UUID incidentDocMasterPk;   // FK
   // @NotBlank
    private String fileName;
    @NotBlank
    private String fileTypeLookup;
    private MultipartFile filePath;
    private Long fileSize;
    @NotBlank
    private String uploadedByTypeLookup;
    @NotBlank
    private String uploadedById;
    private String statusLookup;
}