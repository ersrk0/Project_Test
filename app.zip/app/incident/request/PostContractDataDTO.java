package in.gov.gem.app.incident.request;

import in.gov.gem.app.incident.request.DebarmentDetailDTO;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class PostContractDataDTO {
    private UUID postContractPk;  // PK
    @NotNull
    private UUID incidentPk;      // FK
    private String auctionId;
    private String bidId;
    private String orderId;
    private String productId;
    private String contractNo;
    private String invoiceId;
    private String panNo;
    @NotNull
    private Boolean isDebarred;
    @Valid
    private List<DebarmentDetailDTO> debarmentDetail;
}