package in.gov.gem.app.incident.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Date;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class DebarmentDetailDTO {
    private UUID debarmentPk;       // PK
    @NotNull
    private UUID postContractPk;    // FK
    @NotBlank
    private String debarmentClauseLookup;
    @NotBlank
    private Date debarmentStartDate;
    @NotBlank
    private Date debarmentEndDate;
    @NotBlank
    private String competentAuthorityName;
    @NotBlank
    private String competentAuthorityDesignation;
}