package in.gov.gem.app.incident.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class DebarmentDetailResponseDTO {
    private UUID debarmentPk;        // PK
    private UUID postContractPk;     // FK
    private String debarmentClauseLookup;
    private Date debarmentStartDate;
    private Date debarmentEndDate;
    private String competentAuthorityName;
    private String competentAuthorityDesignation;
}