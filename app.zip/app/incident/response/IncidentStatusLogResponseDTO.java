package in.gov.gem.app.incident.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class IncidentStatusLogResponseDTO {
    private UUID statusLogPk;      // PK
    private UUID incidentPk;       // FK
    private String actionTypeLookup;
    private String previousStatusLookup;
    private String currentStatusLookup;
    private String actionByTypeLookup;
    private String actionById;
    private String remarks;
}
