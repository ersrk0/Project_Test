package in.gov.gem.app.incident.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.ZonedDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class APIResponse<T> {
    private String status;
    private int httpStatus;
    private String message;
    private String msId;
    private T data;
    private ZonedDateTime timestamp;
}