package in.gov.gem.app.incident.response;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class ErrorDetailsDTO {
    private String errorCategory;
    private String errorSeverity;
    private String errorCode;
    private String errorDate;
    private String errorId;
    private Map<String, String> validationErrors;
}