package in.gov.gem.app.incident.response;

import lombok.Data;
import org.springframework.core.io.ByteArrayResource;

@Data
public class DocumentDownloadResponse {
    private ByteArrayResource byteArrayResource;
}

