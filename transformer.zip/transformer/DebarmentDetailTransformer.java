package in.gov.gem.app.incident.transformer;
import in.gov.gem.app.incident.domain.dto.DebarmentDetailDTO;
import in.gov.gem.app.incident.domain.entity.DebarmentDetailEntity;
import org.springframework.stereotype.Component;
import java.util.UUID;
@Component
public class DebarmentDetailTransformer {
  public DebarmentDetailEntity toEntity(DebarmentDetailDTO d, Long postPk){
    DebarmentDetailEntity e = new DebarmentDetailEntity();
    e.setDebarmentId(UUID.randomUUID());
    e.setPostContractIncidentFk(postPk);
    e.setDebarmentClauseLookup(d.getDebarmentClauseLookup());
    e.setDebarmentStartDate(d.getDebarmentStartDate());
    e.setDebarmentEndDate(d.getDebarmentEndDate());
    e.setCompetentAuthorityName(d.getCompetentAuthorityName());
    e.setCompetentAuthorityDesignation(d.getCompetentAuthorityDesignation());
    return e;
  }
  public DebarmentDetailDTO toDto(DebarmentDetailEntity e){
    DebarmentDetailDTO d = new DebarmentDetailDTO();
    d.setDebarmentClauseLookup(e.getDebarmentClauseLookup());
    d.setDebarmentStartDate(e.getDebarmentStartDate());
    d.setDebarmentEndDate(e.getDebarmentEndDate());
    d.setCompetentAuthorityName(e.getCompetentAuthorityName());
    d.setCompetentAuthorityDesignation(e.getCompetentAuthorityDesignation());
    return d;
  }
}
