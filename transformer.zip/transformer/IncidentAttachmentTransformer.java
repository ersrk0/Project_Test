package in.gov.gem.app.incident.transformer;
import in.gov.gem.app.incident.domain.dto.IncidentAttachmentDTO;
import in.gov.gem.app.incident.domain.entity.IncidentAttachmentEntity;
import org.springframework.stereotype.Component;
@Component
public class IncidentAttachmentTransformer {
  public IncidentAttachmentEntity toEntity(IncidentAttachmentDTO d, Long docMasterPk){
    IncidentAttachmentEntity e = new IncidentAttachmentEntity();
    e.setIncidentDocMasterFk(docMasterPk);
    e.setFileName(d.getFileName());
    e.setFileTypeLookup(d.getFileTypeLookup());
    e.setFilePath(d.getFilePath());
    e.setFileSize(d.getFileSize());
    return e;
  }
  public IncidentAttachmentDTO toDto(IncidentAttachmentEntity e){
    IncidentAttachmentDTO d = new IncidentAttachmentDTO();
    d.setFileName(e.getFileName());
    d.setFileTypeLookup(e.getFileTypeLookup());
    d.setFilePath(e.getFilePath());
    d.setFileSize(e.getFileSize());
    return d;
  }
}
